class AllActionTypes {
    //for loader
    static LOADER_STATE_TRUE = 'LOADER_STATE_TRUE';
    static LOADER_STATE_FALSE = 'LOADER_STATE_FALSE';
    static HANDLE_LEFT = 'HANDLE_LEFT';
    static ACTIVE_LINK = 'ACTIVE_LINK';
	static CLEAR_DATA = 'CLEAR_DATA';								 
	static ROLE_PERMISSION = 'ROLE_PERMISSION';								 
	static SELECTED_TAB_NAME = 'SELECTED_TAB_NAME';									 
}
export default AllActionTypes;