import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { FileDrop } from 'react-file-drop';
import ReactTooltip from 'react-tooltip';

class MultipleFileUpload extends Component {
    constructor(props) {
        super(props);

    }

    docNameUi = () => {

        const { documentObject, removeDoc } = this.props;
        //console.log("documentObject docNameUi==========", documentObject)
        let uiArry = []
        if (documentObject.length > 0) {
            documentObject.map((value, i) => {
                uiArry.push(
                    <div key={i} className="docNameUiRow">
                        <div className="file_name_inner_box file_name_inner_box_local" data-tip={value.file_name}><span className="file_name_length">{value.file_name}</span><span className="file_close_icon" onClick={() => { removeDoc(i) }}><svg width="10" height="10" viewBox="0 0 22 22" fill="none"><path d="M21 1L1 21M1 1L21 21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path></svg></span></div>
                        <ReactTooltip place="bottom" />
                    </div>
                )
            })
        }
        return uiArry;

    }

    render() {
        const { t, submit, documentObjName, onChange, onDrop, documentError, submitButtonShow, filesError, documentObject } = this.props;
        //console.log("documentObject=======", documentObject)
        return (
            <>
                <div className="modalinnerbody">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="filedragdropinner">
                                <FileDrop onDrop={(files, event) => { onDrop(files, event) }}>
                                    <img src={require('../../Utility/Public/images/filedownicon.png')} />
                                    <p className="droplabel">{documentObjName == t('choosefile') ? t('dragdocument') : documentObjName}</p>
                                </FileDrop>
                            </div>
                            <div className="docError">{documentError}</div>
                        </div>
                        <div className="col-md-6">
                            <div className="uploadfiledoc">
                                <label className="orlabel">{t('or')} :</label>
                                <div className="file_name_property">
                                    <label className="custom-file-upload">
                                        <span>
                                            {documentObjName}
                                        </span>
                                        <input type="file" onChange={onChange} />
                                    </label>
                                </div>
                                {documentObject.length > 0 && documentObject[0].file_name && documentObject[0].file_obj ?
                                    <div className="uploadeddocRow">
                                        {this.docNameUi()}
                                    </div>
                                    : null}
                            </div>
                        </div>
                        <div className="col-md-12 errorClass error_div">{filesError}</div>
                        <div className="clearfix"></div>
                        {submitButtonShow ? <div className="col-md-12 modfooterbtn">
                            <button type="button" onClick={submit} className="savebtn">{t('Ajouter')}</button>
                        </div> : null}
                    </div>
                </div>
                <ReactTooltip place="bottom" />
            </>
        );
    }
}

MultipleFileUpload.defaultProps = {
    submitButtonShow: true,
    //filesError: ""

}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})(withTranslation()(MultipleFileUpload)));