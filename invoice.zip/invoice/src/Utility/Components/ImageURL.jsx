import React, { Component } from 'react';

const ImageURL = {
    loginpage:{
        loginLogo: require('../Public/images/logo-new.png'),
    },
    commonModule:{
        mettletechlogoWhite: require('../Public/images/mettletech-logo.png'),
        mettletechlogoWhiteBottom: require('../Public/images/mettletech-logo2.png'),
    },
}
export default ImageURL;