import React, { Component } from 'react';
import CustomInput from '../Components/CustomInput';
import AutosuggestComponent from '../Components/AutosuggestComponent';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';


class BankDetailsComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }

    }

    bankDetailsUi = () => {
        let { bankDetails, removeAdditionalBankDetailsDisplay } = this.props;
        console.log("this.props.countryList", this.props.countryList)

        let uiArray = []
        if (bankDetails.length > 0) {
            bankDetails.map((value, i) => {
                uiArray.push(
                    <div className="bankDetailsBox" key={i}>
                        <div className="col-md-12">
                            <CustomInput
                                parentClassName="input_field_inner required"
                                labelName="Account No."
                                errorLabel={this.props.bankDetailsError[i].account_no}
                                name="account_no"
                                type="text"
                                value={value.account_no}
                                labelPresent={true}
                                onChange={(e) => this.props.handelChangeForBankDetails(e, "account_no", i)}
                                maxlength={16}

                            />
                        </div>
                        <div className="col-md-12">
                            <div className="row">
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner required"
                                        labelName="Bank Name"
                                        errorLabel={this.props.bankDetailsError[i].bank_name}
                                        name="bank_name"
                                        type="text"
                                        value={value.bank_name}
                                        labelPresent={true}
                                        onChange={(e) => this.props.handelChangeForBankDetails(e, "bank_name", i)}
                                    />
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner required"
                                        labelName="Bank address"
                                        errorLabel={this.props.bankDetailsError[i].bank_address}
                                        name="bank_address"
                                        type="text"
                                        value={value.bank_address}
                                        labelPresent={true}
                                        onChange={(e) => this.props.handelChangeForBankDetails(e, "bank_address", i)}

                                    />
                                </div>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="dropdowninnerbox required">
                                        <label>Bank country</label>
                                        <AutosuggestComponent
                                            handleOnChange={(e) => this.props.handelChangeForBankDetails(e, "bank_country", i)}
                                            options={this.props.countryList}
                                            selectedValue={value.bank_country}
                                            name=''
                                            isMulti={false}
                                            placeholder=""
                                            isDisabled={false}
                                            isSearchable={true}
                                        />
                                        <div className="col-md-12 errorClass error_div">{this.props.bankDetailsError[i].bank_country}</div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner required"
                                        labelName="IFSC code"
                                        errorLabel={this.props.bankDetailsError[i].ifsc_code}
                                        name="ifsc_code"
                                        type="text"
                                        value={value.ifsc_code}
                                        labelPresent={true}
                                        onChange={(e) => this.props.handelChangeForBankDetails(e, "ifsc_code", i)}
                                    //maxlength={11}
                                    />
                                </div>
                            </div>
                        </div>
                        {removeAdditionalBankDetailsDisplay ?
                            <>
                                {this.props.bankDetails.length != 1 ?
                                    <div className='trash_icon_btn' onClick={this.props.removeAdditionalBankDetails.bind(this, i, "additional_bank_remove")}><i className="fa fa-trash" aria-hidden="true"></i></div>
                                    : null}
                            </>
                        : null}
                    </div>
                )
            })
        }
        return uiArray;
    }



    render() {
        const { addInputProfileImageChanged, addprofileImageSelected, steponehide, t, fromData, bankDetails, bankDetailsError } = this.props;
        // const { addUserImageChanged, addUserImageSelected, addUserFromData, addUserFromDataError, addUserImageError, orgDataEditFlag, userDataEditFlag, imageEditFrom, addUserInfoFromData, addUserInfoFromDataError, fromDataBudget, fromDataError, disabledEmail } = this.props;
        //console.log("fromData===========", fromData)
        //console.log("disabledEmail===========", disabledEmail)
        //console.log("fromData===========", this.props.fromData)
        ///console.log("bankDetails===========", bankDetails)

        return (
            <div className="bankdetailsmodalinnerbody">
                <div className="banckDetailsBtn">
                    <button type="button" class="savebtn" onClick={() => this.props.handelClickBankAdd()}>+ Add</button>
                </div>
                {/* ////////////////////////////// */}
                <div className='bankDetailsContainer'>
                    {this.bankDetailsUi()}
                </div>

                {this.props.submitButton ?
                    <div className="bankSubmitBtn">
                        <button type="button" className="savebtn" onClick={() => this.props.bankDetailsSave()} >Submit</button>
                    </div>
                    : null}
                {/* ////////////////////////////// */}


            </div>
        );
    }
}

BankDetailsComponent.propTypes = {

}

BankDetailsComponent.defaultProps = {
    submitButton: false,
    removeAdditionalBankDetailsDisplay: false,
}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(BankDetailsComponent)));