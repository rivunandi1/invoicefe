import React, { Component } from 'react';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';

class GridActionContent extends Component {
    render() {
        const { t, styleWidth, styleHight, gridObjData, editButtonShow, deleteButtonShow, resultsButtonShow, graphButtonShow, addUserButtonShow, deleteUserButtonShow, sendCustomerButtonShow, sendCustomerButtonLabel, translationButtonShow, viewReportButtonShow, sendReportButtonShow, sendReportButtonLabel, deleteButtonLabel, sendPaynowButtonShow , paymentReceiptButtonShow, sendMailButtonShow, paynowButtonTitle} = this.props;
        //console.log("gridObjData ---", gridObjData )
        return (
            <div className={localStorage.getItem('selected_lan_direction') == "rtl" ? "actionableInnerBox gridaction_direction_rtl" : "actionableInnerBox gridaction_direction_ltr"} style={{ position: 'absolute', left: `${styleWidth}`, top: `${styleHight}` }} ref={this.props.codeOutsideClickRef}>
                <div className="actionableBtnCenter">
                    {editButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={() => { this.props.modefier(gridObjData, "") }}><span><i className="fa fa-pencil" ></i></span> {t('edit')}</button>
                    </div> : null}
                    {deleteButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.delete.bind(this, gridObjData)}><span><i className="fa fa-trash-o"></i></span>{deleteButtonLabel}</button>
                    </div> : null}
                    {sendCustomerButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.sendCustomer.bind(this, gridObjData)}><span><i className="fa fa-paper-plane-o"></i></span> {sendCustomerButtonLabel}</button>
                    </div> : null}
                    {resultsButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.results.bind(this, gridObjData)}><span><i className="fa fa-list-alt"></i></span> {t('results')}</button>
                    </div> : null}
                    {graphButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.graph.bind(this, gridObjData)}><span><i className="fa fa-bar-chart"></i></span> {t('showGraph')}</button>
                    </div> : null}
                    {addUserButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.addUser.bind(this, gridObjData)}><span><i className="fa fa-plus"></i></span> {t('addUser')}</button>
                    </div> : null}
                    {deleteUserButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.deleteUser.bind(this, gridObjData)}><span><i className="fa fa-trash-o"></i></span> {t('deleteUser')}</button>
                    </div> : null}
                    {translationButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.translation.bind(this, gridObjData)}><span><i className="fa fa-language"></i></span> {t('translation')}</button>
                    </div> : null}
                    {viewReportButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.viewReport.bind(this, gridObjData)}><span><i className="fa fa-eye"></i></span> {t('ViewReport')}</button>
                    </div> : null}
                    {sendReportButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.sendCustomer.bind(this, gridObjData)}><span><i className="fa fa-paper-plane-o"></i></span> {sendReportButtonLabel}</button>
                    </div> : null}
                    {sendPaynowButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.sendPaynow.bind(this, gridObjData)}><span><i className="fa fa-paper-plane-o"></i></span> {paynowButtonTitle} </button>
                    </div> : null}
                    {paymentReceiptButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.paymentReceipt.bind(this, gridObjData)}><span><i className="fa fa-money"></i></span> Payment Receipt </button>
                    </div> : null}
                    {sendMailButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.sendmail.bind(this, gridObjData)}><span><i class="fa fa-envelope" aria-hidden="true"></i></span> Send Mail </button>
                    </div> : null}
                </div>
            </div>
        );
    }
}
GridActionContent.defaultProps = {
    editButtonShow: true,
    deleteButtonShow: true,
    resultsButtonShow: false,
    graphButtonShow: false,
    addUserButtonShow: false,
    deleteUserButtonShow: false,
    sendCustomerButtonShow: false,
    sendCustomerButtonLabel: "",
    translationButtonShow: false,
    viewReportButtonShow: false,
    sendReportButtonShow: false,
    sendReportButtonLabel: "",
    deleteButtonLabel:"Delete",
    sendPaynowButtonShow: false,
    paymentReceiptButtonShow: false,
    paynowButtonTitle: "Pay now",
}
const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(GridActionContent)));