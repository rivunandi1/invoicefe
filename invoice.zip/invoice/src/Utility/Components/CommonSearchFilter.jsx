import React, { Component, useState, useEffect } from 'react';
import CustomInput from './CustomInput';
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import moment from 'moment';
import AutosuggestComponent from './AutosuggestComponent';
//import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import Overlay from 'react-bootstrap/Overlay';

function CommonSearchFilter(props) {
    const { handleSearchBar, searchValue, clearSearchValue, searchPlaceHolder, searchInputFiledDispaly, searchDateRangeDispaly, dateRangeDateValue, formatDateRangeInput, handleChangeDateRange, filterDate, statusPlaceholder, amountFilterDisplay, handleChangeAmountFilterFormData, searchAmountPlaceHolder, handleAmountSearchBar, searchInputAmountValue, clearSearchAmountValue, searchAmountOnclick, clearDateRangeFromToDateFunction } = props
    return (
        <>
            {searchInputFiledDispaly ?
                <div className="pageinnersearch">
                    <button type="button" className="btn btn-link search_btn_addon"><i className="fa fa-search"></i></button>
                    <CustomInput
                        parentClassName="comment_input_field"
                        name="srchBox"
                        type="text"
                        placeholder={searchPlaceHolder}
                        onChange={handleSearchBar.bind(this)}
                        value={searchValue}
                    />
                    {
                        searchValue != "" ?
                            <button type="button" className="btn btn-link dropclosebtn" onClick={clearSearchValue}>
                                <img src={require('./../Public/images/dropcloseicon.png')} className="searchClearIcon" />
                            </button>
                            : null}
                </div>
                : null}
            {searchDateRangeDispaly ?
                <div className="dropdownbox datepickerDateRange">
                    <div className="datepickerinnerbox justdefinedatepicker">
                        <DatePicker
                            value={filterDate}
                            onChange={(e) => { handleChangeDateRange(e, "dateRangeDate") }}
                            formatInputText={formatDateRangeInput}
                            inputPlaceholder="Select Date"
                            shouldHighlightWeekends
                            //locale={Utility.customDatePicker()} // custom locale object
                            //minimumDate={minimumJustDefineDate}
                            colorPrimary="#0fbcf9" // added this
                            colorPrimaryLight="rgba(75, 207, 250, 0.4)" // and this
                        />
                        {filterDate.from != null && filterDate.from != "" && filterDate.to != null && filterDate.to != "" ?
                            <button type='button' className='dateclearbutton' onClick={clearDateRangeFromToDateFunction}>
                                <img src={require('./../Public/images/dropcloseicon.png')} className="dateClearIcon" />
                            </button>
                        : null}

                    </div>
                </div>
                : null}


            {props.paymentstatusDisplay ?
                <div className="dropdownbox enterprisedrop statusFilterDrop">
                    <div className="dropdowninnerbox">
                        <AutosuggestComponent
                            options={props.paymentStatusList}
                            selectedValue={props.selectedPaymentStatus}
                            handleOnChange={(e) => { props.handleSelectedPaymentStatus(e) }}
                            name=""
                            isMulti={false}
                            placeholder={statusPlaceholder}
                            isClearable={Object.keys(props.selectedPaymentStatus).length > 0 ? true : false}
                            closeButton={true}
                            menuHeader={statusPlaceholder}
                            isSearchable={true}
                        />
                    </div>
                </div>
                : null}

            {amountFilterDisplay ?
                <>
                    <Overlay
                        show={props.show}
                        target={props.target}
                        placement="bottom"
                    >
                        <Popover className="popover_action_inner popover_action_inner_status">
                            <Popover.Content>
                                <div className="popover_action_row">
                                    <div className="amountFilterRadiobox">
                                        <label className="custom-radio-container">Less than <span className='symbolIcon'>≤</span>
                                            <input type="radio" name="less_greater_amount" value="less_amount" onChange={(e) => handleChangeAmountFilterFormData(e, "less_amount")} checked={props.amountLessOrGreterFormData.less_amount ? true : false} />
                                            <span className="checkmark"></span>
                                        </label>
                                        <label className="custom-radio-container">Greater than <span className='symbolIcon'>≥</span>
                                            <input type="radio" name="less_greater_amount" value="greater_amount" onChange={(e) => handleChangeAmountFilterFormData(e, "greater_amount")} checked={props.amountLessOrGreterFormData.greater_amount ? true : false} />
                                            <span className="checkmark"></span>
                                        </label>
                                    </div>
                                    {props.amountLessOrGreterFormData.less_amount || props.amountLessOrGreterFormData.greater_amount ?
                                        <div className="filterAmountInput">
                                            <button type="button" className="btn btn-link search_btn_addon"><i className="fa fa-search"></i></button>
                                            <CustomInput
                                                parentClassName="comment_input_field"
                                                name="amountSrchBox"
                                                type="text"
                                                placeholder={searchAmountPlaceHolder}
                                                onChange={handleAmountSearchBar.bind(this)}
                                                value={searchInputAmountValue}
                                            />
                                            {
                                                searchInputAmountValue != "" ?
                                                    <button type="button" className="btn btn-link dropclosebtn" onClick={clearSearchAmountValue}>
                                                        <img src={require('./../Public/images/dropcloseicon.png')} className="searchClearIcon" />
                                                    </button>
                                                    : null}
                                            <div className="btnInner"><button onClick={searchAmountOnclick} className="amountSearchBtn">Search</button>
                                            </div>
                                        </div>
                                        : null}
                                </div>
                            </Popover.Content>
                        </Popover>
                    </Overlay>

                    <div className="filterAmountDropdown" onClick={props.handleClick}>Search by amount <i className="fa fa-angle-down" aria-hidden="true"></i></div>
                </>
                : null}

        </>
    )
}

CommonSearchFilter.defaultProps = {
    searchPlaceHolder: "Search",
    searchInputFiledDispaly: false,
    searchDateRangeDispaly: false,
    paymentstatusDisplay: false,
    statusPlaceholder: "Select",
    amountFilterDisplay: false,
    searchAmountPlaceHolder: "Enter amount"
}

export default CommonSearchFilter