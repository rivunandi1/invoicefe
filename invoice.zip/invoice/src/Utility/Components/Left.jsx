import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Nav, Accordion } from "react-bootstrap";
import { handleActiveLink, handleLeft } from '../../Actions/AllAction'
import ImageURL from '../../Utility/Components/ImageURL';
class Left extends Component {
	constructor(props) {
		super(props);
		this.handleBar = this.handleBar.bind(this);
		this.state = {
			toggleType: "",
			activeClass: "",
			accName: "",
			subMenuIcon: ""
		}
	}

	toggle = (params, linkType) => {
		if (linkType === "") {
			this.setState({
				collapsed2: true,
				accName: ""
			}, () => {
				this.props.handleActiveLink(this.state.activeClass, this.state.accName)
			});
		}

		this.setState({
			activeClass: params
		}, () => {
			this.props.handleActiveLink(this.state.activeClass, this.state.accName)
		});
	}

	handleBar = () => {
		this.props.handleLeft(!this.props.leftbar)
	}


	leftUi = () => {
		const { activeClass, accName } = this.props.activeLink;
		const { userCredentials } = this.props;

		let arry = []

		//{ userCredentials.user_details && userCredentials.user_details.type == "admin" ?
		arry.push(
			<Nav.Item className={activeClass === 'profile_module' ? "ActiveClass" : "default"} onClick={this.toggle.bind(this, 'profile_module', '')} key={1}>
				<Link to={`/${localStorage.getItem('i18nextLng')}/userdashboard`} className="nav-link">
					<div className="imgcircle">
						<img src={require('../Public/images/cort.png')} className="sidebaricon" />
					</div>
				</Link>
			</Nav.Item>
		)
		//: null}

		arry.push(
			<Nav.Item className={activeClass === 'home_module' ? "ActiveClass" : "default"} onClick={this.toggle.bind(this, 'home_module', '')} key={0}>
				<Link to={`/${localStorage.getItem('i18nextLng')}/home`} className="nav-link">
					<div className="imgcircle">
						<img src={require('../Public/images/home.png')} className="sidebaricon" />
					</div>
				</Link>
			</Nav.Item>
		)

		{ userCredentials.user_details && userCredentials.user_details.type == "admin" ?
			arry.push(
				<Nav.Item className={activeClass === 'invoice_module' ? "ActiveClass" : "default "} onClick={this.toggle.bind(this, 'invoice_module', '')} key={2} >
					<Link to={`/${localStorage.getItem('i18nextLng')}/invoice`} className="nav-link">
						<div className="imgcircle"><img src={require('../Public/images/invoice.png')} className="sidebaricon" /></div>
					</Link>
				</Nav.Item>
			)
			: null
		}

		{ userCredentials.user_details && userCredentials.user_details.type == "admin" ?
			arry.push(
				<Nav.Item className={activeClass === 'report_module' ? "ActiveClass" : "default "} onClick={this.toggle.bind(this, 'report_module', '')} key={3} >
					<Link to={`/${localStorage.getItem('i18nextLng')}/report`} className="nav-link">
						<div className="imgcircle"><img src={require('../Public/images/reporticon.png')} className="sidebaricon" /></div>
					</Link>
				</Nav.Item>
			)
			: null
		}


		return arry;
	}


	render() {
		const { activeClass, accName } = this.props.activeLink;

		return (
			<aside className={this.props.leftbar ? 'left_bar_customize left-bar open hide-sm' : 'left_bar_customize left-bar closed hide-sm'}>
				<div className="webtitlelogo">
					<img src={ImageURL.commonModule.mettletechlogoWhite} className="sidebarimg" />
				</div>
				<Nav className="flex-column pt-2 side-nav">

					{this.leftUi()}

				</Nav>
				<div className="bottomlogo">
					<img src={ImageURL.commonModule.mettletechlogoWhiteBottom} className="sidebarimg" />
				</div>
			</aside>

		)

	}
}


function mapStateToProps(globalState) {
	return {
		leftbar: globalState.mainReducerData.leftbar,
		activeLink: globalState.mainReducerData.activeLink,
		userCredentials: globalState.LoginReducer.userCredentials,
	};
}

export default connect(mapStateToProps, { handleActiveLink, handleLeft })(Left);