import React, { Component } from 'react';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import Dropdown from 'react-bootstrap/Dropdown'
import Select, { components } from "react-select";

class LangaugeDropdown extends Component {
    render() {
        const { languageList, innerPageLanguage, lanOnSelect } = this.props;
        return (
            <>
                {innerPageLanguage  ?
                    <Select
                        value={this.props.selectedValue}
                        options={this.props.options}
                        onChange={this.props.handleOnChange}
                        placeholder={this.props.placeholder}
                        isDisabled={this.props.isDisabled}
                    /> :

                    <Dropdown onSelect={lanOnSelect.bind(this)}>
                        <Dropdown.Toggle variant="success" id="dropdown-basic" >
                            {localStorage.getItem('i18nextLng').toUpperCase()}
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            {languageList.map((data) => {
                                return (<Dropdown.Item key={data.id} eventKey={data.language_short_key}>{data.language_short_key.toUpperCase()}</Dropdown.Item>)
                            })}
                        </Dropdown.Menu>
                    </Dropdown>}
            </>
        );
    }
}

LangaugeDropdown.defaultProps = {
    innerPageLanguage: false
}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(LangaugeDropdown)));