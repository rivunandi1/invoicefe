const Config = ({
  //Production
  //baseURL: 'https://ix8qxftjzi.execute-api.eu-west-1.amazonaws.com/prod/',
  //Dev
  //baseURL: 'https://kxwojp892l.execute-api.eu-west-1.amazonaws.com/dev/',
  //Uat
  //baseURL: 'https://qv51b5ctvf.execute-api.eu-west-1.amazonaws.com/uat/',
  //ngrok
  baseURL: 'https://6727-116-206-201-225.in.ngrok.io/',
  extendedUrl: 'api/v1/',
  extendedUrlAuth: 'api/v1/',
  environment:'development',
  //environment:'production',
  thumbnailSize: {
    size_width: 200,
    size_height: 200
  },
  planningEditableBeforeCurrentDay: 45,
  pageDataLimit: 10,
  tdsPercentage:10
});

export default Config;