import React, { Component } from 'react';
import { Switch } from "react-router-dom";
import { createHashHistory } from 'history';
import Auth from "../Layouts/Auth";
import { Route } from "react-router-dom";

//login
import LoginRoute from "../Modules/Login/Routes/LoginRoute"

//InvoiceRoute
import InvoiceRoute from '../Modules/Invoice/Routes/InvoiceRoute';

//Home route
import HomeRoute from '../Modules/Home/Routes/HomeRoute';

//DashboardRoute 
import DashboardRoute from '../Modules/Dashboard/Routes/DashboardRoute';

//ReportRoute 
import ReportRoute from '../Modules/Report/Routes/ReportRoute';


class index extends Component {
  render() {
    const history = createHashHistory();
    return (

      <>

        {/*****************Login Module Start****************/}
        <LoginRoute />
        {/*****************Login Module End****************/}

        {/*****************DashboardPage Start****************/}
        <DashboardRoute allowedRoles={['app_admin']} />

        {/*****************DashboardPage End****************/}
        
        {/*****************Home Module start****************/}
        <HomeRoute allowedRoles={['app_admin']} />
        {/*****************Home Module end****************/}

        {/* ****************  Invoice Module***************** */}
        <InvoiceRoute allowedRoles={['app_admin']} />
        
        {/* ****************  Report Module***************** */}
        <ReportRoute allowedRoles={['app_admin']} />



      </>
    );
  }
}
export default index;
