import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { reportListingGet,exportCsvGet } from '../Model/ReportModel';
import Config from '../../../../../Utility/Config';

export const reportListing = (data) => {
    return get(`${Config.extendedUrl}report/invoice`, data).then((response) => {
        return reportListingGet(response)
    });
};

export const exportCsvapi = (data) => {
    return get(`${Config.extendedUrl}report/export`, data).then((response) => {
        return exportCsvGet(response)
    });
};