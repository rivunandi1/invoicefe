import React, { Component } from 'react';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../../Actions/AllAction';
import { setUserCredentials } from '../../../Login/Actions/LoginAction';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Table from 'react-bootstrap/Table';


import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import AutosuggestComponent from '../../../../Utility/Components/AutosuggestComponent';
import { reportListing, exportCsvapi } from '../../Components/Report/Controller/ReportController';
import moment from 'moment-timezone';





class ReportPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      reportSelectedTabName: "report",
      filterDate: {
        from: null,
        to: null
      },
      selectedcurrency: "",

      option: [
        { value: 'local', label: 'Local Currency' },
        { value: 'foreign', label: 'Foreign Currency' },
      ],

      invoiceReportData: {},
      invoiceReportDataforeign: []
    }
  }

  componentDidMount() {
    this.props.handleActiveLink("report_module", "");
    //this.permissionWiseTabSelected();
    this.invoiceReport()

  }

  invoiceReport = () => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = this.props;
    const { filterDate, selectedcurrency } = this.state;
    if (filterDate.from && filterDate.to && selectedcurrency != "") {
      loaderStateTrue();
      let data = {
        "start_date": filterDate.from ? moment(new Date(filterDate.from.year + "-" + filterDate.from.month + "-" + filterDate.from.day)).format('YYYY-MM-DD') : '',
        "end_date": filterDate.to ? moment(new Date(filterDate.to.year + "-" + filterDate.to.month + "-" + filterDate.to.day)).format('YYYY-MM-DD') : '',
        "currency": selectedcurrency.value
        // "attributes": gstArry

      }
      let filters = {
        "filters": data
      }
      reportListing(filters).then((response) => {

        if (response.success) {
          //formate report


          if (selectedcurrency?.value == "foreign") {
            this.setState({
              invoiceReportDataforeign: response.data
            })
          } else {

            let hash = {}
            if (response.data.length > 0) {
              response.data.map((value, idx) => {
                let keys = Object.keys(value)[0];
                hash[keys] = {}
                hash[keys]['customer'] = []
                hash[keys]['vendor'] = []
                let customerLength = value[keys].customer.length;
                let vendorLength = value[keys].vendor.length;
                let customerData = value[keys].customer;
                let vendorData = value[keys].vendor;
                if (customerLength > vendorLength) {
                  let entryObj = customerLength - vendorLength;
                  for (let i = 0; i < entryObj; i++) {
                    vendorData.push({})
                  }
                }
                if (customerLength < vendorLength) {
                  let entryObj2 = vendorLength - customerLength;
                  for (let i = 0; i < entryObj2; i++) {
                    customerData.push({})
                  }
                }
                hash[keys]['customer'] = customerData
                hash[keys]['vendor'] = vendorData

              })
            }
            this.setState({
              invoiceReportData: hash
            })

          }


        } else {
          Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
        }
        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    }

  }

  /*formatDateInput = () => {
    if (!paymentDate.year) return '';
    const Year = paymentDate.year.toString();
    const Month = paymentDate.month.toString().padStart(2, 0);
    const Day = paymentDate.day.toString().padStart(2, 0);
    return `${Day}/${Month}/${Year}`;
  };*/

  handleChangeEventForm = (e, name) => {
    if (name == "justDefineDate") {
      this.setState({
        filterDate: e
      }, () => {
        this.invoiceReport();
      })
    }
  }

  handleSelectedCurreancy = (e) => {
    if (e) {
      this.setState({
        selectedcurrency: e
      }, () => {
        this.invoiceReport();
      })
    } else {
      this.setState({
        selectedcurrency: ""
      }, () => {
        this.invoiceReport();
      })
    }
  }

  tableUi = () => {
    let { invoiceReportData, selectedcurrency, invoiceReportDataforeign } = this.state;
    //console.log("invoiceReportData====", invoiceReportData)
    let uiarray = []
    if (selectedcurrency?.value == "foreign") {
      invoiceReportDataforeign.map((val, idx) => {
        uiarray.push(<tr key={idx}>
          <td >{moment(val.payment_date).format("YYYY-MM-DD")}</td>
          <td className='customername'>{val?.customer_name}</td>
          <td>{val?.invoice_number}</td>

          <td style={{ textAlign: 'center' }}>{val?.conversion_amount && val.conversion_amount != "0" ? parseFloat(val.conversion_amount).toFixed(2) : ""}</td>

          <td style={{ textAlign: 'center' }}>{val?.amount_after_conversion && val.amount_after_conversion != "0" ? parseFloat(val.amount_after_conversion).toFixed(2) : ""}</td>

          <td style={{ textAlign: 'center' }}></td>
          <td style={{ textAlign: 'center' }}></td>

          {idx == 0 ?
            <td rowSpan={invoiceReportDataforeign.length}>&nbsp;</td>
            : null}


          <td className='customername'></td>


          <td style={{ textAlign: 'center' }}></td>
          <td style={{ textAlign: 'center' }}></td>
          <td style={{ textAlign: 'center' }}></td>
          <td style={{ textAlign: 'center' }}></td>


        </tr>)
      })
    } else {

      if (Object.keys(invoiceReportData).length > 0) {
        Object.keys(invoiceReportData).map((value, idx) => {
          uiarray.push(
            invoiceReportData[value].customer.map((reportData, reportIdx) => (
              <tr key={reportIdx}>
                <td >{value}</td>
                <td className='customername'>{reportData?.customer_name}</td>
                <td>{reportData?.invoice_number}</td>

                <>
                  <td style={{ textAlign: 'center' }}>{reportData && reportData.sgst_amount && reportData.sgst_amount != "0" ? parseFloat(reportData.sgst_amount).toFixed(2) : ""}</td>
                  <td style={{ textAlign: 'center' }}>{reportData && reportData.cgst_amount && reportData.cgst_amount != "0" ? parseFloat(reportData.cgst_amount).toFixed(2) : ""}</td>
                  <td style={{ textAlign: 'center' }}>{reportData && reportData.igst_amount && reportData.igst_amount != "0" ? parseFloat(reportData.igst_amount).toFixed(2) : ""}</td>
                  <td style={{ textAlign: 'center' }}>{reportData && reportData.total ? parseFloat(reportData.total).toFixed(2) : ""}</td>

                  {reportIdx == 0 ?
                    <td rowSpan={invoiceReportData[value].customer.length}>&nbsp;</td>
                    : null}


                  <td className='customername'>{invoiceReportData[value]?.vendor[reportIdx]?.cust_details?.name}</td>
                  <td>{invoiceReportData[value]?.vendor[reportIdx]?.invoice_number}</td>


                  <td style={{ textAlign: 'center' }}>{invoiceReportData[value]?.vendor[reportIdx]?.sgst_amount && invoiceReportData[value]?.vendor[reportIdx]?.sgst_amount != "0" ? parseFloat(invoiceReportData[value].vendor[reportIdx].sgst_amount).toFixed(2) : ""}</td>
                  <td style={{ textAlign: 'center' }}>{invoiceReportData[value]?.vendor[reportIdx]?.cgst_amount && invoiceReportData[value]?.vendor[reportIdx]?.cgst_amount != "0" ? parseFloat(invoiceReportData[value].vendor[reportIdx].cgst_amount).toFixed(2) : ""}</td>
                  <td style={{ textAlign: 'center' }}>{invoiceReportData[value]?.vendor[reportIdx]?.igst_amount && invoiceReportData[value]?.vendor[reportIdx]?.igst_amount != "0" ? parseFloat(invoiceReportData[value].vendor[reportIdx].igst_amount).toFixed(2) : ""}</td>
                  <td style={{ textAlign: 'center' }}>{invoiceReportData[value].vendor[reportIdx].total ? parseFloat(invoiceReportData[value].vendor[reportIdx].total).toFixed(2) : ""}</td>
                </>

              </tr>

            ))
          )

        })
      }
    }
    return uiarray;
  }

  totalUiForlocal = () => {
    let { invoiceReportData, selectedcurrency, invoiceReportDataforeign } = this.state;

    let totalSGST = 0;
    let totalCGST = 0;
    let totalIGST = 0;
    let totalAmount = 0;

    let vtotalSGST = 0;
    let vtotalCGST = 0;
    let vtotalIGST = 0;
    let vtotalAmount = 0;


    let uiArry = []
    if (Object.keys(invoiceReportData).length > 0) {
      Object.keys(invoiceReportData).map((value, idx) => {
        invoiceReportData[value].customer.map((reportData, reportIdx) => {

          if (reportData?.sgst_amount && reportData.sgst_amount != "") {
            totalSGST = totalSGST + parseFloat(reportData?.sgst_amount)
          }

          if (reportData?.cgst_amount && reportData.cgst_amount != "") {
            totalCGST = totalCGST + parseFloat(reportData?.cgst_amount)
          }

          if (reportData?.igst_amount && reportData.igst_amount != "") {
            totalIGST = totalIGST + parseFloat(reportData?.igst_amount)
          }

          if (reportData?.total && reportData.total != "") {
            totalAmount = totalAmount + parseFloat(reportData?.total)
          }
          //Vendor

          if (invoiceReportData[value]?.vendor[reportIdx]?.sgst_amount && invoiceReportData[value]?.vendor[reportIdx]?.sgst_amount != "0") {
            vtotalSGST = vtotalSGST + parseFloat(invoiceReportData[value]?.vendor[reportIdx]?.sgst_amount)
          }

          if (invoiceReportData[value]?.vendor[reportIdx]?.cgst_amount && invoiceReportData[value]?.vendor[reportIdx]?.cgst_amount != "0") {
            vtotalCGST = vtotalCGST + parseFloat(invoiceReportData[value]?.vendor[reportIdx]?.cgst_amount)
          }

          if (invoiceReportData[value]?.vendor[reportIdx]?.igst_amount && invoiceReportData[value]?.vendor[reportIdx]?.igst_amount != "0") {
            vtotalIGST = vtotalIGST + parseFloat(invoiceReportData[value]?.vendor[reportIdx]?.igst_amount)
          }

          if (invoiceReportData[value].vendor[reportIdx].total) {
            vtotalAmount = vtotalAmount + parseFloat(invoiceReportData[value].vendor[reportIdx].total)
          }

        })
      })
    }
    uiArry.push(
      <>
        <div style={{ width: '50px' }}>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">SGST</th>
                <th scope="col">CGST</th>
                <th scope="col">IGST</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th >{totalSGST.toFixed(2)}</th>
                <td>{totalSGST.toFixed(2)}</td>
                <td>{totalIGST.toFixed(2)}</td>
                <td>{totalAmount.toFixed(2)}</td>
              </tr>             
            </tbody>
          </table>
        </div>



        <div style={{ float: 'right' }}>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">SGST</th>
                <th scope="col">CGST</th>
                <th scope="col">IGST</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th >{vtotalSGST.toFixed(2)}</th>
                <td>{vtotalSGST.toFixed(2)}</td>
                <td>{vtotalIGST.toFixed(2)}</td>
                <td>{vtotalAmount.toFixed(2)}</td>
              </tr>             
            </tbody>
          </table>
        </div>



      </>
    )

    return uiArry;
  }

  totalUiForforeign = () => {
    let { invoiceReportData, selectedcurrency, invoiceReportDataforeign } = this.state;
    let uiarray = []
    let totalFGST = 0;
    let totalAmount = 0;
    invoiceReportDataforeign.map((val, idx) => {
      if (val?.conversion_amount && val.conversion_amount != "0") {
        totalFGST = totalFGST + parseFloat(val.conversion_amount);
      }
      if (val?.amount_after_conversion && val.amount_after_conversion != "0") {
        totalAmount = totalAmount + parseFloat(val.amount_after_conversion);
      }

    })

    uiarray.push(
      <>
        <div style={{ width: '50px' }}>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">FGST</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th >{totalFGST.toFixed(2)}</th>
                <td>{totalAmount.toFixed(2)}</td>
              </tr>             
            </tbody>
          </table>
        </div>


      </>
    )

    return uiarray;
  }

  formatDateInput = () => {
    if (!this.state.filterDate.to) return '';
    const fromDate = this.state.filterDate.from
    const fromYear = fromDate.year.toString();
    const fromMonth = fromDate.month.toString().padStart(2, 0);
    const fromDay = fromDate.day.toString().padStart(2, 0);

    const toDate = this.state.filterDate.to
    const toYear = toDate.year.toString();
    const toMonth = toDate.month.toString().padStart(2, 0);
    const toDay = toDate.day.toString().padStart(2, 0);

    return `${fromDay}/${fromMonth}/${fromYear} to ${toDay}/${toMonth}/${toYear}`;
  };


  exportCsv = () => {
    const { loaderStateTrue, loaderStateFalse } = this.props;

    const { filterDate, selectedcurrency } = this.state;

    loaderStateTrue();
    let data = {
      "start_date": filterDate.from ? moment(new Date(filterDate.from.year + "-" + filterDate.from.month + "-" + filterDate.from.day)).format('YYYY-MM-DD') : '',
      "end_date": filterDate.to ? moment(new Date(filterDate.to.year + "-" + filterDate.to.month + "-" + filterDate.to.day)).format('YYYY-MM-DD') : '',
      "currency": selectedcurrency.value
      // "attributes": gstArry

    }
    let filters = {
      "filters": data
    }

    exportCsvapi(filters).then((response) => {
      loaderStateFalse()
      const url = window.URL.createObjectURL(new Blob([response]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `report_${moment().format("DD_MM_YYYY hh:mm")}.csv`);
      link.click();
    }).catch((error) => {
      loaderStateFalse();
    });
  }

  render() {
    const { t } = this.props;
    return (
      <div className="gridcontainer reportPageContainer">
        <div className='totalworkercontent'>
          <div className='gridtopviews'>
            <div className='rowClass'>
              <div className="dropdownbox datepickerReportPage">
                <div className="datepickerinnerbox justdefinedatepicker">
                  <label>{t('Select Date')}</label>
                  <DatePicker
                    value={this.state.filterDate}
                    onChange={(e) => { this.handleChangeEventForm(e, "justDefineDate") }}
                    //formatInputText={this.formatDateInput}
                    inputPlaceholder="Select Date"
                    shouldHighlightWeekends
                    //locale={Utility.customDatePicker()} // custom locale object
                    //minimumDate={minimumJustDefineDate}
                    colorPrimary="#0fbcf9" // added this
                    colorPrimaryLight="rgba(75, 207, 250, 0.4)" // and this
                  />

                </div>
              </div>

              <div className="dropdownbox enterprisedrop gstType">
                <div className="dropdowninnerbox">
                  <label>Curreancy Type</label>
                  <AutosuggestComponent
                    //handleOnChange={this.props.handleChangeAlltravailleurSelected.bind(this, "Enterprise")}

                    options={this.state.option}
                    selectedValue={this.state.selectedcurrency}
                    handleOnChange={(e) => { this.handleSelectedCurreancy(e) }}
                    name="currencyType"
                    isMulti={false}
                    placeholder="Select"
                    labelName="Currency Type"
                  //isDisabled={this.props.roleId!=""?true:false}
                  //isSearchable={true}
                  //defaultMenuIsOpen={true}
                  />
                  {/* <div className="col-md-12 errorClass error_div">{props.errorFormData.company_name_errror}</div> */}
                </div>
              </div>


              {this.state.selectedcurrency?.value == "local" ?
                this.totalUiForlocal()
                : null}
              {this.state.selectedcurrency?.value == "foreign" ?
                this.totalUiForforeign()
                : null}


            </div>
          </div>

          {this.state.filterDate.from && this.state.filterDate.to && this.state.selectedcurrency != "" ?
            <div onClick={this.exportCsv}>Export</div>
            : null}

          <div className='tableTabSec'>
            <table striped bordered hover>
              <thead>

                <tr>
                  <th colSpan={8} className="customerPayment">Customer Payment</th>
                  <th>&nbsp;</th>
                  <th colSpan={6} className="vendorPayment">Vendor Payment</th>
                </tr>

              </thead>
              {this.state.selectedcurrency == "" || this.state.selectedcurrency?.value == 'local' ?
                <thead>
                  <tr>
                    <th>Date</th>
                    <th className='customername'>Customer</th>
                    <th>Bill No.</th>
                    <th style={{ textAlign: 'center' }}>SGST</th>
                    <th style={{ textAlign: 'center' }}>CGST</th>
                    <th style={{ textAlign: 'center' }}>IGST</th>
                    <th style={{ textAlign: 'center' }}>Amount</th>
                    <th>&nbsp;</th>
                    <th className='customername'>Customer</th>
                    <th>Bill No.</th>
                    <th style={{ textAlign: 'center' }}>SGST</th>
                    <th style={{ textAlign: 'center' }}>CGST</th>
                    <th style={{ textAlign: 'center' }}>IGST</th>
                    <th style={{ textAlign: 'center' }}>Amount</th>
                  </tr>
                </thead>
                :
                <thead>
                  <tr>
                    <th>Date</th>
                    <th className='customername'>Customer</th>
                    <th>Bill No.</th>
                    <th style={{ textAlign: 'center' }}>FCGST</th>
                    <th style={{ textAlign: 'center' }}>Amount</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th className='customername'>Customer</th>
                    <th>Bill No.</th>
                    <th style={{ textAlign: 'center' }}>SGST</th>
                    <th style={{ textAlign: 'center' }}>CGST</th>
                    <th style={{ textAlign: 'center' }}>IGST</th>
                    <th style={{ textAlign: 'center' }}>Amount</th>
                  </tr>
                </thead>
              }




              {this.tableUi()}




            </table>
          </div>



        </div>
        <>







        </>
      </div>
    )
  }
}

//export default ReportPage
const mapStateToProps = (globalState) => {
  return {
    userCredentials: globalState.LoginReducer.userCredentials,
  };
}
export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setUserCredentials })
  (withTranslation()(ReportPage)));


