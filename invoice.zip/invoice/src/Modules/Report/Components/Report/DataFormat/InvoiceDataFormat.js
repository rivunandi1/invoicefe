const lodash = require('lodash');
import moment from 'moment';
export const invoiceFormatingFormData = (formData, org_id, admin_id, admin_name, invoiceData, invoice_number_generation, additionalInputText, conversion_allowance_percentage) => {
    //console.log("invoice_number_generation++++====", invoice_number_generation)
    //console.log("formData++++====", formData)
    //console.log("org_id++++====", org_id)
    //console.log("admin_id++++====", admin_id)
    //console.log("admin_name++++====", admin_name)
    //console.log("invoiceData++++====", invoiceData)
    //console.log("additionalInputText++++====", additionalInputText)

    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        hash['org_id'] = org_id
        hash['invoice_number'] = invoice_number_generation.invoice1 + "/" + invoice_number_generation.invoice2 + "/" + invoice_number_generation.invoice3 + "/" + formData.invoice_number
        hash['admin_id'] = admin_id
        hash['cust_id'] = formData.company_name.value
        hash['admin_name'] = admin_name
        hash['additional_value'] = additionalInputText
        let invoiceDataArray = []
        invoiceData.map((obj, index) => {
            let invoice_hash = {}
            invoice_hash['sl_no'] = index + 1;
            invoice_hash['description'] = obj.description
            invoice_hash['quantity'] = obj.quantity
            invoice_hash['Rate'] = obj.rate
            invoice_hash['Price'] = obj.price
            invoiceDataArray.push(invoice_hash)
        })
        hash['items'] = invoiceDataArray
        hash['sgst_percentage'] = formData.sgst_percentage.toString()
        hash['cgst_percentage'] = formData.cgst_percentage.toString()
        hash['igst_percentage'] = formData.igst_percentage.toString()
        hash['sub_total'] = formData.sub_total.toString()
        hash['total'] = formData.total.toString()
        hash['conversion_allowance_percentage'] = conversion_allowance_percentage
        dataSet.push(hash)
        resolve(dataSet)
    })

    return promise;

};

export const paymentInvoiceFormatingFormData = (userCredentials, selectedData, conversionAmount, amountAfterConversion, paymentDate, paymentType) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        hash['invoice_number'] = selectedData?.data?.invoice_number
        hash['amount'] = selectedData?.data?.calculation?.total
        hash['currency'] = userCredentials?.user_details?.org_percentages?.currency
        hash['conversion_allowance_percentage'] = selectedData?.data?.calculation?.conversion_allowance_percentage
        hash['conversion_amount'] = conversionAmount
        hash['amount_after_conversion'] = amountAfterConversion.toString()
        hash['payment_date'] = moment(paymentDate).format('YYYY-MM-DD')
        if (paymentType.full_payment) {
            hash['payment_type'] = "Full payment"
        }
        if (paymentType.pertial_payment) {
            hash['payment_type'] = "Partial payment"
        }

        dataSet.push(hash)
        resolve(dataSet)
    })

    return promise;

};

export const previewModalDatasetFormat = (formData, invoice_number_generation, selectedCustomerData, invoiceData, additionalInputText, date, customer_login_name) => {
    let promise = new Promise((resolve, reject) => {
        console.log("1234")
        let previewModalDataset = []
        let preview_hash = {}
        preview_hash['invoice_number'] = invoice_number_generation.invoice1 + "/" + invoice_number_generation.invoice2 + "/" + invoice_number_generation.invoice3 + "/" + formData.invoice_number;
        preview_hash['date'] = date;
        preview_hash['customer_name'] = selectedCustomerData.name;
        preview_hash['gst_number'] =selectedCustomerData.gst_number;
        preview_hash['address'] = selectedCustomerData.address_line1 + "," +selectedCustomerData.address_line2 + "," + selectedCustomerData.city + "," + selectedCustomerData.country + "-" + selectedCustomerData.zip_code;
        invoiceData.map((obj, index) => {
            preview_hash['sl_no'] = index + 1;
            preview_hash['description'] = obj.description
            preview_hash['quantity'] = obj.quantity
            preview_hash['Rate'] = obj.rate
            preview_hash['Price'] = obj.price
        })
        preview_hash['sub_total'] = formData.sub_total;
        preview_hash['sgst_percentage'] = formData.sgst_percentage
        preview_hash['cgst_percentage'] = formData.cgst_percentage
        preview_hash['igst_percentage'] = formData.igst_percentage
        preview_hash['sgst'] = formData.sgst
        preview_hash['cgst'] = formData.cgst
        preview_hash['igst'] = formData.igst
        preview_hash['total'] = formData.total
        additionalInputText.map((obj, index) => {
            preview_hash['additional_text'] = additionalInputText.additional_text;
            preview_hash['additional_value'] = additionalInputText.additional_value;
        })
        preview_hash['gst_number'] = selectedCustomerData.Organisation.gst_number
        preview_hash['pan_number'] = selectedCustomerData.Organisation.pan_number
        preview_hash['gstn'] = selectedCustomerData.Organisation.gstn
        preview_hash['account_no'] = selectedCustomerData.Organisation.account_no
        preview_hash['org_address'] = selectedCustomerData.Organisation.address_line1 + "," + selectedCustomerData.Organisation.address_line2 + "," + selectedCustomerData.Organisation.city + "," + selectedCustomerData.Organisation.country + "-" + selectedCustomerData.zip_code;
        preview_hash['bank_name'] = selectedCustomerData.Organisation.bank_name;
        preview_hash['bank_address'] = selectedCustomerData.Organisation.bank_address;
        preview_hash['bank_country'] = selectedCustomerData.Organisation.bank_country;
        preview_hash['ifsc_code'] = selectedCustomerData.Organisation.ifsc_code;
        preview_hash['customer_login_name'] = customer_login_name
        previewModalDataset.push(preview_hash)
        resolve(previewModalDataset)
    })
    return promise;
}

const difference = (origObj, newObj) => {
    let changes = (newObj, origObj) => {
        let arrayIndexCounter = 0
        return lodash.transform(newObj, (result, value, key) => {
            if (!lodash.isEqual(value, origObj[key])) {
                let resultKey = lodash.isArray(origObj) ? arrayIndexCounter++ : key
                result[resultKey] = (lodash.isObject(value) && lodash.isObject(origObj[key])) ? changes(value, origObj[key]) : value
            }
        })
    }
    return changes(newObj, origObj)
}