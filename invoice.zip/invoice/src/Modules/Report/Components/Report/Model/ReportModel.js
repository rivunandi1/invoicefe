export const reportListingGet = (data) => {
    return data.data;
}
export const exportCsvGet = (data) => {
    return data.data;
}
