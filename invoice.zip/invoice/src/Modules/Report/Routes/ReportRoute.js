import React, { Component } from 'react'
import { createHashHistory } from 'history';
import { Switch } from "react-router-dom";
import { Route } from "react-router-dom";
import Default from "../../../Layouts/Default";
import Auth from "../../../Layouts/Auth";
import Report from '../Pages/Report';

function InvoiceRoute(props) {
    
    const history = createHashHistory();
    const { allowedRoles } = props;

  return (
    <Switch>

        {/*****************Report****************/}
        <Route
          exact
          path="/:lng/report"
          render={() => (
            <Auth history={history} allowedRoles={allowedRoles}>
              <Report  />
            </Auth>
          )}
        />
        {/*****************Report****************/}

      </Switch>
  )
}

export default InvoiceRoute