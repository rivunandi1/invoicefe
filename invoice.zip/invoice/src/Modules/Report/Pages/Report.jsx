import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../Login/Actions/LoginAction';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { Tabs, Tab } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import ReportPage from '../Components/Report/ReportPage'
import '../Assets/css/invoicedoc.scss';
// import DatePicker, { utils } from 'react-modern-calendar-datepicker';
// import 'react-modern-calendar-datepicker/lib/DatePicker.css';
// import AutosuggestComponent from '../../../Utility/Components/AutosuggestComponent';
// import { reportListing } from '../Components/Report/Controller/ReportController';
// import moment from 'moment-timezone';

class Report extends Component {
	constructor(props) {
		super(props);
		this.state = {
			reportSelectedTabName: "report",
			filterDate: {
				from: null,
				to: null
			},
			selectedGst: [],
			
			invoiceReportData: []
		}
	}

	componentDidMount() {
		this.props.handleActiveLink("report_module", "");
		this.permissionWiseTabSelected();

	}
	

	roleHandelSelectTab = (tabName) => {
		this.setState({
			reportSelectedTabName: tabName
		})
	}

	permissionWiseTabSelected = () => {
		const { roleWisePermission } = this.props;
		if (Object.keys(roleWisePermission) && Object.keys(roleWisePermission).length > 0) {
			let tab_order = ["invoice"];
			let first_tab = tab_order.filter((x) => Object.keys(roleWisePermission).includes(x))[0];
			console.log("first_tab", first_tab)
			this.setState({
				reportSelectedTabName: first_tab ? first_tab : "report"
			})
		}
	}
	validationPermission = (eventKey) => {
		const { t, roleWisePermission } = this.props;
		let valid = false;
		if (roleWisePermission && roleWisePermission.hasOwnProperty(eventKey) && roleWisePermission[eventKey].read_write_permission != "") {
			valid = true;
		}
		return valid
	}



	tabUi = () => {
		const { t } = this.props;
		let arry = []

		//if (this.validationPermission('roles')) {
		arry.push(
			<Tab eventKey="report" title={t('report')} key={0}>
				{this.state.reportSelectedTabName == 'report' ?
					<ReportPage
					/>
					: null}
			</Tab>
		)
		//}

		return arry;
	}
	






	render() {
		const { t } = this.props;
		return (
			<div className="homepagecontainer connectheader workerTab">

				

				<Tabs
					id="invoicetabs"
					activeKey={this.state.reportSelectedTabName}
					className="tabsmainbox"
					onSelect={this.roleHandelSelectTab}
				>

					{this.tabUi()}
				</Tabs>

			</div>
		);
	}
}




const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.mainReducerData.userCredentials,
		token: globalState.mainReducerData.token,
		access_token: globalState.mainReducerData.access_token,
		roleWisePermission: globalState.mainReducerData.roleWisePermission
	};
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(Report)));