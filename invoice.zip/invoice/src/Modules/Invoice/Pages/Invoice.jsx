import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../Login/Actions/LoginAction';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { Tabs, Tab } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import InvoicePage from '../Components/Invoice/InvoicePage'
import ReceiveInvoicePage from '../Components/ReceiveInvoice/ReceiveInvoicePage'
import '../Assets/css/invoicedoc.scss';

class Invoice extends Component {
	constructor(props) {
		super(props);
		this.state = {
			invoiceSelectedTabName: "invoice"
		}
	}

	componentDidMount() {
		this.props.handleActiveLink("invoice_module", "");
		this.permissionWiseTabSelected()
	}

	roleHandelSelectTab = (tabName) => {
		this.setState({
			invoiceSelectedTabName: tabName
		})
	}

	permissionWiseTabSelected = () => {
		const { roleWisePermission } = this.props;
		if (Object.keys(roleWisePermission) && Object.keys(roleWisePermission).length > 0) {
			let tab_order = ["invoice", "receiveInvoice"];
			let first_tab = tab_order.filter((x) => Object.keys(roleWisePermission).includes(x))[0];
			// console.log("first_tab", first_tab)
			this.setState({
				invoiceSelectedTabName: first_tab ? first_tab : "invoice"
			})
		}
	}
	validationPermission = (eventKey) => {
		const { t, roleWisePermission } = this.props;
		let valid = false;
		if (roleWisePermission && roleWisePermission.hasOwnProperty(eventKey) && roleWisePermission[eventKey].read_write_permission != "") {
			valid = true;
		}
		return valid
	}



	tabUi = () => {
		const { t } = this.props;
		let arry = []

		//if (this.validationPermission('roles')) {
		arry.push(
			<Tab eventKey="invoice" title={t('customer_payments')} key={0}>
				{this.state.invoiceSelectedTabName == 'invoice' ?
					<InvoicePage />
					: null}
			</Tab>
		)
		//}

		//if (this.validationPermission('roles')) {
		arry.push(
			<Tab eventKey="receiveInvoice" title={t('vendor_payments')} key={1}>
				{this.state.invoiceSelectedTabName == 'receiveInvoice' ?
					<ReceiveInvoicePage />
					: null}
			</Tab>
		)
		//}

		return arry;
	}

	render() {
		const { t } = this.props;
		return (
			<div className="homepagecontainer connectheader">
				<Tabs
					id="invoicetabs"
					activeKey={this.state.invoiceSelectedTabName}
					className="tabsmainbox"
					onSelect={this.roleHandelSelectTab}
				>
					{this.tabUi()}
				</Tabs>
			</div>
		);
	}
}




const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.mainReducerData.userCredentials,
		token: globalState.mainReducerData.token,
		access_token: globalState.mainReducerData.access_token,
		roleWisePermission: globalState.mainReducerData.roleWisePermission
	};
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(Invoice)));