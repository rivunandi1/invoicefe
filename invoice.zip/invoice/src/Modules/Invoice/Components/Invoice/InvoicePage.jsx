import React, { useRef } from 'react';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import { useEffect, useState } from 'react'
import AddEditInvoiceModalContent from './Components/AddEditInvoiceModalContent';
import ModalGlobal from '../../../../Utility/Components/ModalGlobal';
import InvoicePreviewModalContent from './Components/InvoicePreviewModalContent';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../../Actions/AllAction';
import { setUserCredentials } from '../../../Login/Actions/LoginAction';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Utility from '../../../../Utility/Utility';
import moment from 'moment';
import { invoiceListing, customerListing, invoiceAdd, paymentInvoiceAdd, paymentInvoiceList, paymentInvoiceListRowDelete, invoiceRowDelete, customerEmailHistoryListing, emailHistoryAdd, sendEmailPost } from '../Invoice/Controller/InvoiceController';
import { invoiceFormatingFormData, paymentInvoiceFormatingFormData, previewModalDatasetFormat, sendMailDataFormat } from '../Invoice/DataFormat/InvoiceDataFormat'
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';
import PopoverStickOnHover from '../../../../Utility/Components/PopoverStickOnHover';
import GridActionContent from '../../../../Utility/Components/GridActionContent';
import PaynowModalContent from './Components/PaynowModalContent';
import PaymentReceiptModalContent from './Components/PaymentReceiptModalContent';
import ConfirmationAlert from '../../../../Utility/Components/ConfirmationAlert'
import SendMailModalContent from './Components/SendMailModalContent';

import CustomerModalContent from '../../../Home/Components/Customer/Components/CustomerModalContent'
import HomeUtility from '../../../Home/Utility/Utility'
import Currency from '../../../../Utility/JsFolder/Currency';
import CurrencySymbols from '../../../../Utility/JsFolder/CurrencySymbols';
import CountryWithCode from '../../../../Utility/JsFolder/CountryWithCode';
import { formatingFormData } from '../../../Home/Components/Customer/DataFormat/CustomerDataFormat'
import * as CustomerController from '../../../Home/Components/Customer/Controller/CustomerController'
import BankDetailsComponent from '../../../../Utility/Components/BankDetailsComponent';
import CommonSearchFilter from '../../../../Utility/Components/CommonSearchFilter'
import Config from '../../../../Utility/Config';

function InvoicePage(props) {

  const [show, setShowtriger] = useState(false);
  const [target, setTarget] = useState(null);
  const [bankaddflag, setbankaddflag] = useState(false)
  const [orgBankListData, setOrgBankListData] = useState([])
  const [bankList, setbankList] = useState([])
  const [bankDetails, setbankDetails] = useState([{
    "account_no": "",
    "bank_name": "",
    "bank_address": "",
    "bank_country": "",
    "ifsc_code": "",
  }])

  const [customerTotalResponse, setCustomerTotalResponse] = useState({})
  const [customerEmailResponse, setCustomerEmailResponse] = useState({})
  const [customersList, setCustomersList] = useState([])
  const [previewModalDataset, setPreviewModalDataset] = useState([])
  const [percentages, setPercentages] = useState({})
  const [paymentStatusList, setpaymentStatusList] = useState(
    [
      { value: 'pending', label: 'Pending' },
      { value: 'partial_payment', label: 'Partial payment' },
      { value: 'full_payment', label: 'Full payment' },
      { value: 'canceled', label: 'Canceled' },
    ]
  )
  const [companyTypeList, setCompanyTypeList] = useState(
    [
      { label: "Customer", value: 'customer' },
    ]
  )
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState("")
  const [modules, setmodules] = useState([InfiniteRowModelModule]);
  const [defaultColDef, setdefaultColDef] = useState({
    flex: 1,
    //resizable: true,
    minWidth: 50

  });
  let imageRef = useRef();

  const [components, setcomponents] = useState({
    loadingRenderer: (params) => {
      //console.log("params=================== worker", params)
      //return null;
      if (params.value !== undefined) {
        return params.value;
      } else {
        return '<img src="https://www.ag-grid.com/example-assets/loading.gif">';
      }
    },
  }
  )

  const [gridApi, setGridApi] = useState(null);
  const [gridColumnApi, setGridColumnApi] = useState(null);
  const [gridparams, setgridparams] = useState(null);
  const [print, setPrint] = useState(false);

  const [invoiceData, setInvoiceData] = useState([{ description: "", quantity: "", rate: "", price: "" }]);
  const [invoiceDataError, setInvoiceDataError] = useState([{ description_error: "", quantity_error: "", rate_error: "" }]);

  const [formData, setFormData] = useState({
    invoice_number: "",
    company_name: "",
    company_bank: "",
    org_bank: "",
    address: "",
    gst_number: "",
    sub_total: 0,
    sgst: 0,
    cgst: 0,
    igst: 0,
    sgst_percentage: 0,
    cgst_percentage: 0,
    igst_percentage: 0,

    total: 0,
    currency: "INR",
    is_gst_applicable: false,
    is_igst_applicable: false,
    is_sgst_applicable: false,
    cust_bank_name: "",
    cust_bank_account_number: ""
  })



  const [errorFormData, setErrorFormData] = useState({
    invoice_number_error: "",
    company_name_error: "",
    company_bank_error: "",
    org_bank_error: "",
    address_error: "",
    gst_number_error: "",
    sgst_percentage_error: "",
    cgst_percentage_error: "",
    igst_percentage_error: "",
    //less_discount_error: "",
    total_error: "",
    sub_total_error: "",
    gst_applicable_error: "",
    invoice_img_error: "",
    invoice_date_error: ""
  })




  //additional custom input
  const [additionalInputText, setAdditionalInputText] = useState([{ additional_text: "", additional_value: "" }])
  const [additionalInputTextError, setAdditionalInputTextError] = useState([{ additional_error: "" }])
  const [invoice_number_generation, setInvoice_number_generation] = useState({ invoice1: "MT/INV", invoice2: "", invoice3: "Autogenerate" })

  const [formPaymentErr, setformPaymentErr] = useState({ pertial_full_payment_error: "", payment_date_error: "", total_amount_errpr: "", tds_error: "" })
  const [tdsAmount, setTdsAmount] = useState("")

  const [paymentType, setPaymentType] = useState({ pertial_payment: false, full_payment: false })
  const [paymentReceiptData, setPaymentReceiptData] = useState("")
  const [deletePaymentRowId, setDeletePaymentRowId] = useState("")
  const [blurMailFlag, setBlurEmail] = useState(false)

  //preview flag
  // const[preview_button,setPreview_button]=useState(false)

  const [invoiceModalShow, setShow] = useState(false);
  const [rowData, setRowData] = useState([])
  const [invoicPrevieweModalShow, setInvoicPrevieweModal] = useState(false);




  const codeOutsideClickRef = useRef();
  const [actionModalflag, setActionModalFalg] = useState(false)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [selectedData, setSelectedData] = useState("")
  const [paymentStatusPendingFlag, setPaymentStatusPendingFlag] = useState(false)

  const [paymentReceiptFlag, setPaymentReceiptFlag] = useState(false)
  //const [invoiceRowDetails, setInvoiceRowDetails] = useState({})
  const [amountAfterConversion, setamountAfterConversion] = useState(0)
  const [paymentDate, setPaymentDate] = useState("")
  const [dateField, setDateField] = useState("")
  const [dateFieldError, setDateFieldError] = useState({ dateFieldError: "" })
  const [paymentDateError, setPaymentDateError] = useState({ paymentDateError: "" })
  const [conversionAmount, setConversionAmount] = useState("")
  const [lastPaymentType, setLastPaymentType] = useState([])
  const [sendMailFlag, setsendMailFlag] = useState(false)
  const [sendMailModalShow, setSendMailModalShow] = useState(false);
  const [customersEmailHistoryList, setCustomersEmailHistoryList] = useState([])

  //customer add
  const [travailleursModal, settravailleursModal] = useState(false);
  const [cusheaderContent, setcusheaderContent] = useState("Add customer");
  const [customeraddflag, setcustomeraddflag] = useState(false)
  const [currencyList, setcurrencyList] = useState([])
  const [countryList, setcountryList] = useState([])
  const [comment, setComment] = useState("")
  const [searchValue, setSearchValue] = useState("")
  const [fromData, setfromData] = useState({
    "name": "",
    "email": "",
    "ph_no": "",
    "profileImage": "",
    "address_line1": "",
    "address_line2": "",
    "city": "",
    "state": "",
    "country": "",
    "zip_code": "",
    "pan_number": "",
    "gstn": "",
    //"gst_number": "",
    //"conversion_allowance_percentage": "",
    "active": true,
    "is_gst_applicable": false,
    "is_sgst_applicable": false,
    "is_igst_applicable": false,
    "currency": "",
    "customer_type": { label: "Customer", value: 'customer' },
    "tin": "",
    "tan": ""

  })
  const [fromDataError, setfromDataError] = useState({
    "name": "",
    "email": "",
    "ph_no": "",
    "profileImage": "",
    "address_line1": "",
    "address_line2": "",
    "city": "",
    "state": "",
    "country": "",
    "zip_code": "",
    "pan_number": "",
    "gstn": "",
    //"conversion_allowance_percentage": "",
    "currency": "",
    "gst_applicable_error": "",
    "customer_type": "",

  })

  const [filterDate, setFilterDate] = useState({
    from: null,
    to: null
  })

  const [imageCropModalFlag, setimageCropModalFlag] = useState(false)
  const [src, setsrc] = useState(null)
  const [croppedImageUrl, setcroppedImageUrl] = useState("")
  const [crop, setcrop] = useState({ unit: '%', width: 30, aspect: 1 / 1 })
  const [addProfileImagePreviewShow, setaddProfileImagePreviewShow] = useState(false)
  const [addprofileImageSelected, setaddprofileImageSelected] = useState(require('../../../../Utility/Public/images/profile-back.png'))
  const [saveButtonDisableEditModal, setsaveButtonDisableEditModal] = useState(true)
  const [profileImageChangeEditMode, setprofileImageChangeEditMode] = useState(false)
  const [editedFlag, seteditedFlag] = useState(false)
  const [bankModal, setbankModal] = useState(false)
  const [deleteBankDetailsConfirmationAlertModalFlag, setDeleteBankDetailsConfirmationAlertModalFlag] = useState(false)
  const [deleteBankDetailsObj, setDeleteBankDetailsObj] = useState("")


  const openbankAddmodal = () => {
    setbankModal(true)
    countryModefy()

  }
  const closebankModal = () => {
    setbankModal(false)
    setbankDetails([{
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }])
  }

  const [bankDetailsError, setbankDetailsError] = useState([{
    "account_no": "",
    "bank_name": "",
    "bank_address": "",
    "bank_country": "",
    "ifsc_code": "",
  }])

  const handelClickBankAdd = () => {
    let bankDetailsNew = {
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }
    let bankDetailsErrorNew = {
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }
    let tempBankDetails = bankDetails.slice()
    let tempBankDetails_copy = [...tempBankDetails, bankDetailsNew]


    let tempbankDetailsError = bankDetailsError.slice()
    let tempbankDetailsError_copy = [...tempbankDetailsError, bankDetailsErrorNew]

    setbankDetails(tempBankDetails_copy)
    setbankDetailsError(tempbankDetailsError_copy)

  }
  const handelChangeForBankDetails = (event, type, i) => {

    let fromDataTemp = bankDetails.slice();
    let fromDataTempError = bankDetailsError.slice();
    // let fromDataBudgetTemp = Object.assign({}, this.state.fromDataBudget);
    // let fromDataBudgetTempError = Object.assign({}, this.state.fromDataBudgetError);

    if (type == "account_no") {
      if (!isNaN(event.target.value)) {
        fromDataTemp[i]['account_no'] = event.target.value;
        fromDataTempError[i]['account_no'] = ""
      } else {
        //fromDataTemp[i]['account_no'] = "";
        //fromDataTempError['account_no'] = ""
        Utility.toastNotifications(props.t('please_enter_integer_number'), "Warning", "warning")
      }
    }
    if (type == "bank_name") {
      if (event.target.value != "") {
        fromDataTemp[i]['bank_name'] = event.target.value;
        fromDataTempError[i]['bank_name'] = ""
      } else {
        fromDataTemp[i]['bank_name'] = "";
        fromDataTempError[i]['bank_name'] = ""
      }
    }
    if (type == "bank_address") {
      if (event.target.value != "") {
        fromDataTemp[i]['bank_address'] = event.target.value;
        fromDataTempError[i]['bank_address'] = ""
      } else {
        fromDataTemp[i]['bank_address'] = "";
        fromDataTempError[i]['bank_address'] = ""
      }
    }
    if (type == "bank_country") {
      if (event != "") {
        fromDataTemp[i]['bank_country'] = event;
        fromDataTempError[i]['bank_country'] = ""
      } else {
        fromDataTemp[i]['bank_country'] = "";
        fromDataTempError[i]['bank_country'] = props.t('requiredField')
      }
    }
    if (type == "ifsc_code") {
      if (event.target.value != "") {
        if (event.target.value.length == 11) {
          fromDataTempError[i]['ifsc_code'] = ""
        } else {
          fromDataTemp[i]['ifsc_code'] = "";
          fromDataTempError[i]['ifsc_code'] = "* IFSC code must be 11 digit"
        }
        fromDataTemp[i]['ifsc_code'] = event.target.value;
      } else {
        fromDataTemp[i]['ifsc_code'] = "";
        fromDataTempError[i]['ifsc_code'] = ""
      }
    }


    setbankDetails(fromDataTemp)
    setbankDetailsError(fromDataTempError)
    setsaveButtonDisableEditModal(false)

    /*this.setState({
        bankDetails: fromDataTemp,
        // fromDataBudget: fromDataBudgetTemp,
        bankDetailsError: fromDataTempError,
        // fromDataBudgetError: fromDataBudgetTempError,
        // orgDataEditFlag: true,
        saveButtonDisableEditModal: false
    }, () => {
        //console.log("handle fromData", this.state.fromData)
        //console.log("handle fromDataBudget", this.state.fromDataBudget)
    })*/


  }

  const validBankCheck = () => {
    //Bank details validation start
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();
    let bankAccountNumber = []
    let valid = true
    if (tempBankDetails.length > 0) {
      tempBankDetails.map((value, idx) => {
        bankAccountNumber.push(value.account_no)
        if (value.account_no == "") {
          tempBankDetailsError[idx]['account_no'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['account_no'] = ""
        }

        if (value.bank_name == "") {
          tempBankDetailsError[idx]['bank_name'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_name'] = ""
        }
        if (value.bank_address == "") {
          tempBankDetailsError[idx]['bank_address'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_address'] = ""
        }
        if (value.bank_country.length == 0) {
          tempBankDetailsError[idx]['bank_country'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_country'] = ""
        }
        if (value.ifsc_code == "") {
          tempBankDetailsError[idx]['ifsc_code'] = props.t('requiredField')
          valid = false;
        } else {
          if (value.ifsc_code.length == 11) {
            tempBankDetailsError[idx]['ifsc_code'] = ""
          } else {
            value['ifsc_code'] = "";
            tempBankDetailsError[idx]['ifsc_code'] = "* IFSC code must be 11 digit"
            valid = false;
          }
        }
      })


    }


    if (acountNumberDuplicates(bankAccountNumber)) {
      valid = false;
      Utility.toastNotifications("Duplicates account number", "Error", "error")
    }

    setbankDetailsError(tempBankDetailsError)
    return valid
  }

  const acountNumberDuplicates = (array) => {
    if (array.length !== new Set(array).size) {
      return true;
    }

    return false;
  }

  const bankDetailsSave = () => {
    let valid = validBankCheck();
    if (valid) {
      let bankArry = []
      if (bankDetails.length > 0) {
        bankDetails.map((v, i) => {
          let tempHash = {}
          tempHash['account_no'] = v.account_no;
          tempHash['bank_name'] = v.bank_name;
          tempHash['bank_address'] = v.bank_address;
          tempHash['bank_country'] = v.bank_country.value;
          tempHash['ifsc_code'] = v.ifsc_code;
          bankArry.push(tempHash)
        })
      }
      let hash = {}
      hash['bank_details'] = bankArry

      let id = formData.company_name.value;
      CustomerController.customerAdd(hash, id, "patch").then((response) => {
        // console.log("response===", response)
        if (response.success) {
          Utility.toastNotifications(response.message, "Success", "success");
          customerList(formData.company_name.label)
          closebankModal()
          userWiseBankDetailsGet()
        }
      })
    }
  }

  const userWiseBankDetailsGet = (userId = "") => {
    let id = userId != "" ? userId : formData.company_name.value;
    CustomerController.customerBankListing(id).then((response) => {
      //console.log("response===", response)
      let bankArry = []
      let bankDetailsArry = [];
      let bankErrorArry = [];
      if (response.success) {

        /*bankArry = response.data[0].bank_details.map(object => {
          return { ...object, "value": object.account_no, "label": `${object.account_no}(${object.bank_name})` };
        });*/



        if (response.data[0].bank_details.length > 0) {
          response.data[0].bank_details.map((b, i) => {

            let hash = { value: b.account_no, label: `${b.account_no}(${b.bank_name})`, account_no: b.account_no, bank_name: b.bank_name, bank_address: b.bank_address, bank_country: b.bank_country, ifsc_code: b.ifsc_code }
            bankArry.push(hash)
            //
            let findBankCountry = CountryWithCode.filter(Bres => {
              return Bres.country == b.bank_country;
            });

            let bankCountry = {}
            if (findBankCountry.length > 0) {
              bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
            }

            let bankhash = {
              "account_no": b.account_no,
              "bank_name": b.bank_name,
              "bank_address": b.bank_address,
              "bank_country": bankCountry,
              "ifsc_code": b.ifsc_code,
            }
            let errorhash = {
              "account_no": "",
              "bank_name": "",
              "bank_address": "",
              "bank_country": "",
              "ifsc_code": "",
            }

            bankDetailsArry.push(bankhash)
            bankErrorArry.push(errorhash)
          })
        }
      }
      setbankaddflag(true)
      setbankList(bankArry)
      setbankDetails(bankDetailsArry)
      setbankDetailsError(bankErrorArry)
    })
  }



  const actionModalfunction = (e, params) => {
    let width = (parseInt(e.clientX) - 285) + 'px'
    let height = (parseInt(e.clientY) - 65) + 'px'
    setPosition({ x: width, y: height })
    setActionModalFalg(true)
    setSelectedData(params)
    setsendMailFlag(true)
    if (params.data.payment_status == "pending" || params.data.payment_status == "partial_payment") {
      setPaymentStatusPendingFlag(true)
    } else {
      setPaymentStatusPendingFlag(false)
    }
    if (params.data.payment_status == "pending") {
      setPaymentReceiptFlag(false)
    } else {
      setPaymentReceiptFlag(true)
    }

  }

  const handleChangeDateField = (date) => {

    // console.log("date field date---", date)
    let tempDateFieldError = { ...dateFieldError }
    if (date != "") {
      setDateField(date)
      tempDateFieldError["dateFieldError"] = ""
    } else {
      tempDateFieldError["dateFieldError"] = "Invalid Field"
    }

    setDateFieldError(tempDateFieldError)
  }
  useEffect(() => {
    // console.log("date====>.", dateField)
  })

  const handleChangePaymentDate = (type, date) => {
    let tempObj = Object.assign({}, paymentDateError)
    if (date != "") {
      setPaymentDate(date)
      tempObj["payment_date_error"] = ""
    } else {
      tempObj["payment_date_error"] = "* Invalid Field"
    }

    setformPaymentErr(tempObj)
  }
  const formatDateInput = () => {
    if (!paymentDate.year) return '';
    const Year = paymentDate.year.toString();
    const Month = paymentDate.month.toString().padStart(2, 0);
    const Day = paymentDate.day.toString().padStart(2, 0);
    return `${Day}/${Month}/${Year}`;
  };

  useEffect(() => {
  }, [paymentDate])

  const handleChangeConversionAmount = (event, type) => {
    // console.log("type-->", type)
    const { value } = event.target;
    // console.log("value-->", value)

    let tempObj = Object.assign({}, formPaymentErr)
    if (type == "conversionAmount") {
      if (!isNaN(value) && value != "") {
        setConversionAmount(value)
        let output = (value * selectedData.data.calculation.conversion_allowance_percentage) / 100
        //setamountAfterConversion(parseFloat(output.toFixed(2)).toLocaleString())
        setamountAfterConversion(output)
        let tdsPercentage = Config.tdsPercentage
        let tdsAmount = (value / 100) * tdsPercentage
        setTdsAmount(tdsAmount)
        tempObj["total_amount_errpr"] = ""
      } else {
        setConversionAmount("")
        setamountAfterConversion(0)
        setTdsAmount("")
        tempObj["total_amount_errpr"] = "* Invalid Field"
      }
      setformPaymentErr(tempObj)
    }

    if (type == "tds") {
      if (!isNaN(value) && value != "") {
        setTdsAmount(value)
        tempObj["tds_error"] = ""
      } else {
        setTdsAmount("")
      }
      setformPaymentErr(tempObj)
    }
  }
  useEffect(() => {
    // console.log("tdsAmount===>", tdsAmount)
    // console.log("tdsPercentage===>", Config.tdsPercentage)

  }, [tdsAmount])

  const handleChangeComment = (event, type) => {
    const { value } = event.target;
    if (type == "comment") {
      if (value != "") {
        setComment(value)
      } else {
        setComment("")
      }
    }

  }

  useEffect(() => {
  }, [conversionAmount])

  useEffect(() => {
  }, [amountAfterConversion])


  const handleClickOutside = (event) => {
    if (codeOutsideClickRef.current != null) {
      if (codeOutsideClickRef && codeOutsideClickRef.current && !codeOutsideClickRef.current.contains(event.target)) {
        setActionModalFalg(false)
      }
    }

  }

  /*useEffect(() => {
  }, [paymentStatusPendingFlag])

  useEffect(() => {
  }, [paymentReceiptFlag])*/

  const [payNowModalShow, setpayNowModalShow] = useState(false);
  const sendPaynow = () => {
    setpayNowModalShow(true)
    setActionModalFalg(false)
  }
  const payNowModalClose = () => {
    setpayNowModalShow(false)
    resetPaymentData()
    setTdsAmount("")
  }




  const sendmail = () => {
    setSendMailModalShow(true)
    console.log("selectedData send mail========", selectedData.data)
  }
  const sendMailModalClose = () => {
    setSendMailModalShow(false)

  }




  const resetPaymentData = () => {
    setformPaymentErr({ pertial_full_payment_error: "", payment_date_error: "", total_amount_errpr: "" })
    setPaymentType({ pertial_payment: false, full_payment: false })
    setPaymentDate("")
    setConversionAmount("")
    setamountAfterConversion(0)
    setComment("")
  }

  const [paymentReceiptModalShow, setpaymentReceiptModalShow] = useState(false);
  const [paymentReceiptDeleteModalShow, setpaymentReceiptDeleteModalShow] = useState(false);
  const [paymentDeleteObj, setPaymentDeleteObj] = useState("");
  const [invoiceDeleteObj, setInvoiceDeleteObj] = useState("");
  const [invoiceNumberContent, setInvoiceNumberContent] = useState("");
  const [totalReceptAmount, setTotalReceptAmount] = useState(0);
  const [invoiceCancelModalShow, setInvoiceCancelModalShow] = useState(false);
  const [mailList, setmailList] = useState([]);

  const paymentReceipt = () => {
    setpaymentReceiptModalShow(true)
    paymentInvoiceListing()
  }
  const paymentReceiptModalClose = () => {
    setpaymentReceiptModalShow(false)
    setPaymentReceiptData("")
    setTotalReceptAmount(0)
    resetDataGrid()
  }



  const [columnDefs, setColumnDefs] = useState(
    [
      {
        headerName: "Invoice Number",
        field: "invoice_number",
        minWidth: 220,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.invoice_number) {
              return <div className="gridusericon">
                {params.data.invoice_number.length > 15 ?
                  <OverlayTrigger overlay={<Tooltip>{params.data.invoice_number}</Tooltip>}>
                    <span>{params.data.invoice_number.substring(0, 15) + "..."}</span>
                  </OverlayTrigger>
                  :
                  <span>{params.data.invoice_number}</span>
                }
              </div>
            } else {
              return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
            }

          } else {
            return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Invoice Date",
        field: "dateField",
        minWidth: 110,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.invoice_date) {
              return <div className="gridusericon">
                {moment(params.data.invoice_date).format('DD-MM-YYYY')}
              </div>
            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Company Name",
        field: "cust_details",
        minWidth: 140,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.cust_details) {
              return <div className="gridusericon">
                {/* { params.data.cust_details.name.length > 22 ? */}
                {params.data.cust_details.name}
                {/* :null
              } */}
              </div>
            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },

      {
        headerName: "CGST",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 90,
        cellRendererFramework: (params) => {
          //console.log("params....>>", params)
          if (params && params.data && params.data.cust_details) {
            if (params.data.cust_details.is_gst_applicable) {
              if (params.data.cust_details.is_sgst_applicable) {
                if (params.data.calculation) {
                  return <div className="gridusericon percentage">
                    {/* {params.data.calculation.amount_on_cgst_percentage} */}
                    {parseFloat(params.data?.calculation?.amount_on_cgst_percentage).toFixed(2)}
                  </div>
                } else {
                  return null;
                }
              } else {
                return null
              }
            } else {
              return null
            }


          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "SGST",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 90,
        cellRendererFramework: (params) => {
          if (params && params.data && params.data.cust_details) {
            if (params.data.cust_details.is_gst_applicable) {
              if (params.data.cust_details.is_sgst_applicable) {
                if (params.data.calculation) {
                  return <div className="gridusericon percentage">
                    {/* {params.data.calculation.amount_on_sgst_percentage} */}
                    {parseFloat(params.data?.calculation?.amount_on_sgst_percentage).toFixed(2)}
                  </div>
                } else {
                  return null;
                }
              } else {
                return null
              }
            } else {
              return null
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "IGST",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 90,
        cellRendererFramework: (params) => {

          if (params && params.data && params.data.cust_details) {
            if (params.data.cust_details.is_gst_applicable) {
              if (params.data.cust_details.is_igst_applicable) {
                if (params.data.calculation) {
                  return <div className="gridusericon percentage">
                    {/* {params.data.calculation.amount_on_igst_percentage} */}
                    {parseFloat(params.data?.calculation?.amount_on_igst_percentage).toFixed(2)}
                  </div>
                } else {
                  return null;
                }
              } else {
                return null
              }
            } else {
              return null
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Currency",
        field: "cust_details",
        //headerClass: 'headerNumeric',
        minWidth: 100,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.cust_details) {
              return <div className="gridusericon">
                {/* { params.data.cust_details.name.length > 22 ? */}
                {params.data.cust_details.currency}
                {/* :null
              } */}
              </div>
            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Total Value",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 120,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.calculation) {


              let symbolList = CurrencySymbols[params.data.cust_details.currency];
              if (symbolList) {
                return <div className="gridusericon percentage">
                  <span style={{ fontWeight: '600' }}>{symbolList.symbol}</span> {parseFloat(params.data.calculation.total).toFixed(2)}
                </div>
              } else {
                return <div className="gridusericon percentage">
                  {parseFloat(params.data.calculation.total).toFixed(2)}
                </div>
              }

            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Total Payment",
        field: "invoice_amount",
        headerClass: 'headerNumeric',
        minWidth: 130,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data?.invoice_amount) {
              let symbolList = CurrencySymbols[params.data.org_details.currency];
              if (symbolList) {
                return <div className="gridusericon percentage">
                  <span style={{ fontWeight: '600' }}>{symbolList.symbol}</span> {parseFloat(params.data?.invoice_amount).toFixed(2)}
                </div>
              } else {
                return <div className="gridusericon percentage">
                  {parseFloat(params.data?.invoice_amount).toFixed(2)}
                </div>
              }

            } else {
              return null;
            }
          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Status",
        field: "preview",
        headerClass: 'headerNumericStatus',
        minWidth: 140,
        cellRendererFramework: (params) => {
          if (params.data) {

            if (params.data.status == 'disable') {
              return <div className="gridusericon status_align align-left">
                Canceled
              </div>
            } else {
              if (params.data.payment_status == 'pending') {
                return <div className="gridusericon status_align align-left">
                  <i className="fa fa-circle red" aria-hidden="true"></i> Pending
                </div>
              } else if (params.data.payment_status == 'partial_payment') {
                return <div className="gridusericon status_align align-left partial_paid_color">
                  <i className="fa fa-circle yellow" aria-hidden="true"></i> Partial paid
                </div>
              } else if (params.data.payment_status == 'paid') {
                return <div className="gridusericon status_align align-left">
                  <i className="fa fa-circle green" aria-hidden="true"></i> Full paid
                </div>
              } else if (params.data.payment_status == 'full_payment') {
                return <div className="gridusericon status_align align-left">
                  <i className="fa fa-circle green" aria-hidden="true"></i> Full paid
                </div>
              } else {
                return null
              }
            }

          } else {
            return null
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "",
        field: "preview",
        maxWidth: 80,
        cellRendererFramework: (params) => {
          if (params.data) {
            // console.log("invoice preview params data==", params.data)
            return <div className="actionablePopup actionablePopupEye">
              <button className="infoviewicon" onClick={() => { invoicePreviewModalfunctions(params.data) }}><i className="fa fa-eye" aria-hidden="true"></i></button>
            </div>
          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "",
        field: "edit",
        maxWidth: 80,
        cellRendererFramework: (params) => {
          if (params.data && params.data?.status == "enable") {
            return <div className="actionablePopup">
              <button className="ellipsisIcon" onClick={(e) => actionModalfunction(e, params)}><i className="fa fa-ellipsis-v"></i></button>
            </div>
          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      }

    ]
  )



  const handleInputChange = (e, index, type) => {

    let tempInvoiceData = invoiceData.slice()
    let tempInvoiceDataError = invoiceDataError.slice()



    if (type == 'description') {
      if (e.target.value == "") {
        tempInvoiceData[index].description = ""
        tempInvoiceDataError[index].description_error = "* required field !"
      } else {
        tempInvoiceData[index].description = e.target.value
        tempInvoiceDataError[index].description_error = ""
      }

    }

    if (type == 'quantity') {
      if (!isNaN(e.target.value)) {
        if (e.target.value == "") {
          tempInvoiceData[index].quantity = ""
          tempInvoiceDataError[index].quantity_error = "* required field !"
        } else {

          tempInvoiceData[index].quantity = e.target.value
          tempInvoiceDataError[index].quantity_error = ""
          calculationTotalRate(index)

        }
      }
    }

    if (type == 'rate') {
      if (!isNaN(e.target.value)) {
        if (!isNaN(e.target.value) == "") {
          tempInvoiceData[index].rate = ""
          tempInvoiceDataError[index].rate_error = "* required field !"
        } else {
          tempInvoiceData[index].rate = e.target.value
          tempInvoiceDataError[index].rate_error = ""
          calculationTotalRate(index)
        }
      }
    }
    //console.log("----tempInvoiceDataError-->", tempInvoiceDataError)
    setInvoiceData(tempInvoiceData)
    setInvoiceDataError(tempInvoiceDataError)
    totalSubtotalWithGst()

  }



  const calculationTotalRate = (index) => {
    let tempInvoiceData = invoiceData.slice();
    let totalValue = 0;
    if (tempInvoiceData.length > 0) {
      tempInvoiceData.map((value, idx) => {
        if (idx == index) {
          if (value.rate != "" && value.quantity != "") {
            totalValue = value.quantity.valueOf() * value.rate.valueOf();
            tempInvoiceData[index].price = parseFloat(totalValue).toFixed(2);
            setInvoiceData(tempInvoiceData)
          }
        }
      })
    }
  }

  const totalSubtotalWithGst = () => {
    let tempInvoiceData = invoiceData.slice();
    let tempformData = Object.assign({}, formData)
    //console.log("!!!temp form data !!!", tempformData)
    let sub_total = 0;
    if (tempInvoiceData.length > 0) {
      tempInvoiceData.map((value, idx) => {
        if (value.rate != "" && value.quantity != "") {
          sub_total = sub_total + parseFloat(value.price)
        }
      })
    }


    if (formData.is_gst_applicable == true) {
      if (formData.is_sgst_applicable == true) {
        let sgst = (sub_total / 100) * parseFloat(tempformData.sgst_percentage);
        tempformData['sgst'] = sgst
        let cgst = (sub_total / 100) * parseFloat(tempformData.cgst_percentage);
        tempformData['cgst'] = cgst
        total = parseFloat(total) + parseFloat(sgst) + parseFloat(cgst)
      }
      if (formData.is_igst_applicable == true) {
        let igst = (sub_total / 100) * parseFloat(tempformData.igst_percentage);
        tempformData['igst'] = igst
        total = parseFloat(total) + parseFloat(igst)

      }

    }
    tempformData['sub_total'] = parseFloat(sub_total);
    //
    let total = additionalValueCalculation()
    tempformData['total'] = parseFloat(total)

    setFormData(tempformData)

  }


  // ADD row functionality
  const handleAddClick = () => {
    let valid = addRowValidation()
    if (valid == true) {
      let modifiedObj = { description: "", quantity: "", rate: "", price: "" }
      let temp_invoiceData = invoiceData.slice()
      let temp_invoiceData_copy = [...temp_invoiceData, modifiedObj]

      let modifiedErrorObj = { description_error: "", quantity_error: "", rate_error: "", price_error: "" }
      let temp_invoiceDataError = invoiceDataError.slice()
      let temp_invoiceDataError_copy = [...temp_invoiceDataError, modifiedErrorObj]
      //console.log("----invoiceDataError--->>", invoiceDataError)
      setInvoiceData(temp_invoiceData_copy);
      setInvoiceDataError(temp_invoiceDataError_copy);
    }
  }
  useEffect(() => {
    // console.log("---->>>", invoiceData)
    document.body.addEventListener('mousedown', handleClickOutside.bind(this));
  }, [invoiceData])

  const addRowValidation = () => {
    let cloneInvoiceData = invoiceData.slice()
    let cloneInvoiceDataError = invoiceDataError.slice()
    let valid = true
    //  if (cloneInvoiceData.description == "") {
    //   cloneInvoiceDataError['description_error'] = "Enter Value !"
    //    valid = false
    // }
    cloneInvoiceData.map((e, i) => {
      if (e.description == "") {
        cloneInvoiceDataError[i]['description_error'] = "* required field !"
        valid = false
      }
      if (e.quantity == "") {
        cloneInvoiceDataError[i]['quantity_error'] = "* required field !"
        valid = false
      }
      if (e.rate == "") {
        cloneInvoiceDataError[i]['rate_error'] = "* required field !"
        valid = false
      }

      setInvoiceDataError(cloneInvoiceDataError)
    })
    return valid
  }
  //modal close functionality
  const invoiceModalClose = () => {
    setShow(false);
    setInvoiceData([{ description: "", quantity: "", rate: "", price: "" }])
    setInvoiceDataError([{ description_error: "", quantity_error: "", rate_error: "" }])
    setFormData({
      invoice_number: "",
      company_name: "",
      company_bank: "",
      org_bank: "",
      company_name: "",
      address: "",
      gst_number: "",
      sub_total: 0,
      sgst: 0,
      cgst: 0,
      igst: 0,
      sgst_percentage: 0,
      cgst_percentage: 0,
      total: 0,
      is_gst_applicable: false,
      is_igst_applicable: false,
      is_sgst_applicable: false,
      igst_percentage: 0,
      currency: "INR",
      cust_bank_name: "",
      cust_bank_account_number: ""

    })
    setErrorFormData({
      invoice_number_error: "",
      company_name_error: "",
      address_error: "",
      gst_number_error: ""
    })
    setAdditionalInputText([{ additional_text: "", additional_value: "" }])
    setAdditionalInputTextError([{ additional_error: "" }])
    setDateField("")
    setCustomersList([])
    setbankList([])
  }


  const invoiceModalfunction = () => {
    // console.log("usercredential-- invoice modal page==>", props.userCredentials)
    let org_bank_details_array = []

    if (props.userCredentials.user_details.org_bank_details.length > 0) {
      org_bank_details_array = props.userCredentials.user_details.org_bank_details.map(object => {
        return { ...object, "value": object.account_no, "label": `${object.account_no}(${object.bank_name})` };
      });

      // props.userCredentials.user_details.org_bank_details.map((obj) => {
      //   let org_bank_details = {}
      //   org_bank_details['label'] = obj.account_no
      //   org_bank_details['value'] = obj.account_no
      //   org_bank_details_array.push(org_bank_details)
      // })

    }
    setOrgBankListData(org_bank_details_array)
    let currentMonthNumber = moment().month() + 1;
    let currentyear = moment().format("YY");
    let temp_invoice_number_generation = { ...invoice_number_generation }
    if (currentMonthNumber > 4) {
      let currentyearPlus = parseInt(currentyear) + 1;
      temp_invoice_number_generation['invoice2'] = `${currentyear}/${currentyearPlus}`;
      setInvoice_number_generation(temp_invoice_number_generation);
    } else {
      let currentyearminus = parseInt(currentyear) - 1;
      temp_invoice_number_generation['invoice2'] = `${currentyearminus}/${currentyear}`;
      setInvoice_number_generation(temp_invoice_number_generation);
    }
    setShow(true);
    //customerList()
  }

  // useEffect(() => {
  //   console.log("customerTotalResponse====?>", customerTotalResponse)
  // })


  const invoicPrevieweModalClose = () => setInvoicPrevieweModal(false);
  const invoicePreviewModalfunction = () => {
    let valid = form_validation()
    if (valid) {
      let date = moment().format('DD/MM/YYYY');
      let company_admin_login_name = props.userCredentials.user_details.user_name
      let org_name = props.userCredentials.user_details.org_name
      let currency = formData.currency
      // console.log("company_admin_login_name==", company_admin_login_name)
      // console.log("org_name==", org_name)
      // console.log("preview==dateField", dateField)

      let tempFormData = { ...formData }
      let selectedCustomerData = customerTotalResponse.filter(res => {

        return res._id == tempFormData.company_name.value;
      });
      //console.log("selected customer data--->", selectedCustomerData)
      let location_type = 'form'
      previewModalDatasetFormat(formData, invoice_number_generation, selectedCustomerData, invoiceData, additionalInputText, company_admin_login_name, org_name, location_type, "", dateField, currency).then((dataSet) => {
        // console.log("preview modal dataset----??>>", dataSet)
        setPreviewModalDataset(dataSet)
        setInvoicPrevieweModal(true);
      })



    } else {
      Utility.toastNotifications("First fill up these required field", "Warning", "warning");
    }

  }

  useEffect(() => {
    // console.log("previewModalDataset?????//////>", previewModalDataset)
  }, [previewModalDataset])

  const invoicePreviewModalfunctions = (selectedRowData) => {
    // console.log("selectedRowData>>>>>>>>>", selectedRowData)
    let location_type = 'grid'
    let date = moment(selectedRowData.createdAt).format('DD/MM/YYYY');
    let company_admin_login_name = props.userCredentials.user_details.user_name
    let org_name = props.userCredentials.user_details.org_name
    let currency = selectedRowData.cust_details.currency
    let selectedCustomerData = []
    let selectedCustomerDataObject = {}
    selectedCustomerDataObject['name'] = selectedRowData.cust_details.name
    selectedCustomerDataObject['gst_number'] = selectedRowData.cust_details.gstn
    selectedCustomerDataObject['address_line1'] = selectedRowData.cust_details.address_line1
    selectedCustomerDataObject['address_line2'] = selectedRowData.cust_details.address_line2
    selectedCustomerDataObject['city'] = selectedRowData.cust_details.city
    selectedCustomerDataObject['country'] = selectedRowData.cust_details.country
    selectedCustomerDataObject['zip_code'] = selectedRowData.cust_details.zip_code
    let Organisation = {}
    Organisation['gst_number'] = selectedRowData.org_details.gst_number
    Organisation['pan_number'] = selectedRowData.org_details.pan_number
    Organisation['gstn'] = selectedRowData.org_details.gstn
    Organisation['account_no'] = selectedRowData.org_details.account_no
    Organisation['address_line1'] = selectedRowData.org_details.address_line1
    Organisation['address_line2'] = selectedRowData.org_details.address_line2
    Organisation['city'] = selectedRowData.org_details.city
    Organisation['country'] = selectedRowData.org_details.country
    Organisation['bank_name'] = selectedRowData.org_details.bank_name
    Organisation['bank_address'] = selectedRowData.org_details.bank_address
    Organisation['bank_country'] = selectedRowData.org_details.bank_country
    Organisation['ifsc_code'] = selectedRowData.org_details.ifsc_code
    selectedCustomerDataObject['Organisation'] = Organisation
    selectedCustomerDataObject['currency'] = currency
    selectedCustomerData.push(selectedCustomerDataObject)

    let formData = {}

    formData['invoice_number'] = selectedRowData.invoice_number
    formData['company_name'] = selectedRowData.cust_details.name
    formData['address'] = selectedRowData.cust_details.city
    formData['gst_number'] = selectedRowData.cust_details.gstn
    formData['sub_total'] = selectedRowData.calculation.sub_total
    formData['sgst'] = selectedRowData.calculation.amount_on_cgst_percentage
    formData['cgst'] = selectedRowData.calculation.amount_on_sgst_percentage
    formData['igst'] = selectedRowData.calculation.amount_on_igst_percentage
    formData['sgst_percentage'] = selectedRowData.calculation.sgst_percentage
    formData['cgst_percentage'] = selectedRowData.calculation.cgst_percentage
    formData['igst_percentage'] = selectedRowData.calculation.igst_percentage
    formData['total'] = selectedRowData.calculation.total
    formData['is_gst_applicable'] = selectedRowData.cust_details.is_gst_applicable
    formData['is_igst_applicable'] = selectedRowData.cust_details.is_igst_applicable
    formData['is_sgst_applicable'] = selectedRowData.cust_details.is_sgst_applicable

    let invoiceData = []

    selectedRowData.details.map((obj) => {
      let invoiceDataObject = {}
      invoiceDataObject['description'] = obj.description
      invoiceDataObject['quantity'] = obj.quantity
      invoiceDataObject['rate'] = obj.Rate
      invoiceDataObject['price'] = obj.Price
      invoiceData.push(invoiceDataObject)
    })

    let additionalInputText = []
    selectedRowData.additional_value.map((obj) => {
      let additionalInputTextObject = {}
      additionalInputTextObject['additional_text'] = obj.additional_text
      additionalInputTextObject['additional_value'] = obj.additional_value
      additionalInputText.push(additionalInputTextObject)
    })

    previewModalDatasetFormat(formData, invoice_number_generation, selectedCustomerData, invoiceData, additionalInputText, company_admin_login_name, org_name, location_type, selectedRowData, dateField, currency).then((dataSet) => {
      // console.log("grid dataset---->>>", dataSet)
      setPreviewModalDataset(dataSet)
      setInvoicPrevieweModal(true);
    })
  }

  const additionalValueCalculation = () => {
    let tempFormData = { ...formData }
    let temp_additionalInputText = additionalInputText.slice()
    let subTotalWithGst = tempFormData.sub_total.valueOf()

    //
    if (formData.is_gst_applicable == true) {
      if (formData.is_sgst_applicable == true) {
        subTotalWithGst = subTotalWithGst + formData.sgst.valueOf() + formData.cgst.valueOf()
      }
      if (formData.is_igst_applicable == true) {
        subTotalWithGst = subTotalWithGst + formData.igst.valueOf()

      }
    }

    let positive_additional_value = 0
    let negative_additional_value = 0

    temp_additionalInputText.map((e, index) => {
      // console.log("e.....??????////", e)
      if (e.additional_value > 0) {
        positive_additional_value += parseFloat(e.additional_value)
        // console.log("??//11??", 111)
      }
      if (e.additional_value < 0) {
        negative_additional_value += parseFloat(e.additional_value)
        // console.log("??//22??", 222)
      }
    })
    // console.log("positive,negative>>>", positive_additional_value, negative_additional_value, subTotalWithGst)
    // tempFormData['total'] = (subTotalWithGst + positive_additional_value) + negative_additional_value
    // setFormData(tempFormData)
    let total = (parseFloat(subTotalWithGst) + parseFloat(positive_additional_value)) + parseFloat(negative_additional_value)

    return parseFloat(total).toFixed(2)
  }

  const handleAdditionalText_Input = (e, index, type) => {
    // console.log("<<<<<<>>>>:::::e::::",e)
    // console.log("<<<<<<>>>>:::::index::::",index)
    //console.log("<<<<<<>>>>::::::type:::", type)
    const { name, value } = e.target
    //console.log("<<<<<<>>>>:::::name::::", name)
    //console.log("<<<<<<>>>>:::::value::::", value)

    let tempFormData = { ...formData }
    let tempAdditionalInputText = additionalInputText.slice()
    let tempAdditionalInputTextError = additionalInputTextError.slice()
    if (type == 'additional_text') {
      tempAdditionalInputText[index].additional_text = value
      tempAdditionalInputTextError[index].additional_error = ""
    }
    if (type == 'additional_value') {
      // console.log("(/^-?\d*\.?\d{0,6}$/).match(value)",(/^-?\d*\.?\d{0,6}$/).match(value))
      // if (value[0]=='-'){}
      var re = /^-?\d*\.?\d{0,2}$/;
      var isValid = (value.match(re) !== null);

      if (isValid) {
        tempAdditionalInputText[index].additional_value = value
        tempAdditionalInputTextError[index].additional_error = ""
        let total = additionalValueCalculation()
        tempFormData['total'] = total.valueOf()
        setFormData(tempFormData)
      }
    }
    setAdditionalInputText(tempAdditionalInputText)
    setAdditionalInputTextError(tempAdditionalInputTextError)
    //console.log("additionalInputTextError--------1!!!>>>>>", additionalInputText)
  }

  const handleClickAdditionalInputField = () => {
    let modifiedAdditionalInputTextObj = { additional_text: "", additional_value: "" }
    let temp_additionalInputText = additionalInputText.slice()
    let temp_additionalInputText_copy = [...temp_additionalInputText, modifiedAdditionalInputTextObj]
    let modifiedAdditionalInputText = { additional_error: "" }
    let tempAdditionalInputTextError = additionalInputTextError.slice()
    let tempAdditionalInputTextErrorCopy = [...tempAdditionalInputTextError, modifiedAdditionalInputText]
    setAdditionalInputText(temp_additionalInputText_copy)
    setAdditionalInputTextError(tempAdditionalInputTextErrorCopy)
  }



  const handleChangeInvoiceFormData = (e, type) => {
    // console.log(">>>e<<<<", e)
    // const { name, value } = e.target
    // console.log("_____name>>>>>>>", name)
    // console.log("_____value>>>>>>>", value)
    // console.log("_____type>>>>>>>", type)
    let tempFormData = { ...formData };
    let tempErrorFormData = { ...errorFormData }

    if (type == "invoice_number") {
      if (e.target.value == "") {
        tempErrorFormData['invoice_number_error'] = "required input field !"
        tempFormData["invoice_number"] = ""
      } else {
        tempFormData["invoice_number"] = e.target.value
        tempErrorFormData['invoice_number_error'] = ""
      }
    }

    if (type == "company_name") {
      if (e) {
        // console.log(">>>e<<<<", e)
        tempFormData["company_name"] = e

        tempErrorFormData['company_name_error'] = ""
        // console.log("customerTotalResponse---->>>()>>>>>", customerTotalResponse)

        let selectedCustomerData = customerTotalResponse.filter(res => {
          return res._id == e.value;
        });


        // console.log("selectedCustomerData---->>>()>>>>>", selectedCustomerData)

        let addressone = selectedCustomerData[0].hasOwnProperty('address_line1') ? selectedCustomerData[0].address_line1 : "";
        let addresstwo = selectedCustomerData[0].hasOwnProperty('address_line2') ? selectedCustomerData[0].address_line2 : ""
        let city = selectedCustomerData[0].hasOwnProperty('city') ? selectedCustomerData[0].city : ""
        let country = selectedCustomerData[0].hasOwnProperty('country') ? selectedCustomerData[0].country : ""
        let zip = selectedCustomerData[0].hasOwnProperty('zip_code') ? selectedCustomerData[0].zip_code : ""

        let addressArry = []
        if (addressone != "") {
          addressArry.push(addressone)
        }
        if (addresstwo != "") {
          addressArry.push(addresstwo)
        }
        if (city != "") {
          addressArry.push(city)
        }
        if (country != "") {
          addressArry.push(country)
        }
        if (zip != "") {
          addressArry.push(zip)
        }

        let addressJoin = addressArry.join()
        tempFormData['address'] = addressJoin

        if (selectedCustomerData[0].bank_details.length > 1) {
          selectedCustomerData[0].bank_details.map((obj, index) => {
            tempFormData['cust_bank_name'] = obj.hasOwnProperty('bank_name') ? obj.bank_name : ""

            tempFormData['cust_bank_account_number'] = obj.hasOwnProperty('account_no') ? obj.account_no : ""
          })

        }
        //tempFormData['address'] = addressone + '' + addresstwo + '' + city + '' + country + '' + zip


        tempFormData['gst_number'] = selectedCustomerData[0].hasOwnProperty('gst_number') ? selectedCustomerData[0].gst_number : ""
        // console.log("selectedCustomerData>>>>>>>", selectedCustomerData)

        tempFormData['currency'] = selectedCustomerData[0].hasOwnProperty('currency') ? selectedCustomerData[0].currency : ""

        tempFormData['is_gst_applicable'] = selectedCustomerData[0].hasOwnProperty('is_gst_applicable') ? selectedCustomerData[0].is_gst_applicable : false

        tempFormData['is_sgst_applicable'] = selectedCustomerData[0].hasOwnProperty('is_sgst_applicable') ? selectedCustomerData[0].is_sgst_applicable : false

        tempFormData['is_igst_applicable'] = selectedCustomerData[0].hasOwnProperty('is_igst_applicable') ? selectedCustomerData[0].is_igst_applicable : false

        //reset calculation
        setInvoiceData([{ description: "", quantity: "", rate: "", price: "" }])
        setInvoiceDataError([{ description_error: "", quantity_error: "", rate_error: "" }])


        tempFormData["sub_total"] = 0
        tempFormData["sgst"] = 0
        tempFormData["cgst"] = 0
        tempFormData["igst"] = 0
        //tempFormData["sgst_percentage"] = 0
        //tempFormData["cgst_percentage"] = 0
        tempFormData["total"] = 0
        //tempFormData["is_gst_applicable"] = false
        //tempFormData["is_igst_applicable"] = false
        //tempFormData["is_sgst_applicable"] = false
        tempFormData["igst_percentage"] = 0
        tempFormData["currency"] = "INR"


        setAdditionalInputText([{ additional_text: "", additional_value: "" }])
        setAdditionalInputTextError([{ additional_error: "" }])


      } else {
        tempErrorFormData['company_name_error'] = "required input field !"
        tempFormData["company_name"] = ""
        setInvoiceData([{ description: "", quantity: "", rate: "", price: "" }])
        setInvoiceDataError([{ description_error: "", quantity_error: "", rate_error: "" }])

        tempFormData["address"] = ""
        tempFormData["gst_number"] = ""
        tempFormData["sub_total"] = 0
        tempFormData["sgst"] = 0
        tempFormData["cgst"] = 0
        tempFormData["igst"] = 0
        tempFormData["sgst_percentage"] = 0
        tempFormData["cgst_percentage"] = 0
        tempFormData["total"] = 0
        tempFormData["is_gst_applicable"] = false
        tempFormData["is_igst_applicable"] = false
        tempFormData["is_sgst_applicable"] = false
        tempFormData["igst_percentage"] = 0
        tempFormData["currency"] = "INR"


        setAdditionalInputText([{ additional_text: "", additional_value: "" }])
        setAdditionalInputTextError([{ additional_error: "" }])
      }
    }

    if (type == "address") {
      if (e.target.value == "") {
        tempErrorFormData['address_error'] = "required input field !"
        tempFormData["address"] = ""
      } else {
        tempFormData["address"] = e.target.value
        tempErrorFormData['address_error'] = ""
      }
    }

    if (type == "gst_number") {
      if (e.target.value == "") {
        tempErrorFormData['gst_number_error'] = "required input field !"
        tempFormData["gst_number"] = ""
      } else {
        tempFormData["gst_number"] = e.target.value
        tempErrorFormData['gst_number_error'] = ""
      }
    }



    // if (type == "customer_email") {
    //   if (e) {
    //     // console.log(">>>e<<<<", e)
    //     tempFormData["email"] = e
    //     tempErrorFormData['email_error'] = ""
    //     let selectedCustomerData = customerEmailResponse.filter(res => {
    //       return res._id == e.value;

    //     });
    //     console.log("selectedCustomerData-----", selectedCustomerData)


    //   } else {
    //     tempErrorFormData['company_name_error'] = "required input field !"
    //     tempFormData["company_name"] = ""

    //   }
    // }

    // console.log("tempFormData===", tempFormData)
    setFormData(tempFormData)
    setErrorFormData(tempErrorFormData)
  }

  //delete functionality of Invoice system
  const handleDeleteInvoiceData = (i) => {
    let tempInvoiceData = invoiceData.slice()
    tempInvoiceData.splice(i, 1);
    setInvoiceData(tempInvoiceData);
  }
  useEffect(() => {
    totalSubtotalWithGst()
  }, [invoiceData])

  // save button 

  const handleSaveData = () => {
    const { loaderStateTrue, loaderStateFalse } = props;
    let valid = form_validation()
    if (parseInt(formData.total) > 0) {
      // console.log("valid///", valid)
      if (valid) {
        //console.log("????????????---valid-->>>>>", valid)
        let org_id = props.userCredentials.user_details.org_id
        let admin_id = props.userCredentials.id
        let admin_name = props.userCredentials.user_details.user_name
        let orgcurrency = props.userCredentials?.user_details?.org_percentages?.currency

        let conversion_allowance_percentage = props.userCredentials?.user_details?.org_percentages?.conversion_allowance_percentage

        invoiceFormatingFormData(formData, org_id, admin_id, admin_name, invoiceData, invoice_number_generation, additionalInputText, conversion_allowance_percentage, orgcurrency, dateField).then((dataSet) => {
          // console.log("?/?dataset?/?", dataSet)
          loaderStateTrue();
          invoiceAdd(dataSet).then((response) => {
            //console.log("response>>???<<>>>>", response)

            if (response.length > 0) {
              response.map((res, index) => {
                if (res.success) {
                  setShow(false)
                  resetDataGrid()
                  invoiceModalClose()
                  Utility.toastNotifications(res.message, "Success", "success");
                } else {
                  Utility.toastNotifications(res.message, "Error", "error")
                }
              })
            }
          }

          )
        })

      }
    } else {
      Utility.toastNotifications("Total value is nagative, Please check this!!", "Warning", "warning")
    }
  }


  const form_validation = () => {
    let tempFormData = { ...formData }
    let tempErrorFormData = { ...errorFormData }
    let tempInvoiceData = invoiceData.slice()
    let tempInvoiceDataError = invoiceDataError.slice()
    let tempAdditionalInputText = additionalInputText.slice()
    let tempAdditionalInputTextError = additionalInputTextError.slice()
    let tempPaymentDateError = { ...paymentDateError }
    let valid = true
    /*if (tempFormData.invoice_number == "") {
      tempErrorFormData['invoice_number_error'] = "required field !"
      valid = false
    }*/
    //console.log("--->>>>>>", tempFormData.company_name)
    if (tempFormData.company_name == "") {
      tempPaymentDateError['company_name_error'] = "* required field !"

      valid = false
    }

    // if (tempFormData.invoiceDate == "") {
    //   tempErrorFormData["invoice_date_error"] = "Invalid Field"
    //   valid = false
    // } else {
    //   tempErrorFormData["invoice_date_error"] = ""
    // }
    if (dateField == "") {
      dateFieldError['dateFieldError'] = "* Invalid Field"
      valid = false
    }

    if (tempFormData.company_name == "") {
      tempErrorFormData['company_name_error'] = "* Invalid Field"

      valid = false
    }

    if (tempFormData.company_bank == "") {
      tempErrorFormData['company_bank_error'] = "* Invalid Field"

      valid = false
    }
    if (tempFormData.org_bank == "") {
      tempErrorFormData['org_bank_error'] = "* Invalid Field"

      valid = false
    }

    // if ( == "") {
    //   tempObj["payment_date_error"] = "Invalid Field"
    //   valid = false
    // } else {
    //   tempObj["payment_date_error"] = ""
    // }
    /*if (tempFormData.address == "") {
      tempErrorFormData['address_error'] = "required field !"
      valid = false
    }
    if (tempFormData.gst_number == "") {
      tempErrorFormData['gst_number_error'] = "required field !"
      valid = false
    }*/
    tempInvoiceData.map((value, index) => {
      if (value.description == "") {
        tempInvoiceDataError[index]['description_error'] = "* required field !"
        valid = false
      }
      if (value.quantity == "") {
        tempInvoiceDataError[index]['quantity_error'] = "* required field !"
        valid = false
      }
      if (value.rate == "") {
        tempInvoiceDataError[index]['rate_error'] = "* required field !"
        valid = false
      }
      setInvoiceDataError(tempInvoiceDataError)
    })
    tempAdditionalInputText.map((value, index) => {

      if (value.additional_text != "" && value.additional_value == "") {
        valid = false
        tempAdditionalInputTextError[index].additional_error = "* please add additional value"
      }
      if (value.additional_text == "" && value.additional_value != "") {
        valid = false
        tempAdditionalInputTextError[index].additional_error = "* please add additional text"
      }

    })

    setAdditionalInputTextError(tempAdditionalInputTextError)
    setErrorFormData(tempErrorFormData)
    //console.log("___errorData___", errorFormData)
    return valid
  }

  const onGridReady = (params) => {
    setgridparams(params)
    setGridApi(params.api)
    setGridColumnApi(params.columnApi)
    var datasource = serverSideDataSource()
    params.api.setDatasource(datasource);
  };

  const serverSideDataSource = () => {
    //console.log("===================")
    return {
      getRows(params) {
        const { startRow, endRow, filterModel, sortModel } = params
        const { loaderStateTrue, loaderStateFalse } = props;
        loaderStateTrue();
        let filters = {};
        let globalQueryParamshash = {};
        if (searchValue != "") {
          globalQueryParamshash['customer_name'] = searchValue
          filters['filter_op'] = { "customer_name": "substring" }
        }
        // console.log("filterDate==== serverside", filterDate)
        if (filterDate.from && filterDate.to) {
          globalQueryParamshash["start_date"] = filterDate.from ? moment(new Date(filterDate.from.year + "-" + filterDate.from.month + "-" + filterDate.from.day)).format('YYYY-MM-DD') : '';
          globalQueryParamshash["end_date"] = filterDate.to ? moment(new Date(filterDate.to.year + "-" + filterDate.to.month + "-" + filterDate.to.day)).format('YYYY-MM-DD') : '';
        }

        if (selectedPaymentStatus != "") {
          /*let paymentstatus = []
          selectedPaymentStatus.map((val, idx) => {
            paymentstatus.push(val.value)
          })*/

          globalQueryParamshash["payment_status"] = selectedPaymentStatus.value;
        }
        if (searchInputAmountValue != "") {
          globalQueryParamshash['calculation.total'] = searchInputAmountValue
          filters['filter_op'] = { "calculation.total": amountLessOrGreterFormData.less_amount ? "lte" : "gte" }
        }

        globalQueryParamshash["offset"] = startRow;
        globalQueryParamshash["limit"] = endRow;
        // globalQueryParamshash["limit"] = endRow;

        filters['filters'] = globalQueryParamshash

        invoiceListing(filters).then((response) => {
          // console.log("response-----...", JSON.stringify(response) )
          // console.log("payment_status-----...", response.data[0].payment_status )
          if (response.success) {
            params.successCallback(response.data, response.total);
          } else {
            // console.error(error);
            params.failCallback();
            Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
          }
          loaderStateFalse();
        }).catch((error) => {
          loaderStateFalse();
        });


      }
    };
  }

  const customerList = (customerName) => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    loaderStateTrue();
    let tempFormData = { ...formData }
    tempFormData['cgst_percentage'] = userCredentials.hasOwnProperty('user_details') && userCredentials.user_details.hasOwnProperty('org_percentages') && userCredentials.user_details.org_percentages.hasOwnProperty('cgst_percentage') ? userCredentials.user_details.org_percentages.cgst_percentage : "",


      tempFormData['sgst_percentage'] = userCredentials.hasOwnProperty('user_details') && userCredentials.user_details.hasOwnProperty('org_percentages') && userCredentials.user_details.org_percentages.hasOwnProperty('sgst_percentage') ? userCredentials.user_details.org_percentages.sgst_percentage : "",

      tempFormData['igst_percentage'] = userCredentials.hasOwnProperty('user_details') && userCredentials.user_details.hasOwnProperty('org_percentages') && userCredentials.user_details.org_percentages.hasOwnProperty('igst_percentage') ? userCredentials.user_details.org_percentages.igst_percentage : "",

      setFormData(tempFormData)

    /*let data = {
      "org_id": userCredentials.user_details.org_id,
      "active": true

    }
    let filters = {
      "filters": data
    }*/




    let filters = {};
    let globalQueryParamshash = {};
    if (customerName != "") {
      globalQueryParamshash['name'] = customerName
      filters['filter_op'] = { "name": "substring", "customer_type": "ne" }
    }
    globalQueryParamshash["org_id"] = userCredentials.user_details.org_id;
    globalQueryParamshash["customer_type"] = 'vendor';
    globalQueryParamshash["active"] = true;

    filters['filters'] = globalQueryParamshash

    customerListing(filters).then((response) => {
      //console.log("filters=======", filters)
      //console.log("response=======>", response)
      let arry = []
      if (response.success) {
        if (response.data.length > 0) {
          setCustomerTotalResponse(response.data)
          response.data.map((data, index) => {
            arry.push({ label: data.name, value: data._id })
          })
          setCustomersList(arry)
          setShow(true);
        } else {
          // console.log("ok")
          setcustomeraddflag(true)
        }
      } else {
        Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
      }
      loaderStateFalse();
    }).catch((error) => {
      loaderStateFalse();
    });

  }

  //org bank change handle change
  const handleChangeOrgBankDetails = (e) => {
    let orgBankDetailsArray = []
    if (globalState.LoginReducer.userCredentials.user_details.org_bank_details.length > 1) {
      globalState.LoginReducer.userCredentials.user_details.org_bank_details.map((obj, index) => {
        orgBankDetailsArray.push({ label: obj.account_no, value: obj.account_no })
      })
    }
    // console.log("orgBankDetailsArray==", orgBankDetailsArray)
  }

  const resetDataGrid = () => {
    gridparams.api.purgeServerSideCache(null)
    var datasource = serverSideDataSource()
    gridparams.api.setDatasource(datasource);
    // setCustomerTotalResponse("")
  }
  const confirmationModalShowFoInvoiceDelete = (params) => {
    // console.log("params============", params)
    setInvoiceCancelModalShow(true)
    setInvoiceDeleteObj(params.data)
    setInvoiceNumberContent(params.data?.invoice_number)

  }

  const confirmationModalHideFoInvoiceDelete = () => {
    setInvoiceCancelModalShow(false)
    setInvoiceNumberContent("")

  }

  const deleteInvoiceConfirmFunction = () => {
    const promise = new Promise((resolve, reject) => {
      const { loaderStateTrue, loaderStateFalse } = props;
      invoiceDeleteObj
      // console.log("invoiceDeleteObj========", invoiceDeleteObj)
      loaderStateTrue();
      let data = {
        "id": [invoiceDeleteObj._id]
      };
      // console.log("data==========", data)
      invoiceRowDelete(data).then((response) => {
        response.data.map((val) => {
          if (val.success) {
            Utility.toastNotifications(val.message, "Success", "success");
            resetDataGrid();
            confirmationModalHideFoInvoiceDelete();
            resolve(response)
          }
        })
        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    })
    return promise;
  }

  //invoice number creation functionality  
  const invoiceNumberHandleInputChange = (e) => {

    const { name, value } = e.target;
    let temp_invoice_number_generation = { ...invoice_number_generation }

    if (name == 'invoice4') {
      temp_invoice_number_generation.invoice4 = e.target.value;
    }
    setInvoice_number_generation(temp_invoice_number_generation)
    //console.log(">>>>>>>>><>>.", invoice_number_generation)
  }


  const paymentOptionType = (event, type) => {
    let fromDataTemp = Object.assign({}, paymentType);
    let tempObj = Object.assign({}, formPaymentErr)

    if (type == "partialPayment") {
      if (event.target.checked) {
        fromDataTemp['pertial_payment'] = true;
        fromDataTemp['full_payment'] = false;
        tempObj['pertial_full_payment_error'] = "";
      } else {
        tempObj['pertial_full_payment_error'] = "";
      }
    }

    if (type == "fullPayment") {
      if (event.target.checked) {
        fromDataTemp['full_payment'] = true;
        fromDataTemp['pertial_payment'] = false;
        tempObj['pertial_full_payment_error'] = "";
      } else {
        tempObj['pertial_full_payment_error'] = "";
      }
    }
    setPaymentType(fromDataTemp)
    setformPaymentErr(tempObj)
  }

  const checkValidPaymentData = () => {
    let valid = true
    let tempObj = Object.assign({}, formPaymentErr)
    let fromDataTemp = Object.assign({}, paymentType);

    if (paymentDate == "") {
      tempObj["payment_date_error"] = "* Invalid Field"
      valid = false
    } else {
      tempObj["payment_date_error"] = ""
    }

    if (conversionAmount == "" || isNaN(conversionAmount)) {
      tempObj["total_amount_errpr"] = "* Invalid Field"
      valid = false
    } else {
      tempObj["total_amount_errpr"] = ""
    }

    if (fromDataTemp.pertial_payment == false && fromDataTemp.full_payment == false) {
      tempObj['pertial_full_payment_error'] = "* Invalid Field"
      valid = false;
    } else {
      tempObj['pertial_full_payment_error'] = ""
    }

    setPaymentType(fromDataTemp)
    setformPaymentErr(tempObj)
    return valid
  }


  const handleSubmitPayment = () => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    let valid = checkValidPaymentData()
    if (valid) {
      paymentInvoiceFormatingFormData(userCredentials, selectedData, conversionAmount, amountAfterConversion, paymentDate, paymentType, comment, tdsAmount).then((dataSet) => {
        // console.log("add invoice submit dataset", dataSet)
        loaderStateTrue();
        paymentInvoiceAdd(dataSet).then((response) => {
          if (response.length > 0) {
            response.map((res, index) => {
              //console.log("res============",res)
              if (res.success) {
                resetDataGrid()
                payNowModalClose()
                let invoice_id = res.data?.invoice_id
                paymentInvoiceListing("pay_now_success", invoice_id)
                setpaymentReceiptModalShow(true)
                Utility.toastNotifications(res.message, "Success", "success");
              } else {
                Utility.toastNotifications(res.message, "Error", "error")
              }
            })
          }
        }

        )
      })
    }
  }

  const paymentInvoiceListing = (type = "", invoice_id) => {
    const { loaderStateTrue, loaderStateFalse } = props;
    let filters = {};
    let globalQueryParamshash = {};
    //globalQueryParamshash["invoice_number"] = selectedData?.data?.invoice_number;
    if (type == "pay_now_success") {
      globalQueryParamshash["invoice_id"] = invoice_id;
    } else {
      globalQueryParamshash["invoice_id"] = selectedData?.data?._id;
    }
    filters['filters'] = globalQueryParamshash
    loaderStateTrue()
    paymentInvoiceList(filters).then((response) => {
      if (response.success) {
        //console.log("response========", response)
        let totalValue = 0
        let lastPaymentType = []
        response.data.map((res) => {
          //console.log("res===========", res)
          totalValue = parseFloat(totalValue) + parseFloat(res.amount_after_conversion)
          if (res.payment_type) {
            lastPaymentType.push(res.payment_type)
          }

        })
        setPaymentReceiptData(response.data)
        setTotalReceptAmount(totalValue)
        setLastPaymentType(lastPaymentType)
      }

      loaderStateFalse();
    }).catch((error) => {
      loaderStateFalse();
    });
  }

  useEffect(() => {
    //console.log("paymentReceiptData====", paymentReceiptData)
  }, [paymentReceiptData])

  const deletePaymentRowFunction = (id) => {
    setpaymentReceiptDeleteModalShow(true)
    setPaymentDeleteObj(id)
  }

  const deletePaymentRowModalHide = () => {
    setpaymentReceiptDeleteModalShow(false)
  }

  const deletePaymentRowConfirmFunction = () => {
    const promise = new Promise((resolve, reject) => {
      const { loaderStateTrue, loaderStateFalse } = props;
      paymentDeleteObj
      loaderStateTrue();
      let data = {
        "id": [paymentDeleteObj]
      };
      paymentInvoiceListRowDelete(data).then((response) => {
        response.data.map((val) => {
          if (val.success) {
            Utility.toastNotifications(val.message, "Success", "success");
            paymentInvoiceListing();
            deletePaymentRowModalHide();
            resolve(response)
          }
        })
        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    })
    return promise;
  }

  const prinData = () => {
    setPrint(true)
  }

  const customerEmailList = (customerEmail) => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    loaderStateTrue();
    //console.log("customerEmail---",customerEmail)
    let filters = {};
    let globalQueryParamshash = {};
    if (customerEmail != "") {
      globalQueryParamshash['email'] = customerEmail
      filters['filter_op'] = { "email": "substring" }
    }
    globalQueryParamshash["org_id"] = userCredentials.user_details.org_id;
    filters['filters'] = globalQueryParamshash
    customerEmailHistoryListing(filters).then((response) => {
      let arry = []
      if (response.success) {

        if (response.data.length > 0) {
          setCustomerEmailResponse(response.data)
          response.data.map((data, index) => {
            arry.push({ label: data.email, value: data.email })
          })
          setCustomersEmailHistoryList(arry)
          setBlurEmail(false);
        } else {
          setBlurEmail(true);
        }


        //setShow(true);
      } else {
        Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
      }
      loaderStateFalse();
    }).catch((error) => {
      loaderStateFalse();
    });

  }

  const sendMailHandleOnInputChange = (e, type) => {
    //console.log("type====", type)
    //console.log("e====", e)
    if (e != "") {
      customerEmailList(e)
      //console.log("e==yes==")
    }

  }

  const handleChangemail = (e) => {
    setmailList(e)
  }

  const mailSendhandleBlur = (e) => {
    if (blurMailFlag) {
      var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      if (!expr.test(e.target.value)) {
        Utility.toastNotifications("Please enter valid email", "Warning", "warning")
      } else {
        let mailObject = { value: e.target.value, label: e.target.value }
        setmailList(oldArray => [...oldArray, mailObject]);
      }

    }

  }


  useEffect(() => {
    // console.log("mailList===", mailList)
  }, [mailList])


  const clickMailSend = () => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    // console.log("mailList===", mailList)
    // console.log("selectedData===", selectedData)
    if (mailList.length > 0) {
      loaderStateTrue();
      let array = []
      mailList.map((val, idx) => {
        let _hash = {}
        _hash['invoice_number'] = selectedData?.data?.invoice_number
        _hash['org_id'] = selectedData.data?.cust_details?.org_id
        _hash['cust_id'] = selectedData.data?.cust_details?._id
        _hash['email'] = val.label
        array.push(_hash)
      })

      // console.log("array=====", array)

      emailHistoryAdd(array).then((response) => {
        let arry = []

        response.map((data, index) => {
          //sendMailModalClose()
          setmailList([])
          setBlurEmail(false)
          if (data.success) {
            sendMailDataFunction()
            sendMailModalClose()
            // Utility.toastNotifications(data.message, "Success", "success")
          } else {
            Utility.toastNotifications(data.message, "Error", "error")
          }
        })



        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });


    } else {
      Utility.toastNotifications("Please enter valid email", "Warning", "warning")
    }
  }

  //customer add
  const openCustomerAddModal = () => {
    modefyCurrency()
    countryModefy()
    settravailleursModal(true)
  }

  const closeTravailleursModal = () => {
    const { t } = props
    settravailleursModal(false)
    resetCustomerModalContent()
  }

  //Image url crop 
  const addInputProfileImageChanged = (event) => {
    let targetFileSplit = event.target.files[0].name.split('.');
    let lastElement = targetFileSplit.pop();
    let tempfromData = { ...fromData };
    let user_profile_image = {
      "file_name": "",
      "file_obj": ""
    };
    if (lastElement == 'JPEG' || lastElement == 'jpeg' || lastElement == 'jpg' || lastElement == 'JPG' || lastElement == 'png' || lastElement == 'PNG' || lastElement == '') {
      const fsize = event.target.files[0].size;
      const file = Math.round((fsize / 1024));
      if (file >= 300) {
        Utility.toastNotifications(props.t('imageUploadAlert'), "Warning", "warning");
      } else {
        setimageCropModalFlag(true)
        if (event.target.files && event.target.files.length > 0) {
          const reader = new FileReader();
          reader.addEventListener('load', () =>

            setsrc(reader.result)
          );
          reader.readAsDataURL(event.target.files[0]);
          user_profile_image["file_name"] = event.target.files[0].name
          user_profile_image["file_obj"] = ""
          tempfromData["profileImage"] = user_profile_image
          setfromData(tempfromData)
          setaddProfileImagePreviewShow(true)

          /*this.setState({
            fromData,
            workerModalChange: true,
            traprofileImageError: "",
            addProfileImagePreviewShow: true,
            addProfileImageError: "",
          })*/

        }
      }

    } else {
      fromData["profileImage"] = ""
      setaddProfileImagePreviewShow(false)
      setfromData(fromData)
      setaddprofileImageSelected('Add Image')

    }
  }


  const onImageLoaded = (image) => {
    //console.log("onImageLoaded=====", image)
    imageRef = image;
  };

  const onCropComplete = (crop) => {
    makeClientCrop(crop);
    setsaveButtonDisableEditModal(false)
    setprofileImageChangeEditMode(true)

  };

  const makeClientCrop = async (crop) => {
    let tempfromData = { ...fromData }
    if (imageRef && crop.width && crop.height) {
      const croppedImageUrl = await getCroppedImg(
        imageRef,
        crop,
        'newFile.jpeg'
      );
      let user_profile_image = {}

      setaddprofileImageSelected(croppedImageUrl)

      user_profile_image["file_name"] = tempfromData.profileImage.file_name
      user_profile_image["file_obj"] = croppedImageUrl
      tempfromData["profileImage"] = user_profile_image
      setfromData(tempfromData)

    }
  }

  const getCroppedImg = (image, crop, fileName) => {
    const canvas = document.createElement('canvas');
    const pixelRatio = window.devicePixelRatio;
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    const ctx = canvas.getContext('2d');

    canvas.width = crop.width * pixelRatio * scaleX;
    canvas.height = crop.height * pixelRatio * scaleY;

    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    ctx.imageSmoothingQuality = 'high';

    ctx.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width * scaleX,
      crop.height * scaleY
    );

    const base64Image = canvas.toDataURL('image/jpeg');
    return base64Image

  }

  const onCropChange = (crop, percentCrop) => {
    setcrop(crop);
  };

  const imageCropModalShow = () => {

    setimageCropModalFlag(true)
  }

  const imageCropModalHide = () => {
    let tempfromData = { ...fromData }
    tempfromData["profileImage"] = ""
    setimageCropModalFlag(false)
    setfromData(tempfromData)
    setaddProfileImagePreviewShow(false)
    setsaveButtonDisableEditModal(true)
    setaddprofileImageSelected(require('../../../../Utility/Public/images/profile-back.png'))
    /* this.setState({
         imageCropModalFlag: false,
         addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
         addProfileImageError: "",
         fromData,
         addProfileImagePreviewShow: false,
         saveButtonDisableEditModal: true
     })*/

  }

  const imageCropDataSave = () => {
    setimageCropModalFlag(false)
  }

  const handelChange = (event, type) => {
    // console.log("event=======", event)
    // console.log("type=======", type)

    let fromDataTemp = Object.assign({}, fromData);
    let fromDataTempError = Object.assign({}, fromDataError);

    if (type == "name") {
      if (event.target.value != "") {
        fromDataTemp['name'] = event.target.value;
        fromDataTempError['name'] = ""
      } else {
        fromDataTemp['name'] = "";
        fromDataTempError['name'] = props.t('requiredField')
      }
    }

    if (type == "email") {
      if (event.target.value != "") {
        fromDataTemp['email'] = event.target.value;;
        fromDataTempError['email'] = ""
      } else {
        fromDataTemp['email'] = "";
        fromDataTempError['email'] = ""
      }
    }

    if (type == "ph_no") {
      if (event.target.value == "") {
        fromDataTemp['ph_no'] = event.target.value;
        fromDataTempError['ph_no'] = ""
      } else {
        let phoneValidate = HomeUtility.validate_Phone_Number(event.target.value);
        if (phoneValidate) {
          fromDataTemp['ph_no'] = event.target.value;
          fromDataTempError['ph_no'] = ""

        } else {
          fromDataTemp['ph_no'] = event.target.value;
          fromDataTempError['ph_no'] = props.t('validphonenumber')
        }
      }
    }

    if (type == "address_line1") {
      if (event.target.value != "") {
        fromDataTemp['address_line1'] = event.target.value;;
        fromDataTempError['address_line1'] = ""
      } else {
        fromDataTemp['address_line1'] = "";
        fromDataTempError['address_line1'] = ""
      }
    }

    if (type == "address_line2") {
      if (event.target.value != "") {
        fromDataTemp['address_line2'] = event.target.value;;
        fromDataTempError['address_line2'] = ""
      } else {
        fromDataTemp['address_line2'] = "";
        fromDataTempError['address_line2'] = ""
      }
    }

    if (type == "city") {
      if (event.target.value != "") {
        fromDataTemp['city'] = event.target.value;;
        fromDataTempError['city'] = ""
      } else {
        fromDataTemp['city'] = "";
        fromDataTempError['city'] = ""
      }
    }

    if (type == "state") {
      if (event.target.value != "") {
        fromDataTemp['state'] = event.target.value;;
        fromDataTempError['state'] = ""
      } else {
        fromDataTemp['state'] = "";
        fromDataTempError['state'] = ""
      }
    }

    if (type == "country") {
      if (event != "") {
        fromDataTemp['country'] = event;
        fromDataTempError['country'] = ""
      } else {
        fromDataTemp['country'] = "";
        fromDataTempError['country'] = ""
      }
    }

    if (type == "zip_code") {
      if (!isNaN(event.target.value) && event.target.value != "") {
        fromDataTemp['zip_code'] = event.target.value;
        fromDataTempError['zip_code'] = ""
      } else {
        fromDataTemp['zip_code'] = "";
        fromDataTempError['zip_code'] = ""
      }
    }
    if (type == "pan_number") {
      if (event.target.value == "") {
        fromDataTemp['pan_number'] = event.target.value;
        fromDataTempError['pan_number'] = ""
      } else {
        let panValidate = HomeUtility.validate_pan_Number(event.target.value);
        if (panValidate) {
          fromDataTemp['pan_number'] = event.target.value;
          fromDataTempError['pan_number'] = ""

        } else {
          fromDataTemp['pan_number'] = event.target.value;
          fromDataTempError['pan_number'] = props.t('validpannumber')
        }
      }
    }

    if (type == "gstn") {
      if (event.target.value == "") {
        fromDataTemp['gstn'] = event.target.value;
        fromDataTempError['gstn'] = ""
      } else {
        let phoneValidate = HomeUtility.validate_gst_Number(event.target.value);
        if (phoneValidate) {
          fromDataTemp['gstn'] = event.target.value;
          fromDataTempError['gstn'] = ""

        } else {
          fromDataTemp['gstn'] = event.target.value;
          fromDataTempError['gstn'] = props.t('validgstinnumber')
        }
      }
    }


    if (type == "active") {
      if (event.target.checked) {
        fromDataTemp['active'] = true;
        fromDataTempError['active'] = ""
      } else {
        fromDataTemp['active'] = false;
        fromDataTempError['active'] = ""
      }
    }

    if (type == "is_gst_applicable") {
      if (event.target.checked) {
        fromDataTemp['is_gst_applicable'] = true;
        fromDataTempError['is_gst_applicable'] = ""
      } else {
        fromDataTemp['is_gst_applicable'] = false;
        fromDataTempError['is_gst_applicable'] = "";
        fromDataTemp['is_sgst_applicable'] = false;
        fromDataTemp['is_igst_applicable'] = false;
        //fromDataTemp['gst_number'] = ""
      }
    }

    if (type == "is_sgst_applicable") {
      if (event.target.checked) {
        fromDataTemp['is_sgst_applicable'] = true;
        fromDataTemp['is_igst_applicable'] = false;
        fromDataTempError['gst_applicable_error'] = "";
      } else {
        fromDataTempError['gst_applicable_error'] = "";
      }
    }

    if (type == "is_igst_applicable") {
      if (event.target.checked) {
        fromDataTemp['is_igst_applicable'] = true;
        fromDataTemp['is_sgst_applicable'] = false;
        fromDataTempError['gst_applicable_error'] = "";
      } else {
        fromDataTempError['gst_applicable_error'] = "";
      }
    }

    if (type == "currency") {
      if (event != "") {
        fromDataTemp['currency'] = event;
        fromDataTempError['currency'] = ""
      } else {
        fromDataTemp['currency'] = "";
        fromDataTempError['currency'] = ""
      }
    }

    if (type == "customer_type") {
      if (event != "") {
        fromDataTemp['customer_type'] = event;
        fromDataTempError['customer_type'] = ""
      } else {
        fromDataTemp['customer_type'] = "";
        fromDataTempError['customer_type'] = ""
      }
    }

    if (type == "tin") {
      if (event.target.value != "") {
        fromDataTemp['tin'] = event.target.value;;
        fromDataTempError['tin'] = ""
      } else {
        fromDataTemp['tin'] = "";
        fromDataTempError['tin'] = ""
      }
    }

    if (type == "tan") {
      if (event.target.value != "") {
        fromDataTemp['tan'] = event.target.value;;
        fromDataTempError['tan'] = ""
      } else {
        fromDataTemp['tan'] = "";
        fromDataTempError['tan'] = ""
      }
    }

    setfromData(fromDataTemp)
    setfromDataError(fromDataTempError)

    setsaveButtonDisableEditModal(false)

  }


  useEffect(() => {
    // console.log("fromData====customer", fromData)
  }, [fromData])

  const validCustomerData = () => {
    let fromDataTemp = Object.assign({}, fromData);
    let fromDataTempError = Object.assign({}, fromDataError);
    let valid = true;

    if (fromDataTemp.name == "") {
      fromDataTempError['name'] = props.t('requiredField')
      valid = false;
    } else {
      fromDataTempError['name'] = ""
    }

    if (fromDataTemp.email != "") {
      var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      if (!expr.test(fromDataTemp.email)) {
        fromDataTempError['email'] = props.t('validEmail')
        valid = false;
      } else {
        fromDataTempError['email'] = ""
      }

    }
    let phoneValidate = HomeUtility.validate_Phone_Number(fromDataTemp.ph_no);
    if (fromDataTemp.ph_no != "") {
      if (phoneValidate) {
        fromDataTempError['ph_no'] = ""
      } else {
        fromDataTempError['ph_no'] = props.t('validphonenumber')
        valid = false;
      }
    }

    if (fromDataTemp.currency == "") {
      fromDataTempError['currency'] = props.t('requiredField')
      valid = false;
    } else {
      fromDataTempError['currency'] = ""
    }


    let panValidate = HomeUtility.validate_pan_Number(fromDataTemp.pan_number);
    if (fromDataTemp.pan_number != "") {
      if (panValidate) {
        fromDataTempError['pan_number'] = ""
      } else {
        fromDataTempError['pan_number'] = props.t('validpannumber')
        valid = false;
      }
    }

    if (fromDataTemp.is_gst_applicable == true) {
      if (fromDataTemp.gstn == "") {
        fromDataTempError['gstn'] = props.t('requiredField')
        valid = false;
      } else {
        let gstinValidate = HomeUtility.validate_gst_Number(fromDataTemp.gstn);
        if (gstinValidate) {
          fromDataTempError['gstn'] = ""
        } else {
          fromDataTempError['gstn'] = props.t('validgstinnumber')
          valid = false;
        }
      }
    }


    if (fromDataTemp.is_sgst_applicable == false && fromDataTemp.is_igst_applicable == false && fromDataTemp.is_gst_applicable == true) {
      fromDataTempError['gst_applicable_error'] = props.t('requiredField')
      valid = false;
    } else {
      fromDataTempError['gst_applicable_error'] = ""
    }

    if (fromDataTemp.customer_type.length == 0) {
      fromDataTempError['customer_type'] = 'Required Field'
      valid = false;
    } else {
      fromDataTempError['customer_type'] = ""
    }

    //Bank details validation start
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();

    let bankAccountNumber = []
    if (tempBankDetails.length > 0) {
      tempBankDetails.map((value, idx) => {
        bankAccountNumber.push(value.account_no)
        if (value.account_no == "") {
          tempBankDetailsError[idx]['account_no'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['account_no'] = ""
        }

        if (value.bank_name == "") {
          tempBankDetailsError[idx]['bank_name'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_name'] = ""
        }
        if (value.bank_address == "") {
          tempBankDetailsError[idx]['bank_address'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_address'] = ""
        }
        if (value.bank_country.length == 0) {
          tempBankDetailsError[idx]['bank_country'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_country'] = ""
        }
        if (value.ifsc_code == "") {
          tempBankDetailsError[idx]['ifsc_code'] = props.t('requiredField')
          valid = false;
        } else {
          if (value.ifsc_code.length == 11) {
            tempBankDetailsError[idx]['ifsc_code'] = ""
          } else {
            value['ifsc_code'] = "";
            tempBankDetailsError[idx]['ifsc_code'] = "IFSC code must be 11 digit"
            valid = false;
          }
        }
      })


    }

    if (acountNumberDuplicates(bankAccountNumber)) {
      valid = false;
      Utility.toastNotifications("Duplicates account number", "Error", "error")
    }

    setbankDetailsError(tempBankDetailsError)


    setfromDataError(fromDataTempError)
    return valid;

  }

  const modefyCurrency = () => {

    const arrWithLabelValue = Currency.map(object => {
      return { ...object, "value": object.currencyCode, "label": `${object.currencyCode}(${object.countryCode})` };
    });
    //console.log("arrWithLabelValue====", arrWithLabelValue)
    setcurrencyList(arrWithLabelValue)
    /*this.setState({
        currencyList: arrWithLabelValue
    })*/

  }

  const countryModefy = () => {

    const countryData = CountryWithCode.map(object => {
      return { ...object, "value": object.country, "label": object.country };
    });
    // console.log("countryData====", countryData)
    setcountryList(countryData)
    /*this.setState({
        countryList: countryData
    })*/
  }

  const companyHandleOnInputChange = (e, type) => {
    // console.log("type====", type)
    // console.log("e====", e)
    if (type == "company_name") {
      if (e != "") {
        customerList(e)
      }
    }
    if (type == "company_bank") {
      if (e != "") {
        //customerList(e)
      }
    }
  }

  const handleChangeReceiveInvoiceFormData = (e, type) => {
    let tempFormData = { ...formData };
    let tempErrorFormData = { ...errorFormData }

    if (type == "invoice_number") {
      if (e.target.value == "") {
        tempErrorFormData['invoice_number_error'] = "* Invalid Field"
        tempFormData["invoice_number"] = ""
      } else {
        tempFormData["invoice_number"] = e.target.value
        tempErrorFormData['invoice_number_error'] = ""
      }
    }

    if (type == "company_name") {
      let bankArry = []
      let bankDetailsArry = [];
      let bankErrorArry = [];
      if (e) {
        // console.log(">>>e<<company name<<", e)
        tempFormData["company_name"] = e
        tempErrorFormData['company_name_error'] = ""
        tempFormData['company_bank'] = "";
        // console.log("customerTotalResponse--->>>", customerTotalResponse)
        let selectedCustomerData = customerTotalResponse.filter(res => {
          return res._id == e.value;

        });
        // console.log("selectedCustomerData---->>>()>>>>>", selectedCustomerData)


        if (selectedCustomerData[0]?.bank_details && selectedCustomerData[0].bank_details.length > 0) {
          selectedCustomerData[0].bank_details.map((b, i) => {

            let hash = { value: b.account_no, label: `${b.account_no}(${b.bank_name})`, account_no: b.account_no, bank_name: b.bank_name, bank_address: b.bank_address, bank_country: b.bank_country, ifsc_code: b.ifsc_code }
            bankArry.push(hash)
            //
            let findBankCountry = CountryWithCode.filter(Bres => {
              return Bres.country == b.bank_country;
            });

            let bankCountry = {}
            if (findBankCountry.length > 0) {
              bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
            }

            let bankhash = {
              "account_no": b.account_no,
              "bank_name": b.bank_name,
              "bank_address": b.bank_address,
              "bank_country": bankCountry,
              "ifsc_code": b.ifsc_code,
            }
            let errorhash = {
              "account_no": "",
              "bank_name": "",
              "bank_address": "",
              "bank_country": "",
              "ifsc_code": "",
            }

            bankDetailsArry.push(bankhash)
            bankErrorArry.push(errorhash)
          })
        }

        // console.log("bankArry===", bankArry)

        setbankaddflag(true)
        setbankList(bankArry)
        setbankDetails(bankDetailsArry)
        setbankDetailsError(bankErrorArry)


        let addressArray = []
        if (selectedCustomerData[0]?.address_line1 != "") {
          addressArray.push(selectedCustomerData[0].address_line1)
        }
        if (selectedCustomerData[0]?.city != "") {
          addressArray.push(selectedCustomerData[0].city)
        }
        if (selectedCustomerData[0]?.country != "") {
          addressArray.push(selectedCustomerData[0].country)
        }
        if (selectedCustomerData[0]?.zip_code != "") {
          addressArray.push(selectedCustomerData[0].zip_code)
        }

        tempFormData['address'] = addressArray.join(",")

        tempFormData['gst_number'] = selectedCustomerData[0].hasOwnProperty('gst_number') ? selectedCustomerData[0].gst_number : ""
        tempFormData['gst_number'] = selectedCustomerData[0].hasOwnProperty('gst_number') ? selectedCustomerData[0].gst_number : ""
        // console.log("selectedCustomerData>>>>>>>", selectedCustomerData)

        tempFormData['currency'] = selectedCustomerData[0].hasOwnProperty('currency') ? selectedCustomerData[0].currency : ""

        tempFormData['is_gst_applicable'] = selectedCustomerData[0].hasOwnProperty('is_gst_applicable') ? selectedCustomerData[0].is_gst_applicable : false

        tempFormData['is_sgst_applicable'] = selectedCustomerData[0].hasOwnProperty('is_sgst_applicable') ? selectedCustomerData[0].is_sgst_applicable : false

        tempFormData['is_igst_applicable'] = selectedCustomerData[0].hasOwnProperty('is_igst_applicable') ? selectedCustomerData[0].is_igst_applicable : false
      } else {
        tempErrorFormData['company_name_error'] = "* Invalid Field"
        tempFormData["company_name"] = ""

        tempFormData["address"] = ""
        tempFormData["gst_number"] = ""
        setbankaddflag(false)
        setbankList(bankArry)
        setbankDetails(bankDetailsArry)
        setbankDetailsError(bankErrorArry)
        tempFormData["company_bank"] = ""

      }
    }

    if (type == "company_bank") {

      if (e) {
        tempFormData["company_bank"] = e
        tempErrorFormData['company_bank_error'] = ""
      } else {
        tempErrorFormData['company_bank_error'] = "* Invalid Field"
        tempFormData["company_bank"] = ""
      }
    }

    if (type == "org_bank") {
      // console.log("org bank details", e)
      if (e) {
        tempFormData["org_bank"] = e
        tempErrorFormData['org_bank_error'] = ""
      } else {
        tempErrorFormData['org_bank_error'] = "* Invalid Field"
        tempFormData["org_bank"] = ""
      }
    }


    if (type == "address") {
      if (e.target.value == "") {
        tempErrorFormData['address_error'] = "* Invalid Field"
        tempFormData["address"] = ""
      } else {
        tempFormData["address"] = e.target.value
        tempErrorFormData['address_error'] = ""
      }
    }

    if (type == "gst_number") {
      if (e.target.value == "") {
        tempErrorFormData['gst_number_error'] = "* Invalid Field"
        tempFormData["gst_number"] = ""
      } else {
        tempFormData["gst_number"] = e.target.value
        tempErrorFormData['gst_number_error'] = ""
      }
    }
    if (type == "is_gst_applicable") {
      if (e.target.checked) {
        tempFormData['is_gst_applicable'] = true;
        tempErrorFormData['is_gst_applicable'] = ""

      } else {
        tempFormData['is_gst_applicable'] = false;
        tempErrorFormData['is_gst_applicable'] = "";
        tempFormData['is_sgst_applicable'] = false;
        tempFormData['is_igst_applicable'] = false;
        tempFormData['sgst_percentage'] = 0;
        tempFormData['cgst_percentage'] = 0;
        tempFormData['igst_percentage'] = 0;

      }
    }
    if (type == "is_sgst_applicable") {
      if (e.target.checked) {
        tempFormData['is_sgst_applicable'] = true;
        tempFormData['is_igst_applicable'] = false;
        tempErrorFormData['gst_applicable_error'] = "";
        tempFormData['sgst_percentage'] = 0;
        tempFormData['cgst_percentage'] = 0;
        let total = additionalValueCalculation()
        tempFormData['total'] = total
      } else {
        tempErrorFormData['gst_applicable_error'] = "";

      }
    }

    if (type == "is_igst_applicable") {
      if (e.target.checked) {
        tempFormData['is_igst_applicable'] = true;
        tempFormData['is_sgst_applicable'] = false;
        tempErrorFormData['gst_applicable_error'] = "";
        tempFormData['igst_percentage'] = 0;
        let total = additionalValueCalculation()
        tempFormData['total'] = total
      } else {
        tempErrorFormData['gst_applicable_error'] = "";
      }
    }
    if (type == "sgst_percentage") {
      if (!isNaN(e.target.value)) {

        tempFormData['sgst_percentage'] = e.target.value;
        tempErrorFormData['sgst_percentage_error'] = ""

      }
    }
    if (type == "cgst_percentage") {
      if (!isNaN(e.target.value)) {

        tempFormData['cgst_percentage'] = e.target.value;
        tempErrorFormData['cgst_percentage_error'] = ""


      }
    }
    if (type == "igst_percentage") {
      if (!isNaN(e.target.value)) {

        tempFormData['igst_percentage'] = e.target.value;
        tempErrorFormData['igst_percentage_error'] = ""

      }
    }
    /*if (type == "less_discount") {
      if (isNaN(e.target.value) && e.target.value != "") {
        tempErrorFormData['less_discount_error'] = "Invalid Field"
        tempFormData["less_discount"] = ""
      } else {
        tempFormData["less_discount"] = e.target.value
        tempErrorFormData['less_discount_error'] = ""
      }
    }*/
    if (type == "sub_total") {
      if (isNaN(e.target.value) && e.target.value != "") {
        tempErrorFormData['sub_total_error'] = "* Invalid Field"
        tempFormData["sub_total"] = ""
      } else {
        tempFormData["sub_total"] = e.target.value
        tempErrorFormData['sub_total_error'] = ""
      }

      //setFormData(tempFormData)
      //console.log("total===========", total)
    }
    /*if (type == "total") {
      if (isNaN(e.target.value) && e.target.value != "") {
        tempErrorFormData['total_error'] = "Invalid Field"
        tempFormData["total"] = ""
      } else {
        tempFormData["total"] = e.target.value
        tempErrorFormData['total_error'] = ""
      }
    }*/

    setFormData(tempFormData)
    //console.log("tempFormData=======", tempFormData)

    setErrorFormData(tempErrorFormData)
  }

  const addCustomer = () => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    let valid = validCustomerData();
    //console.log("valid=====", valid)
    if (valid) {
      formatingFormData(fromData, userCredentials, {}, editedFlag, profileImageChangeEditMode, bankDetails).then((dataSet) => {
        //let dataSet = this.formatingFormData();
        //console.log("dataSet=====", dataSet);
        // return false;

        loaderStateTrue();
        let type = "post";
        let id = ""

        let formDataTemp = Object.assign({}, formData)
        CustomerController.customerAdd(dataSet, id, type).then((response) => {
          //console.log("response=====", response)
          loaderStateFalse();
          if (response.length > 0) {
            response.map((res, index) => {
              if (res.success) {

                let selectedCustomer = { value: res.data._id, label: res.data.name }
                formDataTemp['company_name'] = selectedCustomer;
                userWiseBankDetailsGet(res.data._id)
                closeTravailleursModal();
                customerList(dataSet[0].name)
                setcustomeraddflag(false)

                let addressone = res.data.address_line1;
                let addresstwo = res.data.address_line2
                let city = res.data.city
                let state = res.data.state
                let country = res.data.country
                let zip = res.data.zip_code

                let addressArry = []
                if (addressone != "") {
                  addressArry.push(addressone)
                }
                if (addresstwo != "") {
                  addressArry.push(addresstwo)
                }
                if (city != "") {
                  addressArry.push(city)
                }
                if (state != "") {
                  addressArry.push(state)
                }
                if (country != "") {
                  addressArry.push(country)
                }
                if (zip != "") {
                  addressArry.push(zip)
                }

                let addressJoin = addressArry.join()

                formDataTemp['address'] = addressJoin
                formDataTemp['gst_number'] = res.data.gst_number

                setFormData(formDataTemp)

                Utility.toastNotifications(res.message, "Success", "success");
              } else {
                Utility.toastNotifications(res.message, "Error", "error")
              }
            })
          }
        }).catch((e) => {
          loaderStateFalse();
        })
      })
    }
  }

  const resetCustomerModalContent = () => {
    setfromData({
      "name": "",
      "email": "",
      "ph_no": "",
      "profileImage": "",
      "address_line1": "",
      "address_line2": "",
      "city": "",
      "state": "",
      "country": "",
      "zip_code": "",
      "pan_number": "",
      "gstn": "",
      "active": true,
      "is_gst_applicable": false,
      "is_sgst_applicable": false,
      "is_igst_applicable": false,
      "currency": "",
      "customer_type": { label: "Customer", value: 'customer' },
      "tin": "",
      "tan": ""
    })
    setfromDataError({
      "name": "",
      "email": "",
      "ph_no": "",
      "profileImage": "",
      "address_line1": "",
      "address_line2": "",
      "city": "",
      "state": "",
      "country": "",
      "zip_code": "",
      "pan_number": "",
      "gstn": "",
      "currency": "",
      "gst_applicable_error": "",
      "customer_type": "",
    })
  }

  /*const removeAdditionalBankDetails = (idx, type) => {
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();
    console.log("tempBankDetails======", tempBankDetails)
    console.log("tempBankDetailsError======", tempBankDetailsError)

    tempBankDetails.splice(idx, 1)
    tempBankDetailsError.splice(idx, 1)

    setbankDetails(tempBankDetails)
    setbankDetailsError(tempBankDetailsError)


  }*/

  const removeAdditionalBankDetails = (idx, type) => {
    setDeleteBankDetailsConfirmationAlertModalFlag(true)
    setDeleteBankDetailsObj(idx)
  }

  const deleteBankDetailsConfirmationModalHide = () => {
    setDeleteBankDetailsConfirmationAlertModalFlag(false)
    setDeleteBankDetailsObj("")
  }

  const deleteBankDetailsConfirmationFunction = () => {
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();
    tempBankDetails.splice(deleteBankDetailsObj, 1)
    tempBankDetailsError.splice(deleteBankDetailsObj, 1)

    setbankDetails(tempBankDetails)
    setbankDetailsError(tempBankDetailsError)
    setDeleteBankDetailsConfirmationAlertModalFlag(false)
  }

  const formatInvoiceDateInput = () => {
    if (!dateField.year) return '';
    const Year = dateField.year.toString();
    const Month = dateField.month.toString().padStart(2, 0);
    const Day = dateField.day.toString().padStart(2, 0);
    return `${Day}/${Month}/${Year}`;
  };

  const handleSearchBar = (e) => {
    const { value } = e.target;
    setSearchValue(value)
    // console.log("searchValue", value)
  }
  useEffect(() => {
    if (searchValue.length > 2) {
      resetDataGrid()
    }
    if (searchValue.length == 0 && gridparams) {
      resetDataGrid()
    }
  }, [searchValue])

  const clearSearchValue = () => {
    setSearchValue("")
    resetDataGrid()
  }

  const handleChangeDateRange = (date, name) => {
    if (name == "dateRangeDate") {
      if (date) {
        setFilterDate(date)
      }
    }
  }

  useEffect(() => {
    if (filterDate.from && filterDate.to) {
      resetDataGrid()
    }

  }, [filterDate])

  const formatDateRangeInput = () => {
    if (!filterDate.to) return '';
    const fromDate = filterDate.from
    const fromYear = fromDate.year.toString();
    const fromMonth = fromDate.month.toString().padStart(2, 0);
    const fromDay = fromDate.day.toString().padStart(2, 0);

    const toDate = filterDate.to
    const toYear = toDate.year.toString();
    const toMonth = toDate.month.toString().padStart(2, 0);
    const toDay = toDate.day.toString().padStart(2, 0);

    return `${fromDay}/${fromMonth}/${fromYear} to ${toDay}/${toMonth}/${toYear}`;
  };

  const handleSelectedPaymentStatus = (e) => {
    if (e) {
      setSelectedPaymentStatus(e)
    } else {
      // console.log("3")
      setSelectedPaymentStatus("")
    }
  }

  useEffect(() => {
    if (selectedPaymentStatus) {
      resetDataGrid()
    }
    if (selectedPaymentStatus.length == 0 && gridparams) {
      resetDataGrid()
    }

  }, [selectedPaymentStatus])

  const [amountLessOrGreterFormData, setAmountLessOrGreterFormData] = useState({
    less_amount: false,
    greater_amount: false

  })

  const [searchInputAmountValue, setSearchInputAmountValue] = useState("")

  const handleChangeAmountFilterFormData = (e, type) => {
    let tempAmountLessOrGreterFormData = { ...amountLessOrGreterFormData };

    if (type == "less_amount") {
      if (e.target.checked) {
        tempAmountLessOrGreterFormData['less_amount'] = true;
        tempAmountLessOrGreterFormData['greater_amount'] = false;
      }
    }

    if (type == "greater_amount") {
      if (e.target.checked) {
        tempAmountLessOrGreterFormData['greater_amount'] = true;
        tempAmountLessOrGreterFormData['less_amount'] = false;
      }
    }

    setAmountLessOrGreterFormData(tempAmountLessOrGreterFormData)
  }

  useEffect(() => {
    // console.log("amountLessOrGreterFormData=======", amountLessOrGreterFormData)
  }, [amountLessOrGreterFormData])

  const handleAmountSearchBar = (e) => {
    const { value } = e.target;
    setSearchInputAmountValue(value)
    // console.log("searchInputAmountValue", value)
  }

  const clearSearchAmountValue = () => {
    setSearchInputAmountValue("")
    //resetDataGrid()
    setShowtriger(false);
  }
  const searchAmountOnclick = () => {
    resetDataGrid()
    setShowtriger(false);
  }

  useEffect(() => {

    if (searchInputAmountValue.length == 0 && gridparams) {
      resetDataGrid()
    }
  }, [searchInputAmountValue])



  const handleClick = (event) => {
    setShowtriger(!show);
    setTarget(event.target);
  };

  const clearDateRangeFromToDateFunction = () => {
    setFilterDate({
      from: null,
      to: null
    })
  }

  useEffect(() => {
    if (filterDate.from == null && filterDate.to == null && gridparams) {
      resetDataGrid()
    }

  }, [filterDate])

  const sendMailDataFunction = () => {
    const { loaderStateTrue, loaderStateFalse } = props;
    // console.log("mailList===", mailList)
    // console.log("selectedData===", selectedData)
    let rowData = selectedData?.data
    loaderStateTrue();
    // console.log("array=====", array)
    sendMailDataFormat(mailList, rowData).then((dataSet) => {
      loaderStateTrue();
      sendEmailPost(dataSet[0]).then((response) => {
        if (response.length > 0) {
          response.map((res, index) => {
            if (res.success) {
              console.log("==============1")
              sendMailModalClose()
              resetDataGrid()
              Utility.toastNotifications(res.message, "Success", "success");
            } else {
              Utility.toastNotifications(res.message, "Error", "error")
            }
          })
        }
        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    })
  }


  return (
    <>
      <div className="homepagecontainer">
        <div className="gridcontainer">
          <div className="gridtopviews gridtopviewsroles">
            <div className="rightboxes">
              <button type="button" className="useraddbtn" onClick={invoiceModalfunction}>Add</button>
            </div>

            <CommonSearchFilter
              searchInputFiledDispaly={true}
              handleSearchBar={handleSearchBar}
              searchValue={searchValue}
              clearSearchValue={clearSearchValue}
              searchPlaceHolder="Search customer"
              searchDateRangeDispaly={true}
              handleChangeDateRange={handleChangeDateRange}
              formatDateRangeInput={formatDateRangeInput}
              filterDate={filterDate}
              paymentstatusDisplay={true}
              paymentStatusList={paymentStatusList}
              handleSelectedPaymentStatus={handleSelectedPaymentStatus}
              selectedPaymentStatus={selectedPaymentStatus}
              statusPlaceholder="Choose status"
              amountFilterDisplay={true}

              amountLessOrGreterFormData={amountLessOrGreterFormData}
              handleChangeAmountFilterFormData={handleChangeAmountFilterFormData}
              handleAmountSearchBar={handleAmountSearchBar}
              searchInputAmountValue={searchInputAmountValue}
              clearSearchAmountValue={clearSearchAmountValue}
              searchAmountOnclick={searchAmountOnclick}

              handleClick={handleClick}
              show={show}
              target={target}
              clearDateRangeFromToDateFunction={clearDateRangeFromToDateFunction}

            />

            <div className="clearfix"></div>
            <div className="ag-theme-alpine aggridview agdepart roleviewgrid">
              <AgGridReact
                modules={modules}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                components={components}
                rowSelection="multiple"
                rowModelType="infinite"
                onGridReady={onGridReady}
                rowHeight={62.5}
                headerHeight={47}
                //onSelectionChanged={this.onSelectionChanged.bind(this)}
                cacheBlockSize={20}
                enableRtl={localStorage.getItem('selected_lan_direction') == "rtl" ? true : false}
              />
            </div>

          </div>
        </div>
        < ModalGlobal
          show={invoiceModalShow}
          onHide={invoiceModalClose}
          title='Add Invoice'
          className="modalcustomize mondimension invoiceModal"
          footer={false}
          closeButton={true}
          body={
            < AddEditInvoiceModalContent
              invoiceData={invoiceData}
              handleAddClick={handleAddClick}
              handleInputChange={handleInputChange}
              handleAdditionalText_Input={handleAdditionalText_Input}
              handleClickAdditionalInputField={handleClickAdditionalInputField}
              additionalInputText={additionalInputText}
              formData={formData}
              handleChangeInvoiceFormData={handleChangeInvoiceFormData}
              invoicePreviewModalfunction={invoicePreviewModalfunction}
              handleDeleteInvoiceData={handleDeleteInvoiceData}
              handleSaveData={handleSaveData}
              errorFormData={errorFormData}
              invoiceDataError={invoiceDataError}
              invoiceModalClose={invoiceModalClose}
              invoiceNumberHandleInputChange={invoiceNumberHandleInputChange}
              invoice_number_generation={invoice_number_generation}
              customersList={customersList}
              additionalInputTextError={additionalInputTextError}
              formatInvoiceDateInput={formatInvoiceDateInput}
              handleChangeDateField={handleChangeDateField}
              dateField={dateField}
              dateFieldError={dateFieldError}
              companyHandleOnInputChange={companyHandleOnInputChange}
              customeraddflag={customeraddflag}
              openCustomerAddModal={openCustomerAddModal}
              orgBankListData={orgBankListData}
              customerTotalResponse={customerTotalResponse}
              handleChangeOrgBankDetails={handleChangeOrgBankDetails}
              openbankAddmodal={openbankAddmodal}
              handleChangeReceiveInvoiceFormData={handleChangeReceiveInvoiceFormData}
              bankList={bankList}
              bankaddflag={bankaddflag}
            />
          }

        />
        < ModalGlobal
          show={invoicPrevieweModalShow}
          onHide={invoicPrevieweModalClose}
          title='Invoice'
          className="modalcustomize mondimension invoicePreviewModal"
          footer={false}
          closeButton={true}
          body={
            <InvoicePreviewModalContent
              invoiceData={invoiceData}
              invoicePreviewModalfunctions={invoicePreviewModalfunctions}
              percentages={percentages}
              formData={formData}
              additionalInputText={additionalInputText}
              invoice_number_generation={invoice_number_generation}
              previewModalDataset={previewModalDataset}
              prinData={prinData}

            />
          }
        />

        <ModalGlobal
          show={bankModal}
          onHide={closebankModal}
          title="Bank Details"
          className="modalcustomize mondimension customerModalContent bank_details_modal_inner_body additionalBanckDetails"
          footer={false}
          closeButton={true}
          body={
            <BankDetailsComponent
              countryList={countryList}
              bankDetails={bankDetails}
              bankDetailsError={bankDetailsError}
              handelChangeForBankDetails={handelChangeForBankDetails}
              handelClickBankAdd={handelClickBankAdd}
              submitButton={true}
              bankDetailsSave={bankDetailsSave}
              removeAdditionalBankDetails={removeAdditionalBankDetails}
              removeAdditionalBankDetailsDisplay={true}
            />
          }
        />


        {actionModalflag ?
          <GridActionContent
            styleWidth={position.x}
            styleHight={position.y}
            codeOutsideClickRef={codeOutsideClickRef}
            gridObjData={selectedData}
            deleteButtonShow={true}
            delete={confirmationModalShowFoInvoiceDelete}
            editButtonShow={false}
            deleteButtonLabel="Cancel"
            sendPaynowButtonShow={paymentStatusPendingFlag}
            sendMailButtonShow={setsendMailFlag}
            paymentReceiptButtonShow={paymentReceiptFlag}
            sendPaynow={sendPaynow}
            paymentReceipt={paymentReceipt}
            sendmail={sendmail}
            paynowButtonTitle="Receive Payment"
          />
          : null}

        < ModalGlobal
          show={payNowModalShow}
          onHide={payNowModalClose}
          title='Receive payment'
          className="modalcustomize mondimension invoicePreviewModal paynowModal"
          footer={false}
          closeButton={true}
          body={
            <PaynowModalContent
              invoiceData={invoiceData}
              paymentOptionType={paymentOptionType}
              amountAfterConversion={amountAfterConversion}
              userCredentials={props.userCredentials}
              handleChangePaymentDate={handleChangePaymentDate}
              paymentDate={paymentDate}
              formatDateInput={formatDateInput}
              handleChangeConversionAmount={handleChangeConversionAmount}
              conversionAmount={conversionAmount}
              handleSubmit={handleSubmitPayment}
              formPaymentErr={formPaymentErr}
              selectedData={selectedData}
              paymentType={paymentType}
              handleChangeComment={handleChangeComment}
              comment={comment}
              tdsAmount={tdsAmount}
            />
          }
        />

        <ModalGlobal
          show={paymentReceiptModalShow}
          onHide={paymentReceiptModalClose}
          //title='Payment Receipt'
          className="modalcustomize mondimension invoicePreviewModal"
          footer={false}
          closeButton={true}
          headerShow={false}
          body={
            <PaymentReceiptModalContent
              paymentReceiptModalClose={paymentReceiptModalClose}
              selectedData={selectedData}
              paymentReceiptData={paymentReceiptData}
              totalReceptAmount={totalReceptAmount}
              deletePaymentRowFunction={deletePaymentRowFunction}
              lastPaymentType={lastPaymentType}
            />
          }
        />

        <ModalGlobal
          show={paymentReceiptDeleteModalShow}
          onHide={deletePaymentRowModalHide}
          className="modalcustomize confirmationalertmodal"
          bodyClassName="cancelConfirmationbody"
          headerclassName="close_btn_icon"
          title={props.t('deletePaymentInvoiceTitle')}
          footer={false}
          body={
            <ConfirmationAlert
              BodyFirstContent={props.t('paymentInvoiceDeleteConfirmation')}
              //BodySecondContent={this.state.examDeleteBodySecondContent}
              BodyThirdContent={props.t('paymentInvoiceDeleteAnableGoBack')}
              confirmationButtonContent={props.t('confirm')}
              cancelButtonContent={props.t('cancel')}
              deleteConfirmButton={deletePaymentRowConfirmFunction}
              deleteCancleButton={deletePaymentRowModalHide}
            />
          }
        />

        <ModalGlobal
          show={invoiceCancelModalShow}
          onHide={confirmationModalHideFoInvoiceDelete}
          className="modalcustomize confirmationalertmodal"
          bodyClassName="cancelConfirmationbody"
          headerclassName="close_btn_icon"
          title={props.t('cancelInvoiceTitle')}
          footer={false}
          body={
            <ConfirmationAlert
              BodyFirstContent={props.t('invoiceDeleteConfirmation')}
              BodySecondContent={invoiceNumberContent}
              BodyThirdContent={props.t('invoiceCancelAnableGoBack')}
              confirmationButtonContent={props.t('confirm')}
              cancelButtonContent={props.t('cancel')}
              deleteConfirmButton={deleteInvoiceConfirmFunction}
              deleteCancleButton={confirmationModalHideFoInvoiceDelete}
            />
          }
        />

        < ModalGlobal
          show={sendMailModalShow}
          onHide={sendMailModalClose}
          title='Send mail'
          className="modalcustomize mondimension invoicePreviewModal paynowModal sendMailModal"
          footer={false}
          closeButton={true}
          body={
            <SendMailModalContent
              sendMailHandleOnInputChange={sendMailHandleOnInputChange}
              customersEmailHistoryList={customersEmailHistoryList}
              handleChangemail={handleChangemail}
              mailSendhandleBlur={mailSendhandleBlur}
              mailList={mailList}
              clickMailSend={clickMailSend}
            />
          }
        />

        <ModalGlobal
          show={travailleursModal}
          onHide={closeTravailleursModal}
          title={cusheaderContent}
          className="modalcustomize mondimension customerModalContent cus_vendor_customer"
          footer={false}
          closeButton={true}
          body={
            <CustomerModalContent
              //Image crop
              addInputProfileImageChanged={addInputProfileImageChanged}
              addprofileImageSelected={addprofileImageSelected}
              crop={crop}
              croppedImageUrl={croppedImageUrl}
              src={src}
              onImageLoaded={onImageLoaded}
              onCropComplete={onCropComplete}
              onCropChange={onCropChange}
              imageCropModalShow={imageCropModalShow}
              imageCropModalHide={imageCropModalHide}
              imageCropModalFlag={imageCropModalFlag}
              imageCropDataSave={imageCropDataSave}
              handelChange={handelChange}
              fromData={fromData}
              fromDataError={fromDataError}
              addCustomer={addCustomer}
              addProfileImagePreviewShow={addProfileImagePreviewShow}
              saveButtonDisableEditModal={saveButtonDisableEditModal}
              disabledEmail={false}
              currencyList={currencyList}
              countryList={countryList}

              bankDetails={bankDetails}
              bankDetailsError={bankDetailsError}
              handelClickBankAdd={handelClickBankAdd}
              handelChangeForBankDetails={handelChangeForBankDetails}
              removeAdditionalBankDetails={removeAdditionalBankDetails}
              companyTypeList={companyTypeList}
            />
          }
        />

        <ModalGlobal
          show={deleteBankDetailsConfirmationAlertModalFlag}
          onHide={deleteBankDetailsConfirmationModalHide}
          className="modalcustomize confirmationalertmodal"
          bodyClassName="cancelConfirmationbody"
          headerclassName="close_btn_icon"
          title={props.t('deleteBankDetails')}
          footer={false}
          body={
            <ConfirmationAlert
              BodyFirstContent={props.t('bankDeleteConfirmation')}
              //BodySecondContent={enDeleteBodySecondContent}
              BodyThirdContent={props.t('bankDeleteAnableGoBack')}
              confirmationButtonContent={props.t('confirm')}
              cancelButtonContent={props.t('cancel')}
              deleteConfirmButton={deleteBankDetailsConfirmationFunction}
              deleteCancleButton={deleteBankDetailsConfirmationModalHide}
            />
          }
        />

      </div>
    </>
  )
}

//export default InvoicePage
const mapStateToProps = (globalState) => {
  return {
    userCredentials: globalState.LoginReducer.userCredentials,
  };
}
export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setUserCredentials })
  (withTranslation()(InvoicePage)));