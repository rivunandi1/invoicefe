const lodash = require('lodash');
import moment from 'moment';
export const invoiceFormatingFormData = (formData, org_id, admin_id, admin_name, invoiceData, invoice_number_generation, additionalInputText, conversion_allowance_percentage, orgcurrency, dateField) => {
    // console.log("dateField++++====", dateField)
    // console.log("formData++++====", formData)
    //console.log("org_id++++====", org_id)
    //console.log("admin_id++++====", admin_id)
    //console.log("admin_name++++====", admin_name)
    //console.log("invoiceData++++====", invoiceData)
    //console.log("additionalInputText++++====", additionalInputText)

    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        hash['org_id'] = org_id
        hash['invoice_number'] = invoice_number_generation.invoice1 + "/" + invoice_number_generation.invoice2 + "/" + formData.invoice_number
        hash['admin_id'] = admin_id
        hash['cust_id'] = formData.company_name.value
        hash['sgst_amount'] = formData.sgst.toString()
        hash['cgst_amount'] = formData.cgst.toString()
        hash['igst_amount'] = formData.igst.toString()
        hash['admin_name'] = admin_name
        hash['additional_value'] = additionalInputText
        let invoiceDataArray = []
        invoiceData.map((obj, index) => {
            let invoice_hash = {}
            invoice_hash['sl_no'] = index + 1;
            invoice_hash['description'] = obj.description
            invoice_hash['quantity'] = obj.quantity
            invoice_hash['Rate'] = obj.rate
            invoice_hash['Price'] = obj.price
            invoiceDataArray.push(invoice_hash)
        })
        hash['items'] = invoiceDataArray
        hash['sgst_percentage'] = formData.sgst_percentage.toString()
        hash['cgst_percentage'] = formData.cgst_percentage.toString()
        hash['igst_percentage'] = formData.igst_percentage.toString()
        hash['sub_total'] = formData.sub_total.toString()
        hash['total'] = formData.total.toString()
        hash['amount_on_sgst_percentage'] = formData.sgst.toString()
        hash['amount_on_cgst_percentage'] = formData.cgst.toString()
        hash['amount_on_igst_percentage'] = formData.igst.toString()
        hash['conversion_allowance_percentage'] = conversion_allowance_percentage
        hash['currency'] = orgcurrency
        hash['invoice_date'] = dateField ? moment(new Date(dateField.year + "-" + dateField.month + "-" + dateField.day)).format('YYYY-MM-DD') : '';
        hash['org_bank_details'] = {
            "account_no": formData.org_bank.account_no,
            "bank_name": formData.org_bank.bank_name,
            "bank_address": formData.org_bank.bank_address,
            "bank_country": formData.org_bank.bank_country,
            "ifsc_code": formData.org_bank.ifsc_code
        }

        hash['cust_bank_details'] = {
            "account_no": formData.company_bank.account_no,
            "bank_name": formData.company_bank.bank_name,
            "bank_address": formData.company_bank.bank_address,
            "bank_country": formData.company_bank.bank_country,
            "ifsc_code": formData.company_bank.ifsc_code

        }
        dataSet.push(hash)
        resolve(dataSet)
    })

    return promise;

};

export const paymentInvoiceFormatingFormData = (userCredentials, selectedData, conversionAmount, amountAfterConversion, paymentDate, paymentType, comment, tdsAmount) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        hash['invoice_number'] = selectedData?.data?.invoice_number

        /* hash['amount'] = selectedData?.data?.calculation?.total
 
         hash['currency'] = userCredentials?.user_details?.org_percentages?.currency
         hash['conversion_allowance_percentage'] = selectedData?.data?.calculation?.conversion_allowance_percentage
         hash['conversion_amount'] = conversionAmount
         hash['amount_after_conversion'] = amountAfterConversion.toString()*/



        if (userCredentials?.user_details?.org_percentages?.currency == selectedData?.data?.cust_details?.currency) {
            hash['amount'] = conversionAmount
            hash['currency'] = userCredentials?.user_details?.org_percentages?.currency
            hash['conversion_allowance_percentage'] = "0"
            hash['amount_after_conversion'] = conversionAmount
            hash['conversion_amount'] = "0"
            hash["tds"] = (parseFloat(tdsAmount).toFixed(2)).toString()

        }

        if (userCredentials?.user_details?.org_percentages?.currency != selectedData?.data?.cust_details?.currency) {
            hash['amount'] = conversionAmount
            hash['currency'] = userCredentials?.user_details?.org_percentages?.currency
            hash['conversion_allowance_percentage'] = selectedData?.data?.calculation?.conversion_allowance_percentage
            hash['amount_after_conversion'] = (parseFloat(conversionAmount) - parseFloat(amountAfterConversion)).toFixed(2)
            hash['conversion_amount'] = amountAfterConversion.toString()
        }


        hash['payment_date'] = paymentDate ? moment(new Date(paymentDate.year + "-" + paymentDate.month + "-" + paymentDate.day)).format('YYYY-MM-DD') : ''
        if (paymentType.full_payment) {
            hash['payment_type'] = "full_payment"
        }
        if (paymentType.pertial_payment) {
            hash['payment_type'] = "partial_payment"
        }
        hash['comment'] = comment
        hash['invoice_id'] = selectedData?.data?._id


        dataSet.push(hash)
        resolve(dataSet)
    })

    return promise;

};

export const previewModalDatasetFormat = (formData, invoice_number_generation, selectedCustomerData, invoiceData, additionalInputText, company_admin_login_name, org_name, location_type, selectedRowData = {}, dateField, currency) => {
    // console.log("preview=????=dateField", dateField)
    // console.log("company_admin_login_name==",company_admin_login_name)
    // console.log("org_name==",org_name)

    let promise = new Promise((resolve, reject) => {
        console.log("1234")
        let previewModalDataset = []
        let preview_hash = {}
        if (location_type == 'grid') {
            preview_hash['invoice_number'] = selectedRowData.invoice_number
            preview_hash['is_gst_applicable'] = selectedRowData.cust_details.is_gst_applicable
            preview_hash['is_igst_applicable'] = selectedRowData.cust_details.is_igst_applicable
            preview_hash['is_sgst_applicable'] = selectedRowData.cust_details.is_sgst_applicable
            preview_hash['cust_user'] = selectedRowData.cust_users
            preview_hash['date'] = moment(selectedRowData.invoice_date).format('YYYY-MM-DD')
            preview_hash['bank_name'] = selectedRowData.org_bank_details.bank_name
            preview_hash['bank_address'] = selectedRowData.org_bank_details.bank_address
            preview_hash['bank_country'] = selectedRowData.org_bank_details.bank_country
            preview_hash['ifsc_code'] = selectedRowData.org_bank_details.ifsc_code
            preview_hash['account_no'] = selectedRowData.org_bank_details.account_no
            preview_hash['gst_number'] = selectedRowData.cust_details.gst_number;
        }
        else {
            preview_hash['invoice_number'] = invoice_number_generation.invoice1 + "/" + invoice_number_generation.invoice2 + "/" + formData.invoice_number;
            preview_hash['cust_user'] = selectedCustomerData[0].Users
            preview_hash['is_gst_applicable'] = selectedCustomerData[0].is_gst_applicable
            preview_hash['is_igst_applicable'] = selectedCustomerData[0].is_igst_applicable
            preview_hash['is_sgst_applicable'] = selectedCustomerData[0].is_sgst_applicable
            preview_hash['date'] = dateField ? moment(new Date(dateField.year + "-" + dateField.month + "-" + dateField.day)).format('YYYY-MM-DD') : '';
            preview_hash['bank_name'] = formData.org_bank.bank_name;
            preview_hash['bank_address'] = formData.org_bank.bank_address;
            preview_hash['bank_country'] = formData.org_bank.bank_country;
            preview_hash['ifsc_code'] = formData.org_bank.ifsc_code;
            preview_hash['account_no'] = formData.org_bank.account_no
            preview_hash['gst_number'] = selectedCustomerData[0].gst_number;

        }

        preview_hash['customer_name'] = selectedCustomerData[0].name;

        let addressArray = []
        if (selectedCustomerData[0].address_line1 != "") {
            addressArray.push(selectedCustomerData[0].address_line1)
        }
        if (selectedCustomerData[0].address_line2 != "") {
            addressArray.push(selectedCustomerData[0].address_line2)
        }
        if (selectedCustomerData[0].city != "") {
            addressArray.push(selectedCustomerData[0].city)
        }
        if (selectedCustomerData[0].country != "") {
            addressArray.push(selectedCustomerData[0].country)
        }
        if (selectedCustomerData[0].zip_code != "") {
            addressArray.push(selectedCustomerData[0].zip_code)
        }
        preview_hash['address'] = addressArray.join(",")
        let invoiceDataPreviewDataArray = []
        invoiceData.map((obj, index) => {
            let invoiceDataPreview = {}
            invoiceDataPreview['sl_no'] = index + 1;
            invoiceDataPreview['description'] = obj.description
            invoiceDataPreview['quantity'] = obj.quantity
            invoiceDataPreview['Rate'] = obj.rate
            invoiceDataPreview['Price'] = obj.price
            invoiceDataPreviewDataArray.push(invoiceDataPreview)
        })
        preview_hash['item'] = invoiceDataPreviewDataArray;
        preview_hash['sub_total'] = formData.sub_total
        preview_hash['sgst_percentage'] = formData.sgst_percentage
        preview_hash['cgst_percentage'] = formData.cgst_percentage
        preview_hash['igst_percentage'] = formData.igst_percentage
        preview_hash['sgst'] = formData.sgst
        preview_hash['cgst'] = formData.cgst
        preview_hash['igst'] = formData.igst
        preview_hash['total'] = formData.total
        let additionalInputTextPreviewArray = []
        additionalInputText.map((obj, index) => {
            let additionalInputTextPreview = {}
            additionalInputTextPreview['additional_text'] = obj.additional_text;
            additionalInputTextPreview['additional_value'] = obj.additional_value;
            additionalInputTextPreviewArray.push(additionalInputTextPreview)
        })
        preview_hash['less_item'] = additionalInputTextPreviewArray

        preview_hash['org_gst_number'] = selectedCustomerData[0].Organisation.gst_number
        preview_hash['pan_number'] = selectedCustomerData[0].Organisation.pan_number
        preview_hash['gstn'] = selectedCustomerData[0].Organisation.gstn

        let totalOrgAddress = "";

        totalOrgAddress += selectedCustomerData[0].Organisation.address_line1 ? selectedCustomerData[0].Organisation.address_line1 + ', ' : ""
        totalOrgAddress += selectedCustomerData[0].Organisation.address_line2 ? selectedCustomerData[0].Organisation.address_line2 + ', ' : ""
        totalOrgAddress += selectedCustomerData[0].Organisation.city ? selectedCustomerData[0].Organisation.city + ', ' : ""
        totalOrgAddress += selectedCustomerData[0].Organisation.country ? selectedCustomerData[0].Organisation.country : ""

        totalOrgAddress = selectedCustomerData[0].Organisation.zip_code ? totalOrgAddress + " - ".toString() + selectedCustomerData[0].Organisation.zip_code.toString() : totalOrgAddress


        preview_hash['org_address'] = totalOrgAddress;

        preview_hash['company_admin_login_name'] = company_admin_login_name
        preview_hash['org_name'] = org_name
        preview_hash['currency'] = currency


        previewModalDataset.push(preview_hash)
        resolve(previewModalDataset)
    })
    return promise;
}

export const sendMailDataFormat = (mailList, rowData) => {
    // console.log("mailList=======", mailList)
    // console.log("rowData=======", rowData)
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let tempHash = {};
        let mailId = []
        mailList.map((val, idx) => {
            mailId.push(val.label)
        })

        let additionalValueData = []
        rowData?.additional_value.map((obj) => {
            let additionalInputTextObject = {}
            additionalInputTextObject['additional_text'] = obj.additional_text
            additionalInputTextObject['additional_value'] = obj.additional_value
            additionalValueData.push(additionalInputTextObject)
        })

        let invoiceDetailsData = []
        rowData?.details.map((obj) => {
            let invoiceDetailsObject = {}
            invoiceDetailsObject['Price'] = obj.Price
            invoiceDetailsObject['Rate'] = obj.Rate
            invoiceDetailsObject['description'] = obj.description
            invoiceDetailsObject['quantity'] = obj.quantity
            invoiceDetailsObject['sl_no'] = obj.sl_no
            invoiceDetailsData.push(invoiceDetailsObject)
        })
        tempHash['email_id'] = mailId,
            tempHash['body'] = "New invoice receive from " + rowData?.admin_name,
            tempHash['email_subject'] = "New invoice receive",
            tempHash['invoice_data'] = {
                "_id": rowData?._id,
                "invoice_number": rowData?.invoice_number,
                "invoice_date": moment(rowData?.invoice_date).format('YYYY-MM-DD'),
                "admin_id": rowData?.admin_id,
                "admin_name": rowData?.admin_name,
                "status": rowData?.status,
                "is_implement": rowData?.is_implement,
                "invoice_amount": rowData?.invoice_amount.toString(),
                "payment_status": rowData?.payment_status,
                "status": rowData?.status,
                "org_details": {
                    "_id": rowData?.org_details?._id,
                    "name": rowData?.org_details?.name,
                    "gst_number": rowData?.org_details?.gst_number,
                    "pan_number": rowData?.org_details?.pan_number,
                    "currency": rowData?.org_details?.currency,
                    "address_line1": rowData?.org_details?.address_line1,
                    "address_line2": rowData?.org_details?.address_line2,
                    "city": rowData?.org_details?.city,
                    "state": rowData?.org_details?.state,
                    "country": rowData?.org_details?.country,
                    "zip_code": rowData?.org_details?.zip_code,
                    "active": rowData?.org_details?.active,
                },
                "cust_details": {
                    "_id": rowData?.cust_details?._id,
                    "org_id": rowData?.cust_details?.org_id,
                    "name": rowData?.cust_details?.name,
                    "active": rowData?.cust_details?.active,
                    "email": rowData?.cust_details?.email,
                    "address_line1": rowData?.cust_details?.address_line1,
                    "address_line2": rowData?.cust_details?.address_line2,
                    "ph_no": rowData?.cust_details?.ph_no,
                    "city": rowData?.cust_details?.city,
                    "state": rowData?.cust_details?.state,
                    "zip_code": rowData?.cust_details?.zip_code,
                    "pan_number": rowData?.cust_details?.pan_number,
                    "gst_number": rowData?.cust_details?.gst_number,
                    "is_gst_applicable": rowData?.cust_details?.is_gst_applicable,
                    "is_sgst_applicable": rowData?.cust_details?.is_sgst_applicable,
                    "is_igst_applicable": rowData?.cust_details?.is_igst_applicable,
                    "currency": rowData?.cust_details?.currency
                },
                "cust_users": [
                    {
                        "_id": rowData?.cust_users[0]?._id,
                        "name": rowData?.cust_users[0]?.name,
                        "type": rowData?.cust_users[0]?.type,
                        "status": rowData?.cust_users[0]?.status,
                        "email": rowData?.cust_users[0]?.email,
                        "created_by": moment(rowData.cust_users[0]?.created_by).format('YYYY-MM-DD'),
                        "createdAt": moment(rowData.cust_users[0]?.createdAt).format('YYYY-MM-DD'),
                        "updatedAt": moment(rowData.cust_users[0]?.updatedAt).format('YYYY-MM-DD'),
                        "__v": rowData?.cust_users[0]?.__v.toString(),
                    }
                ],
                "details": invoiceDetailsData,
                "additional_value": additionalValueData,
                "org_bank_details": {
                    "account_no": rowData?.org_bank_details?.account_no,
                    "bank_name": rowData?.org_bank_details?.bank_name,
                    "bank_address": rowData?.org_bank_details?.bank_address,
                    "bank_country": rowData?.org_bank_details?.bank_country,
                    "ifsc_code": rowData?.org_bank_details?.ifsc_code,
                    "_id": rowData?.org_bank_details?._id,
                },
                "cust_bank_details": {
                    "account_no": rowData?.cust_bank_details?.account_no,
                    "bank_name": rowData?.cust_bank_details?.bank_name,
                    "bank_address": rowData?.cust_bank_details?.bank_address,
                    "bank_country": rowData?.cust_bank_details?.bank_country,
                    "ifsc_code": rowData?.cust_bank_details?.ifsc_code,
                    "_id": rowData?.cust_bank_details?._id,
                },
                "calculation": {
                    "sgst_percentage": rowData?.calculation?.sgst_percentage.toString(),
                    "amount_on_sgst_percentage": rowData?.calculation?.amount_on_sgst_percentage.toString(),
                    "cgst_percentage": rowData?.calculation?.cgst_percentage.toString(),
                    "amount_on_cgst_percentage": rowData?.calculation?.amount_on_cgst_percentage.toString(),
                    "igst_percentage": rowData?.calculation?.igst_percentage.toString(),
                    "amount_on_igst_percentage": rowData?.calculation?.amount_on_igst_percentage.toString(),
                    "conversion_allowance_percentage": rowData?.calculation?.conversion_allowance_percentage.toString(),
                    "sub_total": rowData?.calculation?.sub_total.toString(),
                    "total": rowData?.calculation?.total.toString(),
                    "sgst_amount": rowData?.calculation?.sgst_amount.toString(),
                    "cgst_amount": rowData?.calculation?.cgst_amount.toString(),
                    "igst_amount": rowData?.calculation?.igst_amount.toString(),
                    "_id": rowData?.calculation?._id.toString()
                },
            },
            dataSet.push(tempHash);
        // console.log("dataSet=========", dataSet)
        resolve(dataSet)
    })
    return promise;
}

const difference = (origObj, newObj) => {
    let changes = (newObj, origObj) => {
        let arrayIndexCounter = 0
        return lodash.transform(newObj, (result, value, key) => {
            if (!lodash.isEqual(value, origObj[key])) {
                let resultKey = lodash.isArray(origObj) ? arrayIndexCounter++ : key
                result[resultKey] = (lodash.isObject(value) && lodash.isObject(origObj[key])) ? changes(value, origObj[key]) : value
            }
        })
    }
    return changes(newObj, origObj)
}