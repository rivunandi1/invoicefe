import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { invoiceListingGet, customerListingGet, invoiceAddPost, paymentInvoicePost, paymentInvoiceGet, paymentInvoiceListRowDeleteApi, invoiceRowDeleteApi, customerEmailHistoryListingGet,emailHistoryAddpostapi, emailSendapi } from '../Model/InvoiceModel';
import Config from '../../../../../Utility/Config';

export const invoiceListing = (data) => {
    return get(`${Config.extendedUrl}generate/invoice`, data).then((response) => {
        return invoiceListingGet(response)
    });
};
export const customerListing = (data) => {
    return get(`${Config.extendedUrl}customers`, data).then((response) => {
        return customerListingGet(response)
    });
};
export const invoiceAdd = (data) => {
    return post(`${Config.extendedUrl}generate/invoice`, data).then((response) => {
        return invoiceAddPost(response)
    });
}
export const paymentInvoiceAdd = (data) => {
    return post(`${Config.extendedUrl}payment/invoice`, data).then((response) => {
        return paymentInvoicePost(response)
    });
}
export const emailHistoryAdd = (data) => {
    return post(`${Config.extendedUrl}email/history`, data).then((response) => {
        return emailHistoryAddpostapi(response)
    });
}

export const paymentInvoiceList = (data) => {
    return get(`${Config.extendedUrl}payment/invoice`, data).then((response) => {
        return paymentInvoiceGet(response)
    });
};

export const paymentInvoiceListRowDelete = (data) => {
    return del(`${Config.extendedUrl}payment/invoice`, data).then((response) => {
        return paymentInvoiceListRowDeleteApi(response)
    });
};

export const invoiceRowDelete = (data) => {
    return del(`${Config.extendedUrl}generate/invoice`, data).then((response) => {
        return invoiceRowDeleteApi(response)
    });
};
export const customerEmailHistoryListing = (data) => {
    return get(`${Config.extendedUrl}email/history`, data).then((response) => {
        return customerEmailHistoryListingGet(response)
    });
};

export const sendEmailPost = (data) => {
    return post(`${Config.extendedUrl}email/send_email`, data).then((response) => {
        return emailSendapi(response)
    });
}