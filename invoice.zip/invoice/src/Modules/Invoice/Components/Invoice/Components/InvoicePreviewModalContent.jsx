import React from 'react'
import moment from 'moment';
import Table from 'react-bootstrap/Table'
import ReactToPrint from 'react-to-print';
import { useRef } from 'react';

function InvoicePreviewModalContent(props) {
  // console.log("___>>>props??>>>>", props)
 
  const ref = useRef()
  const previewTableUi = () => {
    let previewUiArray = []

    props.previewModalDataset[0].item.map((e, i) => {
      previewUiArray.push(
        <>

          <tr key={i}>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'left' }}>{i + 1}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>{e.description}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>{e.quantity}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>{e.Rate}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>{e.Price}</td>
          </tr>

        </>

      )

    })
    return previewUiArray;
  }

  const customerUsersNameUi = () => {
    let customerUsersName = []
    if (props.previewModalDataset[0].cust_user.length > 0) {
      props.previewModalDataset[0].cust_user.map((custUsers, i) => {
        customerUsersName.push(
          custUsers.name
        )
      })
      // 

    }
    return customerUsersName.join(",")
  }
  const previewAdditiionalTableUi = () => {
    let previewAdditionalUiArray = []

    if (props.previewModalDataset[0].less_item.length > 0) {
      // console.log("dtrfyfdf")
      props.previewModalDataset[0].less_item.map((e, i) => {
        // console.log("e times///", e)
        previewAdditionalUiArray.push(
          <>
            <tr key={i}>
              <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }} colSpan="4">{e.additional_text}</td>
              <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{e.additional_value}</td>
            </tr>
          </>
        )
      })
    }
    // console.log("previewAdditionalUiArray", previewAdditionalUiArray)
    return previewAdditionalUiArray;
  }

  const alertModal=()=>{
    alert()
  }

  return (

    <div className='invoiceBodyScroll'>
      <div ref={ref} >
        <div style={{ width: '100%', display: 'inline-block' }}>
          <div style={{ width: '100%', display: 'inline-block' }}>
            <div style={{ width: '50%', display: 'inline-block', textAlign: 'left' }}><span style={{ color: '#323C47', fontSize: 16 }}>Ref: {props.previewModalDataset[0].invoice_number}</span></div>
            {/* <div style={{ width: '50%', display: 'inline-block', textAlign: 'right' }}><span style={{ color: '#323C47', fontSize: 16 }}>Date: {props.previewModalDataset[0].date}</span></div> */}
            <div style={{ width: '50%', display: 'inline-block', textAlign: 'right' }}><span style={{ color: '#323C47', fontSize: 16 }}>Date: {moment(props.previewModalDataset[0].date).format('DD-MM-YYYY')}</span></div>

          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'center', paddingTop: 10, paddingBottom: 10 }}>
            <span style={{ color: '#333333', fontSize: 16, fontWeight: 600 }}>Invoice / Bill</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>To,</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15, fontWeight: 600 }}>{props.previewModalDataset[0].customer_name}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>{props.previewModalDataset[0].address}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>{props.previewModalDataset[0].gst_number && props.previewModalDataset[0].gst_number != "" ? "Company GST:" : ""}{props.previewModalDataset[0].gst_number}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left', paddingTop: 20 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'left' }}>Sl No</th>
                  <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>Description</th>
                  <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>Quantity</th>
                  <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>Rate({props.previewModalDataset[0].currency})</th>
                  <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>Price</th>
                </tr>
              </thead>


              <tbody>
                {previewTableUi()}

                <tr>
                  <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }} colSpan="4">Sub Total</td>
                  <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{parseFloat(props.previewModalDataset[0].sub_total).toFixed(2)}</td>
                </tr>

                {

                  (props.previewModalDataset[0].is_gst_applicable == true) ?
                    <>
                      {props.previewModalDataset[0].is_sgst_applicable == true ?
                        <>
                          <tr>
                            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', color: '#4472c7', fontWeight: 600 }} colSpan="4">CGST @ {props.previewModalDataset[0].cgst_percentage} %</td>
                            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{parseFloat(props.previewModalDataset[0].cgst).toFixed(2)}</td>
                          </tr>
                          <tr>
                            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', color: '#4472c7', fontWeight: 600 }} colSpan="4">SGST @ {props.previewModalDataset[0].sgst_percentage}%</td>
                            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{parseFloat(props.previewModalDataset[0].sgst).toFixed(2)}</td>
                          </tr>
                        </>
                        : null}
                      {props.previewModalDataset[0].is_igst_applicable == true ?
                        <tr>
                          <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', color: '#4472c7', fontWeight: 600 }} colSpan="4">IGST @ {props.previewModalDataset[0].igst_percentage}%</td>
                          <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{parseFloat(props.previewModalDataset[0].igst).toFixed(2)}</td>
                        </tr>
                        : null}
                    </>
                    :
                    null



                }

                {/* <tr>
              <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', color: '#4472c7', fontWeight: 600 }} colSpan="5">IST {props.percentages.ist_percentage}%</td>
              <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{props.formData.ist}</td>
            </tr> */}

                {previewAdditiionalTableUi()}


                {/* <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }} colSpan="4">Less Amount</td>
              <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{props.additionalInputText.additional_value}</td> */}

                <tr>
                  <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }} colSpan="4">Total</td>
                  <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}> {parseFloat(props.previewModalDataset[0].total).toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left', paddingTop: 20 }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>N.B. <span style={{ color: 'red', fontSize: 15, fontWeight: 600 }}>Please mention the purpose of the payment as software development service</span></span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>1. PAN NO.: {props.previewModalDataset[0].pan_number}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>GSTN – </span> <span style={{ color: '#323C47', fontSize: 15, fontWeight: 600 }}>{props.previewModalDataset[0].org_gst_number}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>Beneficiary Account No. - </span><span style={{ color: 'red', fontSize: 15, fontWeight: 600 }}>{props.previewModalDataset[0].account_no}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>Beneficiary Name – {props.previewModalDataset[0].org_name}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>Beneficiary Add – {props.previewModalDataset[0].org_address}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>Beneficiary Bank Name – {props.previewModalDataset[0].bank_name}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>Beneficiary Bank address – {props.previewModalDataset[0].bank_address}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>Bank Country – {props.previewModalDataset[0].bank_country}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
            <span style={{ color: '#323C47', fontSize: 15 }}>IFSC – {props.previewModalDataset[0].ifsc_code}</span>
          </div>
          <div style={{ width: '100%', display: 'inline-block', paddingTop: 20 }}>
            <div style={{ width: '60%', display: 'inline-block', textAlign: 'left' }}>
              <div><span style={{ color: '#323C47', fontSize: 15 }}>For, </span></div>
              <div><span style={{ color: '#323C47', fontSize: 15, fontWeight: 600 }}>{props.previewModalDataset[0].customer_name}</span></div>
            </div>
            <div style={{ width: '40%', display: 'inline-block', textAlign: 'left' }}>
              <div><span style={{ color: '#323C47', fontSize: 15 }}>For on & behalf of</span></div>
              <div><span style={{ color: '#323C47', fontSize: 15, fontWeight: 600 }}>{props.previewModalDataset[0].org_name}</span></div>
            </div>
          </div>
          <div style={{ width: '100%', display: 'inline-block' }}>
            <div style={{ width: '60%', display: 'inline-block', textAlign: 'left' }}>
              <div style={{ height: 10, lineHeight: 0, marginTop: 20 }}><span style={{ borderBottom: '1px solid black', width: '50%', display: 'inline-block', lineHeight: 0 }}></span></div>
              <div><span style={{ color: '#323C47', fontSize: 15 }}>{customerUsersNameUi()}</span></div>
              <div><span style={{ color: '#323C47', fontSize: 15 }}>(Authorized Signature) </span></div>
            </div>
            <div style={{ width: '40%', display: 'inline-block', textAlign: 'left' }}>
              <div style={{ height: 10, lineHeight: 0, marginTop: 20 }}><span style={{ borderBottom: '1px solid black', width: '70%', display: 'inline-block', lineHeight: 0 }}></span></div>
              <div><span style={{ color: '#323C47', fontSize: 15 }}>{props.previewModalDataset[0].company_admin_login_name}</span></div>
              <div><span style={{ color: '#323C47', fontSize: 15 }}>(Authorized Signature)</span></div>
            </div>
          </div>
          <div style={{ width: '100%', display: 'inline-block',borderTop: '2px solid #E6E6E6',marginTop: '20px',paddingTop: '6px',textAlign: 'center' }}>
            <p style={{color: 'rgb(50, 60, 71)',fontSize: '15px',margin: '0',fontFamily:'Poppins-Medium'}}>S 129, B.P Township, Kolkata-700094</p>
            <p style={{color: 'rgb(68, 114, 199)',fontSize: '15px',margin: '0',fontFamily:'Poppins-Medium'}}><span>www.mettletech.in</span></p>
          </div>
        </div>
      </div>
      <div style={{textAlign: 'center',paddingTop:'20px'}}>
        <ReactToPrint
          trigger={() => <button style={{ background: '#0ab', border: '1px solid #0ab', color: '#fff', borderRadius: '6px', fontSize: '13px', padding: '1px 10px' }}>Print</button>}
          content={() => ref.current}
        />
      </div>
    </div>

  )
}

export default InvoicePreviewModalContent;