import React, { Component, useState, useEffect } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import "bootstrap/dist/css/bootstrap.min.css";
import Table from 'react-bootstrap/Table';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import moment from 'moment';
import Utility from '../../../../../Utility/Utility';
const options = [
  { value: 'chocolate', label: 'Chocolate' },
  { value: 'strawberry', label: 'Strawberry' },
  { value: 'vanilla', label: 'Vanilla' }
]

function AddEditInvoiceModalContent(props) {

  // console.log("??????Props?????", props);


  const tableUi = () => {
    let uiArray = []
    if (props.invoiceData.length > 0) {
      props.invoiceData.map((item, i) => {
        // console.log("---iiiii--->", i)
        uiArray.push(
          <>

            <tr key={i}>
              <td>{i + 1}</td>

              <td><input type="text" onChange={(e) => { props.handleInputChange(e, i, 'description') }} value={item.description}></input>
                <div className="errorClass error_div">{props.invoiceDataError[i].description_error}</div>
              </td>


              <td><input type="text" onChange={(e) => { props.handleInputChange(e, i, 'quantity') }} value={item.quantity}></input>
                <div className="errorClass error_div">{props.invoiceDataError[i].quantity_error}</div>
              </td>


              <td><input type="text" onChange={(e) => { props.handleInputChange(e, i, 'rate') }} value={item.rate}></input>
                <div className="errorClass error_div">{props.invoiceDataError[i].rate_error}</div>
              </td>


              <td><div className="totalAmount_dev">{props.invoiceData[i].price}</div></td>
              {props.invoiceData.length != 1 ?
                <td><p className="delete" title="Delete" data-toggle="tooltip" style={{ color: "red" }} onClick={() => props.handleDeleteInvoiceData(i)} ><span aria-hidden="true">×</span></p></td> : <td></td>}

            </tr>
          </>

        )
        // console.log("------uiarray------", uiArray.length)
      })
    }
    return uiArray;
  }

  //additional input field 
  const additionalUi = () => {
    let additionaluiArray = []
    if (props.additionalInputText.length > 0) {
      props.additionalInputText.map((item, i) => {
        additionaluiArray.push(
          <>
            <tr>
              <td colSpan={4}>
                <div className="inputrowview inputrowfirstview">
                  <div className="halfrowbox">
                    <CustomInput
                      parentClassName="input_field_inner"
                      labelName="Additional Text"
                      //errorLabel={}
                      name="invoiceNumber"
                      type="text"
                      value={item.additional_text}
                      labelPresent={true}
                      onChange={(e) => { props.handleAdditionalText_Input(e, i, 'additional_text') }}

                    />
                  </div>
                </div>
              </td>
              <td width={150}>

                <div className="inputrowview inputrowfirstview">
                  <div className="halfrowbox">
                    <CustomInput
                      parentClassName="input_field_inner"
                      labelName="Additional Value"
                      //errorLabel={}
                      name="invoiceNumber"
                      input type="text"
                      value={item.additional_value}
                      labelPresent={true}
                      onChange={(e) => { props.handleAdditionalText_Input(e, i, 'additional_value') }}

                    />
                  </div>
                </div>
              </td>
              <div className='error_div'>{props.additionalInputTextError[i].additional_error}</div>
            </tr>



          </>
        )
      })
    }
    return additionaluiArray;
  }


  let maximumDate = {
    year: moment().format("YYYY"),
    month: moment().format("MM"),
    day: moment().format("DD")
  }

  return (
    <div className="modalinnerbody createInvoiceModal requiredField">
      <label className="invoiceNum">Invoice Number<span>*</span></label>
      <div className="row">
        <div className="col-md-2">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              {/* <label> Invoice Number *</label> */}
              <CustomInput
                parentClassName="input_field_inner"
                labelName="Invoice Number"
                //errorLabel={props.errorFormData.invoice_number_error}
                name="invoice1"
                type="text"
                value={props.invoice_number_generation.invoice1}
                readOnly={true}
              //labelPresent={true}
              //onChange={(e) => { props.handleChangeInvoiceFormData(e, 'invoice_number') }}

              />
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                //labelName="Invoice Number *"
                //errorLabel={props.errorFormData.invoice_number_error}
                name="invoice2"
                type="text"
                value={props.invoice_number_generation.invoice2}
                readOnly={true}
              //labelPresent={true}
              //onChange={(e) => { props.handleChangeInvoiceFormData(e, 'invoice_number') }}

              />
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                //labelName="Invoice Number *"
                //errorLabel={props.errorFormData.invoice_number_error}
                name="invoice3"
                type="text"
                value={props.invoice_number_generation.invoice3}
                readOnly={true}
              //labelPresent={true}
              //onChange={(e) => { props.handleChangeInvoiceFormData(e, 'invoice_number') }}

              />
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner"
                // labelName="Invoice Number *"
                // errorLabel={props.errorFormData.invoice_number_error}
                name="invoice4"
                type="text"
                placeholder="Input value"
                // value={props.invoice_number_generation.invoice3}
                //labelPresent={true}
                onChange={(e) => { props.handleChangeInvoiceFormData(e, 'invoice_number') }}

              />
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="dropdowninnerbox addReceiveInvoicedropdown required">

            {props.customeraddflag ?
              <div className="addCustomerBtn">
                <button type="button" className="savebtn" onClick={() => props.openCustomerAddModal()} >+ Add customer</button>
              </div>
              : null}

            <label>Company Name</label>
            <AutosuggestComponent
              handleOnInputChange={(e) => { props.companyHandleOnInputChange(e, "company_name") }}

              options={props.customersList}
              selectedValue={props.formData.company_name}
              handleOnChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'company_name') }}
              name="companyName"
              isMulti={false}
              placeholder=""
              labelName="Invoice Number"
              //isDisabled={this.props.roleId!=""?true:false}
              isSearchable={true}
              isClearable={true}
            //defaultMenuIsOpen={true}
            />
            <div className="col-md-12 errorClass error_div">{props.errorFormData.company_name_error}</div>
          </div>
        </div>

        {/* date input box add */}
        <div className="col-md-6">
          <div className="datepickerinnerbox required">
            <label>Invoice Date</label>
            <DatePicker
              value={props.dateField}
              onChange={props.handleChangeDateField.bind(this)}
              formatInputText={props.formatInvoiceDateInput}
              inputPlaceholder=" "
              shouldHighlightWeekends
              inputClassName="worker_datepicker"
              //dateFormat="dd/mm/yyyy"
              maximumDate={maximumDate}
              //locale={Utility.customDatePicker()}

            // minimumDate={minimumDate}
            />
            <div className='col-md-12 errorClass error_div'>{props.dateFieldError.dateFieldError}</div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="dropdowninnerbox addReceiveInvoicedropdown required">

            {props.bankaddflag ?
              <div className="addCustomerBtn">
                <button type="button" className="savebtn" onClick={() => props.openbankAddmodal()} >+ Add Bank</button>
              </div>
              : null}

            <label>Company Bank</label>
            <AutosuggestComponent
              handleOnInputChange={(e) => { props.companyHandleOnInputChange(e, "company_bank") }}
              options={props.bankList}
              selectedValue={props.formData.company_bank}
              handleOnChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'company_bank') }}
              name="company_bank"
              isMulti={false}
              placeholder=""
              labelName="Company Bank"
              //isDisabled={this.props.roleId!=""?true:false}
              isSearchable={true}
              isClearable={true}
            />
            <div className="col-md-12 errorClass error_div">{props.errorFormData.company_bank_error}</div>
          </div>
        </div>



        {/* org & customer bank details  */}
        <div className="col-md-6 required">
          <label className="invoiceNum">Organisation bank details</label>
          <div className="dropdowninnerbox addReceiveInvoicedropdown">
            <div className="halfrowbox readOnly">
              <AutosuggestComponent
                options={props.orgBankListData}
                // selectedValue={props.userCredentialsData.org_bank_acc_number}
                handleOnInputChange={(e) => { props.companyHandleOnInputChange(e, "org_bank") }}
                handleOnChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'org_bank') }}
                name="companyName"
                isMulti={false}
                placeholder=""
                labelName="Organisation bank details"
                //isDisabled={this.props.roleId!=""?true:false}
                isSearchable={true}
                isClearable={true}
              //defaultMenuIsOpen={true}
              />
              <div className="col-md-12 errorClass error_div">{props.errorFormData.org_bank_error}</div>
            </div>
          </div>
        </div>
      </div>
      {/* <label className="invoiceNum">customer bank details</label>
      <div className="row">
        <div className="col-md-4">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                labelName={props.formData.cust_bank_name}
                // name="invoice3"
                type="text"
                value={props.formData.cust_bank_account_number}
                readOnly={true}

              />
            </div>
          </div>
        </div>
      </div> */}
      <div className="row">
        <div className="col-md-12">
          <div className="inputrowview inputrowfirstview inputtextarea">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="Address"
                // errorLabel={props.errorFormData.address_error}
                name="address"
                type="textarea"
                value={props.formData.address}
                labelPresent={true}
              // onChange={(e) => { props.handleChangeInvoiceFormData(e, 'address') }}
              />
            </div>
          </div>
        </div>
        <div className="col-md-12">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="GST NO"
                // errorLabel={props.errorFormData.gst_number_error}/
                name="gstNumber"
                type="text"
                value={props.formData.gst_number}
                labelPresent={true}
              // onChange={(e) => { props.handleChangeInvoiceFormData(e, 'gst_number') }}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="addrowBox modfooterbtn">
        <button type="button" className="savebtn addrowbtn" onClick={() => { props.handleAddClick() }} >Add row</button>
      </div>
      <div className="clearfix"></div>
      <div className="invoiceTable">
        <div className="row">
          <div className="col-md-12">
            <div className="listTableInner">
              <Table className="listTable">
                <thead>
                  <tr>
                    <th>Sl. No.</th>
                    <th>Description <span>*</span></th>
                    <th>Quantity <span>*</span></th>
                    <th>Rate ({props.formData.currency}) <span>*</span></th>
                    <th>Price</th>
                    <th> </th>
                  </tr>
                </thead>
                <tbody>
                  {tableUi()}
                </tbody>
                <tbody>
                  <tr className="subTotal">
                    <td colSpan="4">Sub Total</td>
                    <td >{props.formData.sub_total.toFixed(2)}</td>
                  </tr>
                </tbody>
              </Table>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <div className="listTableInner subTotalTbl">
              <Table className="listTable">
                <tbody>

                  {/* <tr>
                    <td colSpan="4">Sub Total</td>
                    <td >{props.formData.sub_total.toFixed(2)}</td>
                  </tr> */}
                  {props.formData.is_gst_applicable == true ?

                    <>
                      {props.formData.is_sgst_applicable == true ?
                        <>
                          <tr>
                            <td colSpan="4">SGST@ {props.formData.sgst_percentage}%</td>
                            <td >{props.formData.sgst.toFixed(2)}</td>
                          </tr>
                          <tr>
                            <td colSpan="4">CGST@ {props.formData.cgst_percentage}%</td>
                            <td>{props.formData.cgst.toFixed(2)}</td>
                          </tr>
                        </> : null}

                      {props.formData.is_igst_applicable == true ?
                        <>
                          <tr>
                            <td colSpan="4">IGST@ {props.formData.igst_percentage}%</td>
                            <td>{props.formData.igst.toFixed(2)}</td>
                          </tr>
                        </>
                        : null
                      }
                    </>
                    : null}

                </tbody>

                <tbody>
                  <tr>
                    <td colSpan="5" align='right'>
                      <div className="addinsiderowBox modfooterbtn">
                        <button type="button" className="savebtn" onClick={() => { props.handleClickAdditionalInputField() }}>Add</button>
                      </div>
                    </td>
                  </tr>
                  {additionalUi()}
                </tbody>
                <tbody className='grandTotalTbl'>
                  <tr>
                    <td colSpan="4"><strong>Total</strong></td>
                    <td><strong>{props.formData.total}</strong></td>
                  </tr>
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      </div>
      <div className="clearfix"></div>
      <div className="col-md-12 text-center modfooterbtn">
        <button type="button" className="savebtn" onClick={() => props.handleSaveData()} >Submit</button>

        <button type="button" className="savebtn" onClick={() => { props.invoicePreviewModalfunction() }} style={{ marginLeft: 10, marginRight: 10 }}>Preview</button>


        <button type="button" className="cancelbtn" {...props} onClick={() => { props.invoiceModalClose() }}>Cancel</button>
      </div>
    </div >
  )
}

export default AddEditInvoiceModalContent