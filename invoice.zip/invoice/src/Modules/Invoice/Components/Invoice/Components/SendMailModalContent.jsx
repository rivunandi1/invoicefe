import React, { Component, useState, useEffect } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import moment from 'moment';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
const options = [
  { value: 'chocolate', label: 'Chocolate' },
  { value: 'strawberry', label: 'Strawberry' },
  { value: 'vanilla', label: 'Vanilla' }
]

function SendMailModalContent(props) {
  // console.log("payment====props", props)



  return (
    <div className="modalinnerbody paynowModalBody sendMailModalBody">
      <div className="row">
        <div className="col-md-12">
        <div className="dropdowninnerbox">
            {/* <label>Email </label> */}
            <AutosuggestComponent
              handleOnInputChange={(e) =>{props.sendMailHandleOnInputChange(e, "customer_email")}}
              options={props.customersEmailHistoryList}
              isMulti={true} 
              selectedValue={props.mailList}
              handleOnChange={(e) => { props.handleChangemail(e, 'customer_email') }}
              name="email"
              placeholder="Type email"
              labelName="Email"
              //isDisabled={this.props.roleId!=""?true:false}
              isSearchable={true}
              isClearable={true}
              handleBlur={(e)=>{props.mailSendhandleBlur(e)}}
            //defaultMenuIsOpen={true}
            />
            <div className="col-md-12 errorClass error_div"></div>
          </div>
        </div>
      </div>
      <div className="addrowBox modfooterbtn">
        <button type="button" className="savebtn addrowbtn" onClick={()=>props.clickMailSend()}>Send</button>
      </div>
      <div className="clearfix"></div>
    </div>
  )
}

export default SendMailModalContent