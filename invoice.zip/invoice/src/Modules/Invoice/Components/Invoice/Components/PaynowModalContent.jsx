import React, { Component, useState, useEffect } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import moment from 'moment';

function PaynowModalContent(props) {
  // console.log("invoice payment====props", props)
  //console.log("utils().getToday()", utils().getToday())


  //console.log(props?.selectedData?.data?.cust_details?.currency+"==========="+props?.selectedData?.data?.org_details?.currency)

  let minimumDate = {
    year: moment().format("YYYY"),
    month: moment().format("MM"),
    day: moment().format("DD")
  }

  let maximumDate = {
    year: moment().format("YYYY"),
    month: moment().format("MM"),
    day: moment().format("DD")
  }

  if (props?.selectedData?.data?.invoice_date) {
    let year = moment(props.selectedData.data.invoice_date).format("YYYY")
    let month = moment(props.selectedData.data.invoice_date).format("MM")
    let day = moment(props.selectedData.data.invoice_date).format("DD")
    minimumDate = {
      year: year,
      month: month,
      day: day
    }
  }

  return (
    <div className="modalinnerbody paynowModalBody">
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner readOnly"
                labelName="Invoice number"
                name="invoiceNumber"
                type="text"
                value={props.selectedData?.data?.invoice_number}
                labelPresent={true}
                readOnly={true}
              />
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner readOnly"
                labelName={"Total amount " + `(${props.selectedData?.data?.cust_details?.currency})`}
                name="total_amount"
                type="text"
                value={parseFloat(props.selectedData?.data?.calculation?.total).toFixed(2).toLocaleString()}
                labelPresent={true}
                readOnly={true}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview radioBoxes requiredField">
            <label className="taitlecount">Payment option <span>*</span></label>
            <label className="custom-radio-container">Partial payment
              <input type="radio" name="payment" value="partialPayment" onChange={(e) => props.paymentOptionType(e, "partialPayment")} checked={props.paymentType.pertial_payment ? true : false} />
              <span className="checkmark"></span>
            </label>
            <label className="custom-radio-container">Full payment
              <input type="radio" name="payment" value="fullPayment" onChange={(e) => props.paymentOptionType(e, "fullPayment")} checked={props.paymentType.full_payment ? true : false} />
              <span className="checkmark"></span>
            </label>
          </div>
          <div className="col-md-12 errorClass error_div">{props.formPaymentErr.pertial_full_payment_error}</div>
        </div>
        <div className="col-md-6">
          <div className="datepickerinnerbox required">
            <label>Payment receipt date</label>
            <DatePicker
              value={props.paymentDate}
              onChange={props.handleChangePaymentDate.bind(this, "PaymentDate")}
              formatInputText={props.formatDateInput}
              inputPlaceholder=" "
              shouldHighlightWeekends
              inputClassName="worker_datepicker"
              dateFormat="dd/mm/yyyy"
              maximumDate={maximumDate}
              minimumDate={minimumDate}
            />
            <div className='col-md-12 errorClass error_div'>{props.formPaymentErr.payment_date_error}</div>
          </div>
        </div>
      </div>
      {props.paymentType.pertial_payment || props.paymentType.full_payment ?
        <div className="row">
          <div className="col-md-6">
            <div className="inputrowview inputrowfirstview grandTotalPay">
              <div className="halfrowbox">
                <CustomInput
                  parentClassName="input_field_inner"
                  labelName={"Total amount receipt " + `(${props.userCredentials.user_details.org_percentages.currency})`}
                  name="conversionAmount"
                  type="text"
                  errorLabel={props.formPaymentErr.total_amount_errpr}
                  value={props.conversionAmount}
                  labelPresent={true}
                  onChange={(e) => { props.handleChangeConversionAmount(e, 'conversionAmount') }}
                />
              </div>
            </div>
          </div>
          {props?.selectedData?.data?.cust_details?.currency == props?.selectedData?.data?.org_details?.currency ?
          <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName="TDS"
                    name="tds"
                    type="text"
                    errorLabel={props.formPaymentErr.tds_error}
                    value={props?.tdsAmount ?parseFloat(props.tdsAmount).toFixed(2):""}
                    labelPresent={true}
                    onChange={(e) => { props.handleChangeConversionAmount(e, 'tds') }}
                  />
                </div>
              </div>
            </div>
            :null}

          {props?.selectedData?.data?.cust_details?.currency != props?.selectedData?.data?.org_details?.currency ?

            <div className="col-md-6">
              <div className='paymentMode'>
                {/* <div className="amountLabel"><span className='paymentModeLeft'>IST @ {props.selectedData?.data?.calculation?.conversion_allowance_percentage} %</span> */}
                <div className="amountLabel"><span className='paymentModeLeft'>GST % for foreign currency {props.selectedData?.data?.calculation?.conversion_allowance_percentage} %</span>
                  <div className='paymentModeRight'>
                    <div className="ist_rowbox">
                      <CustomInput
                        parentClassName="input_field_inner readOnly"
                        name="amountAfterConversion"
                        type="text"
                        value={props.amountAfterConversion?parseFloat(props.amountAfterConversion).toFixed(2):""}
                        labelPresent={false}
                        readOnly={true}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            : null}

        </div>
        : null}
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <CustomInput
              parentClassName="input_field_inner"
              labelName="Comment"
              name="comment"
              type="textarea"
              value={props.comment}
              labelPresent={true}
              onChange={(e) => { props.handleChangeComment(e, 'comment') }}
            />
          </div>
        </div>
      </div>

      <div className="addrowBox modfooterbtn">
        <button type="button" className="savebtn addrowbtn" onClick={() => { props.handleSubmit() }}>Pay</button>
      </div>
      <div className="clearfix"></div>
    </div>
  )
}

export default PaynowModalContent