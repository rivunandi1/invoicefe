export const invoiceListingGet = (data) => {
    return data.data;
}
export const customerListingGet = (data) => {
    return data.data;
}
export const invoiceAddPost = (invoiceResponseData) => {
    return invoiceResponseData.data
}
export const paymentInvoicePost = (data) => {
    return data.data
}
export const paymentInvoiceGet = (data) => {
    return data.data
}
export const paymentInvoiceListRowDeleteApi = (data) => {
    return data.data
}

export const invoiceRowDeleteApi = (data) => {
    return data.data
}
export const customerEmailHistoryListingGet = (data) => {
    return data.data;
}
export const emailHistoryAddpostapi = (data) => {
    return data.data;
}
export const emailSendapi = (data) => {
    return data.data;
}
