export const receivedInvoiceListingGet = (data) => {
    return data.data;
}
export const customerListingGet = (data) => {
    return data.data;
}
export const paymentReceiptAddPost = (data) => {
    return data.data
}

export const invoiceRowDeleteApi = (data) => {
    return data.data
}
export const paymentInvoicePost = (data) => {
    return data.data
}
export const paymentTypePatch = (data) => {
    return data.data
}
export const paymentReceiveInvoiceGet = (data) => {
    return data.data
}
export const paymentInvoiceListRowDeleteApi = (data) => {
    return data.data
}
