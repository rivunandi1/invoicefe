const lodash = require('lodash');
import moment from 'moment';
export const paymentReciptFormatingFormData = (formData, org_id, admin_id, admin_name, additionalInputText, editId, reserveFromData, imageChangeFlag,orgcurrency) => {
    // console.log("imageChangeFlag", imageChangeFlag)
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}

        let date = formData.invoiceDate ? moment(new Date(formData.invoiceDate.year + "-" + formData.invoiceDate.month + "-" + formData.invoiceDate.day)).format('YYYY-MM-DD') : '';
        hash['receive_invoice_date'] = date
        hash['org_id'] = org_id
        hash['invoice_number'] = formData.invoice_number
        //hash['received_invoice_id'] = selectedData._id
        hash['admin_id'] = admin_id
        hash['cust_id'] = formData.company_name.value
        hash['admin_name'] = admin_name
        hash['is_gst_applicable'] = formData.is_gst_applicable;
        hash['is_sgst_applicable'] = formData.is_sgst_applicable;
        hash['is_igst_applicable'] = formData.is_igst_applicable;
        hash['sgst_amount'] = formData.sgst_percentage.toString()
        hash['cgst_amount'] = formData.cgst_percentage.toString()
        if (formData?.igst_percentage && formData.igst_percentage != "") {
            hash['igst_amount'] = formData.igst_percentage.toString()
        }
        //hash['less_discount'] = formData.less_discount.toString()
        hash['sub_total'] = formData.sub_total.toString()
        hash['total'] = formData.total.toString()
        hash['currency']=orgcurrency
        //console.log("formData.invoice_img.length",formData.invoice_img.length)
        /*if (formData.invoice_img.length > 0) {
            if (formData.invoice_img[0].hasOwnProperty('file_name') && formData.invoice_img[0].hasOwnProperty('file_obj')) {
                hash['invoice_img'] = formData.invoice_img[0]
            }
        }*/
        //if(imageChangeFlag){
        // console.log("formData.invoice_img", formData.invoice_img)
        if (formData.invoice_img.length > 0) {
            if (formData.invoice_img[0].hasOwnProperty('file_name') && formData.invoice_img[0].hasOwnProperty('file_obj')) {
                hash['invoice_img'] = formData.invoice_img[0]
            }
        } else {
            hash['invoice_img'] = {}
        }
        //}
        hash['additional_value'] = additionalInputText

        hash['org_bank_details'] = {
            "account_no": formData.org_bank.account_no,
            "bank_name": formData.org_bank.bank_name,
            "bank_address": formData.org_bank.bank_address,
            "bank_country": formData.org_bank.bank_country,
            "ifsc_code": formData.org_bank.ifsc_code
        }

        hash['cust_bank_details'] = {
            "account_no": formData.company_bank.account_no,
            "bank_name": formData.company_bank.bank_name,
            "bank_address": formData.company_bank.bank_address,
            "bank_country": formData.company_bank.bank_country,
            "ifsc_code": formData.company_bank.ifsc_code

        }


        dataSet.push(hash)
        //console.log("dataSet==========", dataSet)
        resolve(dataSet)
        //}

    })

    return promise;

};

export const paymentInvoiceFormatingFormData = (userCredentials, selectedData, conversionAmount, amountAfterConversion, paymentDate, paymentType, conversion_allowance_percentage, comment,tdsAmount) => {
    let promise = new Promise((resolve, reject) => {
        //let dataSet = [];
        //let hash = {}

        let paymentTypeData = ""
        if (paymentType.full_payment) {
            paymentTypeData = "full_payment"
        }
        if (paymentType.pertial_payment) {
            paymentTypeData = "partial_payment"
        }
        let arrayHash = [
            {
                "resource_name": "ReceivedInvoicePayment",
                "column_value_pair": [
                    {
                        "invoice_number": selectedData?.invoice_number,
                        "received_invoice_id": selectedData?._id,
                        "amount": conversionAmount,
                        "currency": userCredentials?.user_details?.org_percentages?.currency,
                        "conversion_allowance_percentage": "0",
                        "conversion_amount": amountAfterConversion.toString(),
                        "amount_after_conversion": (parseFloat(conversionAmount) - parseFloat(amountAfterConversion)).toFixed(2),
                        "payment_date": paymentDate ? moment(new Date(paymentDate.year + "-" + paymentDate.month + "-" + paymentDate.day)).format('YYYY-MM-DD') : '',
                        "payment_type": paymentTypeData,
                        "comment": comment,
                        "tds":tdsAmount.toString()
                        
                    }
                ]
            }
        ]

        /* hash['invoice_number'] = selectedData?.data?.invoice_number
         hash['amount'] = conversionAmount
         hash['currency'] = userCredentials?.user_details?.org_percentages?.currency
         hash['conversion_allowance_percentage'] = conversion_allowance_percentage
         hash['amount_after_conversion'] = (parseFloat(conversionAmount) - parseFloat(amountAfterConversion)).toFixed(2)
         hash['conversion_amount'] = amountAfterConversion.toString()
         hash['payment_date'] = moment(paymentDate).format('YYYY-MM-DD')
         if (paymentType.full_payment) {
             hash['payment_type'] = "full_payment"
         }
         if (paymentType.pertial_payment) {
             hash['payment_type'] = "partial_payment"
         }*/
        //dataSet.push(hash)
        resolve(arrayHash)
    })

    return promise;

};

const difference = (origObj, newObj) => {
    let changes = (newObj, origObj) => {
        let arrayIndexCounter = 0
        return lodash.transform(newObj, (result, value, key) => {
            if (!lodash.isEqual(value, origObj[key])) {
                let resultKey = lodash.isArray(origObj) ? arrayIndexCounter++ : key
                result[resultKey] = (lodash.isObject(value) && lodash.isObject(origObj[key])) ? changes(value, origObj[key]) : value
            }
        })
    }
    return changes(newObj, origObj)
}