import moment from 'moment';
export const setEditDataForReceiveInvoice = (gridObjData, formData) => {
    // console.log("gridObjData.data", gridObjData)
    let promise = new Promise((resolve, reject) => {
        let data = {}
        data["editId"] = gridObjData._id
        data["invoice_number"] = gridObjData?.invoice_number
        data["company_name"] = { value: gridObjData.cust_details?._id, label: gridObjData.cust_details?.name }

        let org_bank = gridObjData.org_bank_details;
        let company_bank = gridObjData.cust_bank_details;

        org_bank['value'] = gridObjData.org_bank_details.account_no
        org_bank['label'] = `${gridObjData.org_bank_details.account_no}(${gridObjData.org_bank_details.bank_name})`

        company_bank['value'] = gridObjData.cust_bank_details.account_no
        company_bank['label'] = `${gridObjData.cust_bank_details.account_no}(${gridObjData.cust_bank_details.bank_name})`

        /*let org_bank_details_array = org_bank.map(orgobject => {
            return { ...orgobject, "value": orgobject.account_no, "label": `${orgobject.account_no}(${orgobject.bank_name})` };
        });

        let cust_bank_details = company_bank.map(object => {
            return { ...object, "value": object.account_no, "label": `${object.account_no}(${object.bank_name})` };
        });*/


        //console.log("org_bank", org_bank)


        data["org_bank"] = org_bank
        data["company_bank"] = company_bank

        data["address"] = gridObjData.cust_details?.address_line1
        data["sub_total"] = gridObjData?.sub_total
        data["total"] = gridObjData?.total
        data["gst_number"] = gridObjData?.cust_details?.gst_number
        data["invoice_img"] = [
            {
                "file_name": gridObjData?.invoice_img_url?.file_name,
                "file_obj": gridObjData?.invoice_img_url?.img_url
            }
        ]
        data["additional_value"] = gridObjData?.additional_value
        let additionalError = []
        if (gridObjData.additional_value.length > 0) {
            gridObjData.additional_value.map((val) => {
                let _error = {}
                _error['additional_error'] = ""
                additionalError.push(_error)
            })
            data["additional_error"] = additionalError
        }
        data["is_gst_applicable"] = gridObjData?.is_gst_applicable
        data["is_igst_applicable"] = gridObjData?.is_igst_applicable
        data["is_sgst_applicable"] = gridObjData?.is_sgst_applicable
        data["sgst_percentage"] = gridObjData?.sgst_amount
        data["cgst_percentage"] = gridObjData?.cgst_amount


        data["igst_percentage"] = gridObjData?.igst_amount


        //data["receive_invoice_date"] = gridObjData.data?.receive_invoice_date
        let receive_invoice_date_hash = ""
        if (gridObjData?.receive_invoice_date != "") {
            let receiveInvoiceDate = new Date(gridObjData?.receive_invoice_date)
            receive_invoice_date_hash = {
                year: receiveInvoiceDate.getFullYear(),
                month: receiveInvoiceDate.getMonth() + 1,
                day: receiveInvoiceDate.getDate(),

            }
        }
        data["invoiceDate"] = receive_invoice_date_hash

        resolve(data);
    })
    return promise;
};

