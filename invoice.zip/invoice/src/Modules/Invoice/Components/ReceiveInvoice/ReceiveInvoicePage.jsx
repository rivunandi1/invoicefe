import React, { useRef } from 'react';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import { useEffect, useState } from 'react'
import AddEditReceiveInvoiceModalContent from './Components/AddEditReceiveInvoiceModalContent';
import ModalGlobal from '../../../../Utility/Components/ModalGlobal';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../../Actions/AllAction';
import { setUserCredentials } from '../../../Login/Actions/LoginAction';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Utility from '../../../../Utility/Utility';
import moment from 'moment';
import { receivedInvoiceListing, customerListing, paymentReceiptAdd, invoiceRowDelete, paymentInvoiceAdd, paymentTypeUpdateStatus, paymentReceiveInvoiceList, paymentReceiptInvoiceListRowDelete } from './Controller/ReceiveInvoiceController';
import { paymentReciptFormatingFormData, paymentInvoiceFormatingFormData } from './DataFormat/ReceiveInvoiceDataFormat'
import { formatingFormData } from '../../../Home/Components/Customer/DataFormat/CustomerDataFormat'
import * as CustomerController from '../../../Home/Components/Customer/Controller/CustomerController'
import { setEditDataForReceiveInvoice } from './DataFormat/ReceiveInvoiceSetEditDataSet'
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';
import GridActionContent from '../../../../Utility/Components/GridActionContent';
import ConfirmationAlert from '../../../../Utility/Components/ConfirmationAlert'
import FileViewer from 'react-file-viewer';
import PaynowModalContent from './Components/PaynowModalContent'
import PaymentReceiptInvoiceModalContent from './Components/PaymentReceiptInvoiceModalContent'
import CustomerModalContent from '../../../Home/Components/Customer/Components/CustomerModalContent'
import HomeUtility from '../../../Home/Utility/Utility'
import Currency from '../../../../Utility/JsFolder/Currency';
import CurrencySymbols from '../../../../Utility/JsFolder/CurrencySymbols';
import CountryWithCode from '../../../../Utility/JsFolder/CountryWithCode';
import BankDetailsComponent from '../../../../Utility/Components/BankDetailsComponent';
import CommonSearchFilter from '../../../../Utility/Components/CommonSearchFilter'
import Config from '../../../../Utility/Config';

function ReceiveInvoicePage(props) {
  const [orgBankListData, setOrgBankListData] = useState([])
  const [show, setShowtriger] = useState(false);
  const [target, setTarget] = useState(null);
  const [filterDate, setFilterDate] = useState({
    from: null,
    to: null
  })
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState("")

  const [paymentStatusList, setpaymentStatusList] = useState(
    [
      { value: 'pending', label: 'Pending' },
      { value: 'partial_payment', label: 'Partial payment' },
      { value: 'full_payment', label: 'Full payment' },
      { value: 'canceled', label: 'Canceled' },
    ]
  )
  const [companyTypeList, setCompanyTypeList] = useState(
    [
      { label: "Vendor", value: 'vendor' },
    ]
  )
  let imageRef = useRef();
  const [customerTotalResponse, setCustomerTotalResponse] = useState({})
  const [customersList, setCustomersList] = useState([])
  const [modules, setmodules] = useState([InfiniteRowModelModule]);
  const [defaultColDef, setdefaultColDef] = useState({
    flex: 1,
    //resizable: true,
    minWidth: 50

  });

  const [documentViewModal, setdocumentViewModal] = useState(false)
  const [documentViewObj, setdocumentViewObj] = useState({})
  const [zoominzoomoutflag, setzoominzoomoutflag] = useState("")
  const [customeraddflag, setcustomeraddflag] = useState(false)
  const [currencyList, setcurrencyList] = useState([])
  const [countryList, setcountryList] = useState([])

  const [components, setcomponents] = useState({
    loadingRenderer: (params) => {
      //console.log("params=================== worker", params)
      //return null;
      if (params.value !== undefined) {
        return params.value;
      } else {
        return '<img src="https://www.ag-grid.com/example-assets/loading.gif">';
      }
    },
  }
  )

  const [gridApi, setGridApi] = useState(null);
  const [gridColumnApi, setGridColumnApi] = useState(null);
  const [gridparams, setgridparams] = useState(null);
  const [receiveInvoiceModalShow, setShow] = useState(false);
  const [rowData, setRowData] = useState([])
  const codeOutsideClickRef = useRef();
  const [actionModalflag, setActionModalFalg] = useState(false)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [selectedData, setSelectedData] = useState("")
  const [documentObjName, setdocumentObjName] = useState("Choose file")
  const [invoiceData, setInvoiceData] = useState([{ description: "", quantity: "", rate: "", price: "" }]);
  const [invoiceDataError, setInvoiceDataError] = useState([{ description_error: "", quantity_error: "", rate_error: "" }]);
  const [amountAfterConversion, setamountAfterConversion] = useState(0)
  const [paymentDate, setPaymentDate] = useState("")
  const [conversionAmount, setConversionAmount] = useState("")
  const [tdsAmount, setTdsAmount] = useState("")
  const [conversion_allowance_percentage, set_conversion_allowance_percentage] = useState("")
  const [formPaymentErr, setformPaymentErr] = useState({ pertial_full_payment_error: "", payment_date_error: "", total_amount_errpr: "", conversion_allowance_percentage_error: "", tds_error: "" })
  const [paymentType, setPaymentType] = useState({ pertial_payment: false, full_payment: false })
  const [paymentStatusPendingFlag, setPaymentStatusPendingFlag] = useState(false)
  const [paymentReceiptFlag, setPaymentReceiptFlag] = useState(false)
  const [paymentReceiptModalShow, setpaymentReceiptModalShow] = useState(false);
  const [paymentReceiptData, setPaymentReceiptData] = useState("")
  const [totalReceptAmount, setTotalReceptAmount] = useState(0);
  const [lastPaymentType, setLastPaymentType] = useState([])
  const [paymentReceiptInvoiceDeleteModalShow, setpaymentReceiptInvoiceDeleteModalShow] = useState(false);
  const [paymentDeleteObj, setPaymentDeleteObj] = useState("");
  const [comment, setComment] = useState("")
  const [bankaddflag, setbankaddflag] = useState(false)
  const [bankList, setbankList] = useState([])
  const [bankModal, setbankModal] = useState(false)
  const [searchValue, setSearchValue] = useState("")

  //customer add
  const [travailleursModal, settravailleursModal] = useState(false);
  const [cusheaderContent, setcusheaderContent] = useState("Add vendor");
  const [vendorheaderContent, setVendorheaderContent] = useState("Add Receive Invoice");
  const [fromData, setfromData] = useState({
    "name": "",
    "email": "",
    "ph_no": "",
    "profileImage": "",
    "address_line1": "",
    "address_line2": "",
    "city": "",
    "state": "",
    "country": "",
    "zip_code": "",
    "pan_number": "",
    "gstn": "",
    //"gst_number": "",
    //"conversion_allowance_percentage": "",
    "active": true,
    "is_gst_applicable": false,
    "is_sgst_applicable": false,
    "is_igst_applicable": false,
    "currency": "",
    "customer_type": { label: "Vendor", value: 'vendor' },
    "tin": "",
    "tan": ""

  })
  const [fromDataError, setfromDataError] = useState({
    "name": "",
    "email": "",
    "ph_no": "",
    "profileImage": "",
    "address_line1": "",
    "address_line2": "",
    "city": "",
    "state": "",
    "country": "",
    "zip_code": "",
    "pan_number": "",
    "gstn": "",
    //"conversion_allowance_percentage": "",
    "currency": "",
    "gst_applicable_error": "",
    "customer_type": "",

  })


  const [bankDetails, setbankDetails] = useState([{
    "account_no": "",
    "bank_name": "",
    "bank_address": "",
    "bank_country": "",
    "ifsc_code": "",
  }])

  const [bankDetailsError, setbankDetailsError] = useState([{
    "account_no": "",
    "bank_name": "",
    "bank_address": "",
    "bank_country": "",
    "ifsc_code": "",
  }])


  const [imageCropModalFlag, setimageCropModalFlag] = useState(false)
  const [src, setsrc] = useState(null)
  const [croppedImageUrl, setcroppedImageUrl] = useState("")
  const [crop, setcrop] = useState({ unit: '%', width: 30, aspect: 1 / 1 })
  const [addProfileImagePreviewShow, setaddProfileImagePreviewShow] = useState(false)
  const [addprofileImageSelected, setaddprofileImageSelected] = useState(require('../../../../Utility/Public/images/profile-back.png'))
  const [saveButtonDisableEditModal, setsaveButtonDisableEditModal] = useState(true)
  const [profileImageChangeEditMode, setprofileImageChangeEditMode] = useState(false)
  const [editedFlag, seteditedFlag] = useState(false)
  //const [invoiceDate, setInvoiceDate] = useState("")
  //const [invoiceDateErr, setInvoiceDateErr] = useState({ invoice_date_error: "",})

  const [deleteBankDetailsConfirmationAlertModalFlag, setDeleteBankDetailsConfirmationAlertModalFlag] = useState(false)
  const [deleteBankDetailsObj, setDeleteBankDetailsObj] = useState("")

  const actionModalfunction = (e, params) => {
    let width = (parseInt(e.clientX) - 285) + 'px'
    let height = (parseInt(e.clientY) - 65) + 'px'
    setPosition({ x: width, y: height })
    setActionModalFalg(true)
    setSelectedData(params.data)
    if (params.data.payment_status == "pending" || params.data.payment_status == "partial_payment") {
      setPaymentStatusPendingFlag(true)
    } else {
      setPaymentStatusPendingFlag(false)
    }
    if (params.data.payment_status == "pending") {
      setPaymentReceiptFlag(false)
    } else {
      setPaymentReceiptFlag(true)
    }

  }

  useEffect(() => {
    document.body.addEventListener('mousedown', handleClickOutside.bind(this));
  }, [])

  const handleClickOutside = (event) => {
    if (codeOutsideClickRef.current != null) {
      if (codeOutsideClickRef && codeOutsideClickRef.current && !codeOutsideClickRef.current.contains(event.target)) {
        setActionModalFalg(false)
      }
    }

  }

  const [invoiceDeleteObj, setInvoiceDeleteObj] = useState("");
  const [invoiceNumberContent, setInvoiceNumberContent] = useState("");
  const [invoiceCancelModalShow, setInvoiceCancelModalShow] = useState(false);



  const [columnDefs, setColumnDefs] = useState(
    [
      {
        headerName: "Invoice Number",
        field: "invoice_number",
        minWidth: 200,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.invoice_number) {
              return <div className="gridusericon">
                {params.data.invoice_number.length > 15 ?
                  <OverlayTrigger overlay={<Tooltip>{params.data.invoice_number}</Tooltip>}>
                    <span>{params.data.invoice_number.substring(0, 15) + "..."}</span>
                  </OverlayTrigger>
                  :
                  <span>{params.data.invoice_number}</span>
                }
              </div>
            } else {
              return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
            }

          } else {
            return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Invoice Date",
        field: "dateField",
        minWidth: 160,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.receive_invoice_date) {
              return <div className="gridusericon">
                {moment(params.data.receive_invoice_date).format('DD-MM-YYYY')}
              </div>
            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Company Name",
        field: "cust_details",
        minWidth: 110,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.cust_details) {
              return <div className="gridusericon">
                {/* { params.data.cust_details.name.length > 22 ? */}
                {params.data.cust_details.name}
                {/* :null
              } */}
              </div>
            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },

      {
        headerName: "CGST",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 90,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.is_gst_applicable) {
              if (params.data.is_sgst_applicable) {
                if (params.data) {
                  return <div className="gridusericon percentage">
                    {/* {params.data.cgst_amount} */}
                    {parseFloat(params.data.cgst_amount).toFixed(2)}
                  </div>
                } else {
                  return null;
                }
              } else {
                return null
              }
            } else {
              return null
            }


          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "SGST",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 90,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.is_gst_applicable) {
              if (params.data.is_sgst_applicable) {
                if (params.data) {
                  return <div className="gridusericon percentage">
                    {/* {params.data.sgst_amount} */}
                    {parseFloat(params.data.sgst_amount).toFixed(2)}
                  </div>
                } else {
                  return null;
                }
              } else {
                return null
              }
            } else {
              return null
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "IGST",
        field: "calculation",
        headerClass: 'headerNumeric',
        minWidth: 90,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.is_gst_applicable) {
              if (params.data.is_igst_applicable) {
                if (params.data) {
                  return <div className="gridusericon percentage">
                    {/* {params.data.igst_amount} */}
                    {parseFloat(params.data.igst_amount).toFixed(2)}
                  </div>
                } else {
                  return null;
                }
              } else {
                return null
              }
            } else {
              return null
            }
          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Currency",
        field: "cust_details",
        //headerClass: 'headerNumeric',
        minWidth: 100,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.cust_details) {
              return <div className="gridusericon">
                {/* { params.data.cust_details.name.length > 22 ? */}
                {params.data.cust_details.currency}
                {/* :null
              } */}
              </div>
            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },
      {
        headerName: "Total Value",
        field: "total",
        headerClass: 'headerNumeric',
        minWidth: 120,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data.total) {
              /*return <div className="gridusericon percentage">
                {parseFloat(params.data.total).toFixed(2)}
              </div>*/

              let symbolList = CurrencySymbols[params.data.cust_details.currency];
              if (symbolList) {
                return <div className="gridusericon percentage">
                 <span style={{fontWeight:'600'}}>{symbolList.symbol}</span>  {parseFloat(params.data.total).toFixed(2)}
                </div>
              } else {
                return <div className="gridusericon percentage">
                  {parseFloat(params.data.total).toFixed(2)}
                </div>
              }

            } else {
              return null;
            }

          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },

      {
        headerName: "Total Payment",
        field: "recieve_invoice_amount",
        headerClass: 'headerNumeric',
        minWidth: 130,
        cellRendererFramework: (params) => {
          if (params && params.data) {
            if (params.data?.recieve_invoice_amount) {

              /*return <div className="gridusericon percentage">
                {parseFloat(params.data?.recieve_invoice_amount).toFixed(2)}
              </div>*/

              let symbolList = CurrencySymbols[params.data.org_details.currency];
              if (symbolList) {
                return <div className="gridusericon percentage">
                  <span style={{fontWeight:'600'}}>{symbolList.symbol}</span> {parseFloat(params.data?.recieve_invoice_amount).toFixed(2)}
                </div>
              } else {
                return <div className="gridusericon percentage">
                  {parseFloat(params.data?.recieve_invoice_amount).toFixed(2)}
                </div>
              }

            } else {
              return null;
            }
          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },

      {
        headerName: "",
        field: "edit",
        minWidth: 100,
        cellRendererFramework: (params) => {
          if (params.data && params.data && params.data.invoice_img_url && Object.keys(params.data.invoice_img_url).length > 0) {



            let fileName = params.data.invoice_img_url.file_name.split(".")
            let extension = fileName.pop()

            if (extension.toLowerCase() == "xlsx" || extension.toLowerCase() == "xls" || extension.toLowerCase() == "csv" || extension.toLowerCase() == "doc") {
              return <button type="button" className="downloadiconbtn downloadbtn">
                <a download={params.data.invoice_img_url.file_name} href={params.data.invoice_img_url.img_url} title=" " data-tip={props.t('downloadfile')} target="_blank">
                  <img src={require('../../../../Utility/Public/images/downloadicon.png')} />
                </a>
              </button>
            } else {
              return <>
                <div className="actionablePopup">
                  <button className="ellipsisIcon othersdocbtn" onClick={() => { showDocumentInModal(params.data) }}>
                    <img src={require('../../../../Utility/Public/images/docicon.png')} className="sidebaricon" /></button>
                </div>
                <button type="button" className="downloadiconbtn downloadbtn">
                  <a download={params.data.invoice_img_url.file_name} href={params.data.invoice_img_url.img_url} title=" " data-tip={props.t('downloadfile')} target="_blank">
                    <img src={require('../../../../Utility/Public/images/downloadicon.png')} />
                  </a>
                </button>
              </>
            }



          } else {
            return null;
          }
        },

      },

      {
        headerName: "Status",
        field: "preview",
        headerClass: 'headerNumericStatus',
        minWidth: 110,
        cellRendererFramework: (params) => {
          if (params.data) {

            if (params.data.status == 'disable') {
              return <div className="gridusericon status_align align-left">
                Canceled
              </div>
            } else {
              if (params.data.payment_status == 'pending') {
                return <div className="gridusericon status_align align-left">
                  <i className="fa fa-circle red" aria-hidden="true"></i> Pending
                </div>
              } else if (params.data.payment_status == 'partial_payment') {
                return <div className="gridusericon status_align align-left partial_paid_color">
                  <i className="fa fa-circle yellow" aria-hidden="true"></i> Partial paid
                </div>
              } else if (params.data.payment_status == 'paid') {
                return <div className="gridusericon status_align align-left">
                  <i className="fa fa-circle green" aria-hidden="true"></i> Full paid
                </div>
              } else if (params.data.payment_status == 'full_payment') {
                return <div className="gridusericon status_align align-left">
                  <i className="fa fa-circle green" aria-hidden="true"></i> Full paid
                </div>
              } else {
                return null
              }
            }

          } else {
            return null
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      },

      {
        headerName: "",
        field: "edit",
        minWidth: 90,
        cellRendererFramework: (params) => {
          if (params.data && params.data?.status == "enable") {
            return <div className="actionablePopup">
              <button className="ellipsisIcon" onClick={(e) => actionModalfunction(e, params)}><i className="fa fa-ellipsis-v"></i></button>
            </div>
          } else {
            return null;
          }
        },
        cellStyle: params => {
          if (params.data && params.data?.status == "disable") {
            return { 'pointer-events': 'none', 'background-color': '#ddd' };
          }
          return null;
        }
      }

    ]
  )


  const [formData, setFormData] = useState({
    invoice_number: "",
    company_name: "",
    company_bank: "",
    org_bank: "",
    address: "",
    gst_number: "",
    sub_total: 0,
    sgst_percentage: "",
    cgst_percentage: "",
    igst_percentage: "",
    total: 0,
    is_gst_applicable: false,
    is_igst_applicable: false,
    is_sgst_applicable: false,
    //less_discount: "",
    invoice_img: [],
    invoiceDate: ""

  })

  const [errorFormData, setErrorFormData] = useState({
    invoice_number_error: "",
    company_name_error: "",
    company_bank_error: "",
    org_bank_error: "",
    address_error: "",
    gst_number_error: "",
    sgst_percentage_error: "",
    cgst_percentage_error: "",
    igst_percentage_error: "",
    //less_discount_error: "",
    //total_error: "",
    sub_total_error: "",
    gst_applicable_error: "",
    invoice_img_error: "",
    invoice_date_error: ""
  })

  //additional custom input
  const [additionalInputText, setAdditionalInputText] = useState([{ additional_text: "", additional_value: "" }])
  const [additionalInputTextError, setAdditionalInputTextError] = useState([{ additional_error: "" }])

  const [reserveFromData, setReserveFromData] = useState("")
  const [receiveInvoiceEditId, setReceiveInvoiceEditId] = useState("")
  const [imageChangeFlag, setImageChangeFlag] = useState(false)

  //modal close functionality
  const receiveInvoiceModalClose = () => {
    setShow(false);
    setFormData({
      invoice_number: "",
      company_name: "",
      company_bank: "",
      org_bank: "",
      address: "",
      gst_number: "",
      sub_total: 0,
      sgst_percentage: "",
      cgst_percentage: "",
      igst_percentage: "",
      total: 0,
      is_gst_applicable: false,
      is_igst_applicable: false,
      is_sgst_applicable: false,
      //less_discount: "",
      invoice_img: [],
      invoiceDate: ""
    })
    setErrorFormData({
      company_bank_error: "",
      org_bank_error: "",
      invoice_number_error: "",
      company_name_error: "",
      address_error: "",
      gst_number_error: "",
      sgst_percentage_error: "",
      cgst_percentage_error: "",
      igst_percentage_error: "",
      //less_discount_error: "",
      //total_error: "",
      sub_total_error: "",
      gst_applicable_error: "",
      invoice_img_error: "",
      invoice_date_error: ""
    })
    setAdditionalInputText([{ additional_text: "", additional_value: "" }])
    setAdditionalInputTextError([{ additional_error: "" }])
    setReceiveInvoiceEditId("")
    setcustomeraddflag(false)
    setVendorheaderContent("")
    setCustomersList([])
    setImageChangeFlag(false)
  }

  const showDocumentInModal = (data) => {
    //console.log("document show", data?.invoice_img_url?.img_url)
    let fileName = data?.invoice_img_url?.file_name.split(".")
    let extension = fileName.pop()

    let documentHash = {}

    documentHash["file_obj"] = data?.invoice_img_url?.img_url
    documentHash["fileType"] = extension.toLowerCase()

    if (extension.toLowerCase() == "pdf") {
      const blob = base64toBlob(data?.invoice_img_url?.img_url);
      const url = URL.createObjectURL(blob);
      documentHash["file_temp_url"] = url
    }

    setdocumentViewObj(documentHash)
    setdocumentViewModal(true)
  }

  const base64toBlob = (data) => {
    // Cut the prefix `data:application/pdf;base64` from the raw base 64
    const base64WithoutPrefix = data.substr('data:application/octet-stream;base64,'.length);

    const bytes = atob(base64WithoutPrefix);
    let length = bytes.length;
    let out = new Uint8Array(length);

    while (length--) {
      out[length] = bytes.charCodeAt(length);
    }

    return new Blob([out], { type: 'application/pdf' });
  };

  const additionalValueCalculation = (value = "") => {
    let tempformData = { ...formData }
    //console.log("tempformData===", tempformData)
    let temp_additionalInputText = additionalInputText.slice()
    let positive_additional_value = 0
    let negative_additional_value = 0

    temp_additionalInputText.map((e, index) => {
      if (e.additional_value > 0) {
        positive_additional_value += parseFloat(e.additional_value)
      }
      if (e.additional_value < 0) {
        negative_additional_value += parseFloat(e.additional_value)
      }
    })

    //console.log("positive_additional_value===", positive_additional_value)
    //console.log("negative_additional_value===", negative_additional_value)

    let total = 0

    if (tempformData.sub_total != "") {
      total += parseFloat(tempformData.sub_total);
    }

    if (tempformData.is_gst_applicable) {
      if (tempformData.is_sgst_applicable) {
        if (tempformData.sgst_percentage != "") {
          total += parseFloat(tempformData.sgst_percentage);
        }
        if (tempformData.cgst_percentage != "") {
          total += parseFloat(tempformData.cgst_percentage);
        }

      }

      if (tempformData.is_igst_applicable) {
        total += parseFloat(tempformData.igst_percentage);
      }
    }
    if (positive_additional_value != "") {
      total += parseFloat(positive_additional_value);
    }


    if (negative_additional_value != "") {
      total += parseFloat(negative_additional_value);
    }

    //total = (parseInt(tempformData.sub_total) + positive_additional_value) + negative_additional_value

    return total
  }

  const handleAdditionalInputChange = (e, index, type) => {
    const { name, value } = e.target
    let tempFormData = { ...formData }
    let tempAdditionalInputText = additionalInputText.slice()
    let tempAdditionalInputTextError = additionalInputTextError.slice()
    if (type == 'additional_text') {
      tempAdditionalInputText[index].additional_text = value
      tempAdditionalInputTextError[index].additional_error = ""
    }
    if (type == 'additional_value') {
      tempAdditionalInputText[index].additional_value = value
      tempAdditionalInputTextError[index].additional_error = ""
      let total = additionalValueCalculation()
      tempFormData['total'] = total
      setFormData(tempFormData)
    }
    setAdditionalInputText(tempAdditionalInputText)
    setAdditionalInputTextError(tempAdditionalInputTextError)
  }

  const handleClickAdditionalInputField = () => {
    let modifiedAdditionalInputTextObj = { additional_text: "", additional_value: "" }
    let temp_additionalInputText = additionalInputText.slice()
    let temp_additionalInputText_copy = [...temp_additionalInputText, modifiedAdditionalInputTextObj]
    let modifiedAdditionalInputText = { additional_error: "" }
    let tempAdditionalInputTextError = additionalInputTextError.slice()
    let tempAdditionalInputTextErrorCopy = [...tempAdditionalInputTextError, modifiedAdditionalInputText]
    setAdditionalInputText(temp_additionalInputText_copy)
    setAdditionalInputTextError(tempAdditionalInputTextErrorCopy)
  }

  const invoiceModalfunction = () => {
    // console.log("usercredential-- invoice modal vendor payment page==>", props.userCredentials)
    let org_bank_details_array = []

    if (props.userCredentials.user_details.org_bank_details.length > 0) {

      org_bank_details_array = props.userCredentials.user_details.org_bank_details.map(object => {
        return { ...object, "value": object.account_no, "label": `${object.account_no}(${object.bank_name})` };
      });

      /*props.userCredentials.user_details.org_bank_details.map((obj) => {

        let org_bank_details = {}
        org_bank_details['label'] = obj.account_no 
        org_bank_details['value'] = obj.account_no 

        org_bank_details_array.push(org_bank_details)

      })*/

    }
    setOrgBankListData(org_bank_details_array)
    setShow(true);
    setVendorheaderContent("Add Receive Invoice")
    //customerList()
  }



  const handleChangeReceiveInvoiceFormData = (e, type) => {
    let tempFormData = { ...formData };
    let tempErrorFormData = { ...errorFormData }

    if (type == "invoice_number") {
      if (e.target.value == "") {
        tempErrorFormData['invoice_number_error'] = "* Invalid Field"
        tempFormData["invoice_number"] = ""
      } else {
        tempFormData["invoice_number"] = e.target.value
        tempErrorFormData['invoice_number_error'] = ""
      }
    }

    if (type == "company_name") {
      let bankArry = []
      let bankDetailsArry = [];
      let bankErrorArry = [];
      if (e) {
        // console.log(">>>e<<<<", e)
        tempFormData["company_name"] = e
        tempErrorFormData['company_name_error'] = ""
        tempFormData['company_bank'] = "";
        let selectedCustomerData = customerTotalResponse.filter(res => {
          return res._id == e.value;

        });

        if (selectedCustomerData[0]?.bank_details && selectedCustomerData[0].bank_details.length > 0) {
          selectedCustomerData[0].bank_details.map((b, i) => {

            let hash = { value: b.account_no, label: `${b.account_no}(${b.bank_name})`, account_no: b.account_no, bank_name: b.bank_name, bank_address: b.bank_address, bank_country: b.bank_country, ifsc_code: b.ifsc_code }
            bankArry.push(hash)
            //
            let findBankCountry = CountryWithCode.filter(Bres => {
              return Bres.country == b.bank_country;
            });

            let bankCountry = {}
            if (findBankCountry.length > 0) {
              bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
            }

            let bankhash = {
              "account_no": b.account_no,
              "bank_name": b.bank_name,
              "bank_address": b.bank_address,
              "bank_country": bankCountry,
              "ifsc_code": b.ifsc_code,
            }
            let errorhash = {
              "account_no": "",
              "bank_name": "",
              "bank_address": "",
              "bank_country": "",
              "ifsc_code": "",
            }

            bankDetailsArry.push(bankhash)
            bankErrorArry.push(errorhash)
          })
        }

        //console.log("bankArry===", bankArry)

        setbankaddflag(true)
        setbankList(bankArry)
        setbankDetails(bankDetailsArry)
        setbankDetailsError(bankErrorArry)


        let addressArray = []
        if (selectedCustomerData[0]?.address_line1 != "") {
          addressArray.push(selectedCustomerData[0].address_line1)
        }
        if (selectedCustomerData[0]?.city != "") {
          addressArray.push(selectedCustomerData[0].city)
        }
        if (selectedCustomerData[0]?.country != "") {
          addressArray.push(selectedCustomerData[0].country)
        }
        if (selectedCustomerData[0]?.zip_code != "") {
          addressArray.push(selectedCustomerData[0].zip_code)
        }

        tempFormData['address'] = addressArray.join(",")

        tempFormData['gst_number'] = selectedCustomerData[0].hasOwnProperty('gst_number') ? selectedCustomerData[0].gst_number : ""

      } else {
        tempErrorFormData['company_name_error'] = "* Invalid Field"
        tempFormData["company_name"] = ""
        tempFormData["address"] = ""
        tempFormData["gst_number"] = ""
        setbankaddflag(false)
        setbankList(bankArry)
        setbankDetails(bankDetailsArry)
        setbankDetailsError(bankErrorArry)
        tempFormData["company_bank"] = ""

      }
    }

    if (type == "company_bank") {
      if (e) {
        tempFormData["company_bank"] = e
        tempErrorFormData['company_bank_error'] = ""
      } else {
        tempErrorFormData['company_bank_error'] = "* Invalid Field"
        tempFormData["company_bank"] = ""
      }
    }

    if (type == "org_bank") {
      if (e) {
        tempFormData["org_bank"] = e
        tempErrorFormData['org_bank_error'] = ""
      } else {
        tempErrorFormData['org_bank_error'] = "* Invalid Field"
        tempFormData["org_bank"] = ""
      }
    }

    if (type == "address") {
      if (e.target.value == "") {
        tempErrorFormData['address_error'] = "* Invalid Field"
        tempFormData["address"] = ""
      } else {
        tempFormData["address"] = e.target.value
        tempErrorFormData['address_error'] = ""
      }
    }

    if (type == "gst_number") {
      if (e.target.value == "") {
        tempErrorFormData['gst_number_error'] = "* Invalid Field"
        tempFormData["gst_number"] = ""
      } else {
        tempFormData["gst_number"] = e.target.value
        tempErrorFormData['gst_number_error'] = ""
      }
    }
    if (type == "is_gst_applicable") {
      if (e.target.checked) {
        tempFormData['is_gst_applicable'] = true;
        tempErrorFormData['is_gst_applicable'] = ""

      } else {
        tempFormData['is_gst_applicable'] = false;
        tempErrorFormData['is_gst_applicable'] = "";
        tempFormData['is_sgst_applicable'] = false;
        tempFormData['is_igst_applicable'] = false;
        tempFormData['sgst_percentage'] = 0;
        tempFormData['cgst_percentage'] = 0;
        tempFormData['igst_percentage'] = 0;

      }
    }
    if (type == "is_sgst_applicable") {
      if (e.target.checked) {
        tempFormData['is_sgst_applicable'] = true;
        tempFormData['is_igst_applicable'] = false;
        tempErrorFormData['gst_applicable_error'] = "";
        tempFormData['sgst_percentage'] = 0;
        tempFormData['cgst_percentage'] = 0;
        let total = additionalValueCalculation()
        tempFormData['total'] = total
      } else {
        tempErrorFormData['gst_applicable_error'] = "";

      }
    }

    if (type == "is_igst_applicable") {
      if (e.target.checked) {
        tempFormData['is_igst_applicable'] = true;
        tempFormData['is_sgst_applicable'] = false;
        tempErrorFormData['gst_applicable_error'] = "";
        tempFormData['igst_percentage'] = 0;
        let total = additionalValueCalculation()
        tempFormData['total'] = total
      } else {
        tempErrorFormData['gst_applicable_error'] = "";
      }
    }
    if (type == "sgst_percentage") {
      if (!isNaN(e.target.value)) {

        tempFormData['sgst_percentage'] = e.target.value;
        tempErrorFormData['sgst_percentage_error'] = ""

      }
    }
    if (type == "cgst_percentage") {
      if (!isNaN(e.target.value)) {

        tempFormData['cgst_percentage'] = e.target.value;
        tempErrorFormData['cgst_percentage_error'] = ""


      }
    }
    if (type == "igst_percentage") {
      if (!isNaN(e.target.value)) {

        tempFormData['igst_percentage'] = e.target.value;
        tempErrorFormData['igst_percentage_error'] = ""

      }
    }
    /*if (type == "less_discount") {
      if (isNaN(e.target.value) && e.target.value != "") {
        tempErrorFormData['less_discount_error'] = "Invalid Field"
        tempFormData["less_discount"] = ""
      } else {
        tempFormData["less_discount"] = e.target.value
        tempErrorFormData['less_discount_error'] = ""
      }
    }*/
    if (type == "sub_total") {
      if (isNaN(e.target.value) && e.target.value != "") {
        tempErrorFormData['sub_total_error'] = "* Invalid Field"
        tempFormData["sub_total"] = ""
      } else {
        tempFormData["sub_total"] = e.target.value
        tempErrorFormData['sub_total_error'] = ""
      }

      //setFormData(tempFormData)
      //console.log("total===========", total)
    }
    /*if (type == "total") {
      if (isNaN(e.target.value) && e.target.value != "") {
        tempErrorFormData['total_error'] = "Invalid Field"
        tempFormData["total"] = ""
      } else {
        tempFormData["total"] = e.target.value
        tempErrorFormData['total_error'] = ""
      }
    }*/

    setFormData(tempFormData)
    //console.log("tempFormData=======", tempFormData)

    setErrorFormData(tempErrorFormData)
  }


  useEffect(() => {
    let tempFormData = Object.assign({}, formData)
    if (tempFormData.sub_total != "" || tempFormData.igst_percentage != "" || tempFormData.cgst_percentage != "" || tempFormData.sgst_percentage != "") {
      let total = additionalValueCalculation()
      tempFormData['total'] = total
      setFormData(tempFormData)
    } else {
      tempFormData['total'] = 0
      setFormData(tempFormData)
    }
  }, [formData.sub_total, formData.igst_percentage, formData.cgst_percentage, formData.sgst_percentage])


  const handleChangeinvoiceDate = (type, date) => {
    // console.log("type-----", type)
    // console.log("date-----", date)
    let tempFormData = Object.assign({}, formData)
    let tempFormDataerror = Object.assign({}, errorFormData)
    if (date != "") {
      tempFormData["invoiceDate"] = date
      tempFormDataerror["invoice_date_error"] = ""
    } else {
      tempFormDataerror["invoice_date_error"] = "* Invalid Field"
    }
    setFormData(tempFormData)
    setErrorFormData(tempFormDataerror)
  }

  const formatDateInputs = () => {
    let tempFormData = Object.assign({}, formData)

    if (!tempFormData.invoiceDate.year) return '';
    const Year = tempFormData.invoiceDate.year.toString();
    const Month = tempFormData.invoiceDate.month.toString().padStart(2, 0);
    const Day = tempFormData.invoiceDate.day.toString().padStart(2, 0);
    return `${Day}-${Month}-${Year}`;
  };

  useEffect(() => {
    // console.log("invoiceDate===", formData)
  }, [formData])

  // save button 

  const handleSaveData = (saveAndPay = "") => {
    const { loaderStateTrue, loaderStateFalse } = props;
    let valid = form_validation()
    if (parseInt(formData.total) > 0) {
      if (valid) {
        let org_id = props.userCredentials.user_details.org_id
        let admin_id = props.userCredentials.id
        let admin_name = props.userCredentials.user_details.user_name
        let orgcurrency = props.userCredentials?.user_details?.org_percentages?.currency
        paymentReciptFormatingFormData(formData, org_id, admin_id, admin_name, additionalInputText, receiveInvoiceEditId, reserveFromData, imageChangeFlag,orgcurrency).then((dataSet) => {
          //console.log("dataSet==========main page", dataSet)

          let type = "post"
          let editedId = ""
          if (receiveInvoiceEditId != "") {
            type = "patch"
            editedId = receiveInvoiceEditId
            dataSet = dataSet[0]
          }
          //return false;
          loaderStateTrue();
          paymentReceiptAdd(dataSet, type, editedId).then((response) => {
            loaderStateFalse();
            if (type == "post") {

              if (response.length > 0) {
                response.map((res, index) => {
                  if (res.success) {
                    setShow(false)
                    resetDataGrid()
                    receiveInvoiceModalClose()

                    if (saveAndPay != "") {
                      setSelectedData(res.data)
                      setpayNowModalShow(true)

                    }

                    Utility.toastNotifications(res.message, "Success", "success");
                  } else {
                    Utility.toastNotifications(res.message, "Error", "error")
                  }
                })
              }
            } else {
              if (response.success) {
                setShow(false)
                resetDataGrid()
                receiveInvoiceModalClose()
                Utility.toastNotifications(response.message, "Success", "success");
              } else {
                Utility.toastNotifications(response.message, "Error", "error");
              }
            }

          }).catch((e) => {
            loaderStateFalse();
          })
        })
      }
    } else {
      loaderStateFalse();
      Utility.toastNotifications("Total value is nagative, Please check this!!", "Warning", "warning")
    }
  }


  const form_validation = () => {
    let tempFormData = { ...formData }
    let tempErrorFormData = { ...errorFormData }
    let tempAdditionalInputText = additionalInputText.slice()
    let tempAdditionalInputTextError = additionalInputTextError.slice()
    let valid = true

    //console.log("tempFormData.invoiceDate", tempFormData)


    if (tempFormData.invoiceDate == "") {
      tempErrorFormData["invoice_date_error"] = "* Invalid Field"
      valid = false
    } else {
      tempErrorFormData["invoice_date_error"] = ""
    }


    if (tempFormData.invoice_number == "") {
      tempErrorFormData['invoice_number_error'] = "* Invalid Field"
      valid = false
    }
    if (tempFormData.company_name == "") {
      tempErrorFormData['company_name_error'] = "* Invalid Field"

      valid = false
    }

    if (tempFormData.company_bank == "") {
      tempErrorFormData['company_bank_error'] = "* Invalid Field"

      valid = false
    }
    if (tempFormData.org_bank == "") {
      tempErrorFormData['org_bank_error'] = "* Invalid Field"

      valid = false
    }
    /*if (tempFormData.address == "") {
      tempErrorFormData['address_error'] = "Invalid Field"
      valid = false
    }
    if (tempFormData.gst_number == "") {
      tempErrorFormData['gst_number_error'] = "Invalid Field"
      valid = false
    }*/
    if (tempFormData.is_sgst_applicable == false && tempFormData.is_igst_applicable == false && tempFormData.is_gst_applicable == true) {
      tempErrorFormData['gst_applicable_error'] = "* Invalid Field"
      valid = false;
    } else {
      tempErrorFormData['gst_applicable_error'] = ""
    }
    if (tempFormData.is_sgst_applicable == true && tempFormData.sgst_percentage == "") {
      tempErrorFormData['sgst_percentage_error'] = "* Invalid Field"
      valid = false;
    } else {
      tempErrorFormData['sgst_percentage_error'] = ""
    }
    if (tempFormData.is_sgst_applicable == true && tempFormData.cgst_percentage == "") {
      tempErrorFormData['cgst_percentage_error'] = "* Invalid Field"
      valid = false;
    } else {
      tempErrorFormData['cgst_percentage_error'] = ""
    }
    if (tempFormData.is_igst_applicable == true && tempFormData.igst_percentage == "") {
      tempErrorFormData['igst_percentage_error'] = "* Invalid Field"
      valid = false;
    } else {
      tempErrorFormData['igst_percentage_error'] = ""
    }
    if (tempFormData.sub_total == "") {
      tempErrorFormData['sub_total_error'] = "* Invalid Field"
      valid = false
    }
    /*if (tempFormData.less_discount == "") {
      tempErrorFormData['less_discount_error'] = "Invalid Field"
      valid = false
    }*/
    /*if (tempFormData.total == "") {
      tempErrorFormData['total_error'] = "Invalid Field"
      valid = false
    }*/
    /*if (tempFormData.invoice_img == "") {
      console.log("=========if")
      tempErrorFormData['invoice_img_error'] = "Invalid Field"
      valid = false
    }*/
    tempAdditionalInputText.map((value, index) => {

      if (value.additional_text != "" && value.additional_value == "") {
        valid = false
        tempAdditionalInputTextError[index].additional_error = "* please add additional value"
      }
      if (value.additional_text == "" && value.additional_value != "") {
        valid = false
        tempAdditionalInputTextError[index].additional_error = "* please add additional text"
      }

    })
    setAdditionalInputTextError(tempAdditionalInputTextError)
    setErrorFormData(tempErrorFormData)
    //console.log("___errorData___", errorFormData)
    return valid
  }

  const onGridReady = (params) => {
    setgridparams(params)
    setGridApi(params.api)
    setGridColumnApi(params.columnApi)
    var datasource = serverSideDataSource()
    params.api.setDatasource(datasource);
  };

  const serverSideDataSource = () => {
    //console.log("===================")
    return {
      getRows(params) {
        const { startRow, endRow, filterModel, sortModel } = params
        const { loaderStateTrue, loaderStateFalse } = props;
        loaderStateTrue();
        let filters = {};
        let globalQueryParamshash = {};
        if (searchValue != "") {
          globalQueryParamshash['customer_name'] = searchValue
          filters['filter_op'] = { "customer_name": "substring" }
        }
        // console.log("filterDate==== serverside", filterDate)

        if (filterDate.from && filterDate.to) {
          globalQueryParamshash["start_date"] = filterDate.from ? moment(new Date(filterDate.from.year + "-" + filterDate.from.month + "-" + filterDate.from.day)).format('YYYY-MM-DD') : '';
          globalQueryParamshash["end_date"] = filterDate.to ? moment(new Date(filterDate.to.year + "-" + filterDate.to.month + "-" + filterDate.to.day)).format('YYYY-MM-DD') : '';
        }
        if (selectedPaymentStatus != "") {
          globalQueryParamshash["payment_status"] = selectedPaymentStatus.value;
        }

        if (searchInputAmountValue != "") {
          globalQueryParamshash['total'] = searchInputAmountValue
          filters['filter_op'] = { "total": amountLessOrGreterFormData.less_amount ? "lte" : "gte" }
        }

        globalQueryParamshash["offset"] = startRow;
        globalQueryParamshash["limit"] = endRow;
        // globalQueryParamshash["limit"] = endRow;

        filters['filters'] = globalQueryParamshash

        receivedInvoiceListing(filters).then((response) => {
          // console.log("response-----...", JSON.stringify(response) )
          // console.log("payment_status-----...", response.data[0].payment_status )
          if (response.success) {
            params.successCallback(response.data, response.total);
          } else {
            // console.error(error);
            params.failCallback();
            Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
          }
          loaderStateFalse();
        }).catch((error) => {
          loaderStateFalse();
        });


      }
    };
  }

  const customerList = (customerName) => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    loaderStateTrue();

    let filters = {};
    let globalQueryParamshash = {};
    if (customerName != "") {
      globalQueryParamshash['name'] = customerName
      filters['filter_op'] = { "name": "substring", "customer_type": "ne" }
    }
    globalQueryParamshash["org_id"] = userCredentials.user_details.org_id;
    globalQueryParamshash["customer_type"] = 'customer';
    globalQueryParamshash["active"] = true;
    filters['filters'] = globalQueryParamshash


    customerListing(filters).then((response) => {
      let arry = []
      if (response.success) {
        if (response.data.length > 0) {
          setCustomerTotalResponse(response.data)
          response.data.map((data, index) => {
            arry.push({ label: data.name, value: data._id })
          })
          setCustomersList(arry)
          setShow(true);
          setcustomeraddflag(false)
        } else {
          //console.log("ok")
          setcustomeraddflag(true)
        }
      } else {
        Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
      }
      loaderStateFalse();
    }).catch((error) => {
      loaderStateFalse();
    });

  }

  const resetDataGrid = () => {
    gridparams.api.purgeServerSideCache(null)
    var datasource = serverSideDataSource()
    gridparams.api.setDatasource(datasource);

  }
  const confirmationModalShowFoInvoiceDelete = (params) => {
    //console.log("params============", params)
    setInvoiceCancelModalShow(true)
    setInvoiceDeleteObj(params)
    setInvoiceNumberContent(params?.invoice_number)

  }

  const confirmationModalHideFoInvoiceDelete = () => {
    setInvoiceCancelModalShow(false)
    setInvoiceNumberContent("")

  }

  const getBase64 = (file, cb) => {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      cb(reader.result)
    };
    reader.onerror = function (error) {
      //console.log('Error: ', error);
    };
  }

  const deleteInvoiceConfirmFunction = () => {
    const promise = new Promise((resolve, reject) => {
      const { loaderStateTrue, loaderStateFalse } = props;
      // console.log("invoiceDeleteObj========", invoiceDeleteObj)
      loaderStateTrue();
      let data = {
        "id": [invoiceDeleteObj._id]
      };
      //console.log("data==========", data)
      invoiceRowDelete(data).then((response) => {
        // console.log("response=====delete=====", response)
        response.data.map((val) => {
          if (val.success) {
            Utility.toastNotifications(val.message, "Success", "success");
            resetDataGrid();
            confirmationModalHideFoInvoiceDelete();
            resolve(response)
          }
        })
        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    })
    return promise;
  }

  const dropDocumentFileChange = (files, event) => {
    if (files.length == 1) {
      let fileName = files[0].name.split(".")
      let extension = fileName.pop()
      if (extension.toLowerCase() == "xlsx" || extension.toLowerCase() == "xls" || extension.toLowerCase() == "csv" || extension.toLowerCase() == "docx" || extension.toLowerCase() == "doc" || extension.toLowerCase() == "pdf" || extension.toLowerCase() == "jpg" || extension.toLowerCase() == "jpeg" || extension.toLowerCase() == "png") {
        const fsize = files[0].size;
        const file = Math.round((fsize / 1024));
        if (file >= 5120) {
          Utility.toastNotifications(props.t('fileUploadAlert'), "Warning", "warning");
        } else {
          getBase64(files[0], (result) => {
            let _hash = {}
            _hash['file_name'] = files[0].name
            _hash['file_obj'] = result

            //let documentObjectArryTemp = formData.invoice_img.slice();
            //documentObjectArryTemp.push(_hash)
            let tempFormData = { ...formData }
            //tempFormData['invoice_img'] = documentObjectArryTemp
            tempFormData['invoice_img'] = [_hash]
            setFormData(tempFormData)
            setImageChangeFlag(true)

          })
        }
      } else {
        Utility.toastNotifications(props.t('fileTypeAlert'), "Warning", "warning");
      }
    } else {
      setdocumentObjName("Choose File")
    }
  }

  const uploadMultiDocumentFile = (event) => {
    if (event.target.files.length == 1) {
      let fileName = event.target.files[0].name.split(".")
      let extension = fileName.pop()
      if (extension.toLowerCase() == "xlsx" || extension.toLowerCase() == "xls" || extension.toLowerCase() == "csv" || extension.toLowerCase() == "docx" || extension.toLowerCase() == "doc" || extension.toLowerCase() == "pdf" || extension.toLowerCase() == "jpg" || extension.toLowerCase() == "jpeg" || extension.toLowerCase() == "png") {
        const fsize = event.target.files[0].size;
        const file = Math.round((fsize / 1024));
        if (file >= 5120) {
          Utility.toastNotifications(props.t('fileUploadAlert'), "Warning", "warning");
        } else {
          getBase64(event.target.files[0], (result) => {
            let _hash = {}
            _hash['file_name'] = event.target.files[0].name
            _hash['file_obj'] = result

            //let documentObjectArryTemp = formData.invoice_img.slice();
            //documentObjectArryTemp.push(_hash)
            let tempFormData = { ...formData }
            //tempFormData['invoice_img'] = documentObjectArryTemp
            tempFormData['invoice_img'] = [_hash]
            //console.log("===========else========")
            setFormData(tempFormData)
            setImageChangeFlag(true)
          })
        }
      } else {
        Utility.toastNotifications(props.t('fileTypeAlert'), "Warning", "warning");
      }
    } else {
      setdocumentObjName("Choose File")
    }
  }

  const removeDoc = (i) => {
    let documentObjectArryTemp = formData.invoice_img.slice();
    documentObjectArryTemp.splice(i, 1);
    let tempFormData = { ...formData }
    tempFormData['invoice_img'] = documentObjectArryTemp
    setFormData(tempFormData)
    setImageChangeFlag(false)

  }

  const removeAdditionalTextValue = (idx, type) => {
    //console.log("idx======", idx)
    //console.log("type======", type)
    let tempAdditionalInputText = additionalInputText.slice()
    let tempAdditionalInputTextError = additionalInputTextError.slice()


    //console.log("tempAdditionalInputText======", tempAdditionalInputText)
    //console.log("tempAdditionalInputTextError======", tempAdditionalInputTextError)

    /*if (type == "additional_input_remove") {
      tempAdditionalInputText['additional_text'].splice(idx, 1);
      tempAdditionalInputText['additional_value'].splice(idx, 1);
      tempAdditionalInputTextError['additionalInputTextError'].splice(idx, 1);
    }*/

    tempAdditionalInputText.splice(idx, 1)
    tempAdditionalInputTextError.splice(idx, 1)
    setAdditionalInputText(tempAdditionalInputText)
    setAdditionalInputTextError(tempAdditionalInputTextError)
  }

  const editReceiveInvoice = () => {

    setEditDataForReceiveInvoice(selectedData, formData).then((data) => {
      setShow(true)
      setbankaddflag(true)
      customerList(data?.company_name?.label);
      userWiseBankDetailsGet(data?.company_name?.value)
      invoiceModalfunction();

      //console.log("data=======", data)
      setAdditionalInputTextError(data.additional_error)
      setAdditionalInputText(data.additional_value)
      setFormData(data)

      setReserveFromData(data)
      setReceiveInvoiceEditId(data.editId)
      setVendorheaderContent("Edit Receive Invoice")
      //setImageChangeFlag(true)



    });

  }

  const closedocumentViewModal = () => {
    setdocumentViewModal(false)
    setdocumentViewObj({})
    setzoominzoomoutflag("")

  }


  const zoominFunction = () => {
    //let zoominzoomoutflag = "zoominzoomoutclass"
    // this.setState({
    //   zoominzoomoutflag: zoominzoomoutflag
    // })
    setzoominzoomoutflag("zoominzoomoutclass")
  }
  const zoomoutFunction = () => {
    // let zoominzoomoutflag = ""

    setzoominzoomoutflag("")
  }

  useEffect(() => {
    //console.log("additionalInputTextError=====update state", additionalInputTextError)
  }, [additionalInputTextError])

  const [payNowModalShow, setpayNowModalShow] = useState(false);
  const sendPaynow = () => {
    setpayNowModalShow(true)
    setActionModalFalg(false)
  }
  const payNowModalClose = () => {
    setpayNowModalShow(false)
    resetPaymentData()
    setTdsAmount("")

  }
  const resetPaymentData = () => {
    setformPaymentErr({ pertial_full_payment_error: "", payment_date_error: "", total_amount_errpr: "", conversion_allowance_percentage_error: "" })
    setPaymentType({ pertial_payment: false, full_payment: false })
    setPaymentDate("")
    setConversionAmount("")
    set_conversion_allowance_percentage("")
    setamountAfterConversion(0)
    setComment("")
  }

  const handleChangePaymentDate = (type, date) => {
    let tempObj = Object.assign({}, formPaymentErr)
    if (date != "") {
      setPaymentDate(date)
      tempObj["payment_date_error"] = ""
    } else {
      tempObj["payment_date_error"] = "* Invalid Field"
    }

    setformPaymentErr(tempObj)
  }
  const formatDateInput = () => {
    if (!paymentDate.year) return '';
    const Year = paymentDate.year.toString();
    const Month = paymentDate.month.toString().padStart(2, 0);
    const Day = paymentDate.day.toString().padStart(2, 0);
    return `${Day}/${Month}/${Year}`;
  };

  useEffect(() => {
  }, [paymentDate])

  const paymentOptionType = (event, type) => {
    let fromDataTemp = Object.assign({}, paymentType);
    let tempObj = Object.assign({}, formPaymentErr)

    if (type == "partialPayment") {
      if (event.target.checked) {
        fromDataTemp['pertial_payment'] = true;
        fromDataTemp['full_payment'] = false;
        tempObj['pertial_full_payment_error'] = "";
      } else {
        tempObj['pertial_full_payment_error'] = "";
      }
    }

    if (type == "fullPayment") {
      if (event.target.checked) {
        fromDataTemp['full_payment'] = true;
        fromDataTemp['pertial_payment'] = false;
        tempObj['pertial_full_payment_error'] = "";
      } else {
        tempObj['pertial_full_payment_error'] = "";
      }
    }
    setPaymentType(fromDataTemp)
    setformPaymentErr(tempObj)
  }

  const handleChangeConversionAmount = (event, type) => {
    // console.log("type-->", type)
    const { value } = event.target;
    // console.log("value-->", value)
    let tempObj = Object.assign({}, formPaymentErr)
    if (type == "conversionAmount") {
      if (!isNaN(value) && value != "") {
        setConversionAmount(value)
        set_conversion_allowance_percentage("")
        setamountAfterConversion(0)
        // calculationTdsAmount()
        let tdsPercentage = Config.tdsPercentage
        let tdsAmount = (value / 100) * tdsPercentage

        setTdsAmount(tdsAmount)
        tempObj["total_amount_errpr"] = ""
      } else {
        setConversionAmount("")
        setTdsAmount("")
        tempObj["total_amount_errpr"] = "* Invalid Field"
      }
      setformPaymentErr(tempObj)
    }

    if (type == "tds") {

      if (!isNaN(value) && value != "") {
        setTdsAmount(value)

        tempObj["tds_error"] = ""
      } else {
        setTdsAmount("")
      }
      setformPaymentErr(tempObj)
    }

  }

  const calculationTdsAmount = () => {

    let tdsPercentage = parseFloat(Config.tdsPercentage)
    let totalAmount = parseFloat(conversionAmount)
    let tdsAmount = 0
    if (conversionAmount != "") {
      tdsAmount = (totalAmount / 100) * tdsPercentage
      // console.log("tdsAmount-->", tdsAmount)
      setTdsAmount(tdsAmount)
    }
  }
  useEffect(() => {
    // console.log("tdsAmount===>", tdsAmount)
    // console.log("tdsPercentage===>", Config.tdsPercentage)

  }, [tdsAmount])

  const handleChangeConversionAllowance = (event, type) => {
    const { value } = event.target;
    let tempObj = Object.assign({}, formPaymentErr)
    if (type == "conversion_allowance_percentage") {
      if (!isNaN(value) && value != "") {
        set_conversion_allowance_percentage(value)
        let output = (value * parseInt(conversionAmount)) / 100
        setamountAfterConversion(output)
        tempObj["conversion_allowance_percentage_error"] = ""
      } else {
        set_conversion_allowance_percentage("")
        setamountAfterConversion(0)
        tempObj["conversion_allowance_percentage_error"] = "* Invalid Field"
      }
      setformPaymentErr(tempObj)
    }

  }

  const handleChangeComment = (event, type) => {
    const { value } = event.target;
    if (type == "comment") {
      if (value != "") {
        setComment(value)
      } else {
        setComment("")
      }
    }

  }

  /*useEffect(() => {
  }, [conversionAmount])
  useEffect(() => {
    console.log("amountAfterConversion========", amountAfterConversion)
  }, [amountAfterConversion])
  useEffect(() => {
    console.log("conversion_allowance_percentage=========", conversion_allowance_percentage)
  }, [conversion_allowance_percentage])*/

  const checkValidPaymentData = () => {
    let valid = true
    let tempObj = Object.assign({}, formPaymentErr)
    let fromDataTemp = Object.assign({}, paymentType);

    if (paymentDate == "") {
      tempObj["payment_date_error"] = "* Invalid Field"
      valid = false
    } else {
      tempObj["payment_date_error"] = ""
    }

    if (conversionAmount == "" || isNaN(conversionAmount)) {
      tempObj["total_amount_errpr"] = "* Invalid Field"
      valid = false
    } else {
      tempObj["total_amount_errpr"] = ""
    }



    /*if (conversion_allowance_percentage == "" || isNaN(conversion_allowance_percentage)) {
      tempObj["conversion_allowance_percentage_error"] = "Invalid Field"
      valid = false
    } else {
      tempObj["conversion_allowance_percentage_error"] = ""
    }*/

    if (fromDataTemp.pertial_payment == false && fromDataTemp.full_payment == false) {
      tempObj['pertial_full_payment_error'] = "* Invalid Field"
      valid = false;
    } else {
      tempObj['pertial_full_payment_error'] = ""
    }

    setPaymentType(fromDataTemp)
    setformPaymentErr(tempObj)
    return valid
  }

  const handleSubmitPayment = () => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    let valid = checkValidPaymentData()
    if (valid) {
     
      paymentInvoiceFormatingFormData(userCredentials, selectedData, conversionAmount, amountAfterConversion, paymentDate, paymentType, conversion_allowance_percentage, comment, tdsAmount).then((dataSet) => {
        //console.log("add invoice submit dataset", dataSet)
        loaderStateTrue();
        paymentInvoiceAdd(dataSet).then((response) => {
          if (response.length > 0) {
            response.map((res, index) => {
              if (res.success) {
                //console.log("res============", res)
                paymentTypeStatus()
                resetDataGrid()
                payNowModalClose()
                let received_invoice_id = res.data?.received_invoice_id
                paymentReceiveInvoiceListing("pay_now_success", received_invoice_id)
                setpaymentReceiptModalShow(true)
              }
            })
          }
        }).catch((error) => {
          loaderStateFalse();
        });
      })
    }
  }




  const addCustomer = () => {
    const { loaderStateTrue, loaderStateFalse, userCredentials } = props;
    let valid = validCustomerData();
    //console.log("valid=====", valid)
    if (valid) {
      formatingFormData(fromData, userCredentials, reserveFromData, editedFlag, profileImageChangeEditMode, bankDetails).then((dataSet) => {
        //let dataSet = this.formatingFormData();
        //console.log("dataSet=====", dataSet);
        // return false;

        loaderStateTrue();
        let type = "post";
        let id = ""

        //let formDataTemp = Object.assign({}, formData)

        CustomerController.customerAdd(dataSet, id, type).then((response) => {
          //console.log("response=====", response)
          let tempformData = Object.assign({}, formData)
          loaderStateFalse();
          if (response.length > 0) {
            response.map((res, index) => {
              if (res.success) {
                closeTravailleursModal();
                let selectedCustomer = { value: res.data._id, label: res.data.name }
                tempformData['company_name'] = selectedCustomer;
                //handleChangeReceiveInvoiceFormData(selectedCustomer,'company_name')
                userWiseBankDetailsGet(res.data._id)
                customerList(res.data.name)
                setcustomeraddflag(false)


                let addressone = res.data.address_line1;
                let addresstwo = res.data.address_line2
                let city = res.data.city
                let state = res.data.state
                let country = res.data.country
                let zip = res.data.zip_code

                let addressArry = []
                if (addressone != "") {
                  addressArry.push(addressone)
                }
                if (addresstwo != "") {
                  addressArry.push(addresstwo)
                }
                if (city != "") {
                  addressArry.push(city)
                }
                if (state != "") {
                  addressArry.push(state)
                }
                if (country != "") {
                  addressArry.push(country)
                }
                if (zip != "") {
                  addressArry.push(zip)
                }

                let addressJoin = addressArry.join()

                tempformData['address'] = addressJoin
                tempformData['gst_number'] = res.data.gst_number

                setFormData(tempformData)

                //bank set

                let bankArry = []
                let bankDetailsArry = [];
                let bankErrorArry = [];

                if (res.data.bank_details.length > 0) {
                  res.data.bank_details.map((b, i) => {

                    let hash = { value: b.account_no, label: `${b.account_no}(${b.bank_name})`, account_no: b.account_no, bank_name: b.bank_name, bank_address: b.bank_address, bank_country: b.bank_country, ifsc_code: b.ifsc_code }
                    bankArry.push(hash)
                    //
                    let findBankCountry = CountryWithCode.filter(Bres => {
                      return Bres.country == b.bank_country;
                    });

                    let bankCountry = {}
                    if (findBankCountry.length > 0) {
                      bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
                    }

                    let bankhash = {
                      "account_no": b.account_no,
                      "bank_name": b.bank_name,
                      "bank_address": b.bank_address,
                      "bank_country": bankCountry,
                      "ifsc_code": b.ifsc_code,
                    }
                    let errorhash = {
                      "account_no": "",
                      "bank_name": "",
                      "bank_address": "",
                      "bank_country": "",
                      "ifsc_code": "",
                    }

                    bankDetailsArry.push(bankhash)
                    bankErrorArry.push(errorhash)
                  })
                }

                //console.log("bankArry===", bankArry)

                setbankaddflag(true)
                setbankList(bankArry)
                setbankDetails(bankDetailsArry)
                setbankDetailsError(bankErrorArry)


                Utility.toastNotifications(res.message, "Success", "success");
              } else {
                Utility.toastNotifications(res.message, "Error", "error")
              }
            })
          }
        }).catch((e) => {
          loaderStateFalse();
        })
      })
    }
  }

  const paymentTypeStatus = (type = "") => {
    let id = selectedData?._id
    let dataHash = {};
    let paymentTypeData = ""
    if (type == "") {
      if (paymentType.full_payment) {
        paymentTypeData = "full_payment"
      }
      if (paymentType.pertial_payment) {
        paymentTypeData = "partial_payment"
      }
    } else {
      paymentTypeData = type
    }

    dataHash["payment_status"] = paymentTypeData;
    dataHash["update_for"] = "receive_invoice_payment";
    loaderStateTrue()
    paymentTypeUpdateStatus(id, dataHash).then((response) => {
      loaderStateFalse()
      if (response) {
        if (response.success) {
          resetDataGrid()
          Utility.toastNotifications(response.message, "Success", "success");
        } else {
          Utility.toastNotifications(response.message, "Error", "error");
        }
      }

    }).catch((error) => {
      loaderStateFalse();
    });

  }

  const paymentReceipt = () => {
    setpaymentReceiptModalShow(true)
    paymentReceiveInvoiceListing()
  }
  const paymentReceiptModalClose = () => {
    setpaymentReceiptModalShow(false)
    setPaymentReceiptData("")
    setTotalReceptAmount(0)
    resetDataGrid()
  }

  const paymentReceiveInvoiceListing = (type = "", received_invoice_id) => {
    const { loaderStateTrue, loaderStateFalse } = props;
    let promise = new Promise((resolve, reject) => {


      let filters = {};
      let globalQueryParamshash = {};
      if (type == "pay_now_success") {
        globalQueryParamshash["received_invoice_id"] = received_invoice_id;
      } else {
        globalQueryParamshash["received_invoice_id"] = selectedData?._id;
      }
      filters['filters'] = globalQueryParamshash
      loaderStateTrue()
      paymentReceiveInvoiceList(filters).then((response) => {
        if (response.success) {

          if (response.data.length > 0) {
            let totalValue = 0
            let lastPaymentType = []
            response.data.map((res) => {
              totalValue = parseFloat(totalValue) + parseFloat(res.amount_after_conversion)
              if (res.payment_type) {
                lastPaymentType.push(res.payment_type)
              }

            })
            setPaymentReceiptData(response.data)
            setTotalReceptAmount(totalValue)
            setLastPaymentType(lastPaymentType)
          } else {
            let totalValue = 0
            let lastPaymentType = []
            response.data.map((res) => {
              totalValue = parseFloat(totalValue) + parseFloat(res.amount_after_conversion)
              if (res.payment_type) {
                lastPaymentType.push(res.payment_type)
              }

            })
            setPaymentReceiptData(response.data)
            setTotalReceptAmount(totalValue)
            setLastPaymentType(lastPaymentType)
            //paymentTypeStatus("pending")
          }
          resolve(response)
        }

        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    })

    return promise;
  }

  const deletePaymentReceiptInvoiceFunction = (value) => {
    setpaymentReceiptInvoiceDeleteModalShow(true)
    setPaymentDeleteObj(value)
  }

  const deletePaymentRowModalHide = () => {
    setpaymentReceiptInvoiceDeleteModalShow(false)
  }

  const deletePaymentReceiptInvoiveConfirmFunction = () => {
    const promise = new Promise((resolve, reject) => {
      const { loaderStateTrue, loaderStateFalse } = props;
      paymentDeleteObj
      let id = paymentDeleteObj._id
      //console.log("id=============", id)
      //console.log("paymentDeleteObj=============", paymentDeleteObj)
      loaderStateTrue();
      let data = [
        {
          "resource_name": "ReceivedInvoicePayment",
          "column_value_pair": {
            "ids": [id]
          }
        }
      ]
      paymentReceiptInvoiceListRowDelete(data).then((response) => {
        Utility.toastNotifications(response[0].message, "Success", "success");
        paymentReceiveInvoiceListing().then((listingres) => {
          // console.log("listingres====", listingres)

          if (listingres.total > 0) {
            paymentTypeStatus("partial_payment")
          } else {
            paymentTypeStatus("pending")
          }

        })
        deletePaymentRowModalHide()
        resolve(response)
        loaderStateFalse();
      }).catch((error) => {
        loaderStateFalse();
      });
    })
    return promise;
  }


  const modefyCurrency = () => {

    const arrWithLabelValue = Currency.map(object => {
      return { ...object, "value": object.currencyCode, "label": `${object.currencyCode}(${object.countryCode})` };
    });
    //console.log("arrWithLabelValue====", arrWithLabelValue)
    setcurrencyList(arrWithLabelValue)
    /*this.setState({
        currencyList: arrWithLabelValue
    })*/

  }

  const countryModefy = () => {

    const countryData = CountryWithCode.map(object => {
      return { ...object, "value": object.country, "label": object.country };
    });
    //console.log("arrWithLabelValue====", arrWithLabelValue)
    setcountryList(countryData)
    /*this.setState({
        countryList: countryData
    })*/
  }

  const companyHandleOnInputChange = (e, type) => {
    //console.log("type====", type)
    //console.log("e====", e)
    if (type == "company_name") {
      if (e != "") {
        customerList(e)
      }
    }

    if (type == "company_bank") {
      if (e != "") {
        //customerList(e)
      }
    }


  }


  const openCustomerAddModal = () => {
    modefyCurrency()
    countryModefy()
    settravailleursModal(true)

    setbankDetails([{
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }])

    setbankDetailsError([{
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }])

  }

  const closeTravailleursModal = () => {
    //console.log("-----yes----------")
    const { t } = props
    settravailleursModal(false)
    resetCustomerModalContent();

  }

  //Image url crop 
  const addInputProfileImageChanged = (event) => {
    let targetFileSplit = event.target.files[0].name.split('.');
    let lastElement = targetFileSplit.pop();
    let fromData = { ...fromData };
    let user_profile_image = {
      "file_name": "",
      "file_obj": ""
    };
    if (lastElement == 'JPEG' || lastElement == 'jpeg' || lastElement == 'jpg' || lastElement == 'JPG' || lastElement == 'png' || lastElement == 'PNG' || lastElement == '') {
      const fsize = event.target.files[0].size;
      const file = Math.round((fsize / 1024));
      if (file >= 300) {
        Utility.toastNotifications(props.t('imageUploadAlert'), "Warning", "warning");
      } else {
        setimageCropModalFlag(true)
        if (event.target.files && event.target.files.length > 0) {
          const reader = new FileReader();
          reader.addEventListener('load', () =>

            setsrc(reader.result)
          );
          reader.readAsDataURL(event.target.files[0]);
          user_profile_image["file_name"] = event.target.files[0].name
          user_profile_image["file_obj"] = ""
          fromData["profileImage"] = user_profile_image
          setfromData(fromData)
          setaddProfileImagePreviewShow(true)

          /*this.setState({
            fromData,
            workerModalChange: true,
            traprofileImageError: "",
            addProfileImagePreviewShow: true,
            addProfileImageError: "",
          })*/

        }
      }

    } else {
      fromData["profileImage"] = ""
      setaddProfileImagePreviewShow(false)
      setfromData(fromData)
      setaddprofileImageSelected('Add Image')

    }
  }


  const onImageLoaded = (image) => {
    //console.log("onImageLoaded=====", image)
    imageRef = image;
  };

  const onCropComplete = (crop) => {
    makeClientCrop(crop);
    setsaveButtonDisableEditModal(false)
    setprofileImageChangeEditMode(true)

  };

  const makeClientCrop = async (crop) => {
    let tempfromData = { ...fromData }
    if (imageRef && crop.width && crop.height) {
      const croppedImageUrl = await getCroppedImg(
        imageRef,
        crop,
        'newFile.jpeg'
      );
      let user_profile_image = {}

      setaddprofileImageSelected(croppedImageUrl)

      user_profile_image["file_name"] = tempfromData.profileImage.file_name
      user_profile_image["file_obj"] = croppedImageUrl
      tempfromData["profileImage"] = user_profile_image
      setfromData(tempfromData)

    }
  }

  const getCroppedImg = (image, crop, fileName) => {
    const canvas = document.createElement('canvas');
    const pixelRatio = window.devicePixelRatio;
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    const ctx = canvas.getContext('2d');

    canvas.width = crop.width * pixelRatio * scaleX;
    canvas.height = crop.height * pixelRatio * scaleY;

    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    ctx.imageSmoothingQuality = 'high';

    ctx.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width * scaleX,
      crop.height * scaleY
    );

    const base64Image = canvas.toDataURL('image/jpeg');
    return base64Image

  }

  const onCropChange = (crop, percentCrop) => {
    setcrop(crop);
  };

  const imageCropModalShow = () => {

    setimageCropModalFlag(true)
  }

  const imageCropModalHide = () => {
    let tempfromData = { ...fromData }
    tempfromData["profileImage"] = ""
    setimageCropModalFlag(false)
    setfromData(tempfromData)
    setaddProfileImagePreviewShow(false)
    setsaveButtonDisableEditModal(true)
    setaddprofileImageSelected(require('../../../../Utility/Public/images/profile-back.png'))
    /* this.setState({
         imageCropModalFlag: false,
         addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
         addProfileImageError: "",
         fromData,
         addProfileImagePreviewShow: false,
         saveButtonDisableEditModal: true
     })*/

  }

  const imageCropDataSave = () => {
    setimageCropModalFlag(false)
  }

  const handelChange = (event, type) => {
    //console.log("event=======", event)
    //console.log("type=======", type)

    let fromDataTemp = Object.assign({}, fromData);
    let fromDataTempError = Object.assign({}, fromDataError);

    if (type == "name") {
      if (event.target.value != "") {
        fromDataTemp['name'] = event.target.value;
        fromDataTempError['name'] = ""
      } else {
        fromDataTemp['name'] = "";
        fromDataTempError['name'] = props.t('requiredField')
      }
    }

    if (type == "email") {
      if (event.target.value != "") {
        fromDataTemp['email'] = event.target.value;;
        fromDataTempError['email'] = ""
      } else {
        fromDataTemp['email'] = "";
        fromDataTempError['email'] = ""
      }
    }

    if (type == "ph_no") {
      if (event.target.value == "") {
        fromDataTemp['ph_no'] = event.target.value;
        fromDataTempError['ph_no'] = ""
      } else {
        let phoneValidate = HomeUtility.validate_Phone_Number(event.target.value);
        if (phoneValidate) {
          fromDataTemp['ph_no'] = event.target.value;
          fromDataTempError['ph_no'] = ""

        } else {
          fromDataTemp['ph_no'] = event.target.value;
          fromDataTempError['ph_no'] = props.t('validphonenumber')
        }
      }
    }

    if (type == "address_line1") {
      if (event.target.value != "") {
        fromDataTemp['address_line1'] = event.target.value;;
        fromDataTempError['address_line1'] = ""
      } else {
        fromDataTemp['address_line1'] = "";
        fromDataTempError['address_line1'] = ""
      }
    }

    if (type == "address_line2") {
      if (event.target.value != "") {
        fromDataTemp['address_line2'] = event.target.value;;
        fromDataTempError['address_line2'] = ""
      } else {
        fromDataTemp['address_line2'] = "";
        fromDataTempError['address_line2'] = ""
      }
    }

    if (type == "city") {
      if (event.target.value != "") {
        fromDataTemp['city'] = event.target.value;;
        fromDataTempError['city'] = ""
      } else {
        fromDataTemp['city'] = "";
        fromDataTempError['city'] = ""
      }
    }

    if (type == "state") {
      if (event.target.value != "") {
        fromDataTemp['state'] = event.target.value;;
        fromDataTempError['state'] = ""
      } else {
        fromDataTemp['state'] = "";
        fromDataTempError['state'] = ""
      }
    }

    if (type == "country") {
      if (event != "") {
        fromDataTemp['country'] = event;
        fromDataTempError['country'] = ""
      } else {
        fromDataTemp['country'] = "";
        fromDataTempError['country'] = ""
      }
    }

    if (type == "zip_code") {
      if (!isNaN(event.target.value) && event.target.value != "") {
        fromDataTemp['zip_code'] = event.target.value;
        fromDataTempError['zip_code'] = ""
      } else {
        fromDataTemp['zip_code'] = "";
        fromDataTempError['zip_code'] = ""
      }
    }
    if (type == "pan_number") {
      if (event.target.value == "") {
        fromDataTemp['pan_number'] = event.target.value;
        fromDataTempError['pan_number'] = ""
      } else {
        let panValidate = HomeUtility.validate_pan_Number(event.target.value);
        if (panValidate) {
          fromDataTemp['pan_number'] = event.target.value;
          fromDataTempError['pan_number'] = ""

        } else {
          fromDataTemp['pan_number'] = event.target.value;
          fromDataTempError['pan_number'] = props.t('validpannumber')
        }
      }
    }

    if (type == "gstn") {
      if (event.target.value == "") {
        fromDataTemp['gstn'] = event.target.value;
        fromDataTempError['gstn'] = ""
      } else {
        let phoneValidate = HomeUtility.validate_gst_Number(event.target.value);
        if (phoneValidate) {
          fromDataTemp['gstn'] = event.target.value;
          fromDataTempError['gstn'] = ""

        } else {
          fromDataTemp['gstn'] = event.target.value;
          fromDataTempError['gstn'] = props.t('validgstinnumber')
        }
      }
    }


    if (type == "active") {
      if (event.target.checked) {
        fromDataTemp['active'] = true;
        fromDataTempError['active'] = ""
      } else {
        fromDataTemp['active'] = false;
        fromDataTempError['active'] = ""
      }
    }

    if (type == "is_gst_applicable") {
      if (event.target.checked) {
        fromDataTemp['is_gst_applicable'] = true;
        fromDataTempError['is_gst_applicable'] = ""
      } else {
        fromDataTemp['is_gst_applicable'] = false;
        fromDataTempError['is_gst_applicable'] = "";
        fromDataTemp['is_sgst_applicable'] = false;
        fromDataTemp['is_igst_applicable'] = false;
        //fromDataTemp['gst_number'] = ""
      }
    }

    if (type == "is_sgst_applicable") {
      if (event.target.checked) {
        fromDataTemp['is_sgst_applicable'] = true;
        fromDataTemp['is_igst_applicable'] = false;
        fromDataTempError['gst_applicable_error'] = "";
      } else {
        fromDataTempError['gst_applicable_error'] = "";
      }
    }

    if (type == "is_igst_applicable") {
      if (event.target.checked) {
        fromDataTemp['is_igst_applicable'] = true;
        fromDataTemp['is_sgst_applicable'] = false;
        fromDataTempError['gst_applicable_error'] = "";
      } else {
        fromDataTempError['gst_applicable_error'] = "";
      }
    }

    if (type == "currency") {
      if (event != "") {
        fromDataTemp['currency'] = event;
        fromDataTempError['currency'] = ""
      } else {
        fromDataTemp['currency'] = "";
        fromDataTempError['currency'] = ""
      }
    }

    if (type == "customer_type") {
      if (event != "") {
        fromDataTemp['customer_type'] = event;
        fromDataTempError['customer_type'] = ""
      } else {
        fromDataTemp['customer_type'] = "";
        fromDataTempError['customer_type'] = ""
      }
    }

    if (type == "tin") {
      if (event.target.value != "") {
        fromDataTemp['tin'] = event.target.value;;
        fromDataTempError['tin'] = ""
      } else {
        fromDataTemp['tin'] = "";
        fromDataTempError['tin'] = ""
      }
    }

    if (type == "tan") {
      if (event.target.value != "") {
        fromDataTemp['tan'] = event.target.value;;
        fromDataTempError['tan'] = ""
      } else {
        fromDataTemp['tan'] = "";
        fromDataTempError['tan'] = ""
      }
    }

    setfromData(fromDataTemp)
    setfromDataError(fromDataTempError)

    setsaveButtonDisableEditModal(false)

  }

  const validCustomerData = () => {
    let fromDataTemp = Object.assign({}, fromData);
    let fromDataTempError = Object.assign({}, fromDataError);
    let valid = true;

    if (fromDataTemp.name == "") {
      fromDataTempError['name'] = props.t('requiredField')
      valid = false;
    } else {
      fromDataTempError['name'] = ""
    }

    if (fromDataTemp.email != "") {
      var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      if (!expr.test(fromDataTemp.email)) {
        fromDataTempError['email'] = props.t('validEmail')
        valid = false;
      } else {
        fromDataTempError['email'] = ""
      }

    }
    let phoneValidate = HomeUtility.validate_Phone_Number(fromDataTemp.ph_no);
    if (fromDataTemp.ph_no != "") {
      if (phoneValidate) {
        fromDataTempError['ph_no'] = ""
      } else {
        fromDataTempError['ph_no'] = props.t('validphonenumber')
        valid = false;
      }
    }

    if (fromDataTemp.currency == "") {
      fromDataTempError['currency'] = props.t('requiredField')
      valid = false;
    } else {
      fromDataTempError['currency'] = ""
    }


    /*let panValidate = HomeUtility.validate_pan_Number(fromDataTemp.pan_number);
    if (fromDataTemp.pan_number != "") {
      if (panValidate) {
        fromDataTempError['pan_number'] = ""
      } else {
        fromDataTempError['pan_number'] = props.t('validpannumber')
        valid = false;
      }
    }*/

    let panValidate = HomeUtility.validate_pan_Number(fromDataTemp.pan_number);
    if (fromDataTemp.customer_type.value == "vendor") {
      if (fromDataTemp.pan_number == "") {
        fromDataTempError['pan_number'] = props.t('requiredField')
        valid = false;
      } else {
        if (panValidate) {
          fromDataTempError['pan_number'] = ""
        } else {
          fromDataTempError['pan_number'] = props.t('validpannumber')
          valid = false;
        }
      }
    } else {
      fromDataTempError['pan_number'] = ""
      if (fromDataTemp.pan_number != "") {
        if (panValidate) {
          fromDataTempError['pan_number'] = ""
        } else {
          fromDataTempError['pan_number'] = props.t('validpannumber')
          valid = false;
        }
      }
    }

    if (fromDataTemp.is_gst_applicable == true) {
      if (fromDataTemp.gstn == "") {
        fromDataTempError['gstn'] = props.t('requiredField')
        valid = false;
      } else {
        let gstinValidate = HomeUtility.validate_gst_Number(fromDataTemp.gstn);
        if (gstinValidate) {
          fromDataTempError['gstn'] = ""
        } else {
          fromDataTempError['gstn'] = props.t('validgstinnumber')
          valid = false;
        }
      }
    }


    if (fromDataTemp.is_sgst_applicable == false && fromDataTemp.is_igst_applicable == false && fromDataTemp.is_gst_applicable == true) {
      fromDataTempError['gst_applicable_error'] = props.t('requiredField')
      valid = false;
    } else {
      fromDataTempError['gst_applicable_error'] = ""
    }


    //Bank details validation start
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();

    let bankAccountNumber = []
    if (tempBankDetails.length > 0) {
      tempBankDetails.map((value, idx) => {
        bankAccountNumber.push(value.account_no)
        if (value.account_no == "") {
          tempBankDetailsError[idx]['account_no'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['account_no'] = ""
        }

        if (value.bank_name == "") {
          tempBankDetailsError[idx]['bank_name'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_name'] = ""
        }
        if (value.bank_address == "") {
          tempBankDetailsError[idx]['bank_address'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_address'] = ""
        }
        if (value.bank_country.length == 0) {
          tempBankDetailsError[idx]['bank_country'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_country'] = ""
        }
        if (value.ifsc_code == "") {
          tempBankDetailsError[idx]['ifsc_code'] = props.t('requiredField')
          valid = false;
        } else {
          if (value.ifsc_code.length == 11) {
            tempBankDetailsError[idx]['ifsc_code'] = ""
          } else {
            value['ifsc_code'] = "";
            tempBankDetailsError[idx]['ifsc_code'] = "IFSC code must be 11 digit"
            valid = false;
          }
        }
      })


    }

    if (acountNumberDuplicates(bankAccountNumber)) {
      valid = false;
      Utility.toastNotifications("Duplicates account number", "Error", "error")
    }
    if (fromDataTemp.customer_type.length == 0) {
      fromDataTempError['customer_type'] = 'Required Field'
      valid = false;
    } else {
      fromDataTempError['customer_type'] = ""
    }

    setbankDetailsError(tempBankDetailsError)
    setfromDataError(fromDataTempError)
    return valid;

  }

  const acountNumberDuplicates = (array) => {
    if (array.length !== new Set(array).size) {
      return true;
    }

    return false;
  }



  const resetCustomerModalContent = () => {
    setfromData({
      "name": "",
      "email": "",
      "ph_no": "",
      "profileImage": "",
      "address_line1": "",
      "address_line2": "",
      "city": "",
      "state": "",
      "country": "",
      "zip_code": "",
      "pan_number": "",
      "gstn": "",
      "active": true,
      "is_gst_applicable": false,
      "is_sgst_applicable": false,
      "is_igst_applicable": false,
      "currency": "",
      "customer_type": { label: "Vendor", value: 'vendor' },
      "tin": "",
      "tan": ""
    })
    setfromDataError({
      "name": "",
      "email": "",
      "ph_no": "",
      "profileImage": "",
      "address_line1": "",
      "address_line2": "",
      "city": "",
      "state": "",
      "country": "",
      "zip_code": "",
      "pan_number": "",
      "gstn": "",
      "currency": "",
      "gst_applicable_error": "",
      "customer_type": "",
    })

    setbankDetails([{
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }])

    setbankDetailsError([{
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }])
  }


  const handelClickBankAdd = () => {
    let bankDetailsNew = {
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }
    let bankDetailsErrorNew = {
      "account_no": "",
      "bank_name": "",
      "bank_address": "",
      "bank_country": "",
      "ifsc_code": "",
    }
    let tempBankDetails = bankDetails.slice()
    let tempBankDetails_copy = [...tempBankDetails, bankDetailsNew]


    let tempbankDetailsError = bankDetailsError.slice()
    let tempbankDetailsError_copy = [...tempbankDetailsError, bankDetailsErrorNew]

    setbankDetails(tempBankDetails_copy)
    setbankDetailsError(tempbankDetailsError_copy)

  }


  const handelChangeForBankDetails = (event, type, i) => {




    let fromDataTemp = bankDetails.slice();
    let fromDataTempError = bankDetailsError.slice();
    // let fromDataBudgetTemp = Object.assign({}, this.state.fromDataBudget);
    // let fromDataBudgetTempError = Object.assign({}, this.state.fromDataBudgetError);

    if (type == "account_no") {
      if (!isNaN(event.target.value)) {
        fromDataTemp[i]['account_no'] = event.target.value;
        fromDataTempError[i]['account_no'] = ""
      } else {
        //fromDataTemp[i]['account_no'] = "";
        //fromDataTempError['account_no'] = ""
        Utility.toastNotifications(props.t('please_enter_integer_number'), "Warning", "warning")
      }
    }
    if (type == "bank_name") {
      if (event.target.value != "") {
        fromDataTemp[i]['bank_name'] = event.target.value;
        fromDataTempError[i]['bank_name'] = ""
      } else {
        fromDataTemp[i]['bank_name'] = "";
        fromDataTempError[i]['bank_name'] = ""
      }
    }
    if (type == "bank_address") {
      if (event.target.value != "") {
        fromDataTemp[i]['bank_address'] = event.target.value;
        fromDataTempError[i]['bank_address'] = ""
      } else {
        fromDataTemp[i]['bank_address'] = "";
        fromDataTempError[i]['bank_address'] = ""
      }
    }
    if (type == "bank_country") {
      if (event != "") {
        fromDataTemp[i]['bank_country'] = event;
        fromDataTempError[i]['bank_country'] = ""
      } else {
        fromDataTemp[i]['bank_country'] = "";
        fromDataTempError[i]['bank_country'] = this.props.t('requiredField')
      }
    }
    if (type == "ifsc_code") {
      if (event.target.value != "") {
        if (event.target.value.length == 11) {
          fromDataTempError[i]['ifsc_code'] = ""
        } else {
          fromDataTemp[i]['ifsc_code'] = "";
          fromDataTempError[i]['ifsc_code'] = "* IFSC code must be 11 digit"
        }
        fromDataTemp[i]['ifsc_code'] = event.target.value;
      } else {
        fromDataTemp[i]['ifsc_code'] = "";
        fromDataTempError[i]['ifsc_code'] = ""
      }
    }


    setbankDetails(fromDataTemp)
    setbankDetailsError(fromDataTempError)
    setsaveButtonDisableEditModal(false)

    /*this.setState({
        bankDetails: fromDataTemp,
        // fromDataBudget: fromDataBudgetTemp,
        bankDetailsError: fromDataTempError,
        // fromDataBudgetError: fromDataBudgetTempError,
        // orgDataEditFlag: true,
        saveButtonDisableEditModal: false
    }, () => {
        //console.log("handle fromData", this.state.fromData)
        //console.log("handle fromDataBudget", this.state.fromDataBudget)
    })*/


  }

  const openbankAddmodal = () => {
    setbankModal(true)
    countryModefy()
  }

  const closebankModal = () => {
    setbankModal(false)
    /* setbankDetails([{
       "account_no": "",
       "bank_name": "",
       "bank_address": "",
       "bank_country": "",
       "ifsc_code": "",
     }])
 
     setbankDetailsError([{
       "account_no": "",
       "bank_name": "",
       "bank_address": "",
       "bank_country": "",
       "ifsc_code": "",
     }])*/
  }

  const bankDetailsSave = () => {
    let valid = validBankCheck();
    if (valid) {
      let bankArry = []
      if (bankDetails.length > 0) {
        bankDetails.map((v, i) => {
          let tempHash = {}
          tempHash['account_no'] = v.account_no;
          tempHash['bank_name'] = v.bank_name;
          tempHash['bank_address'] = v.bank_address;
          tempHash['bank_country'] = v.bank_country.value;
          tempHash['ifsc_code'] = v.ifsc_code;
          bankArry.push(tempHash)
        })
      }
      let hash = {}
      hash['bank_details'] = bankArry

      let id = formData.company_name.value;
      CustomerController.customerAdd(hash, id, "patch").then((response) => {
        //console.log("response===", response)
        if (response.success) {
          Utility.toastNotifications(response.message, "Success", "success");
          customerList(formData.company_name.label)
          closebankModal()
          userWiseBankDetailsGet()
        }
      })
    }
  }

  const userWiseBankDetailsGet = (userId = "") => {
    let id = userId != "" ? userId : formData.company_name.value;
    CustomerController.customerBankListing(id).then((response) => {
      //console.log("response===", response)
      let bankArry = []
      let bankDetailsArry = [];
      let bankErrorArry = [];
      if (response.success) {

        /*bankArry = response.data[0].bank_details.map(object => {
          return { ...object, "value": object.account_no, "label": `${object.account_no}(${object.bank_name})` };
        });*/



        if (response.data[0].bank_details.length > 0) {
          response.data[0].bank_details.map((b, i) => {

            let hash = { value: b.account_no, label: `${b.account_no}(${b.bank_name})`, account_no: b.account_no, bank_name: b.bank_name, bank_address: b.bank_address, bank_country: b.bank_country, ifsc_code: b.ifsc_code }
            bankArry.push(hash)
            //
            let findBankCountry = CountryWithCode.filter(Bres => {
              return Bres.country == b.bank_country;
            });

            let bankCountry = {}
            if (findBankCountry.length > 0) {
              bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
            }

            let bankhash = {
              "account_no": b.account_no,
              "bank_name": b.bank_name,
              "bank_address": b.bank_address,
              "bank_country": bankCountry,
              "ifsc_code": b.ifsc_code,
            }
            let errorhash = {
              "account_no": "",
              "bank_name": "",
              "bank_address": "",
              "bank_country": "",
              "ifsc_code": "",
            }

            bankDetailsArry.push(bankhash)
            bankErrorArry.push(errorhash)
          })
        }
      }
      setbankaddflag(true)
      setbankList(bankArry)
      setbankDetails(bankDetailsArry)
      setbankDetailsError(bankErrorArry)
    })
  }

  const validBankCheck = () => {
    //Bank details validation start
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();
    let bankAccountNumber = []
    let valid = true
    if (tempBankDetails.length > 0) {
      tempBankDetails.map((value, idx) => {
        bankAccountNumber.push(value.account_no)
        if (value.account_no == "") {
          tempBankDetailsError[idx]['account_no'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['account_no'] = ""
        }

        if (value.bank_name == "") {
          tempBankDetailsError[idx]['bank_name'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_name'] = ""
        }
        if (value.bank_address == "") {
          tempBankDetailsError[idx]['bank_address'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_address'] = ""
        }
        if (value.bank_country.length == 0) {
          tempBankDetailsError[idx]['bank_country'] = props.t('requiredField')
          valid = false;
        } else {
          tempBankDetailsError[idx]['bank_country'] = ""
        }
        if (value.ifsc_code == "") {
          tempBankDetailsError[idx]['ifsc_code'] = props.t('requiredField')
          valid = false;
        } else {
          if (value.ifsc_code.length == 11) {
            tempBankDetailsError[idx]['ifsc_code'] = ""
          } else {
            value['ifsc_code'] = "";
            tempBankDetailsError[idx]['ifsc_code'] = "* IFSC code must be 11 digit"
            valid = false;
          }
        }
      })


    }
    if (acountNumberDuplicates(bankAccountNumber)) {
      valid = false;
      Utility.toastNotifications("Duplicates account number", "Error", "error")
    }

    return valid

    setbankDetailsError(tempBankDetailsError)

  }

  /*const removeAdditionalBankDetails = (idx, type) => {
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();
    console.log("tempBankDetails======", tempBankDetails)
    console.log("tempBankDetailsError======", tempBankDetailsError)

    tempBankDetails.splice(idx, 1)
    tempBankDetailsError.splice(idx, 1)

    setbankDetails(tempBankDetails)
    setbankDetailsError(tempBankDetailsError)


  }*/
  const removeAdditionalBankDetails = (idx, type) => {
    setDeleteBankDetailsConfirmationAlertModalFlag(true)
    setDeleteBankDetailsObj(idx)
  }

  const deleteBankDetailsConfirmationModalHide = () => {
    setDeleteBankDetailsConfirmationAlertModalFlag(false)
    setDeleteBankDetailsObj("")
  }

  const deleteBankDetailsConfirmationFunction = () => {
    let tempBankDetails = bankDetails.slice();
    let tempBankDetailsError = bankDetailsError.slice();
    tempBankDetails.splice(deleteBankDetailsObj, 1)
    tempBankDetailsError.splice(deleteBankDetailsObj, 1)

    setbankDetails(tempBankDetails)
    setbankDetailsError(tempBankDetailsError)
    setDeleteBankDetailsConfirmationAlertModalFlag(false)
  }

  const formatInvoiceDateInput = () => {
    if (!formData.invoiceDate.year) return '';
    const Year = formData.invoiceDate.year.toString();
    const Month = formData.invoiceDate.month.toString().padStart(2, 0);
    const Day = formData.invoiceDate.day.toString().padStart(2, 0);
    return `${Day}/${Month}/${Year}`;
  };


  const handleSearchBar = (e) => {
    const { value } = e.target;
    setSearchValue(value)
    // console.log("searchValue", value)
  }
  useEffect(() => {
    if (searchValue.length > 2) {
      resetDataGrid()
    }
    if (searchValue.length == 0 && gridparams) {
      resetDataGrid()
    }
  }, [searchValue])

  const clearSearchValue = () => {
    setSearchValue("")
    resetDataGrid()
  }
  const handleChangeDateRange = (date, name) => {
    if (name == "dateRangeDate") {
      if (date) {
        setFilterDate(date)
      }
    }
  }
  const formatDateRangeInput = () => {
    if (!filterDate.to) return '';
    const fromDate = filterDate.from
    const fromYear = fromDate.year.toString();
    const fromMonth = fromDate.month.toString().padStart(2, 0);
    const fromDay = fromDate.day.toString().padStart(2, 0);

    const toDate = filterDate.to
    const toYear = toDate.year.toString();
    const toMonth = toDate.month.toString().padStart(2, 0);
    const toDay = toDate.day.toString().padStart(2, 0);

    return `${fromDay}/${fromMonth}/${fromYear} to ${toDay}/${toMonth}/${toYear}`;
  };
  useEffect(() => {
    if (filterDate.from && filterDate.to) {
      resetDataGrid()
    }

  }, [filterDate])
  const handleSelectedPaymentStatus = (e) => {
    // console.log("1")
    if (e) {
      setSelectedPaymentStatus(e)
      // console.log("2")
    } else {
      // console.log("3")
      setSelectedPaymentStatus("")
    }
  }
  useEffect(() => {
    if (selectedPaymentStatus) {
      resetDataGrid()
    }
    if (selectedPaymentStatus.length == 0 && gridparams) {
      resetDataGrid()
    }

  }, [selectedPaymentStatus])

  const [amountLessOrGreterFormData, setAmountLessOrGreterFormData] = useState({
    less_amount: false,
    greater_amount: false

  })

  const [searchInputAmountValue, setSearchInputAmountValue] = useState("")

  const handleChangeAmountFilterFormData = (e, type) => {
    let tempAmountLessOrGreterFormData = { ...amountLessOrGreterFormData };

    if (type == "less_amount") {
      if (e.target.checked) {
        tempAmountLessOrGreterFormData['less_amount'] = true;
        tempAmountLessOrGreterFormData['greater_amount'] = false;
      }
    }

    if (type == "greater_amount") {
      if (e.target.checked) {
        tempAmountLessOrGreterFormData['greater_amount'] = true;
        tempAmountLessOrGreterFormData['less_amount'] = false;
      }
    }

    setAmountLessOrGreterFormData(tempAmountLessOrGreterFormData)
  }

  useEffect(() => {
    // console.log("amountLessOrGreterFormData=======", amountLessOrGreterFormData)
  }, [amountLessOrGreterFormData])

  const handleAmountSearchBar = (e) => {
    const { value } = e.target;
    setSearchInputAmountValue(value)
    // console.log("searchInputAmountValue", value)
  }

  const clearSearchAmountValue = () => {
    setSearchInputAmountValue("")
    setShowtriger(false);
    //resetDataGrid()
  }
  const searchAmountOnclick = () => {
    resetDataGrid()
    setShowtriger(false);
  }

  useEffect(() => {
    if (searchInputAmountValue.length == 0 && gridparams) {
      resetDataGrid()
    }
  }, [searchInputAmountValue])

  const handleClick = (event) => {
    setShowtriger(!show);
    setTarget(event.target);
  };

  const clearDateRangeFromToDateFunction = () => {
    setFilterDate({
      from: null,
      to: null
    })
  }

  useEffect(() => {
    if (filterDate.from == null && filterDate.to == null && gridparams) {
      resetDataGrid()
    }

  }, [filterDate])

  return (
    <>
      <div className="homepagecontainer">
        <div className="gridcontainer">
          <div className="gridtopviews gridtopviewsroles">
            <div className="rightboxes">
              <button type="button" className="useraddbtn" onClick={invoiceModalfunction}>Add</button>
            </div>
            <CommonSearchFilter
              searchInputFiledDispaly={true}
              handleSearchBar={handleSearchBar}
              searchValue={searchValue}
              clearSearchValue={clearSearchValue}
              searchPlaceHolder="Search customer"
              searchDateRangeDispaly={true}
              handleChangeDateRange={handleChangeDateRange}
              formatDateRangeInput={formatDateRangeInput}
              filterDate={filterDate}
              paymentstatusDisplay={true}
              paymentStatusList={paymentStatusList}
              handleSelectedPaymentStatus={handleSelectedPaymentStatus}
              selectedPaymentStatus={selectedPaymentStatus}

              statusPlaceholder="Choose status"
              amountFilterDisplay={true}

              amountLessOrGreterFormData={amountLessOrGreterFormData}
              handleChangeAmountFilterFormData={handleChangeAmountFilterFormData}
              handleAmountSearchBar={handleAmountSearchBar}
              searchInputAmountValue={searchInputAmountValue}
              clearSearchAmountValue={clearSearchAmountValue}
              searchAmountOnclick={searchAmountOnclick}

              handleClick={handleClick}
              show={show}
              target={target}
              clearDateRangeFromToDateFunction={clearDateRangeFromToDateFunction}

            />
            <div className="clearfix"></div>
            <div className="ag-theme-alpine aggridview agdepart roleviewgrid">
              <AgGridReact
                modules={modules}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                components={components}
                rowSelection="multiple"
                rowModelType="infinite"
                onGridReady={onGridReady}
                rowHeight={62.5}
                headerHeight={47}
                //onSelectionChanged={this.onSelectionChanged.bind(this)}
                cacheBlockSize={20}
                enableRtl={localStorage.getItem('selected_lan_direction') == "rtl" ? true : false}
              />
            </div>

          </div>
        </div>
        < ModalGlobal
          show={receiveInvoiceModalShow}
          onHide={receiveInvoiceModalClose}
          title={vendorheaderContent}
          className="modalcustomize mondimension invoiceModal receiveInvoiceModal"
          footer={false}
          closeButton={true}
          body={
            < AddEditReceiveInvoiceModalContent
              formData={formData}
              handleChangeReceiveInvoiceFormData={handleChangeReceiveInvoiceFormData}
              handleSaveData={handleSaveData}
              errorFormData={errorFormData}
              receiveInvoiceModalClose={receiveInvoiceModalClose}
              customersList={customersList}
              documentObject={formData.invoice_img}
              documentObjName={documentObjName}
              dropDocumentFileChange={dropDocumentFileChange}
              uploadMultiDocumentFile={uploadMultiDocumentFile}
              removeDoc={removeDoc}
              additionalInputText={additionalInputText}
              additionalInputTextError={additionalInputTextError}
              handleClickAdditionalInputField={handleClickAdditionalInputField}
              handleAdditionalInputChange={handleAdditionalInputChange}
              removeAdditionalTextValue={removeAdditionalTextValue}
              companyHandleOnInputChange={companyHandleOnInputChange}
              customeraddflag={customeraddflag}
              openCustomerAddModal={openCustomerAddModal}
              handleChangeinvoiceDate={handleChangeinvoiceDate}
              formatInvoiceDateInput={formatInvoiceDateInput}

              bankaddflag={bankaddflag}
              openbankAddmodal={openbankAddmodal}
              bankList={bankList}
              orgBankListData={orgBankListData}
              receiveInvoiceEditId={receiveInvoiceEditId}
            />
          }

        />


        {actionModalflag ?
          <GridActionContent
            styleWidth={position.x}
            styleHight={position.y}
            codeOutsideClickRef={codeOutsideClickRef}
            gridObjData={selectedData}
            deleteButtonShow={true}
            delete={confirmationModalShowFoInvoiceDelete}
            modefier={editReceiveInvoice}
            sendPaynowButtonShow={paymentStatusPendingFlag}
            paymentReceiptButtonShow={paymentReceiptFlag}
            sendPaynow={sendPaynow}
            paymentReceipt={paymentReceipt}

          />
          : null}

        <ModalGlobal
          show={invoiceCancelModalShow}
          onHide={confirmationModalHideFoInvoiceDelete}
          className="modalcustomize confirmationalertmodal"
          bodyClassName="cancelConfirmationbody"
          headerclassName="close_btn_icon"
          title={props.t('cancelInvoiceTitle')}
          footer={false}
          body={
            <ConfirmationAlert
              BodyFirstContent={props.t('invoiceDeleteConfirmation')}
              BodySecondContent={invoiceNumberContent}
              BodyThirdContent={props.t('invoiceCancelAnableGoBack')}
              confirmationButtonContent={props.t('confirm')}
              cancelButtonContent={props.t('cancel')}
              deleteConfirmButton={deleteInvoiceConfirmFunction}
              deleteCancleButton={confirmationModalHideFoInvoiceDelete}

            />
          }
        />

        <ModalGlobal
          show={documentViewModal}
          onHide={closedocumentViewModal}
          headerShow={true}
          closeButton={true}
          zoominButton={zoominzoomoutflag != "" ? false : true}
          zoomoutButton={zoominzoomoutflag != "" ? true : false}
          //className="modalcustomize documentaddmodal viewdocumentmodal"
          className={zoominzoomoutflag + ' ' + "modalcustomize documentaddmodal viewdocumentmodal documentshowmodal"}
          footer={false}
          backdrop={true}
          keyboard={true}
          zoomin={zoominFunction}
          zoomout={zoomoutFunction}
          body={
            <>
              {
                documentViewObj.fileType == 'pdf' ?
                  <iframe
                    src={documentViewObj && documentViewObj.file_temp_url}
                    title="file"
                    width="100%"
                    height="600"
                  ></iframe>
                  :
                  <FileViewer
                    fileType={documentViewObj.fileType}
                    filePath={documentViewObj.file_obj}
                  //errorComponent={CustomErrorComponent}
                  //onError={this.onError}
                  />
              }

            </>
          }
        />

        < ModalGlobal
          show={payNowModalShow}
          onHide={payNowModalClose}
          title='Pay now'
          className="modalcustomize mondimension invoicePreviewModal paynowModal"
          footer={false}
          closeButton={true}
          body={
            <PaynowModalContent
              invoiceData={invoiceData}
              paymentOptionType={paymentOptionType}
              amountAfterConversion={amountAfterConversion}
              userCredentials={props.userCredentials}
              handleChangePaymentDate={handleChangePaymentDate}
              paymentDate={paymentDate}
              formatDateInput={formatDateInput}
              handleChangeConversionAmount={handleChangeConversionAmount}
              handleChangeConversionAllowance={handleChangeConversionAllowance}
              conversionAmount={conversionAmount}
              handleSubmit={handleSubmitPayment}
              formPaymentErr={formPaymentErr}
              selectedData={selectedData}
              paymentType={paymentType}
              conversion_allowance_percentage={conversion_allowance_percentage}
              handleChangeComment={handleChangeComment}
              comment={comment}
              tdsAmount={tdsAmount}
            />
          }
        />

        <ModalGlobal
          show={paymentReceiptModalShow}
          onHide={paymentReceiptModalClose}
          //title='Payment Receipt'
          className="modalcustomize mondimension invoicePreviewModal"
          footer={false}
          closeButton={true}
          headerShow={false}
          body={
            <PaymentReceiptInvoiceModalContent
              paymentReceiptModalClose={paymentReceiptModalClose}
              selectedData={selectedData}
              paymentReceiptData={paymentReceiptData}
              totalReceptAmount={totalReceptAmount}
              deletePaymentReceiptInvoiceFunction={deletePaymentReceiptInvoiceFunction}
              lastPaymentType={lastPaymentType}
            />
          }
        />

        <ModalGlobal
          show={paymentReceiptInvoiceDeleteModalShow}
          onHide={deletePaymentRowModalHide}
          className="modalcustomize confirmationalertmodal"
          bodyClassName="cancelConfirmationbody"
          headerclassName="close_btn_icon"
          title={props.t('deletePaymentInvoiceTitle')}
          footer={false}
          body={
            <ConfirmationAlert
              BodyFirstContent={props.t('paymentInvoiceDeleteConfirmation')}
              //BodySecondContent={this.state.examDeleteBodySecondContent}
              BodyThirdContent={props.t('paymentInvoiceDeleteAnableGoBack')}
              confirmationButtonContent={props.t('confirm')}
              cancelButtonContent={props.t('cancel')}
              deleteConfirmButton={deletePaymentReceiptInvoiveConfirmFunction}
              deleteCancleButton={deletePaymentRowModalHide}
            />
          }
        />

        <ModalGlobal
          show={travailleursModal}
          onHide={closeTravailleursModal}
          title={cusheaderContent}
          className="modalcustomize mondimension customerModalContent cus_vendor_customer"
          footer={false}
          closeButton={true}
          body={
            <CustomerModalContent
              //Image crop
              addInputProfileImageChanged={addInputProfileImageChanged}
              addprofileImageSelected={addprofileImageSelected}
              crop={crop}
              croppedImageUrl={croppedImageUrl}
              src={src}
              onImageLoaded={onImageLoaded}
              onCropComplete={onCropComplete}
              onCropChange={onCropChange}
              imageCropModalShow={imageCropModalShow}
              imageCropModalHide={imageCropModalHide}
              imageCropModalFlag={imageCropModalFlag}
              imageCropDataSave={imageCropDataSave}
              handelChange={handelChange}
              fromData={fromData}
              fromDataError={fromDataError}
              addCustomer={addCustomer}
              addProfileImagePreviewShow={addProfileImagePreviewShow}
              saveButtonDisableEditModal={saveButtonDisableEditModal}
              disabledEmail={false}
              currencyList={currencyList}
              countryList={countryList}

              bankDetails={bankDetails}
              bankDetailsError={bankDetailsError}
              handelClickBankAdd={handelClickBankAdd}
              handelChangeForBankDetails={handelChangeForBankDetails}
              removeAdditionalBankDetails={removeAdditionalBankDetails}
              companyTypeList={companyTypeList}

            />
          }
        />

        <ModalGlobal
          show={bankModal}
          onHide={closebankModal}
          title="Bank details"
          className="modalcustomize mondimension customerModalContent bank_details_modal_inner_body additionalBanckDetails"
          footer={false}
          closeButton={true}
          body={
            <BankDetailsComponent
              countryList={countryList}
              bankDetails={bankDetails}
              bankDetailsError={bankDetailsError}
              handelChangeForBankDetails={handelChangeForBankDetails}
              handelClickBankAdd={handelClickBankAdd}
              submitButton={true}
              bankDetailsSave={bankDetailsSave}
              removeAdditionalBankDetailsDisplay={true}
              removeAdditionalBankDetails={removeAdditionalBankDetails}
            />
          }
        />

        <ModalGlobal
          show={deleteBankDetailsConfirmationAlertModalFlag}
          onHide={deleteBankDetailsConfirmationModalHide}
          className="modalcustomize confirmationalertmodal"
          bodyClassName="cancelConfirmationbody"
          headerclassName="close_btn_icon"
          title={props.t('deleteBankDetails')}
          footer={false}
          body={
            <ConfirmationAlert
              BodyFirstContent={props.t('bankDeleteConfirmation')}
              //BodySecondContent={enDeleteBodySecondContent}
              BodyThirdContent={props.t('bankDeleteAnableGoBack')}
              confirmationButtonContent={props.t('confirm')}
              cancelButtonContent={props.t('cancel')}
              deleteConfirmButton={deleteBankDetailsConfirmationFunction}
              deleteCancleButton={deleteBankDetailsConfirmationModalHide}
            />
          }
        />

      </div >
    </>
  )
}

//export default ReceiveInvoicePage
const mapStateToProps = (globalState) => {
  return {
    userCredentials: globalState.LoginReducer.userCredentials,
  };
}
export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setUserCredentials })
  (withTranslation()(ReceiveInvoicePage)));