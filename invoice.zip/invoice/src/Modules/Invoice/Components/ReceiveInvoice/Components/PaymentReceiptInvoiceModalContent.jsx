import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { withTranslation } from 'react-i18next';
import moment from 'moment';
import ReactToPrint from 'react-to-print';


class PaymentReceiptInvoiceModalContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      totalValue: 0,
    }

  }


  paymentsReceiptUi = () => {
    const { paymentReceiptData, deletePaymentReceiptInvoiceFunction, lastPaymentType } = this.props;
    let uiArry = []
    //let deleteButtonShow = lastPaymentType.includes("Full payment")
    //console.log("deleteButtonShow=====", deleteButtonShow)
    if (Array.isArray(paymentReceiptData) && paymentReceiptData.length > 0) {
      paymentReceiptData.map((value, i) => {
        //console.log("value==========", value.payment_type)
        uiArry.push(
          <tr key={i}>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'left' }}>{moment(value?.payment_date).format('DD-MM-YYYY')}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'left' }}>{value?.comment}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>{parseFloat(value?.amount).toFixed(2)}</td>
            {/* <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>{parseFloat(value.conversion_amount).toFixed(2)}</td> */}
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>{parseFloat(value?.tds).toFixed(2)}</td>
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>{parseFloat(value?.amount_after_conversion).toFixed(2)}</td>
            
           
            <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>
              <button style={{ fontSize: 15, color: 'red', border: 'none', background: 'transparent' }} onClick={deletePaymentReceiptInvoiceFunction.bind(this, value)} className="delete"><i className="fa fa-trash" aria-hidden="true"></i></button>
            </td>

          </tr>
        )
      })
    } else {
      uiArry.push(<tr key={0}>
        <td colSpan="5" className="norecordfound">{paymentReceiptData}</td>
      </tr>)
    }
    return uiArry;
  }


  onBeforeGetContent=(e)=>{
    // console.log("e==========",e)
  }


  render() {
    const { selectedData, totalReceptAmount, lastPaymentType } = this.props;
    //let actionRowShow = lastPaymentType.includes("Full payment")
    let addressArray = []
    if (selectedData?.cust_details?.address_line1 != "") {
      addressArray.push(selectedData?.cust_details?.address_line1)
    }
    if (selectedData?.cust_details?.address_line2 != "") {
      addressArray.push(selectedData?.cust_details?.address_line2)
    }
    if (selectedData?.cust_details?.city != "") {
      addressArray.push(selectedData?.cust_details?.city)
    }
    if (selectedData?.cust_details?.zip_code != "") {
      addressArray.push(selectedData?.cust_details?.zip_code)
    }
    //console.log("addressArray", addressArray)
    return (
      <div>
        <div className='invoiceBodyScroll' ref={el => (this.componentRef = el)}>

          <div style={{ width: '100%', display: 'inline-block' }}>
            <div style={{ width: '100%', display: 'flex', alignItems: 'end' }}>
              <div style={{ width: '50%', display: 'inline-block', textAlign: 'left' }}>
                <img src={require('../../../../../Utility/Public/images/logo.png')} style={{ height: '90px' }} />
              </div>
              <div style={{ width: '50%', display: 'inline-block', textAlign: 'right' }}>
                <button className='cross' onClick={this.props.paymentReceiptModalClose} style={{ fontSize: '1.5rem', lineHeight: 1, color: '#000', boxShadow: 'none', background: 'transparent', border: 'none', opacity: '0.5', position: 'relative', top: '-10px' }}>x</button>
                <p style={{ fontSize: 15, fontWeight: 300, marginBottom: 0 }}>Pan No: <span>{selectedData?.org_details?.pan_number}</span></p>
                <p style={{ fontSize: 15, fontWeight: 300, marginBottom: 0 }}>GST No: <span>{selectedData?.org_details?.gst_number}</span></p>
              </div>
            </div>
            <div style={{ width: '100%', display: 'inline-block' }}>
              <img src={require('../../../../../Utility/Public/images/divider.png')} style={{ height: '0.2rem', width: '100%' }} />
            </div>
            <div style={{ width: '100%', display: 'inline-block' }}>
              <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}><span style={{ color: '#323C47', fontSize: 15 }}><span style={{ fontWeight: 600 }}>Invoice No:</span> {selectedData?.invoice_number}</span></div>
            </div>
            <div style={{ width: '100%', display: 'inline-block', textAlign: 'center', paddingTop: 10, paddingBottom: 10 }}>
              <span style={{ color: '#333333', fontSize: 16, fontWeight: 600 }}>Receipt</span>
            </div>
            <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
              <span style={{ color: '#323C47', fontSize: 15 }}>To,</span>
            </div>
            <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
              <span style={{ color: '#323C47', fontSize: 15, fontWeight: 600 }}>{selectedData?.cust_details?.name}</span>
            </div>
            <div style={{ width: '100%', display: 'inline-block', textAlign: 'left' }}>
              {/* <span style={{ color: '#323C47', fontSize: 15 }}>{selectedData?.data?.cust_details?.address_line1 + ", " + selectedData?.data?.cust_details?.address_line2 + ", " + selectedData?.data?.cust_details?.city + ", " + selectedData?.data?.cust_details?.zip_code}</span> */}
              <span style={{ color: '#323C47', fontSize: 15 }}>{addressArray.join(",")}</span>
            </div>
            <div style={{ width: '100%', display: 'inline-block', textAlign: 'left', paddingTop: 20 }}>
              <table style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'left' }}>Date</th>
                    <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'left' }}>Comment</th>
                    <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>Amount Receipt</th>
                    <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>TDS</th>
                    {/* <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'center' }}>GST % for foreign currency</th> */}
                    <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}>Total</th>
                    <th style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right' }}></th>
                  </tr>
                </thead>
                <tbody>
                  {this.paymentsReceiptUi()}
                  <tr>
                    <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }} colSpan="4">Total</td>
                    <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}>{parseFloat(totalReceptAmount).toFixed(2)}
                    </td>
                    <td style={{ border: '1px solid black', paddingLeft: 6, paddingRight: 6, textAlign: 'right', fontWeight: 600 }}></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div style={{ width: '100%', display: 'inline-block', paddingTop: 20 }}>
              <div style={{ width: '40%', display: 'inline-block', textAlign: 'left' }}>
                <div><span style={{ color: '#323C47', fontSize: 15 }}>For on & behalf of</span></div>
                <div><span style={{ color: '#323C47', fontSize: 15, fontWeight: 600 }}>{selectedData?.org_details?.name}</span></div>
              </div>
            </div>
            <div style={{ width: '100%', display: 'inline-block' }}>
              <div style={{ width: '40%', display: 'inline-block', textAlign: 'left' }}>
                <div style={{ height: 10, lineHeight: 0, marginTop: 20 }}><span style={{ borderBottom: '1px solid black', width: '70%', display: 'inline-block', lineHeight: 0 }}></span></div>
                <div><span style={{ color: '#323C47', fontSize: 15 }}>{selectedData?.admin_name}</span></div>
                <div><span style={{ color: '#323C47', fontSize: 15 }}>(Authorized Signature)</span></div>
              </div>
            </div>
            <div style={{ width: '100%', display: 'inline-block',borderTop: '2px solid #E6E6E6',marginTop: '20px',paddingTop: '6px',textAlign: 'center' }}>
              <p style={{color: 'rgb(50, 60, 71)',fontSize: '15px',margin: '0',fontFamily:'Poppins-Medium'}}>S 129, B.P Township, Kolkata-700094</p>
              <p style={{color: 'rgb(68, 114, 199)',fontSize: '15px',margin: '0',fontFamily:'Poppins-Medium'}}><span>www.mettletech.in</span></p>
            </div>
          </div>


        </div >
        <ReactToPrint
          trigger={() => {
            // NOTE: could just as easily return <SomeComponent />. Do NOT pass an `onClick` prop
            // to the root node of the returned component as it will be overwritten.
            return <div style={{ width: '100%', display: 'inline-block', textAlign: 'center', marginTop: '20px' }}>
            <button style={{ background: '#0ab', border: '1px solid #0ab', color: '#fff', borderRadius: '6px', fontSize: '13px', padding: '1px 10px' }} >Print</button>
          </div>;
          }}
          content={() => this.componentRef}

          onBeforeGetContent={this.onBeforeGetContent}
        />
      </div>
    );
  }
}

const mapStateToProps = (globalState) => {
  return {
    userCredentials: globalState.LoginReducer.userCredentials
  };
}

export default withRouter(connect(mapStateToProps, {})
  (withTranslation()(PaymentReceiptInvoiceModalContent)));