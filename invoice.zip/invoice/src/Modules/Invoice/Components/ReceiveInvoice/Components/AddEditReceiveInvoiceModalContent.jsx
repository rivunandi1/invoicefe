import React, { Component, useState, useEffect } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import "bootstrap/dist/css/bootstrap.min.css";
import MultipleFileUpload from '../../../../../Utility/Components/MultipleFileUpload'
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import moment from 'moment';

function AddEditReceiveInvoiceModalContent(props) {


  //console.log("props.formData===============", props.formData)
  //console.log("props.errorFormData===============", props.errorFormData)
  //console.log("formData===============", props.formData)
  // console.log("formData.invoiceDate===============", props.formData.invoiceDate)


  const additionalUi = () => {
    let additionaluiArray = []
    if (props.additionalInputText.length > 0) {
      props.additionalInputText.map((item, i) => {
        additionaluiArray.push(
          <div className="row relativeRow" key={i}>
            <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName="Additional Text"
                    //errorLabel={}
                    name="invoiceNumber"
                    type="text"
                    value={item.additional_text}
                    labelPresent={true}
                    onChange={(e) => { props.handleAdditionalInputChange(e, i, 'additional_text') }}
                  />
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName="Additional Value"
                    //errorLabel={}
                    name="invoiceNumber"
                    type="number"
                    value={item.additional_value}
                    labelPresent={true}
                    onChange={(e) => { props.handleAdditionalInputChange(e, i, 'additional_value') }}

                  />
                </div>
              </div>
            </div>
            {props.additionalInputText.length != 1 ?
              <div className='trash_icon_btn' onClick={props.removeAdditionalTextValue.bind(this, i, "additional_input_remove")}><i className="fa fa-trash" aria-hidden="true"></i></div>
              : null}
            <div className="col-md-12 errorClass error_div">{props.additionalInputTextError[i].additional_error}</div>
          </div>
        )
      })
    }
    return additionaluiArray;
  }

  let maximumDate = {
    year: moment().format("YYYY"),
    month: moment().format("MM"),
    day: moment().format("DD")
  }

  return (
    <div className="modalinnerbody createInvoiceModal createReceivedInvoiceModal">
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview required">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="Invoice Number"
                errorLabel={props.errorFormData.invoice_number_error}
                name="invoice_number"
                type="text"
                value={props.formData.invoice_number}
                labelPresent={true}
                onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'invoice_number') }}

              />
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="dropdowninnerbox addReceiveInvoicedropdown required">
            {props.customeraddflag ?
              <div className="addCustomerBtn">
                <button type="button" className="savebtn" onClick={() => props.openCustomerAddModal()} >+ Add vendor</button>
              </div>
              : null}

            <label>Company Name </label>
            <AutosuggestComponent
              handleOnInputChange={(e) => { props.companyHandleOnInputChange(e, "company_name") }}
              options={props.customersList}
              selectedValue={props.formData.company_name}
              handleOnChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'company_name') }}
              name="companyName"
              isMulti={false}
              placeholder=""
              labelName="Company Name"
              //isDisabled={this.props.roleId!=""?true:false}
              isSearchable={true}
              isClearable={true}
            />
            <div className="col-md-12 errorClass error_div">{props.errorFormData.company_name_error}</div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="dropdowninnerbox addReceiveInvoicedropdown required">
            {props.bankaddflag ?
              <div className="addCustomerBtn">
                <button type="button" className="savebtn" onClick={() => props.openbankAddmodal()} >+ Add Bank</button>
              </div>
              : null}

            <label>Company Bank </label>
            <AutosuggestComponent
              handleOnInputChange={(e) => { props.companyHandleOnInputChange(e, "company_bank") }}
              options={props.bankList}
              selectedValue={props.formData.company_bank}
              handleOnChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'company_bank') }}
              name="company_bank"
              isMulti={false}
              placeholder=""
              labelName="Company Bank"
              //isDisabled={this.props.roleId!=""?true:false}
              isSearchable={true}
              isClearable={true}
            />
            <div className="col-md-12 errorClass error_div">{props.errorFormData.company_bank_error}</div>
          </div>
        </div>


        <div className="col-md-6 required">
          <label className="invoiceNum">Organisation bank details</label>
          <div className="dropdowninnerbox addReceiveInvoicedropdown">
            <div className="halfrowbox readOnly">
              <AutosuggestComponent
                options={props.orgBankListData}
                handleOnInputChange={(e) => { props.companyHandleOnInputChange(e, "org_bank") }}
                handleOnChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'org_bank') }}
                name="orgbankname"
                isMulti={false}
                placeholder=""
                labelName="Organisation bank details"
                selectedValue={props.formData.org_bank}
                //isDisabled={this.props.roleId!=""?true:false}
                isSearchable={true}
                isClearable={true}
              //defaultMenuIsOpen={true}
              />
              <div className="col-md-12 errorClass error_div">{props.errorFormData.org_bank_error}</div>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="Address"
                errorLabel={props.errorFormData.address_error}
                name="address"
                type="textarea"
                value={props.formData.address}
                labelPresent={true}
                readOnly={true}
                onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'address') }}
              />
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox readOnly">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="GST NO"
                errorLabel={props.errorFormData.gst_number_error}
                name="gstNumber"
                type="text"
                value={props.formData.gst_number}
                labelPresent={true}
                readOnly={true}
                onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'gst_number') }}
              />
            </div>
          </div>
        </div>
        <div className="col-md-12">
          <div className="multiDocumentaddmodal recInvoice">
            <MultipleFileUpload
              documentObjName={props.documentObjName}
              submitButtonShow={false}
              documentObject={props.documentObject}
              onDrop={props.dropDocumentFileChange}
              onChange={props.uploadMultiDocumentFile}
              filesError={props.errorFormData.invoice_img_error}
              removeDoc={props.removeDoc}
            />
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="col-md-12 custom_checkboxInner gst_applicable_drop">
            <label className="custom_checkbox_tick">GST Applicable
              <input type="checkbox" checked={props.formData.is_gst_applicable} onChange={(e) => props.handleChangeReceiveInvoiceFormData(e, "is_gst_applicable")} />
              <span className="checkmarkCheckbox"></span>
            </label>
          </div>
        </div>
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview required">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="Sub Total"
                errorLabel={props.errorFormData.sub_total_error}
                name="sub_total"
                type="text"
                value={props.formData.sub_total}
                labelPresent={true}
                onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'sub_total') }}
              />
            </div>
          </div>
        </div>
        {props.formData.is_gst_applicable ?
          <div className="col-md-6">
            <div className="gstradiobox">
              <label className="taitlecount">GST Type</label>
              <label className="custom-radio-container">GST
                <input type="radio" name="gst_type" value="is_sgst_applicable" onChange={(e) => props.handleChangeReceiveInvoiceFormData(e, "is_sgst_applicable")} checked={props.formData.is_sgst_applicable ? true : false} />
                <span className="checkmark"></span>
              </label>
              <label className="custom-radio-container">IGST
                <input type="radio" name="gst_type" value="is_igst_applicable" onChange={(e) => props.handleChangeReceiveInvoiceFormData(e, "is_igst_applicable")} checked={props.formData.is_igst_applicable ? true : false} />
                <span className="checkmark"></span>
              </label>
            </div>
            <div className="col-md-12 errorClass error_div">{props.errorFormData.gst_applicable_error}</div>
          </div> : null}

        {props.formData.is_sgst_applicable ?
          <>
            <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName="SGST amount"
                    errorLabel={props.errorFormData.sgst_percentage_error}
                    name="sgst_percentage"
                    type="text"
                    value={props.formData.sgst_percentage}
                    labelPresent={true}
                    onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'sgst_percentage') }}
                  />
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName="CGST amount"
                    errorLabel={props.errorFormData.cgst_percentage_error}
                    name="cgst_percentage"
                    type="text"
                    value={props.formData.cgst_percentage}
                    labelPresent={true}
                    onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'cgst_percentage') }}
                  />
                </div>
              </div>
            </div></> : null}
        {props.formData.is_igst_applicable ?
          <div className="col-md-6">
            <div className="inputrowview inputrowfirstview">
              <div className="halfrowbox">
                <CustomInput
                  parentClassName="input_field_inner"
                  labelName="IGST amount"
                  errorLabel={props.errorFormData.igst_percentage_error}
                  name="igst_percentage"
                  type="text"
                  value={props.formData.igst_percentage}
                  labelPresent={true}
                  onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'igst_percentage') }}
                />
              </div>
            </div>
          </div> : null}

        {/*<div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner"
                labelName="Less Discount"
                errorLabel={props.errorFormData.less_discount_error}
                name="less_discount"
                type="text"
                value={props.formData.less_discount}
                labelPresent={true}
                onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'less_discount') }}
              />
            </div>
          </div>
        </div>*/}
      </div>
      <div className="row">
        <div className="col-md-12">
          {additionalUi()}
        </div>
        <div className="col-md-12">
          <button type="button" className="addMore" onClick={() => { props.handleClickAdditionalInputField() }}>Add</button>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner readOnly"
                labelName="Total"
                //errorLabel={props.errorFormData.total_error}
                name="total"
                type="text"
                value={props.formData.total?parseFloat(props.formData.total).toFixed(2):""}
                labelPresent={true}
                onChange={(e) => { props.handleChangeReceiveInvoiceFormData(e, 'total') }}
                readOnly={true}
              />
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="datepickerinnerbox required">
            <label>Invoice Date</label>
            <DatePicker
              value={props.formData.invoiceDate}
              onChange={props.handleChangeinvoiceDate.bind(this, "invoiceDate")}
              formatInputText={props.formatInvoiceDateInput}
              inputPlaceholder=" "
              shouldHighlightWeekends
              inputClassName="worker_datepicker"
              dateFormat="dd-mm-yyyy"
              maximumDate={maximumDate}
            />
            <div className='col-md-12 errorClass error_div'>{props.errorFormData.invoice_date_error}</div>
          </div>
        </div>
      </div>



      <div className="col-md-12 text-center modfooterbtn">
        <button type="button" className="savebtn" onClick={() => props.handleSaveData()} >Save</button>
        {props.receiveInvoiceEditId == "" ?
        
          <button style={{marginLeft:'7px'}} type="button" className="savebtn" onClick={() => props.handleSaveData("pay")} >Save & Pay</button>
          : null}
        <button type="button" className="cancelbtn" {...props} onClick={() => { props.receiveInvoiceModalClose() }}>Cancel</button>
      </div>
    </div>
  )
}

export default AddEditReceiveInvoiceModalContent