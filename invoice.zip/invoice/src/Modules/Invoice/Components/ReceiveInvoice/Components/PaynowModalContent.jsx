import React, { Component, useState, useEffect } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import moment from 'moment';

function PaynowModalContent(props) {
  // console.log("payment====props", props)
  //console.log("============selectedData", props.selectedData)
  //console.log("utils().getToday()", utils().getToday())

  let minimumDate = {
    year: moment().format("YYYY"),
    month: moment().format("MM"),
    day: moment().format("DD")
  }

  let maximumDate = {
    year: moment().format("YYYY"),
    month: moment().format("MM"),
    day: moment().format("DD")
  }

  if (props?.selectedData?.createdAt) {
    let year = moment(props.selectedData.createdAt).format("YYYY")
    let month = moment(props.selectedData.createdAt).format("MM")
    let day = moment(props.selectedData.createdAt).format("DD")
    minimumDate = {
      year: year,
      month: month,
      day: day
    }
  }

  const additionalValueUi = () => {
    const { selectedData } = props;
    // console.log("selectedData.data.additional_value", selectedData.data.additional_value)
    let uiArry = []
    if (selectedData.additional_value.length > 0) {
      selectedData.additional_value.map((value, i) => {
        // console.log("value==========", value)
        uiArry.push(
          <div className='col-md-6' key={i}>
            <div className="row additional_value_label">
              <div className="col-md-12">
                <div className="additional_label">Additional Amount</div>
                <div className="additional_value">
                  {/* <span>{value.additional_text}</span> */}
                  <span>{value.additional_value}</span>
                </div>
              </div>
            </div>
          </div>
        )
      })
    }
    return uiArry;
  }

  return (
    <div className="modalinnerbody paynowModalBody">
      <div className="row">
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner readOnly"
                labelName="Invoice Number"
                name="invoiceNumber"
                type="text"
                value={props.selectedData?.invoice_number}
                labelPresent={true}
                readOnly={true}
              />
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner readOnly"
                labelName="Sub total "
                name="sub_total"
                type="text"
                value={parseFloat(props.selectedData?.sub_total).toFixed(2).toLocaleString()}
                labelPresent={true}
                readOnly={true}
              />
            </div>
          </div>
        </div>
        <div className="clearfix"></div>
        <div className="col-md-12">
          <div className="row">{additionalValueUi()}</div>
        </div>
        {props.selectedData?.is_gst_applicable ?
          <>
            {props.selectedData?.is_sgst_applicable ?
              <>
                <div className="col-md-6">
                  <div className="inputrowview inputrowfirstview">
                    <div className="halfrowbox">
                      <CustomInput
                        parentClassName="input_field_inner readOnly"
                        labelName="GST amount"
                        name="sgst_percentage"
                        type="text"
                        value={parseFloat(props.selectedData?.sgst_amount).toFixed(2).toLocaleString()}
                        labelPresent={true}
                        readOnly={true}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="inputrowview inputrowfirstview">
                    <div className="halfrowbox">
                      <CustomInput
                        parentClassName="input_field_inner readOnly"
                        labelName="CGST amount"
                        name="cgst_percentage"
                        type="text"
                        value={parseFloat(props.selectedData?.cgst_amount).toFixed(2).toLocaleString()}
                        labelPresent={true}
                        readOnly={true}
                      />
                    </div>
                  </div>
                </div>
              </> : null}
            {props.selectedData?.data?.is_igst_applicable ?
              <div className="col-md-6">
                <div className="inputrowview inputrowfirstview">
                  <div className="halfrowbox">
                    <CustomInput
                      parentClassName="input_field_inner readOnly"
                      labelName="IGST amount"
                      name="igst_percentage"
                      type="text"
                      value={parseFloat(props.selectedData?.igst_amount).toFixed(2).toLocaleString()}
                      labelPresent={true}
                      readOnly={true}
                    />
                  </div>
                </div>
              </div> : null}
          </>
          : null}

        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <div className="halfrowbox">
              <CustomInput
                parentClassName="input_field_inner readOnly"
                labelName={"Total amount " + `(${props.selectedData?.cust_details?.currency})`}
                name="total_amount"
                type="text"
                value={parseFloat(props.selectedData?.total).toFixed(2).toLocaleString()}
                labelPresent={true}
                readOnly={true}
              />
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview radioBoxes requiredField">
            <label className="taitlecount">Payment Option<span>*</span></label>
            <label className="custom-radio-container">Partial Payment
              <input type="radio" name="payment" value="partialPayment" onChange={(e) => props.paymentOptionType(e, "partialPayment")} checked={props.paymentType.pertial_payment ? true : false} />
              <span className="checkmark"></span>
            </label>
            <label className="custom-radio-container">Full Payment
              <input type="radio" name="payment" value="fullPayment" onChange={(e) => props.paymentOptionType(e, "fullPayment")} checked={props.paymentType.full_payment ? true : false} />
              <span className="checkmark"></span>
            </label>
          </div>
          <div className="col-md-12 errorClass error_div">{props.formPaymentErr.pertial_full_payment_error}</div>
        </div>
        <div className="col-md-6">
          <div className="datepickerinnerbox required">
            <label>Payment Date</label>
            <DatePicker
              value={props.paymentDate}
              onChange={props.handleChangePaymentDate.bind(this, "PaymentDate")}
              formatInputText={props.formatDateInput}
              inputPlaceholder=" "
              shouldHighlightWeekends
              inputClassName="worker_datepicker"
              dateFormat="dd/mm/yyyy"
              maximumDate={maximumDate}
            //minimumDate={minimumDate}
            />
            <div className='col-md-12 errorClass error_div'>{props.formPaymentErr.payment_date_error}</div>
          </div>
        </div>
        {props.paymentType.pertial_payment || props.paymentType.full_payment ?
          <>
            <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName={"Total amount to be paid " + `(${props.userCredentials.user_details?.org_percentages?.currency})`}
                    name="conversionAmount"
                    type="text"
                    errorLabel={props.formPaymentErr.total_amount_errpr}
                    value={props.conversionAmount}
                    labelPresent={true}
                    onChange={(e) => { props.handleChangeConversionAmount(e, 'conversionAmount') }}
                  />
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <div className="inputrowview inputrowfirstview">
                <div className="halfrowbox">
                  <CustomInput
                    parentClassName="input_field_inner"
                    labelName="TDS"
                    name="tds"
                    type="text"
                    errorLabel={props.formPaymentErr.tds_error}
                    value={props.tdsAmount? parseFloat(props.tdsAmount).toFixed(2):""}
                    labelPresent={true}
                    onChange={(e) => { props.handleChangeConversionAmount(e, 'tds') }}
                  />
                </div>
              </div>
            </div>

            {/* {props?.selectedData?.data?.cust_details?.currency != props?.selectedData?.data?.org_details?.currency ?
            <>
              <div className="col-md-4">
                <CustomInput
                  parentClassName="input_field_inner"
                  labelName="GST % for foreign currency"
                  name="conversion_allowance_percentage"
                  type="text"
                  value={props.conversion_allowance_percentage}
                  errorLabel={props.formPaymentErr.conversion_allowance_percentage_error}
                  labelPresent={true}
                  //readOnly={true}
                  onChange={(e) => { props.handleChangeConversionAllowance(e, 'conversion_allowance_percentage') }}
                />
              </div>
              <div className="col-md-2" style={{ paddingTop: '24px', paddingLeft: '0px' }}>
                <CustomInput
                  parentClassName="input_field_inner readOnly"
                  labelName=""
                  name="amountAfterConversion"
                  type="text"
                  value={props.amountAfterConversion}
                  labelPresent={true}
                  readOnly={true}
                />
              </div>
            </>
            : null} */}

          </>
          : null}
        <div className="col-md-6">
          <div className="inputrowview inputrowfirstview">
            <CustomInput
              parentClassName="input_field_inner"
              labelName="Comment"
              name="comment"
              type="textarea"
              value={props.comment}
              labelPresent={true}
              onChange={(e) => { props.handleChangeComment(e, 'comment') }}
            />
          </div>
        </div>
      </div>



      <div className="addrowBox modfooterbtn">
        <button type="button" className="savebtn addrowbtn" onClick={() => { props.handleSubmit() }}>Pay</button>
      </div>
      <div className="clearfix"></div>
    </div>
  )
}

export default PaynowModalContent