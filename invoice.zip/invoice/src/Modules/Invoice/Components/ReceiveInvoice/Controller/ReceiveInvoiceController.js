import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { receivedInvoiceListingGet, customerListingGet, paymentReceiptAddPost, invoiceRowDeleteApi, paymentInvoicePost, paymentTypePatch, paymentReceiveInvoiceGet, paymentInvoiceListRowDeleteApi } from '../Model/ReceiveInvoiceModel';
import Config from '../../../../../Utility/Config';

export const receivedInvoiceListing = (data) => {
    return get(`${Config.extendedUrl}received/invoice`, data).then((response) => {
        return receivedInvoiceListingGet(response)
    });
};
export const customerListing = (data) => {
    return get(`${Config.extendedUrl}customers`, data).then((response) => {
        return customerListingGet(response)
    });
};
export const paymentReceiptAdd = (data,type,id) => {
    if(type=="post"){
        return post(`${Config.extendedUrl}received/invoice`, data).then((response) => {
            return paymentReceiptAddPost(response)
        });
    }else{
        return patch(`${Config.extendedUrl}received/invoice/${id}`, data).then((response) => {
            return paymentReceiptAddPost(response)
        });
    }
    
}

export const invoiceRowDelete = (data) => {
    return del(`${Config.extendedUrl}received/invoice`, data).then((response) => {
        return invoiceRowDeleteApi(response)
    });
};

export const paymentInvoiceAdd = (data) => {
    return post(`${Config.extendedUrl}generic`, data).then((response) => {
        return paymentInvoicePost(response)
    });
}

export const paymentTypeUpdateStatus = (id, data) => {
    return patch(`${Config.extendedUrl}received/invoice/${id}`, data).then((response) => {
        return paymentTypePatch(response)
    });
};

export const paymentReceiveInvoiceList = (data) => {
    return get(`${Config.extendedUrl}payment/receive/invoice`, data).then((response) => {
        return paymentReceiveInvoiceGet(response)
    });
};

export const paymentReceiptInvoiceListRowDelete = (data) => {
    return del(`${Config.extendedUrl}generic`, data).then((response) => {
        return paymentInvoiceListRowDeleteApi(response)
    });
};