import React, { Component } from 'react'
import { createHashHistory } from 'history';
import { Switch } from "react-router-dom";
import { Route } from "react-router-dom";
import Default from "../../../Layouts/Default";
import Auth from "../../../Layouts/Auth";
import Invoice from '../Pages/Invoice';

function InvoiceRoute(props) {
    
    const history = createHashHistory();
    const { allowedRoles } = props;

  return (
    <Switch>

        {/*****************Invoice****************/}
        <Route
          exact
          path="/:lng/invoice"
          render={() => (
            <Auth history={history} allowedRoles={allowedRoles}>
              <Invoice  />
            </Auth>
          )}
        />
        {/*****************Invoice****************/}

      </Switch>
  )
}

export default InvoiceRoute