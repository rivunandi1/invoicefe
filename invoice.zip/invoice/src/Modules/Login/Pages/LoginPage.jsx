import React, { useState, useEffect, useRef } from 'react';
import Button from 'react-bootstrap/Button';
import { connect } from 'react-redux';
import Utility from '../../../Utility/Utility';
import { loaderStateTrue, loaderStateFalse, roleWisePermission } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../Actions/LoginAction';
import { Modal } from 'react-bootstrap';
import CommonLogin from '../Components/CommonLogin';
import * as LoginController from '../Controller/LoginController';
import '../Assets/css/logindoc.scss';
import '../Assets/css/loginresponsivedoc.scss';
import LoginUtility from '../Utility/LoginUtility'
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import ModalGlobal from '../../../Utility/Components/ModalGlobal';
import ConfirmationAlert from '../../../Utility/Components/ConfirmationAlert';

//import { useTranslation } from "react-i18next";
import { useTranslation, withTranslation, Trans } from 'react-i18next';

const LoginPage = (props) => {
	const [state, setState] = useState({
		email: "",
		password: "",
		updated_password: "",
		updated_confirm_password: "",
		emailError: "",
		passwordError: "",
		updated_passwordError: "",
		updated_comfirm_passwordError: "",
		passwordLock: false,
		confirmPasswordLock: false,
		passtype: "password",
		confirmPasstype: "password",
		loginCredentials: {},
		//modal
		modalShow: false,
		updatedPasswordSession: "",
		challangeName: "",
		userName: "",

		// Focus
		emailFocus: false,
		passwordFocus: false,

		// Language change
		langaugeConfirmModal: false,
		selectedLangauge: "",
		is_active: true

	})
	//Check multi language
	const { t, i18n } = useTranslation();
	const changeLanguage = (lng) => {
		i18n.changeLanguage(lng);
		props.history.push(`/${lng}/login`);
	};
	//Check multi language


	const { loaderStateTrue, loaderStateFalse, history, logOutApp, setToken, setUserCredentials, roleWisePermission } = props;

	const handleonFocus = (event) => {
		if (event.target.name == "email") {
			setState(prev => ({
				...prev,
				emailFocus: true
			}))
		}

		if (event.target.name == "password") {
			setState(prev => ({
				...prev,
				passwordFocus: true
			}))
		}

	}
	const handleonBlur = (event) => {
		setState(prev => ({
			...prev,
			emailFocus: false,
			passwordFocus: false
		}))
	}

	const handleChange = (event) => {
		if (event.target.name == "email") {

			if (event.target.value == "") {
				setState(prev => ({
					...prev,
					emailError: `${t('emailError')}`
				}))
			} else {
				setState(prev => ({
					...prev,
					emailError: ""
				}))
			}
		}
		if (event.target.name == "password") {
			if (event.target.value == "") {
				setState(prev => ({
					...prev,
					passwordError: `${t('passwordError')}`
				}))

			} else {
				setState(prev => ({
					...prev,
					passwordError: ""
				}))
			}

		}
		if (event.target.name == "updated_password") {
			setState(prev => ({
				...prev,
				updated_passwordError: ""
			}))
		}
		if (event.target.name == "updated_confirm_password") {
			setState(prev => ({
				...prev,
				updated_comfirm_passwordError: ""
			}))
		}
		setState(prev => ({
			...prev,
			[event.target.name]: event.target.value
		}))
	}

	const validation = () => {
		let valid = true;

		if (state.email == "") {
			valid = false;
			setState(prev => ({
				...prev,
				emailError: `${t('emailError')}`
			}))
		} else {
			setState(prev => ({
				...prev,
				emailError: ""
			}))
		}

		if (state.password == "") {
			valid = false;
			setState(prev => ({
				...prev,
				passwordError: `${t('passwordError')}`
			}))
		} else {
			setState(prev => ({
				...prev,
				passwordError: ""
			}))
		}
		return valid;
	}

	const forgotPassword = () => {
		props.history.push(`/${localStorage.getItem('i18nextLng')}/forgot_password`);
	}

	const login = () => {

		let valid = validation();
		const { email, password } = state;
		if (valid) {
			loaderStateTrue();
			let data = {}
			data["email"] = email
			data["password"] = password
			LoginController.loginGetApi(data).then((response) => {
				loaderStateFalse();
				if (response) {
					if (response.success) {
						//new password set
						if (response.data.challengeName == "NEW_PASSWORD_REQUIRED") {
							setState(prev => ({
								...prev,
								modalShow: true,
								updatedPasswordSession: response.data.session,
								challangeName: response.data.challengeName,
								userName: response.data.username
							}))
						} else {
							loginSuccess(response);
						}
					} else {
						if (response.message == "User does not exist.") {
							setState(prev => ({
								...prev,
								passwordError: `${t('wrongEmailPassword')}`
							}))

						} else {
							setState(prev => ({
								...prev,
								passwordError: response.message
							}))
						}
					}
				}
			}).catch(({ response }) => {
				//console.log("catch response",response)
				if (response?.data?.message == "User is disabled.") {
					Utility.toastNotifications(response.data.message, "Error", "error")
				} else if (response?.data?.message == "Incorrect username or password.") {
					Utility.toastNotifications(response.data.message, "Error", "error")
				}
				loaderStateFalse();


			});
		}

	}

	useEffect(() => {

		if (Object.keys(state.loginCredentials).length > 0) {
			setUserCredentialsData();
		}
	}, [state.loginCredentials]);

	const loginSuccess = (response) => {
		const finalIdToken = response.data.tokenType + ' ' + response.data.idToken;
		const accessToken = response.data.accessToken
		const refreshToken = response.data.refreshToken
		const expiresIn = LoginUtility.getExpiryDetails(response.data.expiresIn)

		let filter = {}
		filter['filters'] = { "platform": "web" }
		setToken(finalIdToken, accessToken, expiresIn, refreshToken).then(() => {
			loaderStateTrue();
			LoginController.getCurrentUser(filter).then((userResponse) => {
				//console.log("userResponse",userResponse.message)
				loaderStateFalse();
				if (userResponse.success) {
					setState(prev => ({
						...prev,
						loginCredentials: userResponse.data
					}))
				} else {
					logOutApp().then(
						() => history.push("/")
					);
					Utility.toastNotifications(userResponse.message, "Error", "error")
				}
			}).catch(err => {
				//console.log("err.response.message", err.response)
				if (err.response.data.message == "Access denied!") {
					Utility.toastNotifications(err.response.data.message, "Error", "error")
					loaderStateFalse();
					logOutApp().then(
						() => history.push("/")
					);
				}
				loaderStateFalse();

			})
		})
	}

	const setUserCredentialsData = async () => {
		const { loginCredentials } = state
		setUserCredentials(loginCredentials).then(() => {
			//rolePermission(loginCredentials.user_details.role_id);
			let permission = ['app_admin', 'admin']
			if (permission.includes(loginCredentials.user_details.type)) {
				props.history.push(`/${localStorage.getItem('i18nextLng')}/userdashboard`);
			}
		})
	}

	const rolePermission = (role_id) => {
		let data = [{ "resource_name": "RolesPermissions", "columns": ["id", "role_id", "eventKey", "read_write_permission", "is_enabled"], "column_filters": [{ "is_enabled": 1, "role_id": role_id }] }]
		let filter = {}
		filter['filters'] = JSON.stringify(data);
		LoginController.rolePermissionGetApi(filter).then((response) => {

			//console.log("response.data===",response.data)

			if (response.data.length > 0) {
				let permissionHash = {};
				response.data[0].RolesPermissions_data.map((value) => {
					permissionHash[value.eventKey] = value
				})
				roleWisePermission(permissionHash).then(() => {
					const { loginCredentials } = state
					//console.log("loginCredentials",loginCredentials)
					let permission = ['app_admin', 'admin']
					if (permission.includes(loginCredentials.user_details.role_name)) {
						props.history.push(`/${localStorage.getItem('i18nextLng')}/dashboard`);
					} else {
						props.history.push(`/${localStorage.getItem('i18nextLng')}/userdashboard`);
					}


				});
			}

		}).catch((error) => {
			Utility.toastNotifications(error.message, "Error", "error")
			logOutApp().then(
				() => history.push("/")
			);
		});
	}




	const showText = () => {
		setState(prev => ({
			...prev,
			passwordLock: true,
			passtype: "text"
		}))
	}

	const showPassword = () => {
		setState(prev => ({
			...prev,
			passwordLock: false,
			passtype: "password"
		}))
	}

	const showUpdateConfirmText = () => {
		setState(prev => ({
			...prev,
			confirmPasswordLock: true,
			confirmPasstype: "text"
		}))
	}

	const showUpdateConfirmPassword = () => {
		setState(prev => ({
			...prev,
			confirmPasswordLock: false,
			confirmPasstype: "password"
		}))
	}

	const handleClose = () => {
		loaderStateFalse();
		setState(prev => ({
			...prev,
			modalShow: false,
			updated_password: "",
			updated_confirm_password: ""
		}))
	}

	const updatePassword = () => {
		const { updated_password, updated_confirm_password, userName, updatedPasswordSession, challangeName } = state;
		let valid = updatePasswordCheck();
		//console.log("updatedPasswordSession", updatedPasswordSession)
		if (valid) {
			loaderStateTrue();
			let header = {};
			header["session"] = updatedPasswordSession;
			let data = {
				"email": userName,
				"password": updated_password,
				//session:session,
				"challengeName": challangeName
			}
			LoginController.forcePasswordChange(data, header).then((response) => {
				if (response) {

					if (response.success) {
						handleClose();

						Utility.toastNotifications(response.message, "Success", "success")
						const finalIdToken = response.data.tokenType + ' ' + response.data.idToken;
						const accessToken = response.data.accessToken
						const refreshToken = response.data.refreshToken
						const expiresIn = LoginUtility.getExpiryDetails(response.data.expiresIn)
						setToken(finalIdToken, accessToken, expiresIn, refreshToken).then(() => {
							logOutApp().then(
								() => history.push("/")
							);
						})

					} else {
						loaderStateFalse();
					}
				}
			}).catch((error) => {
				//Utility.toastNotifications(error.message, "Error", "error")
				logOutApp().then(
					() => history.push("/")
				);
			});
		}
	}

	const updatePasswordCheck = () => {
		let valid = true;
		const { updated_password, updated_confirm_password } = state;

		let passwordValidate = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-“!@#%&/,><\’:;|_~`])\S{6,99}$/.test(updated_password);

		if (passwordValidate) {
			setState(prev => ({
				...prev,
				updated_passwordError: ''
			}))
		} else {
			valid = false;
			setState(prev => ({
				...prev,
				updated_passwordError: t('thisFieldIsInvalid')
			}))
			Utility.toastNotifications(`<ul class='password-inner-box'>
            <li><b>${t('minimumLength')}</b>, ${t('mustBeAtLeast6Characters')}</li>
            <li><b>${t('requireNumbers')}</b></li>
            <li><b>${t('requireSpecialCharacter')}</b> ${t('fromThisSet')}: = + - ^ $ * . [ ] { } ( ) ?  ! @ # % & / \ , > < ' : ; | _ ~ </li>
            <li><b>${t('requireUppercaseLetters')}</b></li>
            <li><b>${t('requireLowercaseLetters')}</b></li>
          </ul>`, `${t('passworderror')}`, "longError");
		}


		let CpasswordValidate = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-“!@#%&/,><\’:;|_~`])\S{6,99}$/.test(updated_confirm_password);

		if (CpasswordValidate) {
			setState(prev => ({
				...prev,
				updated_comfirm_passwordError: ''
			}))
		} else {
			valid = false;
			setState(prev => ({
				...prev,
				updated_comfirm_passwordError: t('thisFieldIsInvalid')
			}))
			Utility.toastNotifications(`<ul class='password-inner-box'>
            <li><b>${t('minimumLength')}</b>, ${t('mustBeAtLeast6Characters')}</li>
            <li><b>${t('requireNumbers')}</b></li>
            <li><b>${t('requireSpecialCharacter')}</b> ${t('fromThisSet')}: = + - ^ $ * . [ ] { } ( ) ?  ! @ # % & / \ , > < ' : ; | _ ~ </li>
            <li><b>${t('requireUppercaseLetters')}</b></li>
            <li><b>${t('requireLowercaseLetters')}</b></li>
          </ul>`, `${t('confirmPasswordError')}`, "longError");
		}

		if (updated_password == updated_confirm_password && updated_password != "" && updated_confirm_password != "") {
			setState(prev => ({
				...prev,
				updated_passwordError: '',
				updated_comfirm_passwordError: ''
			}))
		} else {
			valid = false;
			Utility.toastNotifications(t('passwordAndConfirmPasswordNotMatch'), "Error", "error");
		}

		return valid;

	}

	const lanOnSelect = (lng) => {
		setState(prev => ({
			...prev,
			langaugeConfirmModal: true,
			selectedLangauge: lng
		}))
	}

	const confirmLangaugeChange = () => {
		const { selectedLangauge } = state;
		i18n.changeLanguage(selectedLangauge);
		let splitUrl = props.match.url.split('/');
		props.history.push(`/${selectedLangauge}/${splitUrl[2]}`);
		window.location.reload();
		setState(prev => ({
			...prev,
			langaugeConfirmModal: false,
		}))

	}

	const cancelLangaugeChange = () => {
		setState(prev => ({
			...prev,
			langaugeConfirmModal: false,
		}))
	}
	return (
		<div className="appContainer">
			<CommonLogin
				handleChange={handleChange}
				email={state.email}
				password={state.password}
				emailError={state.emailError}
				passwordError={state.passwordError}
				passtype={state.passtype}
				passwordLock={state.passwordLock}
				showText={showText}
				showPassword={showPassword}
				login={login}
				forgotPassword={forgotPassword}

				handleonFocus={handleonFocus}
				handleonBlur={handleonBlur}
				emailFocus={state.emailFocus}
				passwordFocus={state.passwordFocus}

				passPlaceholder={t('passPlaceholder')}
				forgotTitle={t('forgot_password_text')}
				submitTitle={t('loginButton')}
				email_input_placeholder={t('email_input_placeholder')}
				lanOnSelect={lanOnSelect}
			/>

			<Modal
				show={state.modalShow}
				onHide={handleClose}
				//backdrop="static"
				//keyboard={false}
				className="forcePasswordChange"
			>
				<Modal.Header closeButton>
					<Modal.Title>{t('ChangePasswordButton')}</Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<div className="passwordRow">
						<input type={state.passtype} onChange={handleChange} name="updated_password" value={state.updated_password} placeholder={t('updatepassword')} className="input__fields_property" />
						<div className="col-md-12 errorClass error_div">{state.updated_passwordError}</div>
					</div>
					<div className="passwordRow">
						<input type={state.confirmPasstype} onChange={handleChange} name="updated_confirm_password" value={state.updated_confirm_password} placeholder={t('updateconfirmpass')} className="input__fields_property" />
						<div className="col-md-12 errorClass error_div">{state.updated_comfirm_passwordError}</div>
					</div>
				</Modal.Body>
				<Modal.Footer>
					<Button variant="primary" onClick={updatePassword} className="update_btn">{t('submit')}</Button>
				</Modal.Footer>
			</Modal>

			<ModalGlobal
				show={state.langaugeConfirmModal}
				onHide={cancelLangaugeChange}
				className="modalcustomize confirmationalertmodal"
				bodyClassName="cancelConfirmationbody"
				headerclassName="close_btn_icon"
				title={t('languagechange')}
				footer={false}
				body={
					<ConfirmationAlert
						BodyFirstContent={t('areYouSureYouWantToReload')}
						confirmationButtonContent={t('confirm')}
						deleteConfirmButton={confirmLangaugeChange}
						cancelButtonContent={t('cancel')}
						deleteCancleButton={cancelLangaugeChange}
					/>
				}
			/>

		</div>
	);
}

CommonLogin.propTypes = {
	handleChange: PropTypes.func,
	email: PropTypes.string,
	password: PropTypes.string,
	emailError: PropTypes.string,
	passwordError: PropTypes.string,
	passtype: PropTypes.string,
	passwordLock: PropTypes.bool,
	showText: PropTypes.func,
	showPassword: PropTypes.func,
	login: PropTypes.func,
	forgotPassword: PropTypes.func,
	backgroundImageUrl: PropTypes.string
}


const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.LoginReducer.userCredentials, languageList: globalState.LoginReducer.languageList
	};
}

export default connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp, roleWisePermission })(withRouter(LoginPage));


