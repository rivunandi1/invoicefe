import React, { Component } from 'react';
import Button from 'react-bootstrap/Button';
import CustomInput from '../../../Utility/Components/CustomInput';
import PropTypes from 'prop-types';
import Dropdown from 'react-bootstrap/Dropdown'
import ImageURL from '../../../Utility/Components/ImageURL';
class CommonLogin extends Component {

    constructor(props) {
        super(props);
        this.state = {

        }
    }


    render() {
        const { pageBackground, appContainerInner, loginBoxInner, logoBoxInner, companyLogo, titleLabel, webTitle, loginFormDiv, rememberForgotInner, rememberTitle, forgotTitle, submitTitle, checkboxContainer, checkmark, loginBtn, checkboxType, buttonType, parentClassName, checkboxName, checkboxValue, passInputClass, passLockIcon, passEyeIcon, errorClass, passPlaceholder, passName, lockClass, eyeClass, eyeSlash } = this.props;
        return (
            <div className={pageBackground}>
                <div className={appContainerInner}>
                    <div className={loginBoxInner}>
                        <div className={logoBoxInner}>
                            <div className="iconposition">
                                <img src={ImageURL.loginpage.loginLogo} className="blankinputlogo" />
                            </div>
                            <div className="titleposition">
                                <h2 className="titleone">Mettle Tech</h2>
                                <h3 className="titletwo">Invoice Management</h3>
                            </div>
                        </div>
                        <form className={loginFormDiv}>
                            <div className={parentClassName}>
                                <input type="text" onChange={this.props.handleChange} name="email" value={this.props.email} placeholder={this.props.email_input_placeholder} className={passInputClass} onFocus={this.props.handleonFocus} onBlur={this.props.handleonBlur} />
                                <div className={errorClass}>{this.props.emailError}</div>
                            </div>
                            <div className={parentClassName}>
                                <input type={this.props.passtype} onChange={this.props.handleChange} name={passName} value={this.props.password} placeholder={passPlaceholder} className={passInputClass} onFocus={this.props.handleonFocus} onBlur={this.props.handleonBlur} />

                                <div className={errorClass}>{this.props.passwordError}</div>
                            </div>
                            <div className="loginFormInnerDiv logbtndiv">
                                <Button type={buttonType} onClick={this.props.login} className={loginBtn}>{submitTitle}</Button>
                            </div>
                            <div className={rememberForgotInner}>
                                <p onClick={this.props.forgotPassword}><span>{forgotTitle}</span></p>
                            </div>
                            <div className="loglan langdropdown" style={{display:'none'}}>
                                <Dropdown onSelect={this.props.lanOnSelect.bind(this)}>
									<Dropdown.Toggle variant="success" id="dropdown-basic" >
										{localStorage.getItem('i18nextLng').toUpperCase()}
									</Dropdown.Toggle>
									<Dropdown.Menu>
										<Dropdown.Item eventKey="en">EN</Dropdown.Item>
										<Dropdown.Item eventKey="fr">FR</Dropdown.Item>
									</Dropdown.Menu>
								</Dropdown>

                            </div>

                        </form>
                    </div>
                </div>
            </div>
        )
    }
}


CommonLogin.defaultProps = {
    pageBackground: 'loginBackground',
    appContainerInner: 'appContainerInner',
    loginBoxInner: 'login_box_inner',
    logoBoxInner: 'logo-box-inner',
    companyLogo: 'logo-box-top-logo',
    titleLabel: 'loginTitle',
    loginFormDiv: 'loginFormDiv',
    rememberForgotInner: 'loginFormInnerDiv forgot_password_property',
    checkboxContainer: 'custom_checkbox_container',
    checkmark: 'checkmarkCheckbox',
    loginBtn: 'login-btn',
    parentClassName: 'loginFormInnerDiv',
    passInputClass: 'input__fields_property',
    passLockIcon: 'passwordLockIcon',
    passEyeIcon: 'passwordEyeIcon',
    errorClass: 'col-md-12 errorClass error_div',
    passName: 'password',
    lockClass: 'fa fa-lock',
    eyeSlash: 'fa fa-eye-slash',
    eyeClass: 'fa fa-eye',

    checkboxType: 'checkbox',
    checkboxName: 'remember_me',
    checkboxValue: '',
    buttonType: 'button',

    passPlaceholder: 'Mot de passe',
    webTitle: 'HR Management System',
    rememberTitle: 'Remember Me',
    forgotTitle: 'Mot de passe oublié?',
    submitTitle: 'Se connecter'
}
export default CommonLogin;
