import LoginActionTypes from '../Utility/LoginActionTypes'
import AllActionTypes from '../../../Utility/AllActionTypes'
import { get, post, put, del } from '../../../Utility/Http';
import Config from '../../../Utility/Config';

export const setToken = (token, accessToken, expiresIn, refreshToken) => async (dispatch) => {

    dispatch({
        type: LoginActionTypes.SET_TOKEN,
        payload: token
    });
    dispatch({
        type: LoginActionTypes.SET_ACCESS_TOKEN,
        payload: accessToken
    });
    dispatch({
        type: LoginActionTypes.SET_TOKEN_EXPIRE_TIME,
        payload: expiresIn
    });
    dispatch({
        type: LoginActionTypes.SET_REFRESH_TOKEN,
        payload: refreshToken
    });
}


export const logOutApp = (accessToken, token) => async (dispatch) => {
    console.log()
    localStorage.setItem('qlanguage',"");
    localStorage.setItem('qlanguage',"");
    del(`${Config.extendedUrlAuth}users/signout`, "", { "Accesstoken": "", "Authorization": "" }).then((response) => {

    })

    /*axios.delete(apiBaseUrl, {
        data: {},
        headers: header
    }).then((response) => {
        resolve(response);
    }).catch((error) => {
        //errorHandlingBlock(error)
        reject(error);
    })*/

    dispatch({
        type: LoginActionTypes.LOGOUT,
        payload: { "token": "", "accessToken": "", "refreshToken": "", "expiresIn": { "loggedInTime": "", "expiryTime": "", "expiryInterval": "" }, "userCredentials": {}, "roleWisePermission": {},"tabNameStore":"" }
    });
    dispatch({
        type: AllActionTypes.CLEAR_DATA,
        payload: { "loaderState": false, "leftbar": false, "activeLink": { 'accName': "", 'activeClass': "" }, "roleWisePermission": {} }
    });
}

export const setUserCredentials = (value) => async (dispatch) => {
    dispatch({
        type: LoginActionTypes.SET_USER_CREDENTIALS,
        payload: value
    });
}
export const setLanguages = (value) => async (dispatch) => {
    dispatch({
        type: LoginActionTypes.SET_LANGUAGES,
        payload: value
    });
}