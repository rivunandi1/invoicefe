class HomeUtility {
    static validate_Phone_Number = (value) => {
        var number = value;
        var filter = /^\+(?:[0-9] ?){6,14}[0-9]$/;
        if (filter.test(number)) {
            return true;
        }
        else {
            return false;
        }
    }

    static validateStringOnly = (value) => {
        var number = value;
        var filter = /^[a-zA-Z\s]*$/;
        if (filter.test(number)) {
            return true;
        }
        else {
            return false;
        }
    }

    static isNumeric(num) {
        return !isNaN(num)
    }

    static bankAccountNumberValidation = (value) => {
        let valid = true;
        let string = value.substring(0, 2);
        let isString = this.validateStringOnly(string);
        if (isString) {
            var last14 = value.slice(-14);
            let number = this.isNumeric(last14);
            if (number) {
                valid = true;
            } else {
                valid = false;
            }
        } else {
            valid = false;
        }

        return valid;
    }

    static formatApiResponse = (data) => {
        let response = {}
        Object.keys(data).map((item, idx) => {
            response[item] = data[item]
        })
        return response
    }

    static validate_pan_Number = (value) => {
        var number = value;
        var filter = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        if (filter.test(number)) {
            return true;
        }
        else {
            return false;
        }
    }
    static validate_gst_Number = (value) => {
        var number = value;
        var filter = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
        if (filter.test(number)) {
            return true;
        }
        else {
            return false;
        }
    }
    
}
export default HomeUtility;