class HomeActionTypes {
    static USER_ATTACH_ORG = 'USER_ATTACH_ORG';
    static HAVE_A_USER = 'HAVE_A_USER';
}
export default HomeActionTypes;