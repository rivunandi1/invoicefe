import Utility from "../Utility/Utility"

export const departmentApiGet = (deptData) => {
    let response = Utility.formatApiResponse(deptData.data)
    return response
}
export const enterpriseApiGet = (enterpriseData) => {
    let enterpriseDataTemp = enterpriseData.data
    let response = {}
    response["success"] = enterpriseDataTemp.success
    response["total"] = enterpriseDataTemp.total
    response["data"] = enterpriseDataTemp.data
    return response
}
export const enterpriselocationApiGet = (enterpriselocationData) => {
    return enterpriselocationData.data
}
export const workerAddApi = (workerAddData) => {
    return workerAddData.data
}
export const functionsApiGet = (functionsData) => {
    let functionsDataTemp = functionsData.data
    let response = {}
    response["success"] = functionsDataTemp.success
    response["total"] = functionsDataTemp.total
    response["data"] = functionsDataTemp.data
    return response
}
export const rolesApiGet = (rolesData) => {
    let rolesDataTemp = rolesData.data
    let response = {}
    response["success"] = rolesDataTemp.success
    response["total"] = rolesDataTemp.total
    response["data"] = []
    rolesDataTemp.data.map((roleval) => {
        let roleHash = {};
        roleHash['label'] = roleval.role_name;
        roleHash['value'] = roleval.id;
        response["data"].push(roleHash);
    })
    return response
}
export const enterPriseAddGetApi = (endataSet) => {
    return endataSet.data
}
export const departmentAddApi = (deptdataSet) => {
    return deptdataSet.data
}
export const deleteDepartmentGet = (deldata) => {
    return deldata.data
}
export const deptManagersLeavevalApiGet = (managersLeavevalData) => {
    return managersLeavevalData.data
}

export const deptTeamsApiGet = (deptTeamsData) => {
    return deptTeamsData.data
}
export const deleteFunctionGet = (deldata) => {
    return deldata.data
}
export const functionsAddApi = (adddata) => {
    return adddata.data
}

export const teamDepartmentGet = (teamDepartmentData) => {
    return teamDepartmentData.data
}

export const teamLeaderGet = (teamLeaderData) => {
    return teamLeaderData.data
}

export const saveTeamGet = (saveTeamData) => {
    return saveTeamData.data
}

export const teamsGet = (teamsData) => {
    return teamsData.data
}

export const teamDepartmentsGet = (teamDepartmentsData) => {
    return teamDepartmentsData.data
}

export const teamLeadersGet = (teamLeadersData) => {
    return teamLeadersData.data
}

export const deleteTeamGet = (deleteTeamData) => {
    return deleteTeamData.data
}
export const deleteLocationGet = (locationData) => {
    return locationData.data
}
export const locationAddGetApi = (locationData) => {
    return locationData.data
}
export const teamDepartmentAttachGet = (teamDepartmentAttachData) => {
    return teamDepartmentAttachData.data
}
export const relationsUserDepartmentFunctionsApiGet = (relationsUserDepartmentFunctionsData) => {
    let relationsUserDepartmentFunctionsDataTemp = relationsUserDepartmentFunctionsData.data
    let response = {}
    response["success"] = relationsUserDepartmentFunctionsDataTemp.success
    response["total"] = relationsUserDepartmentFunctionsDataTemp.total
    response["data"] = relationsUserDepartmentFunctionsDataTemp.data
    return response
}




