import React from 'react';
import { get, post, put, del, patch } from '../../../Utility/Http';
import {enterpriseApiGet, workerAddApi, functionsApiGet, rolesApiGet, enterPriseAddGetApi, deleteFunctionGet, functionsAddApi, enterpriselocationApiGet,
    departmentApiGet, departmentAddApi, deleteDepartmentGet, teamDepartmentGet, teamLeaderGet, saveTeamGet, teamsGet, teamDepartmentsGet, teamLeadersGet, deleteTeamGet, deptManagersLeavevalApiGet, relationsUserDepartmentFunctionsApiGet, locationAddGetApi, deleteLocationGet, teamDepartmentAttachGet
} from '../Model/HomeModel';
import Config from '../../../Utility/Config';


export const enterprise = (data) => {
    return get(`${Config.extendedUrl}enterprises`, data).then((response) => {
        return enterpriseApiGet(response)
    });
};
export const enterpriseLocation = () => {
    return get(`${Config.extendedUrl}enterprises/locations`, "").then((response) => {
        return enterpriselocationApiGet(response)
    });
};


export const functions = (data) => {
    return get(`${Config.extendedUrl}functions`, data).then((response) => {
        return functionsApiGet(response)
    });
};

export const relationsUserDepartmentFunctions = (data) => {
    return get(`${Config.extendedUrl}org_div_subdiv_func_user_relation`, data).then((response) => {
        return relationsUserDepartmentFunctionsApiGet(response)
    });
};

export const roles = (data) => {
    return get(`${Config.extendedUrl}roles`, data).then((response) => {
        return rolesApiGet(response)
    });
};

export const enterPriseAdd = (data, type, id = "") => {
    if (type == "post") {
        return post(`${Config.extendedUrl}enterprises`, data).then((response) => {
            return enterPriseAddGetApi(response)
        });
    } else if (type == "patch") {
        return patch(`${Config.extendedUrl}enterprises/${id}`, data).then((response) => {
            return enterPriseAddGetApi(response)
        });
    }
};
export const workerAdd = (data, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}admin/users`, data).then((response) => {
            return workerAddApi(response)
        });
    } else if (type == "patch") {
        return patch(`${Config.extendedUrl}users/${data.id}`, data).then((response) => {
            return organizationAddEditGet(response)
        });
    }
};
export const department = (data) => {
    return get(`${Config.extendedUrl}departments`, data).then((response) => {
        return departmentApiGet(response)
    });
};
export const deptManagersLeaveval = (data) => {
    return get(`${Config.extendedUrl}department_managers`, data).then((response) => {
        return deptManagersLeavevalApiGet(response)
    });
};



export const departmentAdd = (data, type, id = "") => {
    if (type == "post") {
        return post(`${Config.extendedUrl}departments`, data).then((response) => {
            return departmentAddApi(response)
        });
    } else if (type == "patch") {
        return patch(`${Config.extendedUrl}departments/${id}`, data).then((response) => {
            return departmentAddApi(response)
        });
    }
};

export const deleteDepartment = (data) => {
    return del(`${Config.extendedUrl}departments`, data).then((response) => {
        return deleteDepartmentGet(response)
    });
};



export const functionsAdd = (data, type, id = "") => {
    if (type == "post") {
        return post(`${Config.extendedUrl}functions`, data).then((response) => {
            return functionsAddApi(response)
        });
    } else if (type == "patch") {
        return patch(`${Config.extendedUrl}functions/${id}`, data).then((response) => {
            return functionsAddApi(response)
        });
    }
};

export const deleteFunction = (data) => {
    return del(`${Config.extendedUrl}functions`, data).then((response) => {
        return deleteFunctionGet(response)
    });
};

export const teamDepartment = (data) => {
    return get(`${Config.extendedUrl}departments`, data).then((response) => {
        return teamDepartmentGet(response)
    });
};

export const teamLeader = (data) => {
    return get(`${Config.extendedUrl}admin/users`, data).then((response) => {
        return teamLeaderGet(response)
    });
};

export const saveTeam = (data) => {
    return post(`${Config.extendedUrl}teams`, data).then((response) => {
        return saveTeamGet(response)
    });
};
export const teamDepartmentAttach = (data) => {
    return post(`${Config.extendedUrl}teamdepartments`, data).then((response) => {
        return teamDepartmentAttachGet(response)
    });
};

export const teams = (data) => {
    return get(`${Config.extendedUrl}teams`, data).then((response) => {
        return teamsGet(response)
    });
};

export const teamDepartments = (data) => {
    return get(`${Config.extendedUrl}teamdepartments`, data).then((response) => {
        return teamDepartmentsGet(response)
    });
};

export const teamLeaders = (data) => {
    return get(`${Config.extendedUrl}teamleaders`, data).then((response) => {
        return teamLeadersGet(response)
    });
};
export const deleteTeam = (data) => {
    return del(`${Config.extendedUrl}teams`, data).then((response) => {
        return deleteTeamGet(response)
    });
};

export const locationDelete = (data) => {
    return del(`${Config.extendedUrl}enterprises/locations`, data).then((response) => {
        return deleteLocationGet(response)
    });
};

export const locationAdd = (data, type, id = "") => {
    if (type == "post") {
        return post(`${Config.extendedUrl}enterprises/locations`, data).then((response) => {
            return locationAddGetApi(response)
        });
    } else if (type == "patch") {
        return patch(`${Config.extendedUrl}enterprises/locations/${id}`, data).then((response) => {
            return locationAddGetApi(response)
        });
    }
};
