
export const customerListingGet = (customerData) => {
    let customerDataTemp = customerData.data
    let response = {}
    response["success"] = customerDataTemp.success
    response["total"] = customerDataTemp.total
    response["data"] = customerDataTemp.data
    return response
}
export const customerAddPost = (customerAdd) => {
    return customerAdd.data
}
export const customerAddPatch = (customerupdate) => {
    return customerupdate.data
}
export const customerDetailsGet = (userDetails) => {
    return userDetails.data
}
/*export const orgListingGet = (orgData) => {
    return orgData.data
}*/
export const customerDeleteApi = (data) => {    
    return data.data;
}
export const customerUpdatePatch = (data) => {    
    return data.data;
}
export const customerBankListingGet = (data) => {    
    return data.data;
}
