import React, { Component } from 'react';
import CustomerModalContent from './Components/CustomerModalContent'
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import * as CustomerController from './Controller/CustomerController';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import ConfirmationAlert from '../../../../Utility/Components/ConfirmationAlert';
import { loaderStateTrue, loaderStateFalse } from '../../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../../Login/Actions/LoginAction';
import CustomInput from '../../../../Utility/Components/CustomInput';
import Utility from '../../../../Utility/Utility';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';
import ModalGlobal from '../../../../Utility/Components/ModalGlobal'
import HomeUtility from '../../Utility/Utility'
import moment from 'moment';
import Config from '../../../../Utility/Config';
import PopoverStickOnHover from '../../../../Utility/Components/PopoverStickOnHover';
import GridActionContent from '../../../../Utility/Components/GridActionContent'
import BootstrapSwitchButton from 'bootstrap-switch-button-react';
import { formatingFormData } from './DataFormat/CustomerDataFormat'
import { setEditDataForCustomer } from './DataFormat/CustomerSetEditDataSet'
import Currency from '../../../../Utility/JsFolder/Currency';
import CountryWithCode from '../../../../Utility/JsFolder/CountryWithCode';
import AutosuggestComponent from '../../../../Utility/Components/AutosuggestComponent'


class Customer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modules: [InfiniteRowModelModule],
            tooltipShowDelay: 0,
            columnDefs: [
                {
                    headerName: "",
                    field: "profile_img_temp",
                    //width: 65,
                    maxWidth: 72,
                    //cellRenderer: 'loadingRenderer',
                    cellRendererFramework: (params) => {
                        if (params && params.data) {
                            if (params.data.profile_img_temp) {
                                return <div className="gridusericon">
                                    <PopoverStickOnHover
                                        data={this.popoverStickDatasetFormatUser(params.data)}
                                        placement="right"
                                    />
                                </div>
                            } else {
                                return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
                            }

                        } else {
                            return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
                        }
                    }
                },
                {
                    headerName: `${this.props.t('Name')}`,
                    field: "name",
                    minWidth: 150,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            let concatname = params.data.name
                            if (params.data.name && params.data.name && concatname.length > 15) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data && params.data.name != "" ? params.data.name : ""} </Tooltip>}>
                                        <span >
                                            {params.data && params.data.name != "" ? params.data.name : ""}
                                        </span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return (<div className="usercursor"><span className="textrenderview">{params.data && params.data.name != "" ? params.data.name : ""} </span></div>)
                                //return null;
                            }

                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('organizationName')}`,
                    field: "Organisation",
                    minWidth: 160,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.Organisation) {
                                if (params.data.Organisation.name) {
                                    if (params.data.Organisation.name.length > 15) {
                                        return <div className="usercursor"><span className="textrenderview">
                                            <OverlayTrigger overlay={<Tooltip>{params.data && params.data.Organisation.name != "" ? params.data.Organisation.name : ""}</Tooltip>}>
                                                <span >{params.data && params.data.Organisation.name != "" ? params.data.Organisation.name : ""}</span>
                                            </OverlayTrigger>
                                        </span></div>
                                    } else {
                                        return <div className="usercursor"><span className="textnowrapview">{params.data && params.data.Organisation.name != "" ? params.data.Organisation.name : ""}</span></div>
                                    }
                                } else {
                                    return null;
                                }
                            } else {
                                return null;
                            }

                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: "Company type",
                    field: "customer_type",
                    minWidth: 120,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            return <div className="customer_type_label">{params.data.customer_type}</div>
                        } else {
                            return null
                        }
                    },
                },
                {
                    headerName: `${this.props.t('Email')}`,
                    field: "email",
                    minWidth: 180,
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.email && params.data.email.length > 20) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data.email}</Tooltip>}>
                                        <span >{params.data.email}</span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return <div className="usercursor"><span className="textnowrapview">{params.data.email}</span></div>
                            }
                        } else {
                            return null;
                        }
                    },
                    //resizable: true
                },
                {
                    headerName: `${this.props.t('city')}`,
                    field: "city",
                    minWidth: 120,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data?.city?.length > 20) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data && params.data?.city != "" ? params.data?.city : ""}</Tooltip>}>
                                        <span >{params.data && params.data?.city != "" ? params.data?.city : ""}</span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return <div><span className="textnowrapview">{params.data && params.data?.city != "" ? params.data?.city : ""}</span></div>
                            }
                        } else {
                            return null;
                        }

                    },
                },
                {
                    headerName: `${this.props.t('country')}`,
                    field: "country",
                    minWidth: 120,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data?.country?.length > 20) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data && params.data?.country != "" ? params.data?.country : ""}</Tooltip>}>
                                        <span >{params.data && params.data?.country != "" ? params.data?.country : ""}</span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return <div><span className="textnowrapview">{params.data && params.data?.country != "" ? params.data?.country : ""}</span></div>
                            }
                        } else {
                            return null;
                        }

                    },
                },
                {
                    headerName: `${this.props.t('currency')}`,
                    field: "currency",
                    minWidth: 100,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data?.currency?.length > 15) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data && params.data?.currency != "" ? params.data?.currency : ""}</Tooltip>}>
                                        <span >{params.data && params.data?.currency != "" ? params.data?.currency : ""}</span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return <div><span className="textnowrapview">{params.data && params.data?.currency != "" ? params.data?.currency : ""}</span></div>
                            }
                        } else {
                            return null;
                        }

                    },
                },

                {
                    headerName: `${this.props.t('phonenumber')}`,
                    field: "ph_no",
                    minWidth: 150,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            return <div className="usercursor">{params.data.ph_no}</div>
                        } else {
                            return null
                        }
                    },
                },
                {
                    headerName: `${this.props.t('status')}`,
                    field: "active",
                    maxWidth: 90,
                    cellRendererFramework: (params) => {
                        if (params) {
                            if (params.data) {
                                return <button className="edittext">
                                    <div className="switch_btn_customize">
                                        <BootstrapSwitchButton checked={params.data && params.data.active ? params.data.active : false} onChange={this.handleChangeSwitchButton.bind(this, params.data)} />
                                        {/*<BootstrapSwitchButton />*/}
                                    </div>
                                </button>
                            } else {
                                return null
                            }
                        } else {
                            return null
                        }
                    },
                },
                {
                    headerName: "",
                    field: "edit",
                    maxWidth: 50,
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            return <div className="actionablePopup">
                                <button className="ellipsisIcon" onClick={this.actionModalfunction.bind(this, params)}><i className="fa fa-ellipsis-v"></i></button>
                            </div>
                        } else {
                            return null;
                        }
                    },
                }
            ],
            defaultColDef: {
                flex: 1,
                //resizable: true,
                minWidth: 50

            },
            components: {
                loadingRenderer: (params) => {
                    //console.log("params=================== worker", params)
                    //return null;
                    if (params.value !== undefined) {
                        return params.value;
                    } else {
                        return '<img src="https://www.ag-grid.com/example-assets/loading.gif">';
                    }
                },
            },



            //Travailleurs Tab State
            travailleursModal: false,

            //user img add
            addProfileImagePreviewShow: false,
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImageError: "",

            //IMage crop
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 1 / 1
            },
            croppedImageUrl: "",

            imageCropModalFlag: false,


            bankDetails: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],

            bankDetailsError: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],

            fromData: {
                "name": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
                "pan_number": "",
                "gstn": "",
                //"gst_number": "",
                //"conversion_allowance_percentage": "",
                "active": true,
                "is_gst_applicable": false,
                "is_sgst_applicable": false,
                "is_igst_applicable": false,
                "currency": "",
                /*===========new add 12.10.2022 start============*/
                "customer_type": "",
                "tin": "",
                "tan": ""
                /*===========new add 12.10.2022 end============*/
            },
            fromDataError: {
                "name": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
                "pan_number": "",
                "gstn": "",
                //"conversion_allowance_percentage": "",
                "currency": "",
                "gst_applicable_error": "",
                /*===========new add 12.10.2022 start============*/
                "customer_type": "",
                /*===========new add 12.10.2022 end============*/
            },
            editedFlag: false,
            editedId: "",
            //orgList: [],
            actionModalflag: false,
            deleteConfirmationAlertModal: false,
            gridObjData: "",
            customerName: "",
            cusheaderContent: "",
            saveButtonDisableEditModal: true,
            disabledEmail: true,
            reserveFromData: "",
            profileImageChangeEditMode: false,
            currencyList: [],
            countryList: [],
            deleteBankDetailsConfirmationAlertModalFlag: false,
            deleteBankDetailsObj: "",
            /*===========new add 12.10.2022 start============*/
            companyTypeList: [
                { label: "Customer", value: 'customer' },
                { label: "Vendor", value: 'vendor' },
                { label: "Both", value: 'both' },
            ],
            companyTypeFilterSelectedData: ""
            /*===========new add 12.10.2022 end============*/

        }
        this.codeOutsideClickRef = React.createRef();

    }




    onGridReady = (params) => {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridparams = params;
        var datasource = this.serverSideDataSource()
        params.api.setDatasource(datasource);
    };





    serverSideDataSource = () => {
        const { customerName, companyTypeFilterSelectedData } = this.state;
        const { userCredentials } = this.props;
        let that = this
        return {
            getRows(params) {
                //console.log(JSON.stringify(params, null, 1));
                const { startRow, endRow, filterModel, sortModel } = params
                const { loaderStateTrue, loaderStateFalse } = that.props;
                loaderStateTrue();
                let filters = {};
                let globalQueryParamshash = {};
                if (customerName != "") {
                    globalQueryParamshash['name'] = customerName
                    filters['filter_op'] = {  "customer_type": "eq","name": "substring" }
                }

                globalQueryParamshash["offset"] = startRow;
                globalQueryParamshash["limit"] = endRow;
                globalQueryParamshash["org_id"] = userCredentials.user_details.org_id;

                /*===========new add 12.10.2022 start============*/
                if (companyTypeFilterSelectedData != "") {
                    globalQueryParamshash['customer_type'] = companyTypeFilterSelectedData.value
                    filters['filter_op'] = { "customer_type": "eq","name": "substring" }
                }
                /*===========new add 12.10.2022 end============*/

                filters['filters'] = globalQueryParamshash
                CustomerController.customerListing(filters).then((response) => {
                    //console.log("response", response)
                    if (response.success) {
                        let promiseArr = []
                        response.data.map((item, index) => {
                            let promise = new Promise((resolve, reject) => {
                                that.logoImageUi(item._id).then((data) => {
                                    // tempUserProfileDetailsHash[item.id.toString()] = data
                                    item["profile_img_temp"] = data
                                    resolve(item)
                                })

                            })
                            promiseArr.push(promise)
                        })

                        Promise.all(promiseArr).then((values) => {
                            //console.log("values==========>", values)
                            params.successCallback(values, response.total);
                        });
                        //params.successCallback(response.data, 499);
                        //that.setImageDataTemp(response.data)

                    } else {
                        console.error(error);
                        params.failCallback();
                        Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
                    }
                    loaderStateFalse();
                }).catch((error) => {
                    console.error("************error*************", error)
                    if (error) {
                        //Utility.toastNotifications(error.message, "Error", "error");
                    }
                    loaderStateFalse();
                    if (error.message == "Network Error") {
                        // Utility.toastNotifications("Please login", "Error", "error");
                        // this.props.logOutApp().then(
                        //     () => this.props.history.push("/")
                        // );
                    }
                });
            }
        };
    }


    resetDataGrid = () => {
        this.gridparams.api.purgeServerSideCache(null)
        var datasource = this.serverSideDataSource()
        this.gridparams.api.setDatasource(datasource);

    }


    componentDidMount = () => {
        document.body.addEventListener('mousedown', this.handleClickOutside.bind(this));
        this.modefyCurrency();
        this.countryModefy();
    }

    countryModefy = () => {

        const countryData = CountryWithCode.map(object => {
            return { ...object, "value": object.country, "label": object.country };
        });
        //console.log("arrWithLabelValue====", arrWithLabelValue)
        this.setState({
            countryList: countryData
        })
    }

    modefyCurrency = () => {

        const arrWithLabelValue = Currency.map(object => {
            return { ...object, "value": object.currencyCode, "label": `${object.currencyCode}(${object.countryCode})` };
        });
        //console.log("arrWithLabelValue====", arrWithLabelValue)
        this.setState({
            currencyList: arrWithLabelValue
        })

    }

    componentWillUnmount() {
        document.body.removeEventListener('mousedown', this.handleClickOutside.bind(this));
    }
    handleClickOutside(event) {
        if (this.codeOutsideClickRef.current != null) {
            if (this.codeOutsideClickRef && this.codeOutsideClickRef.current && !this.codeOutsideClickRef.current.contains(event.target)) {

                this.setState({
                    actionModalflag: false
                })
            }
        }

    }

    logoImageUi = (id) => {
        const promise = new Promise((resolve, reject) => {
            const { loaderStateTrue, loaderStateFalse } = this.props;
            loaderStateTrue();
            let data = {};
            data["filters"] = JSON.stringify(Config.thumbnailSize)
            CustomerController.customerDetails(id, data).then((response) => {
                //console.log("logoImageUi===", response)
                if (response.success) {
                    //console.log("response.data[0]========", response.data[0].user_details)
                    let responseUserDetails = response.data[0].logo_img
                    if (responseUserDetails && Object.keys(responseUserDetails).length > 0) {
                        resolve(responseUserDetails.file_obj)
                    } else {
                        resolve(require('../../../../Utility/Public/images/usericon.png'))
                    }
                }
                loaderStateFalse();
            }).catch((error) => {
                console.error("************error*************", error)
                if (error) {
                    //Utility.toastNotifications(error.message, "Error", "error");
                }
                loaderStateFalse();
                if (error.message == "Network Error") {
                    /*Utility.toastNotifications("Please login", "Error", "error");
                    this.props.logOutApp().then(
                        () => this.props.history.push("/")
                    );*/
                }
            });
        })
        return promise;
    }








    closeTravailleursModal = () => {
        const { t } = this.props

        this.setState({
            travailleursModal: false,
            editedFlag: false,
        }, () => {
            this.resetWorkerFrom();
        })


    }

    //Image url crop 
    addInputProfileImageChanged = (event) => {

        let { fromData } = this.state;
        let targetFileSplit = event.target.files[0].name.split('.');
        let lastElement = targetFileSplit.pop();
        let user_profile_image = {
            "file_name": "",
            "file_obj": ""
        };
        if (lastElement == 'JPEG' || lastElement == 'jpeg' || lastElement == 'jpg' || lastElement == 'JPG' || lastElement == 'png' || lastElement == 'PNG' || lastElement == '') {
            const fsize = event.target.files[0].size;
            const file = Math.round((fsize / 1024));
            if (file >= 300) {
                Utility.toastNotifications(this.props.t('imageUploadAlert'), "Warning", "warning");
            } else {
                this.setState({
                    imageCropModalFlag: true
                })
                if (event.target.files && event.target.files.length > 0) {
                    const reader = new FileReader();
                    reader.addEventListener('load', () =>
                        this.setState({ src: reader.result })
                    );
                    reader.readAsDataURL(event.target.files[0]);
                    user_profile_image["file_name"] = event.target.files[0].name
                    user_profile_image["file_obj"] = ""
                    fromData["profileImage"] = user_profile_image
                    this.setState({
                        fromData,
                        workerModalChange: true,
                        traprofileImageError: "",
                        addProfileImagePreviewShow: true,
                        addProfileImageError: "",
                    })
                }
            }

        } else {
            fromData["profileImage"] = ""
            this.setState({
                traprofileImageError: this.props.t('requiredField'),
                addProfileImagePreviewShow: false,
                addprofileImageSelected: 'Add Image',
                workerModalChange: true
            })
        }
    }



    getBase64(file, cb) {
        let reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {
            cb(reader.result)
        };
        reader.onerror = function (error) {
            //console.log('Error: ', error);
        };
    }

    onImageLoaded = (image) => {
        //console.log("onImageLoaded=====", image)
        this.imageRef = image;
    };

    onCropComplete = (crop) => {
        this.makeClientCrop(crop);
        this.setState({
            saveButtonDisableEditModal: false,
            profileImageChangeEditMode: true
        })
    };

    onCropChange = (crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.setState({ crop });
    };

    async makeClientCrop(crop) {
        const { fromData } = this.state;
        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                'newFile.jpeg'
            );
            let user_profile_image = {}
            this.setState({ addprofileImageSelected: croppedImageUrl }, () => {
                user_profile_image["file_name"] = this.state.fromData.profileImage.file_name
                user_profile_image["file_obj"] = this.state.addprofileImageSelected
                fromData["profileImage"] = user_profile_image
                this.setState({
                    fromData
                })
            });

        }
    }

    getCroppedImg = (image, crop, fileName) => {
        const canvas = document.createElement('canvas');
        const pixelRatio = window.devicePixelRatio;
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext('2d');

        canvas.width = crop.width * pixelRatio * scaleX;
        canvas.height = crop.height * pixelRatio * scaleY;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width * scaleX,
            crop.height * scaleY
        );

        const base64Image = canvas.toDataURL('image/jpeg');
        return base64Image

    }

    //Image url crop

    imageCropModalShow = () => {
        this.setState({
            imageCropModalFlag: true
        })
    }

    imageCropModalHide = () => {
        const { fromData } = this.state;
        fromData["profileImage"] = ""
        this.setState({
            imageCropModalFlag: false,
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImageError: "",
            fromData,
            addProfileImagePreviewShow: false,
            saveButtonDisableEditModal: true
        })
    }

    imageCropDataSave = () => {
        this.setState({
            imageCropModalFlag: false
        })
    }

    handleUserSearchBar = (e) => {
        this.setState({
            customerName: e.target.value
        }, () => {
            if (this.state.customerName.length > 2) {
                this.resetDataGrid()
            }
            if (this.state.customerName == "") {
                this.resetDataGrid()
            }
        })

    }

    clearSearchValue = () => {
        this.setState({
            customerName: ""
        }, () => {
            this.resetDataGrid()
        })
    }

    travailleursModalfunction = () => {
        this.setState({
            travailleursModal: true,
            "profileImage": "",
            cusheaderContent: "Add Customer/Vendor",
            disabledEmail: true
        }, () => {
        })
        //alert()
    }

    handelChange = (event, type) => {
        //console.log("event=======", event)
        //console.log("type=======", type)

        let fromDataTemp = Object.assign({}, this.state.fromData);
        let fromDataTempError = Object.assign({}, this.state.fromDataError);

        if (type == "name") {
            if (event.target.value != "") {
                fromDataTemp['name'] = event.target.value;
                fromDataTempError['name'] = ""
            } else {
                fromDataTemp['name'] = "";
                fromDataTempError['name'] = this.props.t('requiredField')
            }
        }

        if (type == "email") {
            if (event.target.value != "") {
                fromDataTemp['email'] = event.target.value;;
                fromDataTempError['email'] = ""
            } else {
                fromDataTemp['email'] = "";
                fromDataTempError['email'] = ""
            }
        }

        if (type == "ph_no") {
            if (event.target.value == "") {
                fromDataTemp['ph_no'] = event.target.value;
                fromDataTempError['ph_no'] = ""
            } else {
                let phoneValidate = HomeUtility.validate_Phone_Number(event.target.value);
                if (phoneValidate) {
                    fromDataTemp['ph_no'] = event.target.value;
                    fromDataTempError['ph_no'] = ""

                } else {
                    fromDataTemp['ph_no'] = event.target.value;
                    fromDataTempError['ph_no'] = this.props.t('validphonenumber')
                }
            }
        }

        if (type == "address_line1") {
            if (event.target.value != "") {
                fromDataTemp['address_line1'] = event.target.value;;
                fromDataTempError['address_line1'] = ""
            } else {
                fromDataTemp['address_line1'] = "";
                fromDataTempError['address_line1'] = ""
            }
        }

        if (type == "address_line2") {
            if (event.target.value != "") {
                fromDataTemp['address_line2'] = event.target.value;;
                fromDataTempError['address_line2'] = ""
            } else {
                fromDataTemp['address_line2'] = "";
                fromDataTempError['address_line2'] = ""
            }
        }

        if (type == "city") {
            if (event.target.value != "") {
                fromDataTemp['city'] = event.target.value;;
                fromDataTempError['city'] = ""
            } else {
                fromDataTemp['city'] = "";
                fromDataTempError['city'] = ""
            }
        }

        if (type == "state") {
            if (event.target.value != "") {
                fromDataTemp['state'] = event.target.value;;
                fromDataTempError['state'] = ""
            } else {
                fromDataTemp['state'] = "";
                fromDataTempError['state'] = ""
            }
        }

        if (type == "country") {
            if (event != "") {
                fromDataTemp['country'] = event;
                fromDataTempError['country'] = ""
            } else {
                fromDataTemp['country'] = "";
                fromDataTempError['country'] = ""
            }
        }

        if (type == "zip_code") {
            if (!isNaN(event.target.value) && event.target.value != "") {
                fromDataTemp['zip_code'] = event.target.value;
                fromDataTempError['zip_code'] = ""
            } else {
                fromDataTemp['zip_code'] = "";
                fromDataTempError['zip_code'] = ""
            }
        }
        if (type == "pan_number") {
            if (event.target.value == "") {
                fromDataTemp['pan_number'] = event.target.value;
                fromDataTempError['pan_number'] = ""
            } else {
                let panValidate = HomeUtility.validate_pan_Number(event.target.value);
                if (panValidate) {
                    fromDataTemp['pan_number'] = event.target.value;
                    fromDataTempError['pan_number'] = ""

                } else {
                    fromDataTemp['pan_number'] = event.target.value;
                    fromDataTempError['pan_number'] = this.props.t('validpannumber')
                }
            }
        }

        if (type == "gstn") {
            if (event.target.value == "") {
                fromDataTemp['gstn'] = event.target.value;
                fromDataTempError['gstn'] = ""
            } else {
                let phoneValidate = HomeUtility.validate_gst_Number(event.target.value);
                if (phoneValidate) {
                    fromDataTemp['gstn'] = event.target.value;
                    fromDataTempError['gstn'] = ""

                } else {
                    fromDataTemp['gstn'] = event.target.value;
                    fromDataTempError['gstn'] = this.props.t('validgstinnumber')
                }
            }
        }
        /*if (type == "gst_number") {
            if (event.target.value == "") {
                fromDataTemp['gst_number'] = event.target.value;
                fromDataTempError['gst_number'] = this.props.t('requiredField')
            } else {
                let gstValidate = HomeUtility.validate_gst_Number(event.target.value);
                if (gstValidate) {
                    fromDataTemp['gst_number'] = event.target.value;
                    fromDataTempError['gst_number'] = ""

                } else {
                    fromDataTemp['gst_number'] = event.target.value;
                    fromDataTempError['gst_number'] = this.props.t('validgstnumber')
                }
            }
        }*/

        /*if (type == "conversion_allowance_percentage") {
            if (!isNaN(event.target.value)) {
                if (event.target.value >= 1 && event.target.value <= 100) {
                    fromDataTemp['conversion_allowance_percentage'] = event.target.value;
                } else {
                    fromDataTempError['conversion_allowance_percentage'] = "";
                    Utility.toastNotifications(this.props.t('maximum_input'), "Warning", "warning")
                }
            }
        }*/

        if (type == "active") {
            if (event.target.checked) {
                fromDataTemp['active'] = true;
                fromDataTempError['active'] = ""
            } else {
                fromDataTemp['active'] = false;
                fromDataTempError['active'] = ""
            }
        }

        if (type == "is_gst_applicable") {
            if (event.target.checked) {
                fromDataTemp['is_gst_applicable'] = true;
                fromDataTempError['is_gst_applicable'] = ""
            } else {
                fromDataTemp['is_gst_applicable'] = false;
                fromDataTempError['is_gst_applicable'] = "";
                fromDataTemp['is_sgst_applicable'] = false;
                fromDataTemp['is_igst_applicable'] = false;
                fromDataTemp['gstn'] = ""
            }
        }

        if (type == "is_sgst_applicable") {
            if (event.target.checked) {
                fromDataTemp['is_sgst_applicable'] = true;
                fromDataTemp['is_igst_applicable'] = false;
                fromDataTempError['gst_applicable_error'] = "";
            } else {
                fromDataTempError['gst_applicable_error'] = "";
            }
        }

        if (type == "is_igst_applicable") {
            if (event.target.checked) {
                fromDataTemp['is_igst_applicable'] = true;
                fromDataTemp['is_sgst_applicable'] = false;
                fromDataTempError['gst_applicable_error'] = "";
            } else {
                fromDataTempError['gst_applicable_error'] = "";
            }
        }

        if (type == "currency") {
            if (event != "") {
                fromDataTemp['currency'] = event;
                fromDataTempError['currency'] = ""
            } else {
                fromDataTemp['currency'] = "";
                fromDataTempError['currency'] = ""
            }
        }
        /*===========new add 12.10.2022 start============*/
        if (type == "customer_type") {
            if (event != "") {
                fromDataTemp['customer_type'] = event;
                fromDataTempError['customer_type'] = ""
            } else {
                fromDataTemp['customer_type'] = "";
                fromDataTempError['customer_type'] = ""
            }
        }

        if (type == "tin") {
            if (event.target.value != "") {
                fromDataTemp['tin'] = event.target.value;;
                fromDataTempError['tin'] = ""
            } else {
                fromDataTemp['tin'] = "";
                fromDataTempError['tin'] = ""
            }
        }

        if (type == "tan") {
            if (event.target.value != "") {
                fromDataTemp['tan'] = event.target.value;;
                fromDataTempError['tan'] = ""
            } else {
                fromDataTemp['tan'] = "";
                fromDataTempError['tan'] = ""
            }
        }
        /*===========new add 12.10.2022 end============*/


        this.setState({
            fromData: fromDataTemp,
            fromDataError: fromDataTempError,
            saveButtonDisableEditModal: false,
        }, () => {
            //console.log("fromData===========",this.state.fromData)
        })


    }

    addCustomer = () => {
        const { fromData, reserveFromData, editedFlag, profileImageChangeEditMode, bankDetails } = this.state;
        const { loaderStateTrue, loaderStateFalse, userCredentials } = this.props;
        let valid = this.validCustomerData();
        //console.log("valid=====", valid)
        if (valid) {
            formatingFormData(fromData, userCredentials, reserveFromData, editedFlag, profileImageChangeEditMode, bankDetails).then((dataSet) => {
                //let dataSet = this.formatingFormData();
                //console.log("dataSet=====", dataSet);
                // return false;

                loaderStateTrue();
                let type = "post";
                let id = ""
                if (editedFlag) {
                    id = this.state.editedId,
                        type = "patch";
                    dataSet = dataSet[0]
                }

                CustomerController.customerAdd(dataSet, id, type).then((response) => {
                    //console.log("response=====", response)
                    loaderStateFalse();

                    if (type == "post") {
                        if (response.length > 0) {
                            response.map((res, index) => {
                                if (res.success) {
                                    this.closeTravailleursModal();
                                    this.resetDataGrid();
                                    Utility.toastNotifications(res.message, "Success", "success");
                                } else {
                                    Utility.toastNotifications(res.message, "Error", "error")
                                }
                            })
                        }
                    } else {
                        if (response.success) {
                            this.closeTravailleursModal();
                            this.resetDataGrid();
                            Utility.toastNotifications(response.message, "Success", "success");
                        } else {
                            Utility.toastNotifications(response.message, "Error", "error")
                        }
                    }
                }).catch(error => {
                    loaderStateFalse();
                })

            })
        }
    }

    validCustomerData = () => {
        let fromDataTemp = Object.assign({}, this.state.fromData);
        let fromDataTempError = Object.assign({}, this.state.fromDataError);
        let valid = true;

        if (fromDataTemp.name == "") {
            fromDataTempError['name'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['name'] = ""
        }

        if (fromDataTemp.email != "") {
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!expr.test(fromDataTemp.email)) {
                fromDataTempError['email'] = this.props.t('validEmail')
                valid = false;
            } else {
                fromDataTempError['email'] = ""
            }

        }

        let phoneValidate = HomeUtility.validate_Phone_Number(fromDataTemp.ph_no);
        if (fromDataTemp.ph_no != "") {
            if (phoneValidate) {
                fromDataTempError['ph_no'] = ""
            } else {
                fromDataTempError['ph_no'] = this.props.t('validphonenumber')
                valid = false;
            }
        }




        //Bank details validation start
        let tempBankDetails = this.state.bankDetails.slice();
        let tempBankDetailsError = this.state.bankDetailsError.slice();
        let bankAccountNumber = []
        if (tempBankDetails.length > 0) {
            tempBankDetails.map((value, idx) => {

                bankAccountNumber.push(value.account_no)

                if (value.account_no == "") {
                    tempBankDetailsError[idx]['account_no'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['account_no'] = ""
                }

                if (value.bank_name == "") {
                    tempBankDetailsError[idx]['bank_name'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['bank_name'] = ""
                }
                if (value.bank_address == "") {
                    tempBankDetailsError[idx]['bank_address'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['bank_address'] = ""
                }
                if (value.bank_country.length == 0) {
                    tempBankDetailsError[idx]['bank_country'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['bank_country'] = ""
                }
                if (value.ifsc_code == "") {
                    tempBankDetailsError[idx]['ifsc_code'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    if (value.ifsc_code.length == 11) {
                        tempBankDetailsError[idx]['ifsc_code'] = ""
                    } else {
                        value['ifsc_code'] = "";
                        tempBankDetailsError[idx]['ifsc_code'] = "* IFSC code must be 11 digit"
                        valid = false;
                    }
                }
            })
        }

        if (this.acountNumberDuplicates(bankAccountNumber)) {
            valid = false;
            Utility.toastNotifications("Duplicates account number", "Error", "error")
        }




        //Bank details finish




        if (fromDataTemp.currency == "") {
            fromDataTempError['currency'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['currency'] = ""
        }

        /*if (fromDataTemp.address_line1 == "") {
            fromDataTempError['address_line1'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['address_line1'] = ""
        }
        if (fromDataTemp.city == "") {
            fromDataTempError['city'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['city'] = ""
        }
        if (fromDataTemp.state == "") {
            fromDataTempError['state'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['state'] = ""
        }
        if (fromDataTemp.country.length == 0) {
            fromDataTempError['country'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['country'] = ""
        }
        if (fromDataTemp.zip_code == "") {
            fromDataTempError['zip_code'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['zip_code'] = ""
        }*/
        /*let panValidate = HomeUtility.validate_pan_Number(fromDataTemp.pan_number);
        if (fromDataTemp.pan_number != "") {
            if (panValidate) {
                fromDataTempError['pan_number'] = ""
            } else {
                fromDataTempError['pan_number'] = this.props.t('validpannumber')
                valid = false;
            }
        }*/
        let panValidate = HomeUtility.validate_pan_Number(fromDataTemp.pan_number);
        if (fromDataTemp.customer_type.value == "vendor") {
            if (fromDataTemp.pan_number == "") {
                fromDataTempError['pan_number'] = this.props.t('requiredField')
                valid = false;
            } else {
                if (panValidate) {
                    fromDataTempError['pan_number'] = ""
                } else {
                    fromDataTempError['pan_number'] = this.props.t('validpannumber')
                    valid = false;
                }
            }
        } else {
            fromDataTempError['pan_number'] = ""
            if (fromDataTemp.pan_number != "") {
                if (panValidate) {
                    fromDataTempError['pan_number'] = ""
                } else {
                    fromDataTempError['pan_number'] = this.props.t('validpannumber')
                    valid = false;
                }
            }
        }
        /*if (fromDataTemp.is_gst_applicable == true) {
            let gstValidate = HomeUtility.validate_gst_Number(fromDataTemp.gstn);
            if (fromDataTemp.gstn == "") {
                if (gstValidate) {
                    fromDataTempError['gstn'] = ""
                } else {
                    fromDataTempError['gstn'] = this.props.t('validgstinnumber')
                    valid = false;
                }
            }
        }*/
        if (fromDataTemp.is_gst_applicable == true) {
            if (fromDataTemp.gstn == "") {
                fromDataTempError['gstn'] = this.props.t('requiredField')
                valid = false;
            } else {
                let gstinValidate = HomeUtility.validate_gst_Number(fromDataTemp.gstn);
                if (gstinValidate) {
                    fromDataTempError['gstn'] = ""
                } else {
                    fromDataTempError['gstn'] = this.props.t('validgstinnumber')
                    valid = false;
                }
            }
        }
        // if (fromDataTemp.is_gst_applicable == true) {
        //     let gstnValidate = HomeUtility.validate_gst_Number(fromDataTemp.gst_number);
        //     if (fromDataTemp.gst_number == "") {
        //         if (gstnValidate) {
        //             fromDataTempError['gst_number'] = ""
        //         } else {
        //             fromDataTempError['gst_number'] = this.props.t('validgstnumber')
        //             valid = false;
        //         }
        //     }
        // }

        if (fromDataTemp.is_sgst_applicable == false && fromDataTemp.is_igst_applicable == false && fromDataTemp.is_gst_applicable == true) {
            fromDataTempError['gst_applicable_error'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['gst_applicable_error'] = ""
        }

        /*===========new add 12.10.2022 start============*/
        if (fromDataTemp.customer_type.length == 0) {
            fromDataTempError['customer_type'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['customer_type'] = ""
        }
        /*===========new add 12.10.2022 end============*/

        this.setState({
            fromDataError: fromDataTempError,
            bankDetailsError: tempBankDetailsError
        })
        return valid;

    }

    acountNumberDuplicates = (array) => {
        if (array.length !== new Set(array).size) {
            return true;
        }

        return false;
    }

    resetWorkerFrom = () => {
        this.setState({
            fromData: {
                "name": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
                "pan_number": "",
                "gstn": "",
                //"conversion_allowance_percentage": "",
                //"gst_number": "",
                "active": true,
                "is_gst_applicable": false,
                "is_sgst_applicable": false,
                "is_igst_applicable": false,
                "currency": "",
                /*===========new add 12.10.2022 start============*/
                "customer_type": "",
                "tin": "",
                "tan": ""
                /*===========new add 12.10.2022 end============*/
            },
            fromDataError: {
                "name": "",
                "email": "",
                "ph_no": "",
                "address_line1": "",
                //"address_line2": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
                "pan_number": "",
                "gstn": "",
                //"gst_number": "",
                //"conversion_allowance_percentage": "",
                "currency": "",
                "gst_applicable_error": "",
                /*===========new add 12.10.2022 start============*/
                "customer_type": "",
                /*===========new add 12.10.2022 end============*/
            },
            bankDetails: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],

            bankDetailsError: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],
            editedId: "",
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImagePreviewShow: false,
            saveButtonDisableEditModal: true,
            profileImageChangeEditMode: false,
            editedFlag: false,
        })
    }
    actionModalfunction = (gridObj, e) => {
        let width = ""
        if (localStorage.getItem('selected_lan_direction') == "rtl") {
            width = (parseInt(e.clientX) + 40) + 'px'
        } else {
            width = (parseInt(e.clientX) - 280) + 'px'
        }
        let height = (parseInt(e.clientY) - 70) + 'px'
        this.setState({
            actionModalflag: true,
            overlayHight: height,
            overlayWidth: width,
            gridObjData: gridObj
        }, () => {
            //console.log("gridObjData===========", this.state.gridObjData)
            //this.setEditDataForCustomer();
        })
    }

    editCustomer = (params) => {
        //console.log("params======111111", params)
        this.setState({
            gridObjData: params
        }, () => {
            setEditDataForCustomer(this.state.gridObjData).then((data) => {
                //console.log("edit customer data====", data)
                this.setState({
                    fromData: data,
                    reserveFromData: data,
                    editedId: this.state.gridObjData?.data?._id,
                    addProfileImagePreviewShow: true,
                    addprofileImageSelected: this.state.gridObjData?.data?.profile_img_temp,
                    bankDetails: data.bankDetails,
                    bankDetailsError: data.bankDetailsError,

                })
            });
            this.setState({
                travailleursModal: true,
                cusheaderContent: "Edit Customer/Vendor",
                saveButtonDisableEditModal: true,
                disabledEmail: false,
                editedFlag: true,
            })
        })

    }

    deleteConfirmationModalShow = (obj) => {
        //console.log("obj=========", obj)
        this.setState({
            deleteConfirmationAlertModal: true,
            actionModalflag: false,
            enDeleteBodySecondContent: obj.data.name,
            customerDeleteObj: obj.data
        })
    }

    deleteConfirmationModalHide = () => {
        this.setState({
            deleteConfirmationAlertModal: false,
            enDeleteBodySecondContent: ""
        })
    }

    customerDeleteConfirmButton = () => {
        this.customerDeleteApi()
    }

    customerDeleteCancleButton = () => {
        this.deleteConfirmationModalHide();
    }

    customerDeleteApi = () => {
        const { customerDeleteObj } = this.state;
        //console.log("customerDeleteObj", customerDeleteObj)

        const { loaderStateTrue, loaderStateFalse } = this.props;
        loaderStateTrue();
        let data = {}
        data['id'] = [customerDeleteObj._id]

        CustomerController.customerDelete(data).then((response) => {
            if (response.success) {
                this.resetDataGrid()
                this.deleteConfirmationModalHide()
                this.resetWorkerFrom()
                Utility.toastNotifications(response.data[0].message, "Success", "success")
            } else {
                Utility.toastNotifications(response.data[0].message, "Error", "error")
            }
            loaderStateFalse();
        }).catch((error) => {
            loaderStateFalse();
            this.deleteConfirmationModalHide()
        });
    }

    handleChangeSwitchButton = (data) => {

        let dataHash = {};
        let id = data._id
        dataHash["active"] = data.active ? false : true;
        loaderStateTrue()
        CustomerController.customerUpdate(id, dataHash).then((response) => {
            //console.log("response=============>>", response)
            loaderStateFalse()
            if (response) {
                if (response.success) {
                    this.resetDataGrid()
                    Utility.toastNotifications(response.message, "Success", "success");
                } else {
                    Utility.toastNotifications(response.message, "Error", "error");
                }
            }

        }).catch((error) => {
            console.error("************error*************", error)
            if (error) {
                //Utility.toastNotifications(error.message, "Error", "error");
            }
            // if (error.response.status === 401) {
            // 	Utility.toastNotifications(this.props.t('plaeselogin'), "Error", "error");
            // 	this.props.logOutApp().then(
            // 		() => this.props.history.push("/")
            // 	);
            // }
            loaderStateFalse();
            if (error.message == "Network Error") {
                // Utility.toastNotifications("Please login", "Error", "error");
                // this.props.logOutApp().then(
                //     () => this.props.history.push("/")
                // );
            }
        });

    }

    popoverStickDatasetFormatUser = (rowData) => {
        let data = {}
        data = Object.assign(rowData, {
            "phone_no": rowData.ph_no,
        })
        return data
    }


    handelClickBankAdd = () => {
        let bankDetailsNew = {
            "account_no": "",
            "bank_name": "",
            "bank_address": "",
            "bank_country": "",
            "ifsc_code": "",
        }
        let bankDetailsErrorNew = {
            "account_no": "",
            "bank_name": "",
            "bank_address": "",
            "bank_country": "",
            "ifsc_code": "",
        }
        let tempBankDetails = this.state.bankDetails.slice()
        let tempBankDetails_copy = [...tempBankDetails, bankDetailsNew]


        let tempbankDetailsError = this.state.bankDetailsError.slice()
        let tempbankDetailsError_copy = [...tempbankDetailsError, bankDetailsErrorNew]

        this.setState({
            bankDetails: tempBankDetails_copy,
            bankDetailsError: tempbankDetailsError_copy
        })
    }


    handelChangeForBankDetails = (event, type, i) => {


        //console.log("event---", event)
        //console.log("type---", type)
        //console.log("i---", i)



        let fromDataTemp = this.state.bankDetails.slice();
        let fromDataTempError = this.state.bankDetailsError.slice();
        // let fromDataBudgetTemp = Object.assign({}, this.state.fromDataBudget);
        // let fromDataBudgetTempError = Object.assign({}, this.state.fromDataBudgetError);

        if (type == "account_no") {
            if (!isNaN(event.target.value)) {
                fromDataTemp[i]['account_no'] = event.target.value;
                fromDataTempError[i]['account_no'] = ""
            } else {
                //fromDataTemp[i]['account_no'] = "";
                //fromDataTempError['account_no'] = ""
                Utility.toastNotifications(this.props.t('please_enter_integer_number'), "Warning", "warning")
            }
        }
        if (type == "bank_name") {
            if (event.target.value != "") {
                fromDataTemp[i]['bank_name'] = event.target.value;
                fromDataTempError[i]['bank_name'] = ""
            } else {
                fromDataTemp[i]['bank_name'] = "";
                fromDataTempError[i]['bank_name'] = ""
            }
        }
        if (type == "bank_address") {
            if (event.target.value != "") {
                fromDataTemp[i]['bank_address'] = event.target.value;
                fromDataTempError[i]['bank_address'] = ""
            } else {
                fromDataTemp[i]['bank_address'] = "";
                fromDataTempError[i]['bank_address'] = ""
            }
        }
        if (type == "bank_country") {
            if (event != "") {
                fromDataTemp[i]['bank_country'] = event;
                fromDataTempError[i]['bank_country'] = ""
            } else {
                fromDataTemp[i]['bank_country'] = "";
                fromDataTempError[i]['bank_country'] = this.props.t('requiredField')
            }
        }
        if (type == "ifsc_code") {
            if (event.target.value != "") {
                if (event.target.value.length == 11) {
                    fromDataTempError[i]['ifsc_code'] = ""
                } else {
                    fromDataTemp[i]['ifsc_code'] = "";
                    fromDataTempError[i]['ifsc_code'] = "* IFSC code must be 11 digit"
                }
                fromDataTemp[i]['ifsc_code'] = event.target.value;
            } else {
                fromDataTemp[i]['ifsc_code'] = "";
                fromDataTempError[i]['ifsc_code'] = ""
            }
        }



        this.setState({
            bankDetails: fromDataTemp,
            bankDetailsError: fromDataTempError,
            saveButtonDisableEditModal: false
        })


    }

    removeAdditionalBankDetails = (idx, type) => {
        this.setState({
            deleteBankDetailsConfirmationAlertModalFlag: true,
            deleteBankDetailsObj: idx
        })
    }

    deleteBankDetailsConfirmationModalHide = () => {
        this.setState({
            deleteBankDetailsConfirmationAlertModalFlag: false,
            deleteBankDetailsObj: ""
        })
    }

    deleteBankDetailsConfirmationFunction = () => {
        const { deleteBankDetailsObj } = this.state
        let tempBankDetails = this.state.bankDetails.slice();
        let tempBankDetailsError = this.state.bankDetailsError.slice();

        tempBankDetails.splice(deleteBankDetailsObj, 1)
        tempBankDetailsError.splice(deleteBankDetailsObj, 1)
        this.setState({
            bankDetails: tempBankDetails,
            bankDetailsError: tempBankDetailsError,
            deleteBankDetailsConfirmationAlertModalFlag: false,
            saveButtonDisableEditModal: false,
        })
    }

    /*===========new add 12.10.2022 start============*/
    handleChangeCompanyTypeFilter = (type, event) => {
        if (type == 'company_type') {
            if (event) {
                this.setState({
                    companyTypeFilterSelectedData: event
                }, () => {
                    this.resetDataGrid();
                })
            } else {
                this.setState({
                    companyTypeFilterSelectedData: ""
                }, () => {
                    this.resetDataGrid();
                })
            }
        }

    }
    /*===========new add 12.10.2022 end============*/


    render() {
        const { t } = this.props;
        return (
            <div className="gridcontainer">

                <div className="totalworkercontent">
                    <div className="gridtopviews">
                        {/*===========new add 12.10.2022 start============*/}
                        <div className="dropdownbox companyTypeDropFilter">
                            <AutosuggestComponent
                                handleOnChange={this.handleChangeCompanyTypeFilter.bind(this, 'company_type')}
                                options={this.state.companyTypeList}
                                selectedValue={this.state.companyTypeFilterSelectedData}
                                name=''
                                isMulti={false}
                                placeholder="Company type"
                                isDisabled={false}
                                isClearable={true}
                                //defaultMenuIsOpen={true}
                                closeButton={true}
                                menuHeader="Company type"
                                isSearchable={true}
                            />
                        </div>
                        {/*===========new add 12.10.2022 end============*/}
                        <div className="rightboxes">
                            <button type="button" className="useraddbtn" onClick={this.travailleursModalfunction}>{this.props.t('Ajouter')}</button>

                        </div>
                        <div className="pageinnersearch">
                            <button type="button" className="btn btn-link search_btn_addon"><i className="fa fa-search"></i></button>
                            <CustomInput
                                parentClassName="comment_input_field"
                                name="srchBox"
                                type="text"
                                placeholder="Search a company"
                                onChange={this.handleUserSearchBar.bind(this)}
                                value={this.state.customerName}
                            />
                            {
                                this.state.customerName != "" ?
                                    < button type="button" className="btn btn-link dropclosebtn" onClick={this.clearSearchValue}>
                                        <img src={require('../../../../Utility/Public/images/dropcloseicon.png')} className="searchClearIcon" />
                                    </button>
                                    : null}
                        </div>
                    </div>
                    <div className="ag-theme-alpine aggridview homeag">
                        <AgGridReact
                            modules={this.state.modules}
                            columnDefs={this.state.columnDefs}
                            defaultColDef={this.state.defaultColDef}
                            components={this.state.components}
                            rowSelection="multiple"
                            rowModelType="infinite"
                            onGridReady={this.onGridReady}
                            rowHeight={62.5}
                            headerHeight={47}
                            //onSelectionChanged={this.onSelectionChanged.bind(this)}
                            cacheBlockSize={10}
                            enableRtl={localStorage.getItem('selected_lan_direction') == "rtl" ? true : false}
                        />
                    </div>
                    <ModalGlobal
                        show={this.state.travailleursModal}
                        onHide={this.closeTravailleursModal}
                        title={this.state.cusheaderContent}
                        className="modalcustomize mondimension customerModalContent customerModal"
                        footer={false}
                        closeButton={true}
                        body={
                            <CustomerModalContent
                                //Image crop
                                addInputProfileImageChanged={this.addInputProfileImageChanged}
                                addprofileImageSelected={this.state.addprofileImageSelected}
                                crop={this.state.crop}
                                croppedImageUrl={this.state.croppedImageUrl}
                                src={this.state.src}
                                onImageLoaded={this.onImageLoaded}
                                onCropComplete={this.onCropComplete}
                                onCropChange={this.onCropChange}
                                imageCropModalShow={this.imageCropModalShow}
                                imageCropModalHide={this.imageCropModalHide}
                                imageCropModalFlag={this.state.imageCropModalFlag}
                                imageCropDataSave={this.imageCropDataSave}
                                formatDateInput={this.formatDateInput}

                                //orgList={this.state.orgList}

                                //form data
                                handelChange={this.handelChange}
                                fromData={this.state.fromData}
                                fromDataError={this.state.fromDataError}
                                addCustomer={this.addCustomer}
                                addProfileImagePreviewShow={this.state.addProfileImagePreviewShow}
                                saveButtonDisableEditModal={this.state.saveButtonDisableEditModal}
                                disabledEmail={this.state.disabledEmail}
                                currencyList={this.state.currencyList}
                                countryList={this.state.countryList}

                                bankDetails={this.state.bankDetails}
                                bankDetailsError={this.state.bankDetailsError}
                                handelClickBankAdd={this.handelClickBankAdd}
                                handelChangeForBankDetails={this.handelChangeForBankDetails}
                                removeAdditionalBankDetails={this.removeAdditionalBankDetails}
                                removeAdditionalBankDetailsDisplay={true}
                                companyTypeList={this.state.companyTypeList}

                            />
                        }
                    />
                    <ModalGlobal
                        show={this.state.deleteConfirmationAlertModal}
                        onHide={this.deleteConfirmationModalHide}
                        className="modalcustomize confirmationalertmodal"
                        bodyClassName="cancelConfirmationbody"
                        headerclassName="close_btn_icon"
                        title={t('deleteCustomer')}
                        footer={false}
                        body={
                            <ConfirmationAlert
                                BodyFirstContent={t('entDeleteConfirmation')}
                                BodySecondContent={this.state.enDeleteBodySecondContent}
                                BodyThirdContent={t('custDeleteAnableGoBack')}
                                confirmationButtonContent={t('confirm')}
                                cancelButtonContent={t('cancel')}
                                deleteConfirmButton={this.customerDeleteConfirmButton}
                                deleteCancleButton={this.customerDeleteCancleButton}
                            />
                        }
                    />

                    <ModalGlobal
                        show={this.state.deleteBankDetailsConfirmationAlertModalFlag}
                        onHide={this.deleteBankDetailsConfirmationModalHide}
                        className="modalcustomize confirmationalertmodal"
                        bodyClassName="cancelConfirmationbody"
                        headerclassName="close_btn_icon"
                        title={t('deleteBankDetails')}
                        footer={false}
                        body={
                            <ConfirmationAlert
                                BodyFirstContent={t('bankDeleteConfirmation')}
                                //BodySecondContent={this.state.enDeleteBodySecondContent}
                                BodyThirdContent={t('bankDeleteAnableGoBack')}
                                confirmationButtonContent={t('confirm')}
                                cancelButtonContent={t('cancel')}
                                deleteConfirmButton={this.deleteBankDetailsConfirmationFunction}
                                deleteCancleButton={this.deleteBankDetailsConfirmationModalHide}
                            />
                        }
                    />

                    {this.state.actionModalflag ?
                        <GridActionContent
                            styleWidth={this.state.overlayWidth}
                            styleHight={this.state.overlayHight}
                            codeOutsideClickRef={this.codeOutsideClickRef}
                            gridObjData={this.state.gridObjData}
                            modefier={this.editCustomer}
                            delete={this.deleteConfirmationModalShow}
                        />
                        : null}

                </div>

            </div >
        );
    }
}


const mapStateToProps = (globalState) => {
    return {
        userCredentials: globalState.LoginReducer.userCredentials
    };
}

export default withRouter(connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
    (withTranslation()(Customer)));