import CountryWithCode from '../../../../../Utility/JsFolder/CountryWithCode';
export const setEditDataForCustomer = (gridObjData) => {
   // console.log("gridObjData format=======", gridObjData)
    let promise = new Promise((resolve, reject) => {
        let data = {}
        data["name"] = gridObjData.data.name
        data["email"] = gridObjData.data.email
        data["ph_no"] = gridObjData.data.ph_no
        data["profileImage"] = ""
        data["address_line1"] = gridObjData.data.address_line1
        data["address_line2"] = gridObjData.data.address_line2
        data["city"] = gridObjData.data.city
        data["state"] = gridObjData.data.state
        let findCountry = CountryWithCode.filter(res => {
            return res.country == gridObjData.data.country;
        });
        //console.log("findCountry====", findCountry)
        if (findCountry.length > 0) {
            data["country"] = { label: findCountry[0].country, value: findCountry[0].country }
        }

        let bankArry =[];
        let bankErrorArry =[];
        if(gridObjData.data?.bank_details && gridObjData.data.bank_details.length>0){
            gridObjData.data?.bank_details.map((v,i)=>{

                let findBankCountry = CountryWithCode.filter(Bres => {
                    return Bres.country == v.bank_country;
                });

                let bankCountry ={}
                if (findBankCountry.length > 0) {
                    bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
                }

                let bankhash = {
                    "account_no": v.account_no,
                    "bank_name": v.bank_name,
                    "bank_address": v.bank_address,
                    "bank_country": bankCountry,
                    "ifsc_code": v.ifsc_code,
                }
                let errorhash = {
                    "account_no": "",
                    "bank_name": "",
                    "bank_address": "",
                    "bank_country": "",
                    "ifsc_code": "",
                }

                bankArry.push(bankhash)
                bankErrorArry.push(errorhash)
            })
        }

        data["bankDetails"] =bankArry
        data["bankDetailsError"] = bankErrorArry
        
        data["zip_code"] = gridObjData.data.zip_code
        data["pan_number"] = gridObjData.data.pan_number
        data["gstn"] = gridObjData.data.gst_number
        //data["gst_number"] = gridObjData.data.gst_number
        //data["conversion_allowance_percentage"] = gridObjData.data.conversion_allowance_percentage
        data["active"] = gridObjData.data.active,
        data["is_gst_applicable"] = gridObjData.data.is_gst_applicable,
        data["is_sgst_applicable"] = gridObjData.data.is_sgst_applicable,
        data["is_igst_applicable"] = gridObjData.data.is_igst_applicable,
        data["currency"] = { label: gridObjData.data.currency, value: gridObjData.data.currency }
        /*===========new add 12.10.2022 start============*/
        data["tan"] = gridObjData.data.tan
        data["tin"] = gridObjData.data.tin
        data["customer_type"] = { label: gridObjData.data.customer_type, value: gridObjData.data.customer_type }
        /*===========new add 12.10.2022 end============*/
        resolve(data);
    })
    return promise;
};

