const lodash = require('lodash');
export const formatingFormData = (fromData, userCredentials, reserveFromData, editedFlag, profileImageChangeEditMode, bankDetails) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        if (!editedFlag) {
            hash['org_id'] = userCredentials.user_details.org_id
            hash['name'] = fromData.name
            hash['email'] = fromData.email
            hash['ph_no'] = fromData.ph_no
            hash['address_line1'] = fromData.address_line1
            hash['address_line2'] = fromData.address_line2
            hash['city'] = fromData.city
            hash['state'] = fromData.state
            hash['country'] = fromData.country.value
            hash['zip_code'] = fromData.zip_code
            hash['pan_number'] = fromData.pan_number
            //hash['gstn'] = fromData.gstn
            hash['gst_number'] = fromData.gstn
            // if (fromData.is_gst_applicable) {
            //     hash['gst_number'] = fromData.gst_number
            // }
            hash['active'] = fromData.active;
            hash['is_gst_applicable'] = fromData.is_gst_applicable;
            hash['is_sgst_applicable'] = fromData.is_sgst_applicable;
            hash['is_igst_applicable'] = fromData.is_igst_applicable;
            hash["currency"] = fromData.currency.value
            if (Object.keys(fromData.profileImage).length > 0) {
                hash['logo_img'] = fromData.profileImage
            }

            let bankArry = []
            if (bankDetails.length > 0) {
                bankDetails.map((v, i) => {
                    let tempHash = {}
                    tempHash['account_no'] = v.account_no;
                    tempHash['bank_name'] = v.bank_name;
                    tempHash['bank_address'] = v.bank_address;
                    tempHash['bank_country'] = v.bank_country.value;
                    tempHash['ifsc_code'] = v.ifsc_code;
                    bankArry.push(tempHash)
                })
            }
            hash['bank_details'] = bankArry
            /*===========new add 12.10.2022 start============*/
            hash['customer_type'] = fromData.customer_type.value
            hash['tin'] = fromData.tin
            hash['tan'] = fromData.tan
            /*===========new add 12.10.2022 end============*/
            dataSet.push(hash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveFromData, fromData)
            Object.keys(compareData).map((key) => {
                hash[key] = compareData[key]
                if (key == "currency") {
                    hash["currency"] = compareData.currency.value
                }
                if (key == "country") {
                    hash["country"] = compareData.country.value
                }
                if (key == "gstn") {
                    hash['gst_number'] = fromData.gstn
                }
                /*===========new add 12.10.2022 start============*/
                if (key == "customer_type") {
                    hash["customer_type"] = compareData.customer_type.value
                }
                /*===========new add 12.10.2022 end============*/
               

                delete hash.gstn
            })
            if (profileImageChangeEditMode) {
                if (Object.keys(fromData.profileImage).length > 0) {
                    hash['logo_img'] = fromData.profileImage
                }
            }

            let bankArry = []
            if (bankDetails.length > 0) {
                bankDetails.map((v, i) => {
                    let tempHash = {}
                    tempHash['account_no'] = v.account_no;
                    tempHash['bank_name'] = v.bank_name;
                    tempHash['bank_address'] = v.bank_address;
                    tempHash['bank_country'] = v.bank_country.value;
                    tempHash['ifsc_code'] = v.ifsc_code;
                    bankArry.push(tempHash)
                })
            }
            hash['bank_details'] = bankArry





            dataSet.push(hash);
            resolve(dataSet)
        }
    })

    return promise;

};

const difference = (origObj, newObj) => {
    let changes = (newObj, origObj) => {
        let arrayIndexCounter = 0
        return lodash.transform(newObj, (result, value, key) => {
            if (!lodash.isEqual(value, origObj[key])) {
                let resultKey = lodash.isArray(origObj) ? arrayIndexCounter++ : key
                result[resultKey] = (lodash.isObject(value) && lodash.isObject(origObj[key])) ? changes(value, origObj[key]) : value
            }
        })
    }
    return changes(newObj, origObj)
}