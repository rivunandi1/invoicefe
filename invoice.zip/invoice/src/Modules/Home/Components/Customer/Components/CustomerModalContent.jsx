import React, { Component, useEffect } from 'react';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Utility from '../../../../../Utility/Utility';

import ReactCrop from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import ImageCropContent from '../../../../../Utility/Components/ImageCropContent';
import ModalGlobal from '../../../../../Utility/Components/ModalGlobal';
import BankDetailsComponent from '../../../../../Utility/Components/BankDetailsComponent';

class CustomerModalContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 16 / 9
            },
            croppedImageUrl: "",
        }

    }

    //usee



    render() {
        const { addInputProfileImageChanged, addprofileImageSelected, steponehide, t, disabledEmail, fromData, gst_type_visable } = this.props;
        const { crop, croppedImageUrl, src } = this.state;
        return (
            <>
                <div className="modalinnerbody">
                    <div className="firstinformation">
                        <div className="col-md-12">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="row">
                                        <div className="col-md-12">
                                            <CustomInput
                                                parentClassName="input_field_inner required"
                                                labelName={t('Name')}
                                                errorLabel={this.props.fromDataError.name}
                                                name="name"
                                                type="text"
                                                value={this.props.fromData.name}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "name")}

                                            />
                                        </div>
                                        <div className="col-md-12">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <CustomInput
                                                        parentClassName="input_field_inner"
                                                        labelName={t('Email')}
                                                        errorLabel={this.props.fromDataError.email}
                                                        name="email"
                                                        type="text"
                                                        value={this.props.fromData.email}
                                                        labelPresent={true}
                                                        onChange={(e) => this.props.handelChange(e, "email")}

                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="user_add_img modprofile">
                                        <div className="userProfileImg">
                                            {!this.props.addProfileImagePreviewShow ?
                                                <label className="custom-file-upload">
                                                    <span className="filetext">
                                                        <img src={addprofileImageSelected} />
                                                    </span>
                                                    <span className="plusicon">
                                                        <i className="fa fa-plus" aria-hidden="true"></i>
                                                        <input type="file" onChange={addInputProfileImageChanged} />
                                                    </span>
                                                </label>
                                                :
                                                <label className="custom-file-upload">
                                                    <img src={addprofileImageSelected} />
                                                    <span className="plusicon">
                                                        <i className="fa fa-plus" aria-hidden="true"></i>
                                                        <input type="file" onChange={this.props.addInputProfileImageChanged} />
                                                    </span>
                                                </label>
                                            }

                                            <div className="col-md-12 errorClass error_div">{this.props.traprofileImageError}</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner phonenumberError"
                                        labelName={t('phonenumber')}
                                        errorLabel={this.props.fromDataError.ph_no}
                                        name="ph_no"
                                        type="text"
                                        value={this.props.fromData.ph_no}
                                        labelPresent={true}
                                        onChange={(e) => this.props.handelChange(e, "ph_no")}

                                    />
                                </div>
                                {/*===========new add 12.10.2022 start============*/}
                                <div className="col-md-6">
                                    <div className="dropdowninnerbox required customer_type_drop">
                                        <label>Company type</label>
                                        <AutosuggestComponent
                                            handleOnChange={(e) => this.props.handelChange(e, "customer_type")}
                                            options={this.props.companyTypeList}
                                            selectedValue={this.props.fromData.customer_type}
                                            name=''
                                            isMulti={false}
                                            placeholder=""
                                            isDisabled={false}
                                            isSearchable={true}
                                        />
                                        <div className="col-md-12 errorClass error_div">{this.props.fromDataError.customer_type}</div>
                                    </div>
                                </div>
                                {/*===========new add 12.10.2022 end============*/}
                            </div>
                            <label className='tagName'>Bank Details</label>
                            <div className="row banckDetails additionalBanckDetails">

                                <BankDetailsComponent
                                    countryList={this.props.countryList}
                                    bankDetails={this.props.bankDetails}
                                    bankDetailsError={this.props.bankDetailsError}
                                    handelChangeForBankDetails={this.props.handelChangeForBankDetails}
                                    handelClickBankAdd={this.props.handelClickBankAdd}
                                    removeAdditionalBankDetails={this.props.removeAdditionalBankDetails}
                                    removeAdditionalBankDetailsDisplay={true}
                                />

                            </div>




                            <div className="row">

                                <div className="col-md-12">
                                    <div className="row">
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName="Addres line 1"
                                                errorLabel={this.props.fromDataError.address_line1}
                                                name="address_line1"
                                                type="text"
                                                value={this.props.fromData.address_line1}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "address_line1")}

                                            />
                                        </div>
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner phonenumberError"
                                                labelName="Addres line 2"
                                                //errorLabel={this.props.fromDataError.address_line2}
                                                name="address_line2"
                                                type="text"
                                                value={this.props.fromData.address_line2}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "address_line2")}

                                            />
                                        </div>
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName="City"
                                                errorLabel={this.props.fromDataError.city}
                                                name="city"
                                                type="text"
                                                value={this.props.fromData.city}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "city")}

                                            />
                                        </div>
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner phonenumberError"
                                                labelName="State"
                                                errorLabel={this.props.fromDataError.state}
                                                name="state"
                                                type="text"
                                                value={this.props.fromData.state}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "state")}

                                            />
                                        </div>
                                        <div className="col-md-6">
                                            <div className="dropdowninnerbox">
                                                <label>Country</label>
                                                <AutosuggestComponent
                                                    handleOnChange={(e) => this.props.handelChange(e, "country")}
                                                    options={this.props.countryList}
                                                    selectedValue={this.props.fromData.country}
                                                    name=''
                                                    isMulti={false}
                                                    placeholder=""
                                                    isDisabled={false}
                                                    isSearchable={true}
                                                />
                                                <div className="col-md-12 errorClass error_div">{this.props.fromDataError.country}</div>
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName="Zip code"
                                                errorLabel={this.props.fromDataError.zip_code}
                                                name="zip_code"
                                                type="text"
                                                value={this.props.fromData.zip_code}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "zip_code")}

                                            />
                                        </div>
                                        <div className="col-md-6">
                                            <label className="labelTitleTag">Pan No.{this.props.fromData.customer_type.value=="vendor" ?<span>*</span>:null}</label>
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                //labelName="Pan No."
                                                errorLabel={this.props.fromDataError.pan_number}
                                                name="pan_number"
                                                type="text"
                                                value={this.props.fromData.pan_number}
                                                labelPresent={false}
                                                onChange={(e) => this.props.handelChange(e, "pan_number")}

                                            />
                                        </div>

                                        <div className="col-md-6">
                                            <div className="dropdowninnerbox required">
                                                <label>Currency</label>
                                                <AutosuggestComponent
                                                    handleOnChange={(e) => this.props.handelChange(e, "currency")}
                                                    options={this.props.currencyList}
                                                    selectedValue={this.props.fromData.currency}
                                                    name=''
                                                    isMulti={false}
                                                    placeholder=""
                                                    isDisabled={false}
                                                    isSearchable={true}
                                                />
                                                <div className="col-md-12 errorClass error_div">{this.props.fromDataError.currency}</div>
                                            </div>
                                        </div>
                                        {/*===========new add 12.10.2022 start============*/}
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName="TAN"
                                                //errorLabel={this.props.fromDataError.tan}
                                                name="tan"
                                                type="text"
                                                value={this.props.fromData.tan}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "tan")}

                                            />
                                        </div>
                                        <div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName="TIN"
                                                //errorLabel={this.props.fromDataError.tin}
                                                name="tin"
                                                type="text"
                                                value={this.props.fromData.tin}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "tin")}

                                            />
                                        </div>
                                        {/*===========new add 12.10.2022 end============*/}
                                        <div className="col-md-6">
                                            <div className="col-md-12 custom_checkboxInner gst_applicable_drop_cus">
                                                <label className="custom_checkbox_tick">GST Applicable
                                                    <input type="checkbox" checked={fromData.is_gst_applicable} onChange={(e) => this.props.handelChange(e, "is_gst_applicable")} />
                                                    <span className="checkmarkCheckbox"></span>
                                                </label>
                                            </div>
                                        </div>
                                        {/* {fromData.is_gst_applicable ?
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="GST Number"
                                                    errorLabel={this.props.fromDataError.gst_number}
                                                    name="gst_number"
                                                    type="text"
                                                    value={this.props.fromData.gst_number}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "gst_number")}

                                                />
                                            </div> : null} */}
                                        {fromData.is_gst_applicable ?
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner required"
                                                    labelName="GSTIN"
                                                    errorLabel={this.props.fromDataError.gstn}
                                                    name="gstn"
                                                    type="text"
                                                    value={this.props.fromData.gstn}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "gstn")}

                                                />
                                            </div>
                                            : null}
                                        {fromData.is_gst_applicable ?
                                            <div className="col-md-6">
                                                <div className="gstradiobox">
                                                    <label className="taitlecount">GST type <span className='requiredStar'>*</span></label>
                                                    <label className="custom-radio-container">GST
                                                        <input type="radio" name="gst_type" value="is_sgst_applicable" onChange={(e) => this.props.handelChange(e, "is_sgst_applicable")} checked={fromData.is_sgst_applicable ? true : false} />
                                                        <span className="checkmark"></span>
                                                    </label>
                                                    <label className="custom-radio-container">IGST
                                                        <input type="radio" name="gst_type" value="is_igst_applicable" onChange={(e) => this.props.handelChange(e, "is_igst_applicable")} checked={fromData.is_igst_applicable ? true : false} />
                                                        <span className="checkmark"></span>
                                                    </label>
                                                </div>
                                                <div className="col-md-12 errorClass error_div">{this.props.fromDataError.gst_applicable_error}</div>
                                            </div> : null}
                                        <div className="col-md-6 custom_checkboxInner">
                                            <div className="col-md-12 gst_checkbox_drop">
                                                <label className="custom_checkbox_tick">{t('active')}
                                                    <input type="checkbox" checked={fromData.active} onChange={(e) => this.props.handelChange(e, "active")} />
                                                    <span className="checkmarkCheckbox"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-12">
                                    <div className="row">
                                        {/*<div className="col-md-6">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName="Conversion allowance %"
                                                //errorLabel={this.props.fromDataError.conversion_allowance_percentage}
                                                name="conversion_allowance_percentage"
                                                type="text"
                                                value={this.props.fromData.conversion_allowance_percentage}
                                                labelPresent={true}
                                                onChange={(e) => this.props.handelChange(e, "conversion_allowance_percentage")}
                                            />
                                        </div>*/}
                                    </div>
                                </div>
                                <div className="col-md-12 modfooterbtn">
                                    <button type="button" className="savebtn" disabled={this.props.saveButtonDisableEditModal} onClick={this.props.addCustomer}>{t('save')}</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <ModalGlobal
                    show={this.props.imageCropModalFlag}
                    onHide={this.props.imageCropModalHide}
                    onCancel={this.props.imageCropModalHide}
                    onSave={this.props.imageCropDataSave}
                    className="modalcustomize cropmodalcontent"
                    bodyClassName="cropmodalcontentbody"
                    headerclassName="close_btn_icon"
                    title={t('cropimage')}
                    footer={true}
                    closeButton={true}
                    saveButtonLabel={t('crop')}
                    saveButtonClassName="delconfirmbtn btn btn-primary"
                    cancelButtonClassName="delcancelbtn btn btn-primary"
                    body={
                        <ImageCropContent
                            onImageLoaded={this.props.onImageLoaded}
                            onComplete={this.props.onCropComplete}
                            onCropChange={this.props.onCropChange}
                            crop={this.props.crop}
                            croppedImageUrl={this.props.croppedImageUrl}
                            src={this.props.src}
                            onCropComplete={this.props.onCropComplete}
                            imageCropModalShow={this.props.imageCropModalShow}
                        />
                    }
                />
            </>
        );
    }
}

CustomerModalContent.propTypes = {

}

CustomerModalContent.defaultProps = {
    className: "modalcustomize mondimension",
    headerclassName: "close_btn_icon",
    buttonClassName: "btn btn-primary",
    BodyContent: "",
    buttonContent: "",
    bodyClassName: ""
}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(CustomerModalContent)));