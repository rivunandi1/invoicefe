import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { customerListingGet, customerAddPost, customerDetailsGet, customerAddPatch, customerDeleteApi, customerUpdatePatch,customerBankListingGet } from '../Model/CustomerModel';
import Config from '../../../../../Utility/Config';

export const customerListing = (data) => {
    return get(`${Config.extendedUrl}customers`, data).then((response) => {
        return customerListingGet(response)
    });
};

export const customerBankListing = (id) => {
    return get(`${Config.extendedUrl}customers/${id}`,  null).then((response) => {
        return customerBankListingGet(response)
    });
};

export const customerAdd = (data, id, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}customers`, data).then((response) => {
            return customerAddPost(response)
        });
    } else {
        return patch(`${Config.extendedUrl}customers/${id}`, data).then((response) => {
            return customerAddPatch(response)
        });
    }

};
export const customerDetails = (id, data) => {
    return get(`${Config.extendedUrl}customers/details/${id}`, data).then((response) => {
        return customerDetailsGet(response)
    });
};


export const customerDelete = (data) => {
    return del(`${Config.extendedUrl}customers`, data).then((response) => {
        return customerDeleteApi(response)
    });
};

export const customerUpdate = (id, data) => {
    return patch(`${Config.extendedUrl}customers/${id}`, data).then((response) => {
        return customerUpdatePatch(response)
    });
};