import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { orgListingGet, orgCreatePost, orgDetailsGet, orgUpdatePatch,orgUpdatePatchApi, organizationDeleteApi, addUserPost, addUserPatch, orgCustRelationPostApi, userDetailsGet, userDeleteApi, usersInfoPost, usersInfoPatch, yearlyBudgetPercentagePost, yearlyBudgetPercentagePatch} from '../Model/OrganizationModel';
import Config from '../../../../../Utility/Config';

export const orgListing = (data) => {
    return get(`${Config.extendedUrl}organisations`, data).then((response) => {
        return orgListingGet(response)
    });
};
export const orgCreate = (data,id,type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}organisations`, data).then((response) => {
            return orgCreatePost(response)
        });
    } else {
        return patch(`${Config.extendedUrl}organisations/${id}`, data).then((response) => {
            return orgUpdatePatchApi(response)
        });
    }
};

export const orgDetails = (id, data) => {
    return get(`${Config.extendedUrl}organisations/details/${id}`, data).then((response) => {
        return orgDetailsGet(response)
    });
};
export const orgUpdate = (id, data) => {
    return patch(`${Config.extendedUrl}organisations/${id}`, data).then((response) => {
        return orgUpdatePatch(response)
    });
};

export const organizationDelete = (data) => {
    return del(`${Config.extendedUrl}organisations`, data).then((response) => {
        return organizationDeleteApi(response)
    });
};


export const addUser = (data, type, id ) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}admin/users`, data).then((response) => {
            return addUserPost(response)
        });
    } else {
        return patch(`${Config.extendedUrl}admin/users/${id}`, data).then((response) => {
            return addUserPatch(response)
        });
    }
};

export const orgCustRelationPost = (data) => {
    return post(`${Config.extendedUrl}org_cust_user_relations`, data).then((response) => {
        return orgCustRelationPostApi(response)
    });
};

export const userDetails = (id, data) => {
    return get(`${Config.extendedUrl}admin/users_details/${id}`, data).then((response) => {
        return userDetailsGet(response)
    });
};

export const userDelete = (data) => {
    return del(`${Config.extendedUrl}admin/users`, data).then((response) => {
        return userDeleteApi(response)
    });
};
export const usersInfo = (data, id, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}user_info`, data).then((response) => {
            return usersInfoPost(response)
        });
    } else {
        return patch(`${Config.extendedUrl}user_info/${id}`, data).then((response) => {
            return usersInfoPatch(response)
        });
    }
};

export const yearlyBudgetPercentageCreate = (data) => {
    return post(`${Config.extendedUrl}yearly_org_budget_percentage`, data).then((response) => {
        return yearlyBudgetPercentagePost(response)
    });
};

export const yearlyBudgetPercentageUpdate = (id, data) => {
    return patch(`${Config.extendedUrl}yearly_org_budget_percentage/${id}`, data).then((response) => {
        return yearlyBudgetPercentagePatch(response)
    });
};