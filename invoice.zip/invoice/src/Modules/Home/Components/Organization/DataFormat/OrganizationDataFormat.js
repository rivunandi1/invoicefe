const lodash = require('lodash');
export const formatingFormData = (fromData, reserveFromData, orgFlagType, orgProfileImageChangeEditMode, bankDetails) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        if (!orgFlagType) {
            hash['name'] = fromData.name
            hash['email'] = fromData.email
            hash['ph_no'] = fromData.ph_no
            if (Object.keys(fromData.profileImage).length > 0) {
                hash['logo_img'] = fromData.profileImage
            }
            //hash['gst_number'] = fromData.gst_number
            hash['pan_number'] = fromData.pan_number
            //hash['gstn'] = fromData.gstn
            hash['gst_number'] = fromData.gstn

            hash['address_line1'] = fromData.address_line1
            hash['address_line2'] = fromData.address_line2
            hash['city'] = fromData.city
            hash['state'] = fromData.state
            hash['country'] = fromData.country.value
            hash['zip_code'] = fromData.zip_code


            let bankArry = []
            if (bankDetails.length > 0) {
                bankDetails.map((v, i) => {
                    let tempHash = {}
                    tempHash['account_no'] = v.account_no;
                    tempHash['bank_name'] = v.bank_name;
                    tempHash['bank_address'] = v.bank_address;
                    tempHash['bank_country'] = v.bank_country.value;
                    tempHash['ifsc_code'] = v.ifsc_code;
                    bankArry.push(tempHash)
                })
            }
            hash['bank_details'] = bankArry
            dataSet.push(hash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveFromData, fromData)
            Object.keys(compareData).map((key) => {
                hash[key] = compareData[key]
                if (key == "country") {
                    hash["country"] = compareData.country.value
                }
               
                if (key == "gstn") {
                    hash['gst_number'] = fromData.gstn
                }
                delete hash.gstn
            })
            if (orgProfileImageChangeEditMode) {
                if (Object.keys(fromData.profileImage).length > 0) {
                    hash['logo_img'] = fromData.profileImage
                }
            }

            let bankArry = []
            if (bankDetails.length > 0) {
                bankDetails.map((v, i) => {
                    let tempHash = {}
                    tempHash['account_no'] = v.account_no;
                    tempHash['bank_name'] = v.bank_name;
                    tempHash['bank_address'] = v.bank_address;
                    tempHash['bank_country'] = v.bank_country.value;
                    tempHash['ifsc_code'] = v.ifsc_code;
                    bankArry.push(tempHash)
                })
            }
            hash['bank_details'] = bankArry
            
            dataSet.push(hash);
            resolve(dataSet)
        }
    })

    return promise;

};

/*export const formatingFormDataYearlyBudgetPercentage = (orgId, fromDataBudget, reserveBudgetFromData, orgFlagType) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        if (!orgFlagType) {
            hash['sgst_percentage'] = fromDataBudget.sgst_percentage
            hash['cgst_percentage'] = fromDataBudget.cgst_percentage
            hash['igst_percentage'] = fromDataBudget.igst_percentage
            hash['conversion_allowance_percentage'] = fromDataBudget.conversion_allowance_percentage
            hash['org_id'] = orgId
            hash["currency"] = fromDataBudget.currency.value
            dataSet.push(hash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveBudgetFromData, fromDataBudget)
            Object.keys(compareData).map((key) => {
                hash[key] = compareData[key]
                if (key == "currency") {
                    hash["currency"] = compareData.currency.value
                }
            })
            dataSet.push(hash);
            resolve(dataSet)
        }

    })
    return promise;
}*/
export const formatingFormDataYearlyBudgetPercentage = (orgId, fromDataBudget, reserveBudgetFromData, orgFlagType, gridObjData) => {
    console.log("gridObjData========", gridObjData)
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        if (!orgFlagType) {
            hash['sgst_percentage'] = fromDataBudget.sgst_percentage
            hash['cgst_percentage'] = fromDataBudget.cgst_percentage
            hash['igst_percentage'] = fromDataBudget.igst_percentage
            hash['conversion_allowance_percentage'] = fromDataBudget.conversion_allowance_percentage
            hash['org_id'] = orgId
            hash["currency"] = fromDataBudget.currency.value
            dataSet.push(hash);
            resolve(dataSet)
        } else {
            hash['sgst_percentage'] = fromDataBudget.sgst_percentage
            hash['cgst_percentage'] = fromDataBudget.cgst_percentage
            hash['igst_percentage'] = fromDataBudget.igst_percentage
            hash['conversion_allowance_percentage'] = fromDataBudget.conversion_allowance_percentage
            hash["currency"] = fromDataBudget.currency.value
            hash['org_id'] = gridObjData.data._id
            // let compareData = difference(reserveBudgetFromData, fromDataBudget)
            // Object.keys(compareData).map((key) => {
            //     hash[key] = compareData[key]
            //     if (key == "currency") {
            //         hash["currency"] = compareData.currency.value
            //     }
            // })
            dataSet.push(hash);
            console.log("dataSet=======", dataSet)
            resolve(dataSet)
        }

    })
    return promise;
}

export const formatingUserData = (addUserFromData, reserveUserFromData, userProfileImageChangeEditMode) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let tempHash = {};

        if (addUserFromData.user_id == "") {
            tempHash['name'] = addUserFromData.name != "" ? addUserFromData.name : "";
            tempHash['email'] = addUserFromData.email != "" ? addUserFromData.email : "";
            tempHash['type'] = "admin";
            tempHash['status'] = addUserFromData.status ? 1 : 0;
            if (Object.keys(addUserFromData.profileImage).length > 0) {
                tempHash['profile_img'] = addUserFromData.profileImage
            }


            dataSet.push(tempHash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveUserFromData, addUserFromData)
            Object.keys(compareData).map((key) => {
                tempHash[key] = compareData[key]
                tempHash['type'] = "admin";
            })
            if (userProfileImageChangeEditMode) {
                if (Object.keys(addUserFromData.profileImage).length > 0) {
                    tempHash['profile_img'] = addUserFromData.profileImage
                }
            }
            dataSet.push(tempHash);
            resolve(dataSet)
        }

    })
    return promise;
}

export const formatingInfoUserData = (addUserInfoFromData, reserveUserInfoFromData, orgFlagType) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let tempHash = {};
        if (!orgFlagType) {
            tempHash['phone_no'] = addUserInfoFromData.phone_no != "" ? addUserInfoFromData.phone_no : "";
            tempHash['city'] = addUserInfoFromData.city != "" ? addUserInfoFromData.city.toString() : "";
            tempHash['country'] = addUserInfoFromData.country.value
            tempHash['address_line1'] = addUserInfoFromData.address_line1 != "" ? addUserInfoFromData.address_line1.toString() : "";
            tempHash['address_line2'] = addUserInfoFromData.address_line2 != "" ? addUserInfoFromData.address_line2.toString() : "";
            tempHash['state'] = addUserInfoFromData.state != "" ? addUserInfoFromData.state.toString() : "";
            tempHash['zip_code'] = addUserInfoFromData.zip_code != "" ? addUserInfoFromData.zip_code.toString() : "";
            tempHash['type'] = 'admin';
            dataSet.push(tempHash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveUserInfoFromData, addUserInfoFromData)
            Object.keys(compareData).map((key) => {
                tempHash[key] = compareData[key]
                if (key == "country") {
                    tempHash["country"] = compareData.country.value
                }
            })
            tempHash['type'] = 'admin';
            dataSet.push(tempHash);
            resolve(dataSet)
        }
    })
    return promise;
}

const difference = (origObj, newObj) => {
    let changes = (newObj, origObj) => {
        let arrayIndexCounter = 0
        return lodash.transform(newObj, (result, value, key) => {
            if (!lodash.isEqual(value, origObj[key])) {
                let resultKey = lodash.isArray(origObj) ? arrayIndexCounter++ : key
                result[resultKey] = (lodash.isObject(value) && lodash.isObject(origObj[key])) ? changes(value, origObj[key]) : value
            }
        })
    }
    return changes(newObj, origObj)
}