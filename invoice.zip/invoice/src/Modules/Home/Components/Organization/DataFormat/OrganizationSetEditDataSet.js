import CountryWithCode from '../../../../../Utility/JsFolder/CountryWithCode';
export const setEditData = (gridObjData) => {
    //console.log("gridObjData.data.email==========",gridObjData)
    let promise = new Promise((resolve, reject) => {
        let data = {}
        data["name"] = gridObjData.data.name
        data["email"] = gridObjData.data.org_email
        data["ph_no"] = gridObjData.data.ph_no
        data["profileImage"] = ""
        data["org_id"] = gridObjData.data._id
        //data["gst_number"] = gridObjData.data.gst_number
        data["pan_number"] = gridObjData.data.pan_number
        data["gstn"] = gridObjData.data.gst_number
        /* data["account_no"] = gridObjData.data.account_no
         data["bank_name"] = gridObjData.data.bank_name
         data["bank_address"] = gridObjData.data.bank_address
         let findBankCountry = CountryWithCode.filter(res => {
             return res.iso == gridObjData.data.bank_country;
         });
         if (findBankCountry.length > 0) {
             data["bank_country"] = { label: findBankCountry[0].country, value: findBankCountry[0].iso }
         }
         data["ifsc_code"] = gridObjData.data.ifsc_code*/
         let bankArry =[];
        let bankErrorArry =[];
        if(gridObjData.data?.bank_details && gridObjData.data.bank_details.length>0){
            gridObjData.data.bank_details.map((v,i)=>{

                let findBankCountry = CountryWithCode.filter(Bres => {
                    return Bres.country == v.bank_country;
                });

                let bankCountry ={}
                if (findBankCountry.length > 0) {
                    bankCountry = { label: findBankCountry[0].country, value: findBankCountry[0].country }
                }

                let bankhash = {
                    "account_no": v.account_no,
                    "bank_name": v.bank_name,
                    "bank_address": v.bank_address,
                    "bank_country": bankCountry,
                    "ifsc_code": v.ifsc_code,
                }
                let errorhash = {
                    "account_no": "",
                    "bank_name": "",
                    "bank_address": "",
                    "bank_country": "",
                    "ifsc_code": "",
                }

                bankArry.push(bankhash)
                bankErrorArry.push(errorhash)
            })
        }

        data["bankDetails"] =bankArry
        data["bankDetailsError"] = bankErrorArry

        data["address_line1"] = gridObjData.data.address_line1
        data["address_line2"] = gridObjData.data.address_line2
        data["city"] = gridObjData.data.city
        data["state"] = gridObjData.data.state
        let findCountry = CountryWithCode.filter(res => {
            return res.country == gridObjData.data.country;
        });
        if (findCountry.length > 0) {
            data["country"] = { label: findCountry[0].country, value: findCountry[0].country }
        }
        data["zip_code"] = gridObjData.data.zip_code
        resolve(data);
    })
    return promise;
};

export const setEditBudgetData = (gridObjData) => {
    let promise = new Promise((resolve, reject) => {
        let data = {}
        data["sgst_percentage"] = gridObjData?.data?.budgetPercentage[0]?.sgst_percentage
        data["cgst_percentage"] = gridObjData?.data?.budgetPercentage[0]?.cgst_percentage
        data["igst_percentage"] = gridObjData?.data?.budgetPercentage[0]?.igst_percentage
        data["conversion_allowance_percentage"] = gridObjData?.data?.budgetPercentage[0]?.conversion_allowance_percentage
        data["currency"] = { label: gridObjData?.data?.budgetPercentage[0]?.currency, value: gridObjData?.data?.budgetPercentage[0]?.currency }
        resolve(data);
    })
    return promise;
};

export const setUserEditData = (gridObjData) => {
    console.log("gridObjData.data.user_email==========", gridObjData.data.user_email)
    let promise = new Promise((resolve, reject) => {
        let data = {}
        if (gridObjData.data.admins.length > 0) {
            console.log("gridObjData.data.admins", gridObjData.data.admins[0].status)
            data["name"] = gridObjData.data.admins[0].user_name,
                data["email"] = gridObjData.data.admins[0].user_email,
                data["profileImage"] = "",
                data["status"] = gridObjData.data.admins[0].status ? 1 : 0,
                data["user_id"] = gridObjData.data.admins[0].id
        }
        console.log("data========", data)
        resolve(data);
    })
    return promise;
}

export const setUserInfoEditData = (gridObjData) => {
    let promise = new Promise((resolve, reject) => {
        let data = {}
        if (gridObjData.data.admins.length > 0) {
            data["city"] = gridObjData?.data?.admins[0]?.userinfo?.city
            let findUserCountry = CountryWithCode.filter(res => {
                return res.country == gridObjData?.data?.admins[0]?.userinfo?.country;
            });
            if (findUserCountry.length > 0) {
                data["country"] = { label: findUserCountry[0].country, value: findUserCountry[0].country }
            }

            data["phone_no"] = gridObjData?.data?.admins[0]?.userinfo?.phone_no
            data["address_line1"] = gridObjData?.data?.admins[0]?.userinfo?.address_line1
            data["address_line2"] = gridObjData?.data?.admins[0]?.userinfo?.address_line2
            data["state"] = gridObjData?.data?.admins[0]?.userinfo?.state
            data["zip_code"] = gridObjData?.data?.admins[0]?.userinfo?.zip_code
        }
        resolve(data);
    })
    return promise;
}

