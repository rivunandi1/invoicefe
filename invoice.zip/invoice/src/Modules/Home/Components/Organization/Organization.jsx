import React, { Component } from 'react';
import OrganizationModalContent from './Components/OrganizationModalContent'
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import * as OrganizationController from './Controller/OrganizationController';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import ConfirmationAlert from '../../../../Utility/Components/ConfirmationAlert';
import { loaderStateTrue, loaderStateFalse } from '../../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../../Login/Actions/LoginAction';
import CustomInput from '../../../../Utility/Components/CustomInput';
import Utility from '../../../../Utility/Utility';
import ModalGlobal from '../../../../Utility/Components/ModalGlobal'
import HomeUtility from '../../Utility/Utility'
import moment from 'moment';
import Config from '../../../../Utility/Config';
import PopoverStickOnHover from '../../../../Utility/Components/PopoverStickOnHover';
import GridActionContent from '../../../../Utility/Components/GridActionContent'
import BootstrapSwitchButton from 'bootstrap-switch-button-react';
import AddUserModalContent from './Components/AddUserModalContent'
import { has } from 'lodash';
const lodash = require('lodash')
import { formatingFormData, formatingFormDataYearlyBudgetPercentage, formatingUserData, formatingInfoUserData } from './DataFormat/OrganizationDataFormat'
import { setEditBudgetData, setEditData, setUserEditData, setUserInfoEditData } from './DataFormat/OrganizationSetEditDataSet'
import Currency from '../../../../Utility/JsFolder/Currency';
import CountryWithCode from '../../../../Utility/JsFolder/CountryWithCode';

class Organization extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modules: [InfiniteRowModelModule],
            tooltipShowDelay: 0,
            columnDefs: [
                {
                    headerName: "",
                    field: "profile_img_temp",
                    maxWidth: 72,
                    cellRendererFramework: (params) => {
                        if (params && params.data) {
                            if (params.data.profile_img_temp) {
                                return <div className="gridusericon">
                                    <PopoverStickOnHover
                                        //data={params.data}
                                        data={this.popoverStickDatasetFormatUser(params.data)}
                                        placement="right"
                                    />
                                </div>
                            } else {
                                return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
                            }

                        } else {
                            return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
                        }
                    }
                },
                {
                    headerName: `${this.props.t('organizationName')}`,
                    field: "first_name",
                    minWidth: 150,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params && params.data) {
                            return <div>{params.data.name}</div>

                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('Name')}`,
                    field: "admins",
                    minWidth: 150,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        //console.log("params.data", params.data)
                        if (params.data) {
                            if (params.data.admins.length > 0) {
                                return <div>{params.data.admins[0].user_name}</div>
                            } else {
                                return null
                            }
                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('Email')}`,
                    field: "admins",
                    minWidth: 250,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params && params.data && params.data.admins.length > 0) {
                            return <div>{params.data.admins[0].user_email}</div>

                        } else {
                            return null;
                        }
                    },
                },

                {
                    headerName: `${this.props.t('city')}`,
                    field: "city",
                    minWidth: 110,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.admins.length > 0 && params.data.admins[0].hasOwnProperty('userinfo')) {
                                return <div>{params.data.admins[0].userinfo.city}</div>
                            } else {
                                return null
                            }
                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('country')}`,
                    field: "country",
                    minWidth: 110,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.admins.length > 0 && params.data.admins[0].hasOwnProperty('userinfo')) {
                                return <div>{params.data.admins[0].userinfo.country}</div>
                            } else {
                                return null
                            }
                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('phonenumber')}`,
                    field: "phone_no",
                    minWidth: 120,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.admins.length > 0 && params.data.admins[0].hasOwnProperty('userinfo')) {
                                return <div>{params.data.admins[0].userinfo.phone_no}</div>
                            } else {
                                return null
                            }
                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: "",
                    field: "active",
                    minWidth: 80,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params) {
                            if (params.data) {
                                return <button className="edittext">
                                    <div className="switch_btn_customize">
                                        <BootstrapSwitchButton checked={params.data && params.data.active ? params.data.active : false} onChange={this.handleChangeSwitchButton.bind(this, params.data)} />
                                        {/*<BootstrapSwitchButton />*/}
                                    </div>
                                </button>
                            } else {
                                return null
                            }
                        } else {
                            return null
                        }
                    },
                },
                {
                    headerName: "",
                    field: "edit",
                    maxWidth: 90,
                    cellRendererFramework: (params) => {

                        if (params.data) {
                            //console.log("load grid==", params.data)
                            return <div className="actionablePopup">
                                <button className="ellipsisIcon" onClick={this.actionModalfunction.bind(this, params)}><i className="fa fa-ellipsis-v"></i></button>
                            </div>
                        } else {
                            return null;
                        }
                    },
                }
            ],
            defaultColDef: {
                flex: 1,
                //resizable: true,
                minWidth: 90

            },
            components: {
                loadingRenderer: (params) => {
                    //console.log("params=================== worker", params)
                    //return null;
                    if (params.value !== undefined) {
                        return params.value;
                    } else {
                        return '<img src="https://www.ag-grid.com/example-assets/loading.gif">';
                    }
                },
            },



            //Organization Tab State
            organizationModal: false,

            //Org img add
            addProfileImagePreviewShow: false,
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImageError: "",

            // User Image Add
            addUserImagePreviewShow: false,
            addUserImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addUserImageError: "",

            //IMage crop
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 1 / 1
            },
            croppedImageUrl: "",

            imageCropModalFlag: false,
            bankDetails: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],

            bankDetailsError: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],

            fromData: {
                "name": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "org_id": "",
                //"gst_number": "",
                "pan_number": "",
                "gstn": "",
                // "account_no": "",
                // "bank_name": "",
                // "bank_address": "",
                // "bank_country": "",
                // "ifsc_code": "",
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
            },
            fromDataBudget: {
                "sgst_percentage": "",
                "cgst_percentage": "",
                "igst_percentage": "",
                "conversion_allowance_percentage": "",
                "currency": ""
            },

            fromDataError: {
                "name": "",
                // "account_no": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "org_id": "",
                //"gst_number": "",
                "pan_number": "",
                "gstn": "",
                // "bank_name": "",
                // "bank_address": "",
                // "bank_country": "",
                // "ifsc_code": "",
                "address_line1": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
            },
            fromDataBudgetError: {
                "sgst_percentage": "",
                "cgst_percentage": "",
                "igst_percentage": "",
                "conversion_allowance_percentage": "",
                "currency": ""
            },
            statusList: [{ label: "Active", value: "Active" }, { label: "Inactive", value: "Inactive" }],
            actionModalflag: false,
            deleteConfirmationAlertModal: false,
            gridObjData: "",
            addUserModalFlag: false,

            //Add User From Data
            addUserFromData: {
                "name": "",
                "email": "",
                "profileImage": "",
                "status": true,
                "user_id": "",
            },

            addUserFromDataError: {
                "name": "",
                "email": ""
            },
            addUserInfoFromData: {
                "city": "",
                "country": "",
                "phone_no": "",
                "address_line1": "",
                "address_line2": "",
                "state": "",
                "zip_code": "",
            },
            addUserInfoFromDataError: {
                //"city": "",
                //"country": "",
                "phone_no": "",
            },

            orgHandleChangeDataFlag: false,
            userHandleChangeDataFlag: false,
            userInfoHandleChangeDataFlag: false,
            orgFlagType: false,
            imageEditFrom: "",
            deleteButtonEnableFlagForGridActionContent: false,

            deleteUserConfirmationAlertModal: false,
            userDeleteBodySecondContent: "",
            userDeleteObj: "",
            orgAddEditModalTitle: "",
            orgName: "",
            saveButtonDisableEditModal: true,
            reserveFromData: "",
            reserveBudgetFromData: "",
            orgProfileImageChangeEditMode: false,
            reserveUserFromData: "",
            reserveUserInfoFromData: "",
            userProfileImageChangeEditMode: false,
            currencyList: [],
            countryList: [],
            disabledEmail: false,
            deleteBankDetailsConfirmationAlertModalFlag: false,
            deleteBankDetailsObj: ""

        }
        this.codeOutsideClickRef = React.createRef();

    }

    handleChangeSwitchButton = (data) => {

        let dataHash = {};
        let id = data._id
        dataHash["active"] = data.active ? 0 : 1;
        loaderStateTrue()
        OrganizationController.orgUpdate(id, dataHash).then((response) => {
            //console.log("response=============>>", response)
            loaderStateFalse()
            if (response) {
                if (response.success) {
                    this.resetDataGrid()
                    Utility.toastNotifications(response.message, "Success", "success");
                } else {
                    Utility.toastNotifications(response.message, "Error", "error");
                }
            }
        }).catch((error) => {
            loaderStateFalse();
        });

    }


    onGridReady = (params) => {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridparams = params;
        var datasource = this.serverSideDataSource()
        params.api.setDatasource(datasource);
    };

    serverSideDataSource = () => {
        const { activeInActiveWorkerFilter, orgName } = this.state;
        let that = this
        return {
            getRows(params) {
                //console.log(JSON.stringify(params, null, 1));
                const { startRow, endRow, filterModel, sortModel } = params
                const { loaderStateTrue, loaderStateFalse } = that.props;
                loaderStateTrue();
                let filters = {};
                let globalQueryParamshash = {};
                if (orgName != "") {
                    globalQueryParamshash['name'] = orgName
                    filters['filter_op'] = { "name": "substring" }
                }

                globalQueryParamshash['active'] = activeInActiveWorkerFilter

                globalQueryParamshash["offset"] = startRow;
                globalQueryParamshash["limit"] = endRow;

                filters['filters'] = globalQueryParamshash
                OrganizationController.orgListing(filters).then((response) => {
                    //console.log("response.data==========>", response.data)
                    if (response.success) {
                        let promiseArr = []
                        response.data.map((item, index) => {
                            let promise = new Promise((resolve, reject) => {
                                that.logoImageUi(item._id).then((data) => {
                                    // tempUserProfileDetailsHash[item.id.toString()] = data
                                    item["profile_img_temp"] = data
                                    if (item.admins.length > 0) {
                                        item.admins.map((innerItem, index) => {
                                            let innerPromise = new Promise((resolve, reject) => {
                                                that.profileImageUi(innerItem.id).then((data) => {
                                                    innerItem["user_profile_img_temp"] = data
                                                    resolve(item)
                                                })
                                            })
                                            promiseArr.push(innerPromise)
                                        })
                                    }
                                    resolve(item)
                                })

                            })
                            promiseArr.push(promise)
                        })

                        Promise.all(promiseArr).then((values) => {
                            params.successCallback(values, response.total);
                        });
                        //params.successCallback(response.data, 499);
                        //that.setImageDataTemp(response.data)

                    } else {
                        console.error(error);
                        params.failCallback();
                        Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
                    }
                    loaderStateFalse();
                }).catch((error) => {
                    //console.error("************error*************", error)
                    if (error) {
                        //Utility.toastNotifications(error.message, "Error", "error");
                    }
                    loaderStateFalse();
                    if (error.message == "Network Error") {
                        // Utility.toastNotifications("Please login", "Error", "error");
                        // this.props.logOutApp().then(
                        //     () => this.props.history.push("/")
                        // );
                    }
                });
            }
        };
    }


    resetDataGrid = () => {
        this.gridparams.api.purgeServerSideCache(null)
        var datasource = this.serverSideDataSource()
        this.gridparams.api.setDatasource(datasource);

    }


    componentDidMount = () => {
        document.body.addEventListener('mousedown', this.handleClickOutside.bind(this));
        this.modefyCurrency();
        this.countryModefy();
    }
    componentWillUnmount() {
        document.body.removeEventListener('mousedown', this.handleClickOutside.bind(this));
    }
    handleClickOutside(event) {
        if (this.codeOutsideClickRef.current != null) {
            if (this.codeOutsideClickRef && this.codeOutsideClickRef.current && !this.codeOutsideClickRef.current.contains(event.target)) {

                this.setState({
                    actionModalflag: false,
                })
            }
        }

    }

    modefyCurrency = () => {

        const arrWithLabelValue = Currency.map(object => {
            return { ...object, "value": object.currencyCode, "label": `${object.currencyCode}(${object.countryCode})` };
        });
        //console.log("arrWithLabelValue====", arrWithLabelValue)
        this.setState({
            currencyList: arrWithLabelValue
        })

    }

    countryModefy = () => {
        const countryData = CountryWithCode.map(object => {
            return { ...object, "value": object.country, "label": object.country };
        });
        //console.log("countryData====", countryData)
        this.setState({
            countryList: countryData
        })
    }

    logoImageUi = (id) => {
        const promise = new Promise((resolve, reject) => {
            const { loaderStateTrue, loaderStateFalse } = this.props;
            loaderStateTrue();
            let data = {};
            data["filters"] = JSON.stringify(Config.thumbnailSize)
            OrganizationController.orgDetails(id, data).then((response) => {
                //console.log("logoImageUi===",response)
                if (response.success) {
                    //console.log("response.data[0]========", response.data[0].user_details)
                    let responseUserDetails = response.data[0].logo_img
                    if (responseUserDetails && Object.keys(responseUserDetails).length > 0) {
                        resolve(responseUserDetails.file_obj)
                    } else {
                        resolve(require('../../../../Utility/Public/images/usericon.png'))
                    }
                }
                loaderStateFalse();
            }).catch((error) => {
                //console.error("************error*************", error)
                if (error) {
                    //Utility.toastNotifications(error.message, "Error", "error");
                }
                loaderStateFalse();
                if (error.message == "Network Error") {
                    /*Utility.toastNotifications("Please login", "Error", "error");
                    this.props.logOutApp().then(
                        () => this.props.history.push("/")
                    );*/
                }
            });
        })
        return promise;
    }

    profileImageUi = (id) => {
        const promise = new Promise((resolve, reject) => {
            const { loaderStateTrue, loaderStateFalse } = this.props;
            loaderStateTrue();
            let data = {};
            data["filters"] = JSON.stringify(Config.thumbnailSize)
            OrganizationController.userDetails(id, data).then((response) => {
                if (response.success) {
                    let responseUserDetails = response.data[0].profile_img
                    if (responseUserDetails && Object.keys(responseUserDetails).length > 0) {
                        resolve(responseUserDetails.file_obj)
                    } else {
                        resolve(require('../../../../Utility/Public/images/usericon.png'))
                    }
                }
                loaderStateFalse();
            }).catch((error) => {
                //console.error("************error*************", error)
                if (error) {
                    //Utility.toastNotifications(error.message, "Error", "error");
                }
                loaderStateFalse();
                if (error.message == "Network Error") {
                    /*Utility.toastNotifications("Please login", "Error", "error");
                    this.props.logOutApp().then(
                        () => this.props.history.push("/")
                    );*/
                }
            });
        })
        return promise;
    }


    closeOrganizationModal = () => {
        const { t } = this.props
        this.setState({
            organizationModal: false,
            orgFlagType: false
        }, () => {
            this.resetOrganizationFrom();
        })


    }

    //Image url crop 
    addInputProfileImageChanged = (event) => {

        let { fromData } = this.state;
        let targetFileSplit = event.target.files[0].name.split('.');
        let lastElement = targetFileSplit.pop();
        let user_profile_image = {
            "file_name": "",
            "file_obj": ""
        };
        if (lastElement == 'JPEG' || lastElement == 'jpeg' || lastElement == 'jpg' || lastElement == 'JPG' || lastElement == 'png' || lastElement == 'PNG' || lastElement == '') {
            const fsize = event.target.files[0].size;
            const file = Math.round((fsize / 1024));
            if (file >= 300) {
                Utility.toastNotifications(this.props.t('imageUploadAlert'), "Warning", "warning");
            } else {
                this.setState({
                    imageCropModalFlag: true
                })
                if (event.target.files && event.target.files.length > 0) {
                    const reader = new FileReader();
                    reader.addEventListener('load', () =>
                        this.setState({ src: reader.result })
                    );
                    reader.readAsDataURL(event.target.files[0]);
                    user_profile_image["file_name"] = event.target.files[0].name
                    user_profile_image["file_obj"] = ""
                    fromData["profileImage"] = user_profile_image
                    this.setState({
                        fromData,
                        addProfileImagePreviewShow: true,
                        addProfileImageError: "",
                        orgHandleChangeDataFlag: true,
                        imageEditFrom: "org",
                    })
                }
            }

        } else {
            fromData["profileImage"] = ""
            this.setState({
                fromData,
                addProfileImagePreviewShow: false,
                addprofileImageSelected: 'Add Image',
                orgHandleChangeDataFlag: true,
            })
        }
    }

    onImageLoaded = (image) => {
        //console.log("onImageLoaded=====", image)
        this.imageRef = image;
    };

    onCropChange = (crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.setState({ crop });
    };

    onCropComplete = (crop) => {
        this.makeClientCrop(crop, 'forOrgImage');
        this.setState({
            saveButtonDisableEditModal: false,
            orgProfileImageChangeEditMode: true
        })
    };

    onCropCompleteForUser = (crop) => {
        this.makeClientCrop(crop, 'forUserImage');
        this.setState({
            saveButtonDisableEditModal: false,
            userProfileImageChangeEditMode: true
        })
    };

    async makeClientCrop(crop, callFrom) {
        const { fromData, addUserFromData } = this.state;
        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                'newFile.jpeg'
            );
            let org_image = {}
            let add_user_image = {}
            if (callFrom == 'forOrgImage') {
                this.setState({
                    addprofileImageSelected: croppedImageUrl,
                })
                // for org image
                org_image["file_name"] = this.state.fromData.profileImage.file_name
                org_image["file_obj"] = this.state.addprofileImageSelected
                fromData["profileImage"] = org_image
            } else {
                this.setState({
                    addUserImageSelected: croppedImageUrl
                })
                // for user image
                add_user_image["file_name"] = this.state.addUserFromData.profileImage.file_name
                add_user_image["file_obj"] = this.state.addUserImageSelected
                addUserFromData["profileImage"] = add_user_image
            }
            this.setState({
                fromData,
                addUserFromData
            })


        }
    }



    getCroppedImg = (image, crop, fileName) => {
        const canvas = document.createElement('canvas');
        const pixelRatio = window.devicePixelRatio;
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext('2d');

        canvas.width = crop.width * pixelRatio * scaleX;
        canvas.height = crop.height * pixelRatio * scaleY;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width * scaleX,
            crop.height * scaleY
        );

        const base64Image = canvas.toDataURL('image/jpeg');
        return base64Image

    }




    //Image url crop

    imageCropModalShow = () => {
        this.setState({
            imageCropModalFlag: true
        })
    }

    imageCropModalHide = () => {
        const { fromData, addUserFromData } = this.state;
        fromData["profileImage"] = ""
        addUserFromData["profileImage"] = ""
        this.setState({
            imageCropModalFlag: false,

            // for org image
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImageError: "",
            fromData,
            addProfileImagePreviewShow: false,

            // for user image
            addUserImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addUserImageError: "",
            addUserFromData,
            addUserImagePreviewShow: false,
            saveButtonDisableEditModal: true
        })
    }

    imageCropDataSave = () => {
        this.setState({
            imageCropModalFlag: false
        })
    }

    handleUserSearchBar = (e) => {
        this.setState({
            orgName: e.target.value
        }, () => {
            if (this.state.orgName.length > 2) {
                this.resetDataGrid()
            }
            if (this.state.orgName == "") {
                this.resetDataGrid()
            }
        })

    }

    clearSearchValue = () => {
        this.setState({
            orgName: ""
        }, () => {
            this.resetDataGrid()
        })
    }

    organizationModalfunction = () => {
        this.setState({
            organizationModal: true,
            orgAddEditModalTitle: this.props.t('addOrganization'),
            disabledEmail: false
        }, () => {
            //console.log("organizationModal add", this.state.organizationModal)
        })
        //alert()
    }

    handelChange = (event, type) => {

        let fromDataTemp = Object.assign({}, this.state.fromData);
        let fromDataTempError = Object.assign({}, this.state.fromDataError);
        let fromDataBudgetTemp = Object.assign({}, this.state.fromDataBudget);
        let fromDataBudgetTempError = Object.assign({}, this.state.fromDataBudgetError);

        if (type == "name") {
            if (event.target.value != "") {
                fromDataTemp['name'] = event.target.value;
                fromDataTempError['name'] = ""
            } else {
                fromDataTemp['name'] = "";
                fromDataTempError['name'] = this.props.t('requiredField')
            }
        }
        if (type == "email") {
            if (event.target.value != "") {
                fromDataTemp['email'] = event.target.value;
                fromDataTempError['email'] = ""
            } else {
                fromDataTemp['email'] = "";
                fromDataTempError['email'] = this.props.t('requiredField')
            }
        }
        if (type == "ph_no") {
            if (event.target.value == "") {
                fromDataTemp['ph_no'] = event.target.value;
                fromDataTempError['ph_no'] = this.props.t('requiredField')
            } else {
                let phoneValidate = HomeUtility.validate_Phone_Number(event.target.value);
                if (phoneValidate) {
                    fromDataTemp['ph_no'] = event.target.value;
                    fromDataTempError['ph_no'] = ""

                } else {
                    fromDataTemp['ph_no'] = event.target.value;
                    fromDataTempError['ph_no'] = this.props.t('validphonenumber')
                }
            }
        }
        // if (type == "gst_number") {
        //     if (event.target.value == "") {
        //         fromDataTemp['gst_number'] = event.target.value;
        //         fromDataTempError['gst_number'] = this.props.t('requiredField')
        //     } else {
        //         let phoneValidate = HomeUtility.validate_gst_Number(event.target.value);
        //         if (phoneValidate) {
        //             fromDataTemp['gst_number'] = event.target.value;
        //             fromDataTempError['gst_number'] = ""

        //         } else {
        //             fromDataTemp['gst_number'] = event.target.value;
        //             fromDataTempError['gst_number'] = this.props.t('validgstnumber')
        //         }
        //     }
        // }
        if (type == "pan_number") {
            if (event.target.value == "") {
                fromDataTemp['pan_number'] = event.target.value;
                fromDataTempError['pan_number'] = this.props.t('requiredField')
            } else {
                let phoneValidate = HomeUtility.validate_pan_Number(event.target.value);
                if (phoneValidate) {
                    fromDataTemp['pan_number'] = event.target.value;
                    fromDataTempError['pan_number'] = ""

                } else {
                    fromDataTemp['pan_number'] = event.target.value;
                    fromDataTempError['pan_number'] = this.props.t('validpannumber')
                }
            }
        }
        if (type == "gstn") {
            if (event.target.value == "") {
                fromDataTemp['gstn'] = event.target.value;
                fromDataTempError['gstn'] = this.props.t('requiredField')
            } else {
                let phoneValidate = HomeUtility.validate_gst_Number(event.target.value);
                if (phoneValidate) {
                    fromDataTemp['gstn'] = event.target.value;
                    fromDataTempError['gstn'] = ""

                } else {
                    fromDataTemp['gstn'] = event.target.value;
                    fromDataTempError['gstn'] = this.props.t('validgstinnumber')
                }
            }
        }
        /*if (type == "account_no") {
            if (!isNaN(event.target.value)) {
                fromDataTemp['account_no'] = event.target.value;
                fromDataTempError['account_no'] = ""
            } else {
                fromDataTemp['account_no'] = "";
                //fromDataTempError['account_no'] = ""
                Utility.toastNotifications(this.props.t('please_enter_integer_number'), "Warning", "warning")
            }
        }
        if (type == "bank_name") {
            if (event.target.value != "") {
                fromDataTemp['bank_name'] = event.target.value;
                fromDataTempError['bank_name'] = ""
            } else {
                fromDataTemp['bank_name'] = "";
                fromDataTempError['bank_name'] = ""
            }
        }
        if (type == "bank_address") {
            if (event.target.value != "") {
                fromDataTemp['bank_address'] = event.target.value;
                fromDataTempError['bank_address'] = ""
            } else {
                fromDataTemp['bank_address'] = "";
                fromDataTempError['bank_address'] = ""
            }
        }
        if (type == "bank_country") {
            if (event != "") {
                fromDataTemp['bank_country'] = event;
                fromDataTempError['bank_country'] = ""
            } else {
                fromDataTemp['bank_country'] = "";
                fromDataTempError['bank_country'] = this.props.t('requiredField')
            }
        }
        if (type == "ifsc_code") {
            if (event.target.value != "") {
                if (event.target.value.length == 11) {
                    fromDataTempError['ifsc_code'] = ""
                } else {
                    fromDataTemp['ifsc_code'] = "";
                    fromDataTempError['ifsc_code'] = "IFSC code must be 11 digit"
                }
                fromDataTemp['ifsc_code'] = event.target.value;
            } else {
                fromDataTemp['ifsc_code'] = "";
                fromDataTempError['ifsc_code'] = ""
            }
        }*/
        if (type == "address_line1") {
            if (event.target.value != "") {
                fromDataTemp['address_line1'] = event.target.value;
                fromDataTempError['address_line1'] = ""
            } else {
                fromDataTemp['address_line1'] = "";
                fromDataTempError['address_line1'] = ""
            }
        }
        if (type == "address_line2") {
            if (event.target.value != "") {
                fromDataTemp['address_line2'] = event.target.value;
                fromDataTempError['address_line2'] = ""
            } else {
                fromDataTemp['address_line2'] = "";
                fromDataTempError['address_line2'] = ""
            }
        }
        if (type == "city") {
            if (event.target.value != "") {
                fromDataTemp['city'] = event.target.value;
                fromDataTempError['city'] = ""
            } else {
                fromDataTemp['city'] = "";
                fromDataTempError['city'] = ""
            }
        }
        if (type == "state") {
            if (event.target.value != "") {
                fromDataTemp['state'] = event.target.value;
                fromDataTempError['state'] = ""
            } else {
                fromDataTemp['state'] = "";
                fromDataTempError['state'] = ""
            }
        }
        if (type == "country") {
            if (event != "") {
                fromDataTemp['country'] = event;
                fromDataTempError['country'] = ""
            } else {
                fromDataTemp['country'] = "";
                fromDataTempError['country'] = this.props.t('requiredField')
            }
        }
        if (type == "zip_code") {
            if (!isNaN(event.target.value) && event.target.value != "") {
                fromDataTemp['zip_code'] = event.target.value;
                fromDataTempError['zip_code'] = ""
            } else {
                fromDataTemp['zip_code'] = "";
                fromDataTempError['zip_code'] = ""
            }
        }
        if (type == "sgst_percentage") {
            if (!isNaN(event.target.value)) {
                if (event.target.value >= 1 && event.target.value <= 100) {
                    fromDataBudgetTemp['sgst_percentage'] = event.target.value;
                    fromDataBudgetTempError['sgst_percentage'] = ""
                } else {
                    fromDataBudgetTemp['sgst_percentage'] = "";
                    Utility.toastNotifications(this.props.t('maximum_input'), "Warning", "warning")
                }
            }
        }
        if (type == "cgst_percentage") {
            if (!isNaN(event.target.value)) {
                if (event.target.value >= 1 && event.target.value <= 100) {
                    fromDataBudgetTemp['cgst_percentage'] = event.target.value;
                    fromDataBudgetTempError['cgst_percentage'] = ""
                } else {
                    fromDataBudgetTemp['cgst_percentage'] = "";
                    Utility.toastNotifications(this.props.t('maximum_input'), "Warning", "warning")
                }
            }
        }
        if (type == "igst_percentage") {
            if (!isNaN(event.target.value)) {
                if (event.target.value >= 1 && event.target.value <= 100) {
                    fromDataBudgetTemp['igst_percentage'] = event.target.value;
                    fromDataBudgetTempError['igst_percentage'] = ""
                } else {
                    fromDataBudgetTemp['igst_percentage'] = "";
                    Utility.toastNotifications(this.props.t('maximum_input'), "Warning", "warning")
                }
            }
        }
        if (type == "conversion_allowance_percentage") {

            /*if (!isNaN(event.target.value)) {
                if (event.target.value >= 1 && event.target.value <= 100) {
                    fromDataBudgetTemp['conversion_allowance_percentage'] = event.target.value;
                    fromDataBudgetTempError['conversion_allowance_percentage'] = ""
                } else {
                    fromDataBudgetTemp['conversion_allowance_percentage'] = "";
                    Utility.toastNotifications(this.props.t('maximum_input'), "Warning", "warning")
                }
            }*/


            if (type == 'conversion_allowance_percentage') {
                if (!isNaN(event.target.value)) {
                  if (!isNaN(event.target.value) == "") {
                    fromDataBudgetTemp['conversion_allowance_percentage'] = "";
                  } else {
                    fromDataBudgetTemp['conversion_allowance_percentage'] = event.target.value;
                    fromDataBudgetTempError['conversion_allowance_percentage'] = ""
                  }
                }
              }

           


        }
        if (type == "currency") {
            if (event != "") {
                fromDataBudgetTemp['currency'] = event;
                fromDataBudgetTempError['currency'] = ""
            } else {
                fromDataBudgetTemp['currency'] = "";
                fromDataBudgetTempError['currency'] = ""
            }
        }

        this.setState({
            fromData: fromDataTemp,
            fromDataBudget: fromDataBudgetTemp,
            fromDataError: fromDataTempError,
            fromDataBudgetError: fromDataBudgetTempError,
            orgHandleChangeDataFlag: true,
            saveButtonDisableEditModal: false
        }, () => {
            //console.log("handle fromData", this.state.fromData)
            //console.log("handle fromDataBudget", this.state.fromDataBudget)
        })


    }

    /*isValid = (value, evnt) => {
        var charC = (evnt.which) ? evnt.which : evnt.keyCode;
        if (charC == 46) {
            if (value.indexOf('.') === -1) {
                return true;
            } else {
                return false;
            }
        } else {
            if (charC > 31 && (charC < 48 || charC > 57))
                return false;
        }
        return true;
    }*/



    handelChangeForBankDetails = (event, type, i) => {



        let fromDataTemp = this.state.bankDetails.slice();
        let fromDataTempError = this.state.bankDetailsError.slice();
        // let fromDataBudgetTemp = Object.assign({}, this.state.fromDataBudget);
        // let fromDataBudgetTempError = Object.assign({}, this.state.fromDataBudgetError);

        if (type == "account_no") {
            if (!isNaN(event.target.value)) {
                fromDataTemp[i]['account_no'] = event.target.value;
                fromDataTempError[i]['account_no'] = ""
            } else {
                //fromDataTemp[i]['account_no'] = "";
                //fromDataTempError['account_no'] = ""
                Utility.toastNotifications(this.props.t('please_enter_integer_number'), "Warning", "warning")
            }
        }
        if (type == "bank_name") {
            if (event.target.value != "") {
                fromDataTemp[i]['bank_name'] = event.target.value;
                fromDataTempError[i]['bank_name'] = ""
            } else {
                fromDataTemp[i]['bank_name'] = "";
                fromDataTempError[i]['bank_name'] = ""
            }
        }
        if (type == "bank_address") {
            if (event.target.value != "") {
                fromDataTemp[i]['bank_address'] = event.target.value;
                fromDataTempError[i]['bank_address'] = ""
            } else {
                fromDataTemp[i]['bank_address'] = "";
                fromDataTempError[i]['bank_address'] = ""
            }
        }
        if (type == "bank_country") {
            if (event != "") {
                fromDataTemp[i]['bank_country'] = event;
                fromDataTempError[i]['bank_country'] = ""
            } else {
                fromDataTemp[i]['bank_country'] = "";
                fromDataTempError[i]['bank_country'] = this.props.t('requiredField')
            }
        }
        if (type == "ifsc_code") {
            if (event.target.value != "") {
                if (event.target.value.length == 11) {
                    fromDataTempError[i]['ifsc_code'] = ""
                } else {
                    fromDataTemp[i]['ifsc_code'] = "";
                    fromDataTempError[i]['ifsc_code'] = "* IFSC code must be 11 digit"
                }
                fromDataTemp[i]['ifsc_code'] = event.target.value;
            } else {
                fromDataTemp[i]['ifsc_code'] = "";
                fromDataTempError[i]['ifsc_code'] = ""
            }
        }



        this.setState({
            bankDetails: fromDataTemp,
            // fromDataBudget: fromDataBudgetTemp,
            bankDetailsError: fromDataTempError,
            // fromDataBudgetError: fromDataBudgetTempError,
            // orgHandleChangeDataFlag: true,
            saveButtonDisableEditModal: false,
            orgHandleChangeDataFlag: true
        }, () => {
            console.log("handle bankDetails", this.state.bankDetails)
            //console.log("handle fromData", this.state.fromData)
            //console.log("handle bankDetailsError", this.state.bankDetailsError)
        })


    }

    handelClickBankAdd = () => {
        let bankDetailsNew = {
            "account_no": "",
            "bank_name": "",
            "bank_address": "",
            "bank_country": "",
            "ifsc_code": "",
        }
        let bankDetailsErrorNew = {
            "account_no": "",
            "bank_name": "",
            "bank_address": "",
            "bank_country": "",
            "ifsc_code": "",
        }
        let tempBankDetails = this.state.bankDetails.slice()
        let tempBankDetails_copy = [...tempBankDetails, bankDetailsNew]


        let tempbankDetailsError = this.state.bankDetailsError.slice()
        let tempbankDetailsError_copy = [...tempbankDetailsError, bankDetailsErrorNew]

        this.setState({
            bankDetails: tempBankDetails_copy,
            bankDetailsError: tempbankDetailsError_copy
        })
    }



    addOrganization = () => {
        const { orgHandleChangeDataFlag, userHandleChangeDataFlag } = this.state

        if (orgHandleChangeDataFlag) {
            this.addEditOrganizationData()
        }
        if (userHandleChangeDataFlag) {
            this.addEditUser()
        }

    }

    addEditOrganizationData = () => {
        //alert()
        const { fromData, reserveFromData, orgFlagType, orgProfileImageChangeEditMode, gridObjData, bankDetails } = this.state;
        const { loaderStateTrue, loaderStateFalse } = this.props;

        let valid = this.validCustomerData();
        console.log("valid org===========", valid)
        if (valid) {
            //console.log("==============")
            formatingFormData(fromData, reserveFromData, orgFlagType, orgProfileImageChangeEditMode, bankDetails).then((formatDataSet) => {

                loaderStateTrue();
                //console.log("fromData call=========,", fromData)
                let type = "post";
                let id = ""
                if (fromData.org_id != "") {
                    id = fromData.org_id,
                        type = "patch";
                    formatDataSet = formatDataSet[0]
                }
                let apiCallFlag = true
                if (type == "patch") {
                    apiCallFlag = Object.keys(formatDataSet).length > 0 ? true : false
                }
                if (apiCallFlag) {
                    OrganizationController.orgCreate(formatDataSet, id, type).then((response) => {
                        loaderStateFalse();
                        if (type == 'post') {
                            if (response.length > 0) {
                                response.map((res, index) => {
                                    if (res.success) {
                                        //console.log("==============res org", res)
                                        let orgId = res.data._id
                                        //console.log("orgId============", orgId)
                                        this.yearlyBudgetPercentageAdd(orgId)
                                        Utility.toastNotifications(res.message, "Success", "success");
                                    } else {
                                        Utility.toastNotifications(res.message, "Error", "error")
                                    }
                                })
                            }
                        } else {
                            if (response.success) {
                                this.closeOrganizationModal();
                                this.resetDataGrid();
                                Utility.toastNotifications(response.message, "Success", "success");
                            } else {
                                Utility.toastNotifications(response.message, "Error", "error")
                            }
                        }

                    }).catch((error) => {
                        loaderStateFalse();
                    });
                }
                if (type == 'patch') {
                    let budgetId = gridObjData?.data?.budgetPercentage[0]?._id
                    this.updateYearlyBudgetPercentage(budgetId)
                }
            })

        }
    }

    validCustomerData = (e) => {
        let fromDataTemp = Object.assign({}, this.state.fromData);

        console.log("fromDataTemp===",fromDataTemp)
        let fromDataTempError = Object.assign({}, this.state.fromDataError);
        let fromDataBudgetTemp = Object.assign({}, this.state.fromDataBudget);
        let fromDataBudgetTempError = Object.assign({}, this.state.fromDataBudgetError);
        let valid = true;
        if (fromDataTemp.name == "") {
            fromDataTempError['name'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['name'] = ""
        }

        if (fromDataTemp.email == "") {
            fromDataTempError['email'] = this.props.t('requiredField')
            valid = false;
        } else {
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!expr.test(fromDataTemp.email)) {
                fromDataTempError['email'] = this.props.t('validEmail')
                valid = false;
            } else {
                fromDataTempError['email'] = ""
            }
        }

        if (fromDataTemp.ph_no == "") {
            fromDataTempError['ph_no'] = this.props.t('requiredField')
            valid = false;
        } else {
            let phoneValidate = HomeUtility.validate_Phone_Number(fromDataTemp.ph_no);
            if (phoneValidate) {
                fromDataTempError['ph_no'] = ""
            } else {
                fromDataTempError['ph_no'] = this.props.t('validphonenumber')
                valid = false;
            }
        }

        // if (fromDataTemp.gst_number == "") {
        //     fromDataTempError['gst_number'] = this.props.t('requiredField')
        //     valid = false;
        // } else {
        //     let gstnValidate = HomeUtility.validate_gst_Number(fromDataTemp.gst_number);
        //     if (gstnValidate) {
        //         fromDataTempError['gst_number'] = ""
        //     } else {
        //         fromDataTempError['gst_number'] = this.props.t('validgstnumber')
        //         valid = false;
        //     }
        // }

        if (fromDataTemp.pan_number == "") {
            fromDataTempError['pan_number'] = this.props.t('requiredField')
            valid = false;
        } else {
            let panValidate = HomeUtility.validate_pan_Number(fromDataTemp.pan_number);
            if (panValidate) {
                fromDataTempError['pan_number'] = ""
            } else {
                fromDataTempError['pan_number'] = this.props.t('validpannumber')
                valid = false;
            }
        }

        if (fromDataTemp.gstn == "") {
            fromDataTempError['gstn'] = this.props.t('requiredField')
            valid = false;
        } else {
            let gstinValidate = HomeUtility.validate_gst_Number(fromDataTemp.gstn);
            if (gstinValidate) {
                fromDataTempError['gstn'] = ""
            } else {
                fromDataTempError['gstn'] = this.props.t('validgstinnumber')
                valid = false;
            }
        }


        //Bank details validation start
        let tempBankDetails = this.state.bankDetails.slice();
        let tempBankDetailsError = this.state.bankDetailsError.slice();
        console.log("tempBankDetails.length", tempBankDetails)

        let bankAccountNumber = []

        if (tempBankDetails.length > 0) {
            tempBankDetails.map((value, idx) => {
                bankAccountNumber.push(value.account_no)
                if (value.account_no == "") {
                    tempBankDetailsError[idx]['account_no'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['account_no'] = ""
                }

                if (value.bank_name == "") {
                    tempBankDetailsError[idx]['bank_name'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['bank_name'] = ""
                }
                if (value.bank_address == "") {
                    tempBankDetailsError[idx]['bank_address'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['bank_address'] = ""
                }
                if (value.bank_country.length == 0) {
                    tempBankDetailsError[idx]['bank_country'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    tempBankDetailsError[idx]['bank_country'] = ""
                }

                if (value.ifsc_code == "") {
                    tempBankDetailsError[idx]['ifsc_code'] = this.props.t('requiredField')
                    valid = false;
                } else {
                    if (value.ifsc_code.length == 11) {
                        tempBankDetailsError[idx]['ifsc_code'] = ""
                    } else {
                        value['ifsc_code'] = "";
                        tempBankDetailsError[idx]['ifsc_code'] = "* IFSC code must be 11 digit"
                        valid = false;
                    }
                }



            })
        }

        if (this.acountNumberDuplicates(bankAccountNumber)) {
            valid = false;
            Utility.toastNotifications("Duplicates account number", "Error", "error")
        }




        //Bank details finish

        if (fromDataTemp.address_line1 == "") {
            fromDataTempError['address_line1'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['address_line1'] = ""
        }
        if (fromDataTemp.city == "") {
            fromDataTempError['city'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['city'] = ""
        }
        if (fromDataTemp.state == "") {
            fromDataTempError['state'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['state'] = ""
        }
        if (fromDataTemp.country=="") {
            fromDataTempError['country'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['country'] = ""
        }
        if (fromDataTemp.zip_code == "") {
            fromDataTempError['zip_code'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['zip_code'] = ""
        }

        /*if (fromDataTemp.account_no == "") {
            fromDataTempError['account_no'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['account_no'] = ""
        }*/
        if (fromDataBudgetTemp.currency == "") {
            fromDataBudgetTempError['currency'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataBudgetTempError['currency'] = ""
        }

        if (fromDataBudgetTemp.conversion_allowance_percentage == "") {
            fromDataBudgetTempError['conversion_allowance_percentage'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataBudgetTempError['conversion_allowance_percentage'] = ""
        }

        if (fromDataBudgetTemp.sgst_percentage == "") {
            fromDataBudgetTempError['sgst_percentage'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataBudgetTempError['sgst_percentage'] = ""
        }
        if (fromDataBudgetTemp.cgst_percentage == "") {
            fromDataBudgetTempError['cgst_percentage'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataBudgetTempError['cgst_percentage'] = ""
        }
        if (fromDataBudgetTemp.igst_percentage == "") {
            fromDataBudgetTempError['igst_percentage'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataBudgetTempError['igst_percentage'] = ""
        }

        this.setState({
            fromDataError: fromDataTempError,
            fromDataBudgetError: fromDataBudgetTempError,
            bankDetails: tempBankDetails,
            bankDetailsError: tempBankDetailsError
        })
        console.log("valid=======",valid)
        return valid;

    }

    acountNumberDuplicates = (array) => {
        if (array.length !== new Set(array).size) {
            return true;
        }

        return false;
    }

    resetOrganizationFrom = () => {
        this.setState({
            fromData: {
                "name": "",
                "email": "",
                "profileImage": "",
                "org_id": "",
                //"gst_number": "",
                "pan_number": "",
                "gstn": "",
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
                "ph_no": "",
            },
            fromDataBudget: {
                "sgst_percentage": "",
                "cgst_percentage": "",
                "igst_percentage": "",
                "conversion_allowance_percentage": "",
                "currency": ""
            },
            fromDataError: {
                "name": "",
                "account_no": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "org_id": "",
                //"gst_number": "",
                "pan_number": "",
                "gstn": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
                "address_line1": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
            },
            fromDataBudgetError: {
                "sgst_percentage": "",
                "cgst_percentage": "",
                "igst_percentage": "",
                "conversion_allowance_percentage": "",
                "currency": ""
            },
            bankDetails: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],

            bankDetailsError: [{
                "account_no": "",
                "bank_name": "",
                "bank_address": "",
                "bank_country": "",
                "ifsc_code": "",
            }],
            orgHandleChangeDataFlag: false,
            orgFlagType: false,
            imageEditFrom: "",

            addUserFromData: {
                "name": "",
                "email": "",
                "profileImage": "",
                "status": true,
                "user_id": "",
            },
            addUserFromDataError: {
                "name": "",
                "email": ""
            },
            addUserInfoFromData: {
                "city": "",
                "country": "",
                "phone_no": "",
                "address_line1": "",
                "address_line2": "",
                "state": "",
                "zip_code": "",
            },
            addUserInfoFromDataError: {
                //"city": "",
                //"country": "",
                "phone_no": "",
            },

            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImagePreviewShow: false,
            saveButtonDisableEditModal: true,
            orgProfileImageChangeEditMode: false,
            userProfileImageChangeEditMode: false,
            disabledEmail: false

        })
    }

    actionModalfunction = (gridObj, e) => {
        //console.log("===============gridObj", gridObj)
        let width = ""
        if (localStorage.getItem('selected_lan_direction') == "rtl") {
            width = (parseInt(e.clientX) + 40) + 'px'
        } else {
            width = (parseInt(e.clientX) - 280) + 'px'
        }
        let height = (parseInt(e.clientY) - 70) + 'px'

        this.setState({
            actionModalflag: true,
            overlayHight: height,
            overlayWidth: width,
            gridObjData: gridObj
        }, () => {
            //console.log("this.state.gridObjDat====first time", this.state.gridObjData)
            if (this.state.gridObjData.data.admins.length == 0) {
                this.setState({
                    deleteButtonEnableFlagForGridActionContent: false
                })
            } else {
                this.setState({
                    deleteButtonEnableFlagForGridActionContent: true
                })
            }
        })
    }

    editOrganization = (params) => {
        //console.log("============params", params)
        this.setState({
            gridObjData: params
        }, () => {

            setEditData(this.state.gridObjData).then((data) => {
                //console.log("==============edit data set", data)
                this.setState({
                    fromData: data,
                    reserveFromData: data,
                    addProfileImagePreviewShow: true,
                    addprofileImageSelected: this.state.gridObjData?.data?.profile_img_temp,
                    bankDetails: data.bankDetails,
                    // fromDataBudget: fromDataBudgetTemp,
                    bankDetailsError: data.bankDetailsError,
                })
            });
            setEditBudgetData(this.state.gridObjData).then((budgetData) => {
                this.setState({
                    fromDataBudget: budgetData,
                    reserveBudgetFromData: budgetData,

                })
            })
            setUserEditData(this.state.gridObjData).then((userData) => {
                this.setState({
                    addUserFromData: userData,
                    reserveUserFromData: userData,
                    addUserImagePreviewShow: true,
                    addUserImageSelected: this.state.gridObjData?.data?.admins[0]?.user_profile_img_temp,

                })
            })
            setUserInfoEditData(this.state.gridObjData).then((userInfoData) => {
                //console.log("userInfoData===", userInfoData)
                this.setState({
                    addUserInfoFromData: userInfoData,
                    reserveUserInfoFromData: userInfoData,

                })
            })
            this.setState({
                organizationModal: true,
                orgAddEditModalTitle: this.props.t('editOrganization'),
                saveButtonDisableEditModal: true,
                userHandleChangeDataFlag: this.state.gridObjData.data.admins.length > 0 ? true : false,
                orgFlagType: true,
                disabledEmail: true
            }, () => {
                //console.log("orgFlagType", this.state.orgFlagType)
                //console.log("userHandleChangeDataFlag", this.state.userHandleChangeDataFlag)
            })
        })
        //console.log("params============", params)


    }

    deleteOrganization = (params) => {
        this.setState({
            deleteConfirmationAlertModal: true,
            actionModalflag: false,
            orgDeleteBodySecondContent: params.data.name,
            organizationDeleteObj: params.data
        })
    }

    deleteConfirmationModalHide = () => {
        this.setState({
            deleteConfirmationAlertModal: false,
            orgDeleteBodySecondContent: ""
        })
    }

    orgDeleteConfirmButton = () => {
        this.oranizationDeleteApi()
    }

    orgDeleteCancleButton = () => {
        this.deleteConfirmationModalHide();
    }

    oranizationDeleteApi = () => {
        const { organizationDeleteObj } = this.state;
        const { loaderStateTrue, loaderStateFalse } = this.props;
        loaderStateTrue();
        let data = {}
        data['id'] = [organizationDeleteObj._id]

        OrganizationController.organizationDelete(data).then((response) => {
            if (response.success) {
                this.resetDataGrid()
                this.deleteConfirmationModalHide()
                this.resetOrganizationFrom()
                Utility.toastNotifications(response.data[0].message, "Success", "success")
            } else {
                Utility.toastNotifications(response.data[0].message, "Error", "error")
            }
            loaderStateFalse();
        }).catch((error) => {
            loaderStateFalse();
            this.deleteConfirmationModalHide()
        });
    }

    addUserShow = () => {
        this.setState({
            addUserModalFlag: true,
            addUserImagePreviewShow: false,
            addUserImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addUserFromData: {
                "name": "",
                "email": "",
                "profileImage": "",
                "status": true,
                "user_id": "",
            },
            addUserInfoFromData: {
                "city": "",
                "country": "",
                "phone_no": "",
                "address_line1": "",
                "address_line2": "",
                "state": "",
                "zip_code": "",
            },
            addUserFromDataError: {
                "name": "",
                "email": ""
            },
            addUserInfoFromDataError: {
                //"city": "",
                //"country": "",
                "phone_no": "",
            },
        })
    }
    closeUserModal = () => {
        this.setState({
            addUserModalFlag: false
        }, () => {
            this.cancelAddUserData()
        })
    }

    addUserFromDataChange = (event, type) => {
        const { addUserFromData, addUserFromDataError } = this.state
        let tempAddUserFromData = Object.assign({}, addUserFromData);
        let tempAddUserFromDataError = Object.assign({}, addUserFromDataError);


        if (type == "name") {
            if (event.target.value != "") {
                tempAddUserFromData['name'] = event.target.value;
                tempAddUserFromDataError['name'] = ""
            } else {
                tempAddUserFromData['name'] = "";
                tempAddUserFromDataError['name'] = this.props.t('requiredField')
            }
        }

        if (type == "email") {
            if (event.target.value != "") {
                tempAddUserFromData['email'] = event.target.value;
                tempAddUserFromDataError['email'] = ""
            } else {
                tempAddUserFromData['email'] = "";
                tempAddUserFromDataError['email'] = this.props.t('requiredField')
            }
        }

        if (type == "status") {
            if (event.target.checked) {
                tempAddUserFromData['status'] = 1;
                tempAddUserFromDataError['status'] = ""
            } else {
                tempAddUserFromData['status'] = 0;
                tempAddUserFromDataError['status'] = ""
            }
        }

        this.setState({
            addUserFromData: tempAddUserFromData,
            addUserFromDataError: tempAddUserFromDataError,
            userHandleChangeDataFlag: true,
            saveButtonDisableEditModal: false,

        })

    }

    addUserInfoFromDataChange = (event, type) => {
        const { addUserInfoFromData, addUserInfoFromDataError } = this.state
        let tempAddUserInfoFromData = Object.assign({}, addUserInfoFromData);
        let tempAddUserInfoFromDataError = Object.assign({}, addUserInfoFromDataError);

        if (type == "address_line1") {
            if (event.target.value != "") {
                tempAddUserInfoFromData['address_line1'] = event.target.value;
                tempAddUserInfoFromDataError['address_line1'] = ""
            } else {
                tempAddUserInfoFromData['address_line1'] = "";
                tempAddUserInfoFromDataError['address_line1'] = ""
            }
        }
        if (type == "address_line2") {
            if (event.target.value != "") {
                tempAddUserInfoFromData['address_line2'] = event.target.value;
                tempAddUserInfoFromDataError['address_line2'] = ""
            } else {
                tempAddUserInfoFromData['address_line2'] = "";
                tempAddUserInfoFromDataError['address_line2'] = ""
            }
        }

        if (type == "city") {
            if (event.target.value != "") {
                tempAddUserInfoFromData['city'] = event.target.value;
                tempAddUserInfoFromDataError['city'] = ""
            } else {
                tempAddUserInfoFromData['city'] = "";
                tempAddUserInfoFromDataError['city'] = ""
            }
        }
        if (type == "state") {
            if (event.target.value != "") {
                tempAddUserInfoFromData['state'] = event.target.value;
                tempAddUserInfoFromDataError['state'] = ""
            } else {
                tempAddUserInfoFromData['state'] = "";
                tempAddUserInfoFromDataError['state'] = ""
            }
        }

        if (type == "country") {
            if (event != "") {
                tempAddUserInfoFromData['country'] = event;
                tempAddUserInfoFromDataError['country'] = ""
            } else {
                tempAddUserInfoFromData['country'] = "";
                tempAddUserInfoFromDataError['country'] = this.props.t('requiredField')
            }
        }
        if (type == "zip_code") {
            if (!isNaN(event.target.value) && event.target.value != "") {
                tempAddUserInfoFromData['zip_code'] = event.target.value;
                tempAddUserInfoFromDataError['zip_code'] = ""
            } else {
                tempAddUserInfoFromData['zip_code'] = "";
                tempAddUserInfoFromDataError['zip_code'] = ""
            }
        }
        if (type == "phone_no") {
            if (event.target.value == "") {
                tempAddUserInfoFromData['phone_no'] = event.target.value;
                tempAddUserInfoFromDataError['phone_no'] = this.props.t('requiredField')
            } else {
                let phoneValidate = HomeUtility.validate_Phone_Number(event.target.value);
                if (phoneValidate) {
                    tempAddUserInfoFromData['phone_no'] = event.target.value;
                    tempAddUserInfoFromDataError['phone_no'] = ""

                } else {
                    tempAddUserInfoFromData['phone_no'] = event.target.value;
                    tempAddUserInfoFromDataError['phone_no'] = this.props.t('validphonenumber')
                }
            }
        }
        this.setState({
            addUserInfoFromData: tempAddUserInfoFromData,
            addUserInfoFromDataError: tempAddUserInfoFromDataError,
            saveButtonDisableEditModal: false,
            userInfoHandleChangeDataFlag: true
        }, () => {
            //console.log("addUserInfoFromData====",this.state.addUserInfoFromData)
        })


    }

    addUserImageChanged = (event) => {

        let { addUserFromData } = this.state;
        let targetFileSplit = event.target.files[0].name.split('.');
        let lastElement = targetFileSplit.pop();
        let user_profile_image = {
            "file_name": "",
            "file_obj": ""
        };
        if (lastElement == 'JPEG' || lastElement == 'jpeg' || lastElement == 'jpg' || lastElement == 'JPG' || lastElement == 'png' || lastElement == 'PNG' || lastElement == '') {
            const fsize = event.target.files[0].size;
            const file = Math.round((fsize / 1024));
            if (file >= 300) {
                Utility.toastNotifications(this.props.t('imageUploadAlert'), "Warning", "warning");
            } else {
                this.setState({
                    imageCropModalFlag: true
                })
                if (event.target.files && event.target.files.length > 0) {
                    const reader = new FileReader();
                    reader.addEventListener('load', () =>
                        this.setState({ src: reader.result })
                    );
                    reader.readAsDataURL(event.target.files[0]);
                    user_profile_image["file_name"] = event.target.files[0].name
                    user_profile_image["file_obj"] = ""
                    addUserFromData["profileImage"] = user_profile_image
                    this.setState({
                        addUserFromData,
                        addUserImagePreviewShow: true,
                        addUserImageError: "",
                        userHandleChangeDataFlag: true,
                        imageEditFrom: "user"
                    })
                }
            }

        } else {
            addUserFromData["profileImage"] = ""

            this.setState({
                addUserFromData,
                addUserImagePreviewShow: false,
                addUserImageSelected: 'Add Image',
                addUserImageError: this.props.t('requiredField'),
                userHandleChangeDataFlag: true
            })
        }
    }

    addEditUser = () => {
        let valid = ""
        let userValid = this.validAddUserData();
        //addUserFromData.user_id && addUserFromData.user_id != ""
        let orgValid = this.validCustomerData();
        const { loaderStateTrue, loaderStateFalse } = this.props;
        const { addUserFromData, userProfileImageChangeEditMode, reserveUserFromData, gridObjData } = this.state;

        if (addUserFromData.user_id && addUserFromData.user_id != "") {
            console.log("===============user edit")
            console.log("===============userValid",userValid)
            console.log("===============orgValid",orgValid)
            if (userValid == false || orgValid == false) {
                valid = false
            }else{
                valid = true
            }
        } else {
            valid = userValid
        }

        console.log("valid customer============", valid)
        if (valid) {

            formatingUserData(addUserFromData, reserveUserFromData, userProfileImageChangeEditMode).then((addUserDataSet) => {
                //let data = this.formatingUserData();
                let method = 'post';
                let id = ""
                //let addUserDataSet = [data];
                if (addUserFromData.user_id != "") {
                    id = addUserFromData.user_id,
                        method = "patch";
                    addUserDataSet = addUserDataSet[0];
                }
                let apiCallFlag = true
                if (method == "patch") {
                    apiCallFlag = Object.keys(addUserDataSet).length > 0 ? true : false
                }
                //console.log("addUserDataSet===========", addUserDataSet)
                //return false;

                loaderStateTrue();
                if (apiCallFlag) {
                    OrganizationController.addUser(addUserDataSet, method, id).then((response) => {
                        loaderStateFalse();
                        if (method == 'post') {
                            if (response[0].success) {
                                this.orgCustRelation(response[0]?.data[0]?._id).then((orgCustRelationResponse) => {
                                    if (orgCustRelationResponse) {
                                        this.closeUserModal()
                                        //this.closeOrganizationModal()
                                        this.resetDataGrid()
                                        Utility.toastNotifications(response[0].message, "Success", "success");
                                    }
                                })
                                this.adminUsersInfo(response[0]?.data[0]?._id)
                            } else {
                                Utility.toastNotifications(response[0].message, "Error", "error");
                            }
                        } else {
                            if (response.success) {
                                this.closeUserModal()
                                this.closeOrganizationModal()
                                this.resetDataGrid()
                                Utility.toastNotifications(response.message, "Success", "success");
                            } else {
                                Utility.toastNotifications(response.message, "Error", "error");
                            }

                        }

                    }).catch((error) => {
                        loaderStateFalse();
                    });
                }
                if (this.state.userInfoHandleChangeDataFlag) {
                    if (method == 'patch') {
                        console.log("=============info")
                        console.log("=============userInfoHandleChangeDataFlag", this.state.userInfoHandleChangeDataFlag)

                        if (gridObjData?.data?.admins?.length > 0) {
                            //let userNumber = gridObjData?.data?.admins[0]?.user_number
                            let userId = gridObjData?.data?.admins[0]?.id
                            this.adminUsersInfo(userId)
                        }
                    }
                }
            })

        }

    }

    orgCustRelation = (userId) => {
        //console.log("userId==========",userId)
        let promise = new Promise((resolve, reject) => {
            const { loaderStateTrue, loaderStateFalse } = this.props;
            const { addUserFromData, gridObjData } = this.state;
            let data = [
                {
                    "org_id": gridObjData.data._id,
                    "user_id": userId
                }
            ]
            loaderStateTrue();
            OrganizationController.orgCustRelationPost(data).then((response) => {
                loaderStateFalse();
                if (response[0].success) {
                    resolve(response)
                } else {
                    Utility.toastNotifications(response[0].message, "Error", "error");
                }

            }).catch((error) => {
                loaderStateFalse();
            });
        })
        return promise
    }


    validAddUserData = () => {
        const { addUserFromData, addUserFromDataError, addUserImageError, addUserInfoFromData, addUserInfoFromDataError } = this.state;
        let tempAddUserFromDataError = Object.assign({}, addUserFromDataError)
        let tempAddUserInfoFromDataError = Object.assign({}, addUserInfoFromDataError);

        let valid = true;
        if (addUserFromData.name == "") {
            tempAddUserFromDataError['name'] = this.props.t('requiredField')
            valid = false;
            //console.log("1111111111")
        } else {
            tempAddUserFromDataError['name'] = ""
        }

        if (addUserFromData.email == "") {
            tempAddUserFromDataError['email'] = this.props.t('requiredField')
            valid = false;
            //console.log("22222222222")
        } else {
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!expr.test(addUserFromData.email)) {
                tempAddUserFromDataError['email'] = this.props.t('validEmail')
                valid = false;
                //console.log("333333333333")
            } else {
                tempAddUserFromDataError['email'] = ""
            }

        }


        /*if (addUserInfoFromData.phone_no == "") {
            tempAddUserInfoFromDataError['phone_no'] = this.props.t('requiredField')
            valid = false;
            console.log("4444444444444")
        } else {
            let phoneValidate = HomeUtility.validate_Phone_Number(addUserInfoFromData.phone_no);
            console.log("phoneValidate==",phoneValidate)
            console.log("addUserInfoFromData.phone_no==",addUserInfoFromData.phone_no)
            console.log("addUserInfoFromData==",addUserInfoFromData)
            if (phoneValidate) {
                tempAddUserInfoFromDataError['phone_no'] = ""
            } else {
                tempAddUserInfoFromDataError['phone_no'] = this.props.t('validphonenumber')
                valid = false;
                console.log("555555")
            }
        }*/

        this.setState({
            addUserFromDataError: tempAddUserFromDataError,
            addUserInfoFromDataError: tempAddUserInfoFromDataError,
        })

        return valid;
    }

    deleteUser = (params) => {
        //console.log("params=========", params)
        this.setState({
            deleteUserConfirmationAlertModal: true,
            actionModalflag: false,
            userDeleteBodySecondContent: params.data.admins[0].user_name,
            userDeleteObj: params.data
        })
    }

    deleteUserConfirmationModalHide = () => {
        this.setState({
            deleteUserConfirmationAlertModal: false,
            userDeleteBodySecondContent: ""
        })
    }

    userDeleteCancleButton = () => {
        this.deleteUserConfirmationModalHide();
    }

    userDeleteConfirmButton = () => {
        this.userDeleteApi()
    }


    userDeleteApi = () => {
        const { userDeleteObj } = this.state;
        //console.log("userDeleteObj",userDeleteObj)
        const { loaderStateTrue, loaderStateFalse } = this.props;
        loaderStateTrue();
        let data = {}
        data['id'] = [userDeleteObj.admins[0].id]

        OrganizationController.userDelete(data).then((response) => {
            if (response.success) {
                this.resetDataGrid()
                this.deleteUserConfirmationModalHide()
                this.resetOrganizationFrom()
                Utility.toastNotifications(response.data[0].message, "Success", "success")
            } else {
                Utility.toastNotifications(response.data[0].message, "Error", "error")
            }
            loaderStateFalse();
        }).catch((error) => {
            loaderStateFalse();
            this.deleteUserConfirmationModalHide()
        });
    }



    cancelAddUserData = () => {
        this.setState({
            addUserFromData: {
                "name": "",
                "email": "",
                "phone": "",
                "address": "",
                "profileImage": "",
                "status": true,
                "user_id": "",
            },

            addUserFromDataError: {
                "name": "",
                "email": ""
            },
            addUserInfoFromData: {
                "city": "",
                "country": "",
                "phone_no": "",
            },
            addUserInfoFromDataError: {
                "city": "",
                "country": "",
                "phone_no": "",
            },

            fromDataError: {
                "name": "",
                "email": "",
                "ph_no": "",
                "profileImage": "",
                "org_id": "",
                "pan_number": "",
                "gstn": "",
                "address_line1": "",
                "city": "",
                "state": "",
                "country": "",
                "zip_code": "",
            },
            fromDataBudgetError: {
                "sgst_percentage": "",
                "cgst_percentage": "",
                "igst_percentage": "",
                "conversion_allowance_percentage": "",
                "currency": ""
            },
            userHandleChangeDataFlag: false,
            addUserImagePreviewShow: false,
            addUserImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addUserImageError: "",
            saveButtonDisableEditModal: true,
            userInfoHandleChangeDataFlag: false
        })
    }

    popoverStickDatasetFormatUser = (rowData) => {
        let data = {}
        //console.log("rowDatarowData", rowData)
        data = Object.assign(rowData, {
            "email": rowData.admins.length > 0 ? rowData.admins[0].user_email : "",
            "phone_no": rowData.admins.length > 0 ? rowData.admins[0].user_ph_no : ""
        })
        return data
    }

    adminUsersInfoValid = () => {
        const { addUserInfoFromData, addUserInfoFromDataError } = this.state;
        let tempAddUserInfoFromDataError = Object.assign({}, addUserInfoFromDataError);
        let valid = true;
        let phoneValidate = HomeUtility.validate_Phone_Number(addUserInfoFromData.phone_no);
        if (addUserInfoFromData.phone_no != "") {
            if (phoneValidate) {
                tempAddUserInfoFromDataError['phone_no'] = ""
            } else {
                tempAddUserInfoFromDataError['phone_no'] = this.props.t('validphonenumber')
                valid = false;
            }
        }
        this.setState({
            addUserInfoFromDataError: tempAddUserInfoFromDataError,
        })
        return valid;
    }

    adminUsersInfo = (userId, type) => {
        let promise = new Promise((resolve, reject) => {
            let valid = this.adminUsersInfoValid();
            const { loaderStateTrue, loaderStateFalse } = this.props;
            const { addUserInfoFromData, gridObjData, reserveUserInfoFromData, orgFlagType } = this.state;
            //console.log("valid", valid)
            if (valid) {
                formatingInfoUserData(addUserInfoFromData, reserveUserInfoFromData, orgFlagType).then((addUserDataSet) => {
                    let method = 'post';
                    let id = "";
                    if (orgFlagType) {
                        id = userId,
                            method = "patch";
                        addUserDataSet = addUserDataSet[0];
                    } else {
                        addUserDataSet[0].user_id = userId
                    }
                    let apiCallFlag = true
                    if (method == "patch") {
                        apiCallFlag = Object.keys(addUserDataSet).length > 0 ? true : false
                    }
                    loaderStateTrue();
                    if (apiCallFlag) {
                        OrganizationController.usersInfo(addUserDataSet, id, method).then((response) => {
                            loaderStateFalse();
                            if (method == "post") {
                                if (response.length > 0) {
                                    response.map((res, index) => {
                                        if (res.success) {
                                            this.closeUserModal();
                                            this.resetDataGrid();
                                            Utility.toastNotifications(res.message, "Success", "success");
                                        } else {
                                            Utility.toastNotifications(res.message, "Error", "error")
                                        }
                                    })
                                }
                            } else {
                                if (response.success) {
                                    this.closeUserModal();
                                    this.closeOrganizationModal()
                                    this.resetDataGrid();
                                    Utility.toastNotifications(response.message, "Success", "success");
                                } else {
                                    Utility.toastNotifications(response.message, "Error", "error")
                                }
                            }
                        }).catch((error) => {
                            loaderStateFalse();
                        })
                    }
                })
            }
        })

        return promise
    }


    yearlyBudgetPercentageAdd = (orgId) => {
        const { loaderStateTrue, loaderStateFalse } = this.props;
        const { fromDataBudget, reserveBudgetFromData, orgFlagType } = this.state;
        let promise = new Promise((resolve, reject) => {
            if (this.validCustomerData()) {
                formatingFormDataYearlyBudgetPercentage(orgId, fromDataBudget, reserveBudgetFromData, orgFlagType).then((formatDataset) => {
                    loaderStateTrue();
                    OrganizationController.yearlyBudgetPercentageCreate(formatDataset)
                        .then((response) => {
                            if (response.length > 0) {
                                response.map((messageItem, messageIndex) => {
                                    if (messageItem.success) {
                                        this.closeOrganizationModal();
                                        this.resetDataGrid();
                                        Utility.toastNotifications(messageItem.message, "Success", "success")
                                    } else {
                                        Utility.toastNotifications(messageItem.message, "Error", "error")
                                    }

                                })
                                loaderStateFalse();
                            }
                            loaderStateFalse();
                        })
                        .catch((error) => {
                            Utility.toastNotifications(error.message, "Error", "error");
                            loaderStateFalse();
                        })
                })
            }
        })
        return promise
    }

    updateYearlyBudgetPercentage = (budgetId) => {
        const { loaderStateTrue, loaderStateFalse } = this.props;
        const { fromDataBudget, reserveBudgetFromData, orgFlagType, gridObjData } = this.state;
        //console.log("gridObjData", gridObjData)
        let promise = new Promise((resolve, reject) => {
            if (this.validCustomerData()) {
                formatingFormDataYearlyBudgetPercentage(budgetId, fromDataBudget, reserveBudgetFromData, orgFlagType, gridObjData).then((formatDataset) => {
                    loaderStateTrue();
                    let id = budgetId
                    formatDataset = formatDataset[0]
                    let apiCallFlag = true
                    apiCallFlag = Object.keys(formatDataset).length > 0 ? true : false
                    if (apiCallFlag) {
                        OrganizationController.yearlyBudgetPercentageUpdate(id, formatDataset)
                            .then((response) => {
                                this.resetDataGrid();
                                this.closeOrganizationModal();
                                Utility.toastNotifications(response.message, "Success", "success")
                                loaderStateFalse();
                            })
                            .catch((error) => {
                                Utility.toastNotifications(error.message, "Error", "error");
                                loaderStateFalse();
                            })
                    }
                })
            }

        })
    }

    /*removeAdditionalBankDetails = (idx, type) => {
        console.log("idx======", idx)
        console.log("type======", type)
        let tempBankDetails = this.state.bankDetails.slice();
        let tempBankDetailsError = this.state.bankDetailsError.slice();
        console.log("tempBankDetails======", tempBankDetails)
        console.log("tempBankDetailsError======", tempBankDetailsError)

        tempBankDetails.splice(idx, 1)
        tempBankDetailsError.splice(idx, 1)
        this.setState({
            bankDetails: tempBankDetails,
            bankDetailsError: tempBankDetailsError,
            orgHandleChangeDataFlag: true,
            saveButtonDisableEditModal: false
        })
    }*/

    removeAdditionalBankDetails = (idx, type) => {
        this.setState({
            deleteBankDetailsConfirmationAlertModalFlag: true,
            deleteBankDetailsObj: idx
        })
    }

    deleteBankDetailsConfirmationModalHide = () => {
        this.setState({
            deleteBankDetailsConfirmationAlertModalFlag: false,
            deleteBankDetailsObj: ""
        })
    }

    deleteBankDetailsConfirmationFunction = () => {
        const { deleteBankDetailsObj } = this.state
        let tempBankDetails = this.state.bankDetails.slice();
        let tempBankDetailsError = this.state.bankDetailsError.slice();

        tempBankDetails.splice(deleteBankDetailsObj, 1)
        tempBankDetailsError.splice(deleteBankDetailsObj, 1)
        this.setState({
            deleteBankDetailsConfirmationAlertModalFlag: false,
            bankDetails: tempBankDetails,
            bankDetailsError: tempBankDetailsError,
            orgHandleChangeDataFlag: true,
            saveButtonDisableEditModal: false
        })
    }

    render() {
        const { t, roleWisePermission } = this.props;
        return (
            <div className="gridcontainer">
                <div className="totalworkercontent">
                    <div className="gridtopviews">
                        <div className="rightboxes">
                            <button type="button" className="useraddbtn" onClick={this.organizationModalfunction}>{this.props.t('Ajouter')}</button>
                        </div>
                        <div className="pageinnersearch">
                            <button type="button" className="btn btn-link search_btn_addon"><i className="fa fa-search"></i></button>
                            <CustomInput
                                parentClassName="comment_input_field"
                                name="srchBox"
                                type="text"
                                placeholder={this.props.t('searchOrganization')}
                                onChange={this.handleUserSearchBar.bind(this)}
                                value={this.state.orgName}
                            />
                            {
                                this.state.orgName != "" ?
                                    < button type="button" className="btn btn-link dropclosebtn" onClick={this.clearSearchValue}>
                                        <img src={require('../../../../Utility/Public/images/dropcloseicon.png')} className="searchClearIcon" />
                                    </button>
                                    : null}
                        </div>
                    </div>
                    <div className="ag-theme-alpine aggridview homeag orgGrid">
                        <AgGridReact
                            modules={this.state.modules}
                            columnDefs={this.state.columnDefs}
                            defaultColDef={this.state.defaultColDef}
                            components={this.state.components}
                            rowSelection="multiple"
                            rowModelType="infinite"
                            onGridReady={this.onGridReady}
                            rowHeight={62.5}
                            headerHeight={47}
                            //onSelectionChanged={this.onSelectionChanged.bind(this)}
                            cacheBlockSize={20}
                            enableRtl={localStorage.getItem('selected_lan_direction') == "rtl" ? true : false}
                        />
                    </div>
                    <ModalGlobal
                        show={this.state.organizationModal}
                        onHide={this.closeOrganizationModal}
                        title={this.state.orgAddEditModalTitle}
                        className="modalcustomize mondimension orgModal"
                        footer={false}
                        closeButton={true}
                        body={
                            <OrganizationModalContent
                                //Image crop
                                addInputProfileImageChanged={this.addInputProfileImageChanged}
                                addprofileImageSelected={this.state.addprofileImageSelected}
                                crop={this.state.crop}
                                croppedImageUrl={this.state.croppedImageUrl}
                                src={this.state.src}
                                onImageLoaded={this.onImageLoaded}
                                onCropComplete={this.onCropComplete}
                                onCropChange={this.onCropChange}
                                imageCropModalShow={this.imageCropModalShow}
                                imageCropModalHide={this.imageCropModalHide}
                                imageCropModalFlag={this.state.imageCropModalFlag}
                                imageCropDataSave={this.imageCropDataSave}

                                //form data
                                handelChange={this.handelChange}
                                fromData={this.state.fromData}
                                fromDataError={this.state.fromDataError}
                                statusList={this.state.statusList}
                                addOrganization={this.addOrganization}
                                addProfileImagePreviewShow={this.state.addProfileImagePreviewShow}
                                fromDataBudget={this.state.fromDataBudget}
                                //Add user From Data for Edit
                                addUserImageSelected={this.state.addUserImageSelected}
                                addEditUser={this.addEditUser}
                                addUserFromDataChange={this.addUserFromDataChange}
                                addUserFromData={this.state.addUserFromData}
                                addUserFromDataError={this.state.addUserFromDataError}
                                addUserImageError={this.state.addUserImageError}
                                addUserImageChanged={this.addUserImageChanged}

                                orgHandleChangeDataFlag={this.state.orgHandleChangeDataFlag}
                                userHandleChangeDataFlag={this.state.userHandleChangeDataFlag}

                                onCropCompleteForUser={this.onCropCompleteForUser}
                                imageEditFrom={this.state.imageEditFrom}
                                addUserImagePreviewShow={this.state.addUserImagePreviewShow}
                                saveButtonDisableEditModal={this.state.saveButtonDisableEditModal}

                                addUserInfoFromDataError={this.state.addUserInfoFromDataError}
                                addUserInfoFromData={this.state.addUserInfoFromData}
                                addUserInfoFromDataChange={this.addUserInfoFromDataChange}
                                currencyList={this.state.currencyList}
                                fromDataBudgetError={this.state.fromDataBudgetError}
                                countryList={this.state.countryList}
                                disabledEmail={this.state.disabledEmail}

                                bankDetails={this.state.bankDetails}
                                bankDetailsError={this.state.bankDetailsError}
                                handelClickBankAdd={this.handelClickBankAdd}
                                handelChangeForBankDetails={this.handelChangeForBankDetails}
                                removeAdditionalBankDetails={this.removeAdditionalBankDetails}
                                removeAdditionalBankDetailsDisplay={true}

                            />
                        }
                    />
                    <ModalGlobal
                        show={this.state.deleteConfirmationAlertModal}
                        onHide={this.deleteConfirmationModalHide}
                        className="modalcustomize confirmationalertmodal"
                        bodyClassName="cancelConfirmationbody"
                        headerclassName="close_btn_icon"
                        title={t('deleteOrgTitle')}
                        footer={false}
                        body={
                            <ConfirmationAlert
                                BodyFirstContent={t('entDeleteConfirmation')}
                                BodySecondContent={this.state.orgDeleteBodySecondContent}
                                BodyThirdContent={t('organizationDeleteAnableGoBack')}
                                confirmationButtonContent={t('confirm')}
                                cancelButtonContent={t('cancel')}
                                deleteConfirmButton={this.orgDeleteConfirmButton}
                                deleteCancleButton={this.orgDeleteCancleButton}
                            />
                        }
                    />
                    <ModalGlobal
                        show={this.state.deleteUserConfirmationAlertModal}
                        onHide={this.deleteUserConfirmationModalHide}
                        className="modalcustomize confirmationalertmodal"
                        bodyClassName="cancelConfirmationbody"
                        headerclassName="close_btn_icon"
                        title={t('deleteUserTitle')}
                        footer={false}
                        body={
                            <ConfirmationAlert
                                BodyFirstContent={t('entDeleteConfirmation')}
                                BodySecondContent={this.state.userDeleteBodySecondContent}
                                BodyThirdContent={t('userDeleteAnableGoBack')}
                                confirmationButtonContent={t('confirm')}
                                cancelButtonContent={t('cancel')}
                                deleteConfirmButton={this.userDeleteConfirmButton}
                                deleteCancleButton={this.userDeleteCancleButton}
                            />
                        }
                    />

                    <ModalGlobal
                        show={this.state.addUserModalFlag}
                        onHide={this.closeUserModal}
                        title={t('addUser')}
                        className="modalcustomize mondimension userModal"
                        footer={false}
                        closeButton={true}
                        body={
                            <AddUserModalContent
                                //Image crop
                                addInputProfileImageChanged={this.addInputProfileImageChanged}
                                addUserImageSelected={this.state.addUserImageSelected}
                                crop={this.state.crop}
                                croppedImageUrl={this.state.croppedImageUrl}
                                src={this.state.src}
                                onImageLoaded={this.onImageLoaded}
                                onCropCompleteForUser={this.onCropCompleteForUser}
                                onCropChange={this.onCropChange}
                                imageCropModalShow={this.imageCropModalShow}
                                imageCropModalHide={this.imageCropModalHide}
                                imageCropModalFlag={this.state.imageCropModalFlag}
                                imageCropDataSave={this.imageCropDataSave}
                                addUserImagePreviewShow={this.state.addUserImagePreviewShow}

                                addEditUser={this.addEditUser}
                                addUserFromDataChange={this.addUserFromDataChange}
                                addUserFromData={this.state.addUserFromData}
                                addUserFromDataError={this.state.addUserFromDataError}
                                addUserImageError={this.state.addUserImageError}
                                addUserImageChanged={this.addUserImageChanged}

                                addUserInfoFromDataError={this.state.addUserInfoFromDataError}
                                addUserInfoFromData={this.state.addUserInfoFromData}
                                addUserInfoFromDataChange={this.addUserInfoFromDataChange}
                                countryList={this.state.countryList}

                            />
                        }
                    />

                    {this.state.actionModalflag && this.state.deleteButtonEnableFlagForGridActionContent == true ?
                        <GridActionContent
                            styleWidth={this.state.overlayWidth}
                            styleHight={this.state.overlayHight}
                            codeOutsideClickRef={this.codeOutsideClickRef}
                            gridObjData={this.state.gridObjData}
                            modefier={this.editOrganization}
                            delete={this.deleteOrganization}
                            archivedButtonShow={false}
                            addUserButtonShow={false}
                            addUser={this.addUserShow}
                            deleteUserButtonShow={true}
                            deleteUser={this.deleteUser}
                        />
                        : this.state.actionModalflag && this.state.deleteButtonEnableFlagForGridActionContent == false ?
                            <GridActionContent
                                styleWidth={this.state.overlayWidth}
                                styleHight={this.state.overlayHight}
                                codeOutsideClickRef={this.codeOutsideClickRef}
                                gridObjData={this.state.gridObjData}
                                modefier={this.editOrganization}
                                delete={this.deleteOrganization}
                                archivedButtonShow={false}
                                addUserButtonShow={true}
                                addUser={this.addUserShow}
                                deleteUserButtonShow={false}
                                deleteUser={this.deleteUser}
                            />
                            : null
                    }

                    <ModalGlobal
                        show={this.state.deleteBankDetailsConfirmationAlertModalFlag}
                        onHide={this.deleteBankDetailsConfirmationModalHide}
                        className="modalcustomize confirmationalertmodal"
                        bodyClassName="cancelConfirmationbody"
                        headerclassName="close_btn_icon"
                        title={t('deleteBankDetails')}
                        footer={false}
                        body={
                            <ConfirmationAlert
                                BodyFirstContent={t('bankDeleteConfirmation')}
                                //BodySecondContent={this.state.enDeleteBodySecondContent}
                                BodyThirdContent={t('bankDeleteAnableGoBack')}
                                confirmationButtonContent={t('confirm')}
                                cancelButtonContent={t('cancel')}
                                deleteConfirmButton={this.deleteBankDetailsConfirmationFunction}
                                deleteCancleButton={this.deleteBankDetailsConfirmationModalHide}
                            />
                        }
                    />

                </div>

            </div >
        );
    }
}


const mapStateToProps = (globalState) => {
    return {
        userCredentials: globalState.LoginReducer.userCredentials,
        roleWisePermission: globalState.mainReducerData.roleWisePermission
    };
}

export default withRouter(connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
    (withTranslation()(Organization)));