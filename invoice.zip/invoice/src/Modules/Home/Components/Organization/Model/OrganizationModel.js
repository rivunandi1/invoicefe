export const orgListingGet = (data) => {    
    //console.log("data===model",data.data)
    return data.data;
}
export const orgCreatePost = (data) => {    
    return data.data;
}
export const orgDetailsGet = (data) => {    
    return data.data;
}
export const orgUpdatePatch = (data) => {    
    return data.data;
}
export const orgUpdatePatchApi = (data) => {    
    return data.data;
}
export const organizationDeleteApi = (data) => {    
    return data.data;
}
export const addUserPost = (data) => {    
    return data.data;
}
export const addUserPatch = (data) => {    
    return data.data;
}

export const orgCustRelationPostApi = (data) => {    
    return data.data;
}

export const userDetailsGet = (data) => {    
    return data.data;
}

export const userDeleteApi = (data) => {    
    return data.data;
}
export const usersInfoPost = (usersInfoAdd) => {
    return usersInfoAdd.data
}
export const usersInfoPatch = (usersInfoUpdate) => {
    return usersInfoUpdate.data
}
export const yearlyBudgetPercentagePost = (data) => {
    return data.data
}
export const yearlyBudgetPercentagePatch = (data) => {
    return data.data
}
