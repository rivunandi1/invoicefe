import React, { Component } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Utility from '../../../../../Utility/Utility';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import ReactCrop from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import ImageCropContent from '../../../../../Utility/Components/ImageCropContent';
import ModalGlobal from '../../../../../Utility/Components/ModalGlobal';
import BankDetailsComponent from '../../../../../Utility/Components/BankDetailsComponent'


class OrganizationModalContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 16 / 9
            },
            croppedImageUrl: "",
        }

    }



    render() {
        const { addInputProfileImageChanged, addprofileImageSelected, steponehide, t, fromData, bankDetails } = this.props;
        const { addUserImageChanged, addUserImageSelected, addUserFromData, addUserFromDataError, addUserImageError, orgHandleChangeDataFlag, userHandleChangeDataFlag, imageEditFrom, addUserInfoFromData, addUserInfoFromDataError, fromDataBudget, fromDataError, disabledEmail } = this.props;
        //console.log("fromData===========", fromData)
        //console.log("disabledEmail===========", disabledEmail)
        //console.log("fromData.account_no===========", fromData)
        //console.log("bankDetails===========", bankDetails)


        return (
            <>
                <div className="modalinnerbody">
                    <div className="firstinformation">
                        <div className="innerbodydimension">
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="row">
                                            <div className="col-md-12 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName={t('Name')}
                                                    errorLabel={this.props.fromDataError.name}
                                                    name="name"
                                                    type="text"
                                                    value={fromData.name}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "name")}

                                                />
                                            </div>
                                            <div className={"col-md-12 required"}>
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName={t('Email')}
                                                    errorLabel={this.props.fromDataError.email}
                                                    name="email"
                                                    type="text"
                                                    value={fromData.email}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "email")}

                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="user_add_img modprofile">
                                            <div className="userProfileImg">
                                                {!this.props.addProfileImagePreviewShow ?
                                                    <label className="custom-file-upload">
                                                        <span className="filetext">
                                                            <img src={addprofileImageSelected} />
                                                        </span>
                                                        <span className="plusicon">
                                                            <i className="fa fa-plus" aria-hidden="true"></i>
                                                            <input type="file" onChange={addInputProfileImageChanged} />
                                                        </span>
                                                    </label>
                                                    :
                                                    <label className="custom-file-upload">
                                                        <img src={addprofileImageSelected} />
                                                        <span className="plusicon">
                                                            <i className="fa fa-plus" aria-hidden="true"></i>
                                                            <input type="file" onChange={this.props.addInputProfileImageChanged} />
                                                        </span>
                                                    </label>
                                                }

                                                <div className="col-md-12 errorClass error_div"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName={t('phonenumber')}
                                                    errorLabel={this.props.fromDataError.ph_no}
                                                    name="ph_no"
                                                    type="text"
                                                    value={fromData.ph_no}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "ph_no")}

                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Pan No."
                                                    errorLabel={this.props.fromDataError.pan_number}
                                                    name="pan_number"
                                                    type="text"
                                                    value={fromData.pan_number}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "pan_number")}

                                                />
                                            </div>
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="GSTIN"
                                                    errorLabel={this.props.fromDataError.gstn}
                                                    name="gstn"
                                                    type="text"
                                                    value={fromData.gstn}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "gstn")}

                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <label className='tagName'>Bank Details</label>
                                <div className="row banckDetails additionalBanckDetails">

                                    <BankDetailsComponent
                                        countryList={this.props.countryList}
                                        bankDetails={this.props.bankDetails}
                                        bankDetailsError={this.props.bankDetailsError}
                                        handelChangeForBankDetails={this.props.handelChangeForBankDetails}
                                        handelClickBankAdd={this.props.handelClickBankAdd}
                                        removeAdditionalBankDetails={this.props.removeAdditionalBankDetails}
                                        removeAdditionalBankDetailsDisplay={true}
                                    />

                                </div>
                                {/* ////////////////////////////// */}



                                {/* <div className="col-md-12">
                                        <CustomInput
                                            parentClassName="input_field_inner"
                                            labelName="Account No."
                                            errorLabel={this.props.fromDataError.account_no}
                                            name="account_no"
                                            type="text"
                                            value={fromData.account_no}
                                            labelPresent={true}
                                            onChange={(e) => this.props.handelChange(e, "account_no")}
                                            maxlength={16}

                                        />
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Bank Name"
                                                    errorLabel={this.props.fromDataError.bank_name}
                                                    name="bank_name"
                                                    type="text"
                                                    value={fromData.bank_name}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "bank_name")}
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Bank address"
                                                    errorLabel={this.props.fromDataError.bank_address}
                                                    name="bank_address"
                                                    type="text"
                                                    value={fromData.bank_address}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "bank_address")}

                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <div className="dropdowninnerbox">
                                                    <label>Bank country</label>
                                                    <AutosuggestComponent
                                                        handleOnChange={(e) => this.props.handelChange(e, "bank_country")}
                                                        options={this.props.countryList}
                                                        selectedValue={this.props.fromData.bank_country}
                                                        name=''
                                                        isMulti={false}
                                                        placeholder=""
                                                        isDisabled={false}
                                                        isSearchable={true}
                                                    />
                                                    <div className="col-md-12 errorClass error_div">{this.props.fromDataError.bank_country}</div>
                                                </div>
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="IFSC code"
                                                    errorLabel={this.props.fromDataError.ifsc_code}
                                                    name="ifsc_code"
                                                    type="text"
                                                    value={fromData.ifsc_code}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "ifsc_code")}
                                                //maxlength={11}
                                                />
                                            </div>
                                        </div>
                                    </div> */}
                                {/* ////////////////////////////// */}

                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Address line 1"
                                                    errorLabel={this.props.fromDataError.address_line1}
                                                    name="address_line1"
                                                    type="text"
                                                    value={fromData.address_line1}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "address_line1")}
                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Address line 2"
                                                    //errorLabel={}
                                                    name="address_line2"
                                                    type="text"
                                                    value={fromData.address_line2}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "address_line2")}

                                                />
                                            </div>


                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="City"
                                                    errorLabel={this.props.fromDataError.city}
                                                    name="city"
                                                    type="text"
                                                    value={fromData.city}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "city")}

                                                />
                                            </div>
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="State"
                                                    errorLabel={this.props.fromDataError.state}
                                                    name="state"
                                                    type="text"
                                                    value={fromData.state}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "state")}

                                                />
                                            </div>

                                        </div>
                                    </div>



                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <div className="dropdowninnerbox required">
                                                    <label>Country</label>
                                                    <AutosuggestComponent
                                                        handleOnChange={(e) => this.props.handelChange(e, "country")}
                                                        options={this.props.countryList}
                                                        selectedValue={this.props.fromData.country}
                                                        name=''
                                                        isMulti={false}
                                                        placeholder=""
                                                        isDisabled={false}
                                                        isSearchable={true}
                                                    />
                                                    <div className="col-md-12 errorClass error_div">{this.props.fromDataError.country}</div>
                                                </div>
                                            </div>
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Zip code"
                                                    errorLabel={this.props.fromDataError.zip_code}
                                                    name="zip_code"
                                                    type="text"
                                                    value={fromData.zip_code}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "zip_code")}

                                                />
                                            </div>

                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="SGST %"
                                                    errorLabel={this.props.fromDataBudgetError.sgst_percentage}
                                                    name="sgst_percentage"
                                                    type="text"
                                                    value={fromDataBudget.sgst_percentage}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "sgst_percentage")}

                                                />
                                            </div>
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="CGST %"
                                                    errorLabel={this.props.fromDataBudgetError.cgst_percentage}
                                                    name="cgst_percentage"
                                                    type="text"
                                                    value={fromDataBudget.cgst_percentage}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "cgst_percentage")}

                                                />
                                            </div>

                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="IGST %"
                                                    errorLabel={this.props.fromDataBudgetError.igst_percentage}
                                                    name="igst_percentage"
                                                    type="text"
                                                    value={fromDataBudget.igst_percentage}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "igst_percentage")}

                                                />
                                            </div>
                                            <div className="col-md-6 required">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="GST % for foreign currency"
                                                    errorLabel={this.props.fromDataBudgetError.conversion_allowance_percentage}
                                                    name="conversion_allowance_percentage"
                                                    type="text"
                                                    value={fromDataBudget.conversion_allowance_percentage}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "conversion_allowance_percentage")}

                                                />
                                            </div>

                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="dropdowninnerbox required">
                                            <label>Currency</label>
                                            <AutosuggestComponent
                                                handleOnChange={(e) => this.props.handelChange(e, "currency")}
                                                options={this.props.currencyList}
                                                selectedValue={fromDataBudget.currency}
                                                name=''
                                                isMulti={false}
                                                placeholder=""
                                                isDisabled={false}
                                                isSearchable={true}
                                            />
                                            <div className="col-md-12 errorClass error_div">{this.props.fromDataBudgetError.currency}</div>
                                        </div>
                                    </div>


                                    {addUserFromData.user_id && addUserFromData.user_id != "" ?
                                        <div className="col-md-12">
                                            <div className="userDetailsEditView">
                                                <div className="row">
                                                    <div className="col-md-12">
                                                        <h3 className="header_title">Edit User</h3>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="row">
                                                            <div className="col-md-12 required">
                                                                <CustomInput
                                                                    parentClassName="input_field_inner"
                                                                    labelName={t('userName')}
                                                                    errorLabel={addUserFromDataError.name}
                                                                    name="name"
                                                                    type="text"
                                                                    value={addUserFromData.name}
                                                                    labelPresent={true}
                                                                    onChange={(e) => this.props.addUserFromDataChange(e, "name")}
                                                                />
                                                            </div>
                                                            <div className="col-md-12 required">
                                                                <CustomInput
                                                                    parentClassName="input_field_inner"
                                                                    labelName={t('userEmail')}
                                                                    errorLabel={addUserFromDataError.email}
                                                                    name="email"
                                                                    type="text"
                                                                    value={addUserFromData.email}
                                                                    labelPresent={true}
                                                                    onChange={(e) => this.props.addUserFromDataChange(e, "email")}
                                                                //readOnly={true}
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="user_add_img modprofile">
                                                            <div className="userProfileImg">
                                                                {!this.props.addUserImagePreviewShow ?
                                                                    <label className="custom-file-upload">
                                                                        <span className="filetext">
                                                                            <img src={addUserImageSelected} />
                                                                        </span>
                                                                        <span className="plusicon">
                                                                            <i className="fa fa-plus" aria-hidden="true"></i>
                                                                            <input type="file" onChange={addUserImageChanged} />
                                                                        </span>
                                                                    </label>
                                                                    :
                                                                    <label className="custom-file-upload">
                                                                        <img src={addUserImageSelected} />
                                                                        <span className="plusicon">
                                                                            <i className="fa fa-plus" aria-hidden="true"></i>
                                                                            <input type="file" onChange={addUserImageChanged} />
                                                                        </span>
                                                                    </label>
                                                                }

                                                                <div className="col-md-12 errorClass error_div">{addUserImageError}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-md-6">
                                                        <CustomInput
                                                            parentClassName="input_field_inner phoneValid"
                                                            labelName={t('phonenumber')}
                                                            errorLabel={addUserInfoFromDataError.phone_no}
                                                            name="phone_no"
                                                            type="text"
                                                            value={addUserInfoFromData.phone_no}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.addUserInfoFromDataChange(e, "phone_no")}

                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <CustomInput
                                                            parentClassName="input_field_inner"
                                                            labelName="Address line 1"
                                                            //errorLabel={this.props.fromDataError.address_line1}
                                                            name="address_line1"
                                                            type="text"
                                                            value={addUserInfoFromData.address_line1}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.addUserInfoFromDataChange(e, "address_line1")}
                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <CustomInput
                                                            parentClassName="input_field_inner"
                                                            labelName="Address line 2"
                                                            //errorLabel={}
                                                            name="address_line2"
                                                            type="text"
                                                            value={addUserInfoFromData.address_line2}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.addUserInfoFromDataChange(e, "address_line2")}

                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <CustomInput
                                                            parentClassName="input_field_inner"
                                                            labelName={t('city')}
                                                            errorLabel={addUserInfoFromDataError.city}
                                                            name="city"
                                                            type="textarea"
                                                            value={addUserInfoFromData.city}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.addUserInfoFromDataChange(e, "city")}

                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <CustomInput
                                                            parentClassName="input_field_inner"
                                                            labelName="State"
                                                            //errorLabel={this.props.fromDataError.state}
                                                            name="state"
                                                            type="text"
                                                            value={addUserInfoFromData.state}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.addUserInfoFromDataChange(e, "state")}

                                                        />
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="dropdowninnerbox">
                                                            <label>Country</label>
                                                            <AutosuggestComponent
                                                                handleOnChange={(e) => this.props.addUserInfoFromDataChange(e, "country")}
                                                                options={this.props.countryList}
                                                                selectedValue={this.props.addUserInfoFromData.country}
                                                                name=''
                                                                isMulti={false}
                                                                placeholder=""
                                                                isDisabled={false}
                                                                isSearchable={true}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <CustomInput
                                                            parentClassName="input_field_inner"
                                                            labelName="Zip code"
                                                            //errorLabel={this.props.fromDataError.zip_code}
                                                            name="zip_code"
                                                            type="text"
                                                            value={addUserInfoFromData.zip_code}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.addUserInfoFromDataChange(e, "zip_code")}

                                                        />
                                                    </div>
                                                    <div className="col-md-6 custom_checkboxInner">
                                                        <label className="custom_checkbox_tick">{t('active')}
                                                            <input type="checkbox" checked={addUserFromData.status} onChange={(e) => this.props.addUserFromDataChange(e, "status")} />
                                                            <span className="checkmarkCheckbox"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        : null}
                                </div>
                            </div>
                        </div>
                        <div className="col-md-12 modfooterbtn">
                            <button type="button" className="savebtn" onClick={this.props.addOrganization} disabled={this.props.saveButtonDisableEditModal}>{fromData.org_id == "" ? t('Ajouter') : t('edit')}</button>
                        </div>

                    </div>
                </div>
                {
                    imageEditFrom == 'org' ?
                        <ModalGlobal
                            show={this.props.imageCropModalFlag}
                            onHide={this.props.imageCropModalHide}
                            onCancel={this.props.imageCropModalHide}
                            onSave={this.props.imageCropDataSave}
                            className="modalcustomize cropmodalcontent"
                            bodyClassName="cropmodalcontentbody"
                            headerclassName="close_btn_icon"
                            title={t('cropimage')}
                            footer={true}
                            closeButton={true}
                            saveButtonLabel={t('crop')}
                            saveButtonClassName="delconfirmbtn btn btn-primary"
                            cancelButtonClassName="delcancelbtn btn btn-primary"
                            body={
                                <ImageCropContent
                                    onImageLoaded={this.props.onImageLoaded}
                                    onComplete={this.props.onCropComplete}
                                    onCropChange={this.props.onCropChange}
                                    crop={this.props.crop}
                                    croppedImageUrl={this.props.croppedImageUrl}
                                    src={this.props.src}
                                    onCropComplete={this.props.onCropComplete}
                                    imageCropModalShow={this.props.imageCropModalShow}
                                />
                            }
                        />
                        :
                        <ModalGlobal
                            show={this.props.imageCropModalFlag}
                            onHide={this.props.imageCropModalHide}
                            onCancel={this.props.imageCropModalHide}
                            onSave={this.props.imageCropDataSave}
                            className="modalcustomize cropmodalcontent"
                            bodyClassName="cropmodalcontentbody"
                            headerclassName="close_btn_icon"
                            title={t('cropimage')}
                            footer={true}
                            closeButton={true}
                            saveButtonLabel={t('crop')}
                            saveButtonClassName="delconfirmbtn btn btn-primary"
                            cancelButtonClassName="delcancelbtn btn btn-primary"
                            body={
                                <ImageCropContent
                                    onImageLoaded={this.props.onImageLoaded}
                                    onComplete={this.props.onCropComplete}
                                    onCropChange={this.props.onCropChange}
                                    crop={this.props.crop}
                                    croppedImageUrl={this.props.croppedImageUrl}
                                    src={this.props.src}
                                    onCropComplete={this.props.onCropCompleteForUser}
                                    imageCropModalShow={this.props.imageCropModalShow}
                                />
                            }
                        />

                }

            </>
        );
    }
}

OrganizationModalContent.propTypes = {

}

OrganizationModalContent.defaultProps = {
    className: "modalcustomize mondimension",
    headerclassName: "close_btn_icon",
    buttonClassName: "btn btn-primary",
    BodyContent: "",
    buttonContent: "",
    bodyClassName: ""
}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(OrganizationModalContent)));