import React, { Component } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Utility from '../../../../../Utility/Utility';
import DatePicker, { utils } from 'react-modern-calendar-datepicker';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import ReactCrop from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import ImageCropContent from '../../../../../Utility/Components/ImageCropContent'
import ModalGlobal from '../../../../../Utility/Components/ModalGlobal'


class AddUserModalContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 16 / 9
            },
            croppedImageUrl: "",
        }

    }



    render() {
        const { addUserImageChanged, addUserImageSelected, t, addUserFromData, addUserFromDataError, addUserImageError, addUserInfoFromDataError, addUserInfoFromData } = this.props;
        // console.log("addUserFromData",addUserFromData)
        return (
            <>
                <div className="modalinnerbody">
                    <div className="col-md-12">
                        <div className="innerbodydimension">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="row">
                                        <div className="col-md-12 required">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName={t('userName')}
                                                errorLabel={addUserFromDataError.name}
                                                name="name"
                                                type="text"
                                                value={addUserFromData.name}
                                                labelPresent={true}
                                                onChange={(e) => this.props.addUserFromDataChange(e, "name")}

                                            />
                                        </div>
                                        <div className="col-md-12 required">
                                            <CustomInput
                                                parentClassName="input_field_inner"
                                                labelName={t('userEmail')}
                                                errorLabel={addUserFromDataError.email}
                                                name="email"
                                                type="text"
                                                value={addUserFromData.email}
                                                labelPresent={true}
                                                onChange={(e) => this.props.addUserFromDataChange(e, "email")}

                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="user_add_img modprofile">
                                        <div className="userProfileImg">
                                            {!this.props.addUserImagePreviewShow ?
                                                <label className="custom-file-upload">
                                                    <span className="filetext">
                                                        <img src={addUserImageSelected} />
                                                    </span>
                                                    <span className="plusicon">
                                                        <i className="fa fa-plus" aria-hidden="true"></i>
                                                        <input type="file" onChange={addUserImageChanged} />
                                                    </span>
                                                </label>
                                                :
                                                <label className="custom-file-upload">
                                                    <img src={addUserImageSelected} />
                                                    <span className="plusicon">
                                                        <i className="fa fa-plus" aria-hidden="true"></i>
                                                        <input type="file" onChange={addUserImageChanged} />
                                                    </span>
                                                </label>
                                            }

                                            <div className="col-md-12 errorClass error_div">{addUserImageError}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner phoneValid"
                                        labelName={t('phonenumber')}
                                        errorLabel={addUserInfoFromDataError.phone_no}
                                        name="phone_no"
                                        type="text"
                                        value={addUserInfoFromData.phone_no}
                                        labelPresent={true}
                                        onChange={(e) => this.props.addUserInfoFromDataChange(e, "phone_no")}

                                    />
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner"
                                        labelName="Address line 1"
                                        //errorLabel={this.props.fromDataError.address_line1}
                                        name="address_line1"
                                        type="text"
                                        value={addUserInfoFromData.address_line1}
                                        labelPresent={true}
                                        onChange={(e) => this.props.addUserInfoFromDataChange(e, "address_line1")}
                                    />
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner"
                                        labelName="Address line 2"
                                        //errorLabel={}
                                        name="address_line2"
                                        type="text"
                                        value={addUserInfoFromData.address_line2}
                                        labelPresent={true}
                                        onChange={(e) => this.props.addUserInfoFromDataChange(e, "address_line2")}

                                    />
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner"
                                        labelName={t('city')}
                                        //errorLabel={addUserInfoFromDataError.city}
                                        name="city"
                                        type="textarea"
                                        value={addUserInfoFromData.city}
                                        labelPresent={true}
                                        onChange={(e) => this.props.addUserInfoFromDataChange(e, "city")}

                                    />
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner"
                                        labelName="State"
                                        //errorLabel={this.props.fromDataError.state}
                                        name="state"
                                        type="text"
                                        value={addUserInfoFromData.state}
                                        labelPresent={true}
                                        onChange={(e) => this.props.addUserInfoFromDataChange(e, "state")}

                                    />
                                </div>
                                <div className="col-md-6">
                                    <div className="dropdowninnerbox">
                                        <label>Country</label>
                                        <AutosuggestComponent
                                            handleOnChange={(e) => this.props.addUserInfoFromDataChange(e, "country")}
                                            options={this.props.countryList}
                                            selectedValue={this.props.addUserInfoFromData.country}
                                            name=''
                                            isMulti={false}
                                            placeholder=""
                                            isDisabled={false}
                                            isSearchable={true}
                                        />
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <CustomInput
                                        parentClassName="input_field_inner"
                                        labelName="Zip code"
                                        //errorLabel={this.props.fromDataError.zip_code}
                                        name="zip_code"
                                        type="text"
                                        value={addUserInfoFromData.zip_code}
                                        labelPresent={true}
                                        onChange={(e) => this.props.addUserInfoFromDataChange(e, "zip_code")}

                                    />
                                </div>
                                <div className="col-md-6 custom_checkboxInner">
                                    <label className="custom_checkbox_tick">{t('active')}
                                        <input type="checkbox" checked={addUserFromData.status} onChange={(e) => this.props.addUserFromDataChange(e, "status")} />
                                        <span className="checkmarkCheckbox"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-12 text-center topspace">
                            <button type="button" className="modbtn" onClick={this.props.addEditUser}>{t('Ajouter')}</button>
                        </div>

                    </div>

                </div>

                <ModalGlobal
                    show={this.props.imageCropModalFlag}
                    onHide={this.props.imageCropModalHide}
                    onCancel={this.props.imageCropModalHide}
                    onSave={this.props.imageCropDataSave}
                    className="modalcustomize cropmodalcontent"
                    bodyClassName="cropmodalcontentbody"
                    headerclassName="close_btn_icon"
                    title={t('cropimage')}
                    footer={true}
                    closeButton={true}
                    saveButtonLabel={t('crop')}
                    saveButtonClassName="delconfirmbtn btn btn-primary"
                    cancelButtonClassName="delcancelbtn btn btn-primary"
                    body={
                        <ImageCropContent
                            onImageLoaded={this.props.onImageLoaded}
                            onComplete={this.props.onCropComplete}
                            onCropChange={this.props.onCropChange}
                            crop={this.props.crop}
                            croppedImageUrl={this.props.croppedImageUrl}
                            src={this.props.src}
                            onCropComplete={this.props.onCropCompleteForUser}
                            imageCropModalShow={this.props.imageCropModalShow}
                        />
                    }
                />
            </>
        );
    }
}

AddUserModalContent.propTypes = {

}

AddUserModalContent.defaultProps = {
    className: "modalcustomize mondimension",
    headerclassName: "close_btn_icon",
    buttonClassName: "btn btn-primary",
    BodyContent: "",
    buttonContent: "",
    bodyClassName: ""
}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(AddUserModalContent)));