import React, { Component } from 'react';
import UsersModalContent from './Components/UsersModalContent'
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import * as UsersController from './Controller/UsersController';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import ConfirmationAlert from '../../../../Utility/Components/ConfirmationAlert';
import { loaderStateTrue, loaderStateFalse } from '../../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../../Login/Actions/LoginAction';
import CustomInput from '../../../../Utility/Components/CustomInput';
import Utility from '../../../../Utility/Utility';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';
import ModalGlobal from '../../../../Utility/Components/ModalGlobal'
import HomeUtility from '../../Utility/Utility'
import moment from 'moment';
import Config from '../../../../Utility/Config';
import PopoverStickOnHover from '../../../../Utility/Components/PopoverStickOnHover';
import GridActionContent from '../../../../Utility/Components/GridActionContent'
import BootstrapSwitchButton from 'bootstrap-switch-button-react';
import DetailsViewModalContent from '../../../../Utility/Components/DetailsViewModalContent';
import { formatingFormData, formatingFormDataInfo } from './DataFormat/UserDataFormat'
import { setEditDataForUsers, setEditDataForInfo } from './DataFormat/UserSetEditDataSet'
import CountryWithCode from '../../../../Utility/JsFolder/CountryWithCode';

class Users extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modules: [InfiniteRowModelModule],
            tooltipShowDelay: 0,
            columnDefs: [
                {
                    headerName: "",
                    field: "profile_img_temp",
                    maxWidth: 72,
                    cellRendererFramework: (params) => {
                        if (params && params.data) {
                            if (params.data.profile_img_temp) {
                                return <div className="gridusericon">
                                    <PopoverStickOnHover
                                        data={params.data}
                                        placement="right"
                                    />
                                </div>
                            } else {
                                return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
                            }
                        } else {
                            return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
                        }
                    }
                },
                {
                    headerName: `${this.props.t('Name')}`,
                    field: "name",
                    minWidth: 200,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            let concatname = params.data.name
                            if (params.data.name && params.data.name && concatname.length > 20) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data && params.data.name != "" ? params.data.name : ""} </Tooltip>}>
                                        <span >
                                            {params.data && params.data.name != "" ? params.data.name : ""}
                                        </span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return (<div className="usercursor"><span className="textrenderview">{params.data && params.data.name != "" ? params.data.name : ""} </span></div>)
                                //return null;
                            }

                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('Email')}`,
                    field: "email",
                    minWidth: 260,
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.email && params.data.email.length > 25) {
                                return <div className="usercursor"><span className="textrenderview">
                                    <OverlayTrigger overlay={<Tooltip>{params.data.email}</Tooltip>}>
                                        <span >{params.data.email}</span>
                                    </OverlayTrigger>
                                </span></div>
                            } else {
                                return <div className="usercursor"><span className="textnowrapview">{params.data.email}</span></div>
                            }
                        } else {
                            return null;
                        }
                    },
                    //resizable: true
                },
                {
                    headerName: `${this.props.t('customers')}`,
                    field: "customers",
                    minWidth: 190,
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.Customer && params.data.Customer.length > 0) {
                                if (params.data.Customer[0]) {
                                    return <div className="infoviewbox"><div className="infoviewlabel">{params.data.Customer[0].name}</div> <div className="infoviewicon" onClick={this.detailsViewModalfunction.bind(this, params.data)}>{params.data.Customer.length > 1 ? <i className="fa fa-info-circle" onClick={(e) => this.showCoustomerInfo(e, params.data.Customer)}></i> : ""}</div></div>
                                } else {
                                    return null
                                }
                            } else {
                                return null
                            }
                        } else {
                            return null
                        }
                    },
                },
                {
                    headerName: `${this.props.t('city')}`,
                    field: "city",
                    minWidth: 150,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.userinfo) {
                                //console.log("params.data.userinfo.city", params.data.userinfo?.city)
                                if (params.data.userinfo?.city) {
                                    if (params.data.userinfo?.city.length > 20) {
                                        return <div className="usercursor"><span className="textrenderview">
                                            <OverlayTrigger overlay={<Tooltip>{params.data && params.data.userinfo?.city != "" ? params.data.userinfo?.city : ""}</Tooltip>}>
                                                <span >{params.data && params.data.userinfo?.city != "" ? params.data.userinfo?.city : ""}</span>
                                            </OverlayTrigger>
                                        </span></div>
                                    } else {
                                        return <div><span className="textnowrapview">{params.data && params.data.userinfo?.city != "" ? params.data.userinfo?.city : ""}</span></div>
                                    }
                                } else {
                                    return null;
                                }
                            } else {
                                return null;
                            }

                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('country')}`,
                    field: "country",
                    minWidth: 120,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.userinfo) {
                                //console.log("params.data.userinfo.country", params.data.userinfo?.country)
                                if (params.data.userinfo?.country) {
                                    if (params.data.userinfo?.country.length > 20) {
                                        return <div className="usercursor"><span className="textrenderview">
                                            <OverlayTrigger overlay={<Tooltip>{params.data && params.data.userinfo?.country != "" ? params.data.userinfo?.country : ""}</Tooltip>}>
                                                <span >{params.data && params.data.userinfo?.country != "" ? params.data.userinfo?.country : ""}</span>
                                            </OverlayTrigger>
                                        </span></div>
                                    } else {
                                        return <div><span className="textnowrapview">{params.data && params.data.userinfo?.country != "" ? params.data.userinfo?.country : ""}</span></div>
                                    }
                                } else {
                                    return null;
                                }
                            } else {
                                return null;
                            }

                        } else {
                            return null;
                        }
                    },
                },
                {
                    headerName: `${this.props.t('phonenumber')}`,
                    field: "phone_no",
                    minWidth: 200,
                    //resizable: true
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            if (params.data.userinfo) {
                                if (params.data.userinfo?.phone_no) {
                                    if (params.data.userinfo?.phone_no.length > 20) {
                                        return <div className="usercursor"><span className="textrenderview">
                                            <OverlayTrigger overlay={<Tooltip>{params.data && params.data.userinfo?.phone_no != "" ? params.data.userinfo?.phone_no : ""}</Tooltip>}>
                                                <span >{params.data && params.data.userinfo?.phone_no != "" ? params.data.userinfo?.phone_no : ""}</span>
                                            </OverlayTrigger>
                                        </span></div>
                                    } else {
                                        return <div><span className="textnowrapview">{params.data && params.data.userinfo?.phone_no != "" ? params.data.userinfo?.phone_no : ""}</span></div>
                                    }
                                } else {
                                    return null;
                                }
                            } else {
                                return null;
                            }

                        } else {
                            return null;
                        }
                    },
                },

                {
                    headerName: `${this.props.t('status')}`,
                    field: "status",
                    minWidth: 90,
                    cellRendererFramework: (params) => {
                        if (params) {
                            if (params.data) {
                                return <button className="edittext">
                                    <div className="switch_btn_customize">
                                        <BootstrapSwitchButton checked={params.data && params.data.status ? params.data.status : false} onChange={this.handleChangeSwitchButton.bind(this, params.data)} />
                                    </div>
                                </button>
                            } else {
                                return null
                            }
                        } else {
                            return null
                        }
                    },
                },
                {
                    headerName: "",
                    field: "edit",
                    maxWidth: 50,
                    cellRendererFramework: (params) => {
                        if (params.data) {
                            return <div className="actionablePopup">
                                <button className="ellipsisIcon" onClick={this.actionModalfunction.bind(this, params)}><i className="fa fa-ellipsis-v"></i></button>
                            </div>
                        } else {
                            return null;
                        }
                    },
                }
            ],
            defaultColDef: {
                flex: 1,
                //resizable: true,
                minWidth: 50

            },
            components: {
                loadingRenderer: (params) => {
                    //console.log("params=================== worker", params)
                    //return null;
                    if (params.value !== undefined) {
                        return params.value;
                    } else {
                        return '<img src="https://www.ag-grid.com/example-assets/loading.gif">';
                    }
                },
            },



            //Users Tab State
            usersModal: false,

            //user img add
            addProfileImagePreviewShow: false,
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImageError: "",

            //IMage crop
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 1 / 1
            },
            croppedImageUrl: "",

            imageCropModalFlag: false,

            fromData: {
                "name": "",
                "email": "",
                "profileImage": "",
                "status": true,
            },
            fromDataError: {
                "name": "",
                "status": "",
            },
            fromDataInfo: {
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "zip_code": "",
                "country": "",
                "phone_no": "",
            },
            fromDataInfoError: {
                //"city": "",
                //"country": "",
                "phone_no": "",
            },
            fromDataCustomer: {
                "customers_name": [],
            },
            fromDataCustomerError: {
                "customers_name": "",
            },
            actionModalflag: false,
            deleteConfirmationAlertModal: false,
            editedId: "",
            customersList: [],
            gridObjData: "",
            usersName: "",
            exheaderContent: "",
            saveButtonDisableUsersEditModal: true,
            detailsViewModalflag: false,
            detailsHeader: "",
            popupCustomer: [],
            customerReserveData: [],
            disabledEmail: true,
            usersUserInfoChanges: true,
            reserveFromData: "",
            profileImageChangeEditMode: false,
            reserveFromDataInfo: "",
            countryList: [],

        }
        this.codeOutsideClickRef = React.createRef();

    }

    showCoustomerInfo = (e, customerList) => {
        //console.log("customerList===",customerList)
        //console.log("e===",e)
        this.setState({
            popupCustomer: customerList
        })
    }


    onGridReady = (params) => {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridparams = params;
        var datasource = this.serverSideDataSource()
        params.api.setDatasource(datasource);
    };

    serverSideDataSource = () => {
        const { usersName } = this.state;
        const { userCredentials } = this.props;
        let that = this
        return {
            getRows(params) {
                //console.log(JSON.stringify(params, null, 1));
                const { startRow, endRow, filterModel, sortModel } = params
                const { loaderStateTrue, loaderStateFalse } = that.props;
                loaderStateTrue();
                let filters = {};
                let globalQueryParamshash = {};
                if (usersName != "") {
                    globalQueryParamshash['name'] = usersName
                    filters['filter_op'] = { "name": "substring" }
                }

                globalQueryParamshash["offset"] = startRow;
                globalQueryParamshash["limit"] = endRow;
                globalQueryParamshash["type"] = "user";
                globalQueryParamshash["org_id"] = userCredentials.user_details.org_id;

                filters['filters'] = globalQueryParamshash
                UsersController.usersListing(filters).then((response) => {
                    if (response.success) {
                        let promiseArr = []
                        response.data.map((item, index) => {
                            let promise = new Promise((resolve, reject) => {
                                that.logoImageUi(item._id).then((data) => {
                                    item["profile_img_temp"] = data
                                    resolve(item)
                                })

                            })
                            promiseArr.push(promise)
                        })

                        Promise.all(promiseArr).then((values) => {
                            //console.log("values==========>", values)
                            params.successCallback(values, response.total);
                        });
                        //params.successCallback(response.data, 499);
                        //that.setImageDataTemp(response.data)

                    } else {
                        console.error(error);
                        params.failCallback();
                        Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
                    }
                    loaderStateFalse();
                }).catch((error) => {
                    console.error("************error*************", error)
                    if (error) {
                        //Utility.toastNotifications(error.message, "Error", "error");
                    }
                    loaderStateFalse();
                    if (error.message == "Network Error") {
                        // Utility.toastNotifications("Please login", "Error", "error");
                        // this.props.logOutApp().then(
                        //     () => this.props.history.push("/")
                        // );
                    }
                });
            }
        };
    }


    resetDataGrid = () => {
        this.gridparams.api.purgeServerSideCache(null)
        var datasource = this.serverSideDataSource()
        this.gridparams.api.setDatasource(datasource);

    }


    componentDidMount = () => {
        document.body.addEventListener('mousedown', this.handleClickOutside.bind(this));
        this.customerList();
        this.countryModefy();
    }
    componentWillUnmount() {
        document.body.removeEventListener('mousedown', this.handleClickOutside.bind(this));
    }
    handleClickOutside(event) {
        if (this.codeOutsideClickRef.current != null) {
            if (this.codeOutsideClickRef && this.codeOutsideClickRef.current && !this.codeOutsideClickRef.current.contains(event.target)) {

                this.setState({
                    actionModalflag: false
                })
            }
        }

    }

    countryModefy = () => {

        const countryData = CountryWithCode.map(object => {
            return { ...object, "value": object.country, "label": object.country };
        });
        //console.log("arrWithLabelValue====", arrWithLabelValue)
        this.setState({
            countryList: countryData
        })
    }

    customerList = () => {
        const { loaderStateTrue, loaderStateFalse, userCredentials } = this.props;
        loaderStateTrue();
        let data = {
            "org_id": userCredentials.user_details.org_id,
            "active": true
        }
        let filters = {
            "filters": data
        }
        UsersController.customerList(filters).then((response) => {
            console.log("filters=======", filters)
            console.log("response=======", response)
            let arry = []
            if (response.success) {
                response.data.map((data, index) => {
                    arry.push({ label: data.name, value: data._id })
                })
                this.setState({
                    customersList: arry
                })

            } else {

                Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
            }
            loaderStateFalse();
        }).catch((error) => {
            loaderStateFalse();
        });
    }

    logoImageUi = (id) => {
        const promise = new Promise((resolve, reject) => {
            const { loaderStateTrue, loaderStateFalse } = this.props;
            loaderStateTrue();
            let data = {};
            data["filters"] = JSON.stringify(Config.thumbnailSize)
            UsersController.usersDetails(id, data).then((response) => {
                //console.log("logoImageUi===", response)
                if (response.success) {
                    //console.log("response.data[0]========", response.data[0].user_details)
                    let responseUserDetails = response.data[0].profile_img
                    if (responseUserDetails && Object.keys(responseUserDetails).length > 0) {
                        resolve(responseUserDetails.file_obj)
                    } else {
                        resolve(require('../../../../Utility/Public/images/usericon.png'))
                    }
                }
                loaderStateFalse();
            }).catch((error) => {
                //console.error("************error*************", error)
                if (error) {
                    //Utility.toastNotifications(error.message, "Error", "error");
                }
                loaderStateFalse();
                if (error.message == "Network Error") {
                    /*Utility.toastNotifications("Please login", "Error", "error");
                    this.props.logOutApp().then(
                        () => this.props.history.push("/")
                    );*/
                }
            });
        })
        return promise;
    }


    closeUsersModal = () => {
        const { t } = this.props
        this.setState({
            usersModal: false,
        }, () => {
            this.resetUsersFrom();
        })


    }

    //Image url crop 
    addInputProfileImageChanged = (event) => {

        let { fromData } = this.state;
        let targetFileSplit = event.target.files[0].name.split('.');
        let lastElement = targetFileSplit.pop();
        let user_profile_image = {
            "file_name": "",
            "file_obj": ""
        };
        if (lastElement == 'JPEG' || lastElement == 'jpeg' || lastElement == 'jpg' || lastElement == 'JPG' || lastElement == 'png' || lastElement == 'PNG' || lastElement == '') {
            const fsize = event.target.files[0].size;
            const file = Math.round((fsize / 1024));
            if (file >= 300) {
                Utility.toastNotifications(this.props.t('imageUploadAlert'), "Warning", "warning");
            } else {
                this.setState({
                    imageCropModalFlag: true
                })
                if (event.target.files && event.target.files.length > 0) {
                    const reader = new FileReader();
                    reader.addEventListener('load', () =>
                        this.setState({ src: reader.result })
                    );
                    reader.readAsDataURL(event.target.files[0]);
                    user_profile_image["file_name"] = event.target.files[0].name
                    user_profile_image["file_obj"] = ""
                    fromData["profileImage"] = user_profile_image
                    this.setState({
                        fromData,
                        workerModalChange: true,
                        traprofileImageError: "",
                        addProfileImagePreviewShow: true,
                        addProfileImageError: "",
                    })
                }
            }

        } else {
            fromData["profileImage"] = ""
            this.setState({
                traprofileImageError: this.props.t('requiredField'),
                addProfileImagePreviewShow: false,
                addprofileImageSelected: 'Add Image',
                workerModalChange: true
            })
        }
    }



    getBase64(file, cb) {
        let reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {
            cb(reader.result)
        };
        reader.onerror = function (error) {
            //console.log('Error: ', error);
        };
    }

    onImageLoaded = (image) => {
        //console.log("onImageLoaded=====", image)
        this.imageRef = image;
    };

    onCropComplete = (crop) => {
        this.makeClientCrop(crop);
        this.setState({
            saveButtonDisableUsersEditModal: false,
            profileImageChangeEditMode: true,
        })
    };

    onCropChange = (crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.setState({ crop });
    };

    async makeClientCrop(crop) {
        const { fromData } = this.state;
        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                'newFile.jpeg'
            );
            let user_profile_image = {}
            this.setState({ addprofileImageSelected: croppedImageUrl }, () => {
                user_profile_image["file_name"] = this.state.fromData.profileImage.file_name
                user_profile_image["file_obj"] = this.state.addprofileImageSelected
                fromData["profileImage"] = user_profile_image
                this.setState({
                    fromData
                })
            });

        }
    }

    getCroppedImg = (image, crop, fileName) => {
        const canvas = document.createElement('canvas');
        const pixelRatio = window.devicePixelRatio;
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext('2d');

        canvas.width = crop.width * pixelRatio * scaleX;
        canvas.height = crop.height * pixelRatio * scaleY;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width * scaleX,
            crop.height * scaleY
        );

        const base64Image = canvas.toDataURL('image/jpeg');
        return base64Image

    }

    //Image url crop

    imageCropModalShow = () => {
        this.setState({
            imageCropModalFlag: true
        })
    }

    imageCropModalHide = () => {
        const { fromData } = this.state;
        fromData["profileImage"] = ""
        this.setState({
            imageCropModalFlag: false,
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImageError: "",
            fromData,
            addProfileImagePreviewShow: false,
            saveButtonDisableUsersEditModal: true
        })
    }

    imageCropDataSave = () => {
        this.setState({
            imageCropModalFlag: false
        })
    }

    handleUserSearchBar = (e) => {
        this.setState({
            usersName: e.target.value
        }, () => {
            if (this.state.usersName.length > 2) {
                this.resetDataGrid()
            }
            if (this.state.usersName == "") {
                this.resetDataGrid()
            }
        })

    }
    clearSearchValue = () => {
        this.setState({
            usersName: ""
        }, () => {
            this.resetDataGrid()
        })
    }

    usersModalfunction = () => {
        this.setState({
            usersModal: true,
            exheaderContent: this.props.t('addUser'),
            disabledEmail: true,

        }, () => {

        })

    }

    handelChange = (event, type) => {
        //console.log("event=======", event)
        //console.log("type=======", type)

        let fromDataTemp = Object.assign({}, this.state.fromData);
        let fromDataTempError = Object.assign({}, this.state.fromDataError);

        let fromDataCustomerTemp = Object.assign({}, this.state.fromDataCustomer);
        let fromDataCustomerTempError = Object.assign({}, this.state.fromDataCustomerError);

        if (type == "name") {
            if (event.target.value != "") {
                fromDataTemp['name'] = event.target.value;
                fromDataTempError['name'] = ""
            } else {
                fromDataTemp['name'] = "";
                fromDataTempError['name'] = this.props.t('requiredField')
            }
        }

        if (type == "email") {
            if (event.target.value != "") {
                fromDataTemp['email'] = event.target.value;;
                fromDataTempError['email'] = ""
            } else {
                fromDataTemp['email'] = "";
                fromDataTempError['email'] = this.props.t('requiredField')
            }
        }

        if (type == "customers_name") {
            if (event) {
                fromDataCustomerTemp['customers_name'] = [event];
                fromDataCustomerTempError['customers_name'] = ""
            } else {
                fromDataCustomerTemp['customers_name'] = [];
                fromDataCustomerTempError['customers_name'] = this.props.t('requiredField')
            }
        }

        if (type == "status") {
            if (event.target.checked) {
                fromDataTemp['status'] = 1
                fromDataTempError['status'] = ""
            } else {
                fromDataTemp['status'] = 0
                fromDataTempError['status'] = this.props.t('requiredField')
            }

        }
        this.setState({
            fromData: fromDataTemp,
            fromDataError: fromDataTempError,
            fromDataCustomer: fromDataCustomerTemp,
            fromDataCustomerError: fromDataCustomerTempError,
            saveButtonDisableUsersEditModal: false,
        })


    }

    handelChangeInfo = (event, type) => {
        //console.log("event=======", event)
        //console.log("type=======", type)

        let fromDataInfoTemp = Object.assign({}, this.state.fromDataInfo);
        let fromDataTempInfoError = Object.assign({}, this.state.fromDataInfoError);

        if (type == "address_line1") {
            if (event.target.value != "") {
                fromDataInfoTemp['address_line1'] = event.target.value;
                fromDataTempInfoError['address_line1'] = ""
            } else {
                fromDataInfoTemp['address_line1'] = "";
                fromDataTempInfoError['address_line1'] = ""
            }
        }
        if (type == "address_line2") {
            if (event.target.value != "") {
                fromDataInfoTemp['address_line2'] = event.target.value;
                fromDataTempInfoError['address_line2'] = ""
            } else {
                fromDataInfoTemp['address_line2'] = "";
                fromDataTempInfoError['address_line2'] = ""
            }
        }
        if (type == "city") {
            if (event.target.value != "") {
                fromDataInfoTemp['city'] = event.target.value;
                fromDataTempInfoError['city'] = ""
            } else {
                fromDataInfoTemp['city'] = "";
                fromDataTempInfoError['city'] = ""
            }
        }
        if (type == "state") {
            if (event.target.value != "") {
                fromDataInfoTemp['state'] = event.target.value;
                fromDataTempInfoError['state'] = ""
            } else {
                fromDataInfoTemp['state'] = "";
                fromDataTempInfoError['state'] = ""
            }
        }
        if (type == "country") {
            if (event != "") {
                fromDataInfoTemp['country'] = event;
                fromDataTempInfoError['country'] = ""
            } else {
                fromDataInfoTemp['country'] = "";
                fromDataTempInfoError['country'] = this.props.t('requiredField')
            }
        }

        if (type == "phone_no") {
            if (event.target.value == "") {
                fromDataInfoTemp['phone_no'] = event.target.value;
                fromDataTempInfoError['phone_no'] = ""
            } else {
                let phoneValidate = HomeUtility.validate_Phone_Number(event.target.value);
                //console.log("phoneValidate",phoneValidate)
                if (phoneValidate) {
                    fromDataInfoTemp['phone_no'] = event.target.value;
                    fromDataTempInfoError['phone_no'] = ""

                } else {
                    fromDataInfoTemp['phone_no'] = event.target.value;
                    fromDataTempInfoError['phone_no'] = this.props.t('validphonenumber')
                }
            }
        }
        if (type == "zip_code") {
            if (!isNaN(event.target.value) && event.target.value != "") {
                fromDataInfoTemp['zip_code'] = event.target.value;
                fromDataTempInfoError['zip_code'] = ""
            } else {
                fromDataInfoTemp['zip_code'] = "";
                fromDataTempInfoError['zip_code'] = ""
            }
        }

        this.setState({
            fromDataInfo: fromDataInfoTemp,
            fromDataInfoError: fromDataTempInfoError,
            saveButtonDisableUsersEditModal: false,
            usersUserInfoChanges: false
        }, () => {
            //console.log("fromDataInfo", this.state.fromDataInfo)
        })


    }

    validUsersData = () => {
        let fromDataTemp = Object.assign({}, this.state.fromData);
        let fromDataTempError = Object.assign({}, this.state.fromDataError);
        let fromDataInfoTemp = Object.assign({}, this.state.fromDataInfo);
        let fromDataTempInfoError = Object.assign({}, this.state.fromDataInfoError);
        let fromDataCustomerTemp = Object.assign({}, this.state.fromDataCustomer);
        let fromDataCustomerTempError = Object.assign({}, this.state.fromDataCustomerError);
        let valid = true;
        //console.log("fromDataTemp", fromDataTemp)

        if (fromDataTemp.name == "") {
            fromDataTempError['name'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataTempError['name'] = ""
        }

        if (fromDataTemp.email == "") {
            fromDataTempError['email'] = this.props.t('requiredField')
            valid = false;
        } else {
            var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!expr.test(fromDataTemp.email)) {
                fromDataTempError['email'] = this.props.t('validEmail')
                valid = false;
            } else {
                fromDataTempError['email'] = ""
            }
        }

        if (fromDataCustomerTemp.customers_name.length == 0) {
            fromDataCustomerTempError['customers_name'] = this.props.t('requiredField')
            valid = false;
        } else {
            fromDataCustomerTempError['customers_name'] = ""
        }

        let phoneValidate = HomeUtility.validate_Phone_Number(fromDataInfoTemp.phone_no);
        if (fromDataInfoTemp.phone_no != "") {
            if (phoneValidate) {
                fromDataTempInfoError['phone_no'] = ""
            } else {
                fromDataTempInfoError['phone_no'] = this.props.t('validphonenumber')
                valid = false;
            }
        }


        this.setState({
            fromDataError: fromDataTempError,
            fromDataInfoError: fromDataTempInfoError,
            fromDataCustomerError: fromDataCustomerTempError
        })
        return valid;

    }

    resetUsersFrom = () => {
        this.setState({
            fromData: {
                "name": "",
                "email": "",
                "status": true,
                "profileImage": "",
            },
            fromDataError: {
                "name": "",
                "email": "",
                "status": "",
                "profileImage": "",
            },
            fromDataInfo: {
                "address_line1": "",
                "address_line2": "",
                "city": "",
                "state": "",
                "zip_code": "",
                "country": "",
                "phone_no": "",
            },
            fromDataInfoError: {
                //"city": "",
                //"country": "",
                "phone_no": "",
            },
            fromDataCustomer: {
                "customers_name": [],
            },
            fromDataCustomerError: {
                "customers_name": "",
            },
            editedId: "",
            saveButtonDisableUsersEditModal: true,
            addprofileImageSelected: require('../../../../Utility/Public/images/profile-back.png'),
            addProfileImagePreviewShow: false,
            usersUserInfoChanges: true,
            customerReserveData: [],
            profileImageChangeEditMode: false,

        })
    }
    actionModalfunction = (gridObj, e) => {
        let width = (parseInt(e.clientX) - 280) + 'px'
        let height = (parseInt(e.clientY) - 70) + 'px'
        this.setState({
            actionModalflag: true,
            overlayHight: height,
            overlayWidth: width,
            gridObjData: gridObj
        })
    }

    setEditDataForCustomer = () => {
        const { gridObjData } = this.state;
        let customerDataArray = []
        gridObjData.data.Customer.map((item, idx) => {
            console.log("item=========", item)
            let _hash = {}
            _hash["value"] = item.id
            _hash["label"] = item.name
            _hash["id"] = gridObjData.data.OrgCustUserRelations[idx]._id
            customerDataArray.push(_hash)
        })
        this.setState({
            fromDataCustomer: {
                "customers_name": customerDataArray,
            },
            customerReserveData: customerDataArray,
            fromDataCustomerError: {
                "customers_name": "",
            },
        }, () => {
            console.log("fromDataCustomer set state===========", this.state.fromDataCustomer)
        })
    }


    editUsers = (obj) => {
        //console.log("obj", obj)
        this.setState({
            usersModal: true,
            exheaderContent: this.props.t('editUser'),
            saveButtonDisableUsersEditModal: true,
            disabledEmail: false
        }, () => {
            setEditDataForUsers(this.state.gridObjData).then((data) => {
                this.setState({
                    fromData: data,
                    reserveFromData: data,
                    editedId: this.state.gridObjData.data._id,
                    addProfileImagePreviewShow: true,
                    addprofileImageSelected: this.state.gridObjData.data.profile_img_temp,

                })
            });
            setEditDataForInfo(this.state.gridObjData).then((dataForInfo) => {
                this.setState({
                    fromDataInfo: dataForInfo,
                    reserveFromDataInfo: dataForInfo,
                    editedId: this.state.gridObjData.data._id,

                })
            });
            this.setEditDataForCustomer();
        })
    }


    deleteConfirmationModalShow = (obj) => {
        //console.log("obj=========", obj)
        this.setState({
            deleteConfirmationAlertModal: true,
            actionModalflag: false,
            enDeleteBodySecondContent: obj.data.name,
            usersDeleteObj: obj.data
        })
    }

    deleteConfirmationModalHide = () => {
        this.setState({
            deleteConfirmationAlertModal: false,
            enDeleteBodySecondContent: ""
        })
    }

    usersDeleteConfirmButton = () => {
        this.usersDeleteApi()
    }

    usersDeleteCancleButton = () => {
        this.deleteConfirmationModalHide();
    }

    usersDeleteApi = () => {
        const { usersDeleteObj } = this.state;

        const { loaderStateTrue, loaderStateFalse } = this.props;
        loaderStateTrue();
        let data = {}
        data['id'] = [usersDeleteObj._id]

        UsersController.usersDelete(data).then((response) => {
            if (response.success) {
                this.resetDataGrid()
                this.deleteConfirmationModalHide()
                this.resetUsersFrom()
                Utility.toastNotifications(response.data[0].message, "Success", "success")
            } else {
                Utility.toastNotifications(response.data[0].message, "Error", "error")
            }
            loaderStateFalse();
        }).catch((error) => {
            loaderStateFalse();
            this.deleteConfirmationModalHide()
        });
    }

    addUsers = () => {
        let valid = this.validUsersData();
        //console.log("validvalid++++++++", valid)
        const { loaderStateTrue, loaderStateFalse } = this.props;
        const { fromData, gridObjData, usersUserInfoChanges, editedId, reserveFromData, profileImageChangeEditMode } = this.state;
        console.log("editedId=====", editedId)

        if (valid) {
            //let data = this.formatingFormData();
            formatingFormData(fromData, reserveFromData, editedId, profileImageChangeEditMode).then((addUsersDataSet) => {
                let method = 'post';
                let id = ""
                //let addUsersDataSet = data;
                if (this.state.editedId != "") {
                    id = this.state.editedId,
                        method = "patch";
                    addUsersDataSet = addUsersDataSet[0]
                }
                loaderStateTrue();
                let apiCallFlag = true
                if (method == "patch") {
                    apiCallFlag = Object.keys(addUsersDataSet).length > 0 ? true : false
                } if (apiCallFlag) {
                    UsersController.usersAdd(addUsersDataSet, id, method).then((response) => {
                        loaderStateFalse();
                        if (method == 'post') {
                            if (response[0].success) {
                                console.log("response[0].data", response[0].data)
                                this.usersCustRelation(response[0].data[0]._id).then((usersCustRelationResponse) => {
                                    if (usersCustRelationResponse) {
                                        this.closeUsersModal()
                                        this.resetDataGrid()
                                        Utility.toastNotifications(response[0].message, "Success", "success");
                                    }
                                })
                                this.usersUsersInfo(response[0].data[0]._id, method)
                            } else {
                                Utility.toastNotifications(response[0].message, "Error", "error");
                            }
                        } else {
                            //console.log("")
                            if (response.success) {

                                //this.deleteCustomer(this.state.editedId);
                                //New customer add
                                /*this.usersCustRelation(this.state.editedId).then((response) => {
                                    if (response) {
                                        this.closeUsersModal()
                                        this.resetDataGrid()
                                        Utility.toastNotifications(response[0].message, "Success", "success");
                                    }
                                })*/
                                this.resetDataGrid()

                                Utility.toastNotifications(response.message, "Success", "success");
                            } else {
                                Utility.toastNotifications(response.message, "Error", "error");
                            }

                        }


                    }).catch((error) => {
                        loaderStateFalse();
                    });
                }
                if (method == "patch") {
                    if (usersUserInfoChanges == false) {
                        this.usersUsersInfo(null, method)
                    }
                    this.deleteCustomer(this.state.editedId);
                    this.usersCustRelation(this.state.editedId).then((response) => {
                        if (response) {
                            this.closeUsersModal()
                            this.resetDataGrid()
                            Utility.toastNotifications(response[0].message, "Success", "success");
                        }
                    })
                }
            })

        }

    }

    deleteCustomer = (id) => {
        const { loaderStateTrue, loaderStateFalse } = this.props;
        loaderStateTrue();

        const customerDifferenceData = this.state.customerReserveData.filter(({ value: id1 }) => !this.state.fromDataCustomer.customers_name.some(({ value: id2 }) => id2 === id1));
        //console.log("customerDifferenceData", customerDifferenceData)
        let arry = []
        customerDifferenceData.map((val, idx) => {
            arry.push(val.id)
        })
        if (arry.length > 0) {
            let data = {
                "id": arry
            }
            UsersController.deleteCustomer(data).then((response) => {
                //console.log("response===delete", response)
                loaderStateFalse();
                if (response.success) {
                    this.closeUsersModal()
                    this.resetDataGrid()
                    Utility.toastNotifications(response.data[0].message, "Success", "success");
                }
            }).catch((error) => {
                loaderStateFalse();
            });
        }
    }

    usersCustRelation = (userId) => {
        let promise = new Promise((resolve, reject) => {

            const { loaderStateTrue, loaderStateFalse, userCredentials } = this.props;
            const { fromDataCustomer, gridObjData, editedId } = this.state;
            let data = []

            if (editedId == "") {
                fromDataCustomer.customers_name.map((item) => {
                    let _hash = {}
                    _hash["org_id"] = userCredentials.user_details.org_id
                    _hash["user_id"] = userId
                    _hash["cust_id"] = item.value
                    data.push(_hash)
                })
            } else {
                fromDataCustomer.customers_name.map((val, idx) => {
                    if (!val.hasOwnProperty("id")) {
                        let _hash = {}
                        _hash["org_id"] = userCredentials.user_details.org_id
                        _hash["user_id"] = userId
                        _hash["cust_id"] = val.value
                        _hash["op_type"] = "edit"
                        data.push(_hash)
                    }
                })
            }
            // console.log("data==============", data)
            if (data.length > 0) {
                loaderStateTrue();
                UsersController.usersCustRelationPost(data).then((response) => {
                    loaderStateFalse();
                    if (response[0].success) {
                        resolve(response)
                    } else {
                        response.map((res, index) => {
                            Utility.toastNotifications(res.message, "Error", "error");
                        })
                        this.closeUsersModal()
                    }

                }).catch((error) => {
                    loaderStateFalse();
                });
            } else {
                this.closeUsersModal()
                this.resetDataGrid()
            }

        })
        return promise
    }

    handleChangeSwitchButton = (data) => {

        let dataHash = {};
        let id = data._id
        dataHash["status"] = data.status ? 0 : 1;
        loaderStateTrue()
        UsersController.usersUpdate(id, dataHash).then((response) => {
            //console.log("response=============>>", response)
            loaderStateFalse()
            if (response) {
                if (response.success) {
                    this.resetDataGrid()
                    Utility.toastNotifications(response.message, "Success", "success");
                } else {
                    Utility.toastNotifications(response.message, "Error", "error");
                }
            }

        }).catch((error) => {
            loaderStateFalse();
        });

    }

    detailsViewModalfunction = () => {
        this.setState({
            detailsViewModalflag: true,
            detailsHeader: this.props.t('customersList'),
        })
    }

    closeDetailsViewModal = () => {
        this.setState({
            detailsViewModalflag: false,
            detailsHeader: ""
        })
    }

    usersUsersInfo = (userId, method) => {
        let promise = new Promise((resolve, reject) => {
            let valid = this.validUsersData();
            const { loaderStateTrue, loaderStateFalse } = this.props;
            const { fromDataInfo, gridObjData, reserveFromDataInfo, editedId } = this.state;
            if (valid) {
                formatingFormDataInfo(fromDataInfo, reserveFromDataInfo, editedId).then((addUsersDataSet) => {
                    loaderStateTrue();
                    //let method = 'post';
                    let id = "";
                    if (method == 'post') {
                        addUsersDataSet[0].user_id = userId
                    }
                    if (editedId.length != 0) {
                        id = editedId,
                            method = "patch";
                        addUsersDataSet = addUsersDataSet[0]
                    }
                    UsersController.usersInfo(addUsersDataSet, id, method).then((response) => {
                        //console.log("response=====", response)
                        loaderStateFalse();
                        if (method == "post") {
                            if (response.length > 0) {
                                response.map((res, index) => {
                                    if (res.success) {
                                        this.closeUsersModal();
                                        this.resetDataGrid();
                                        Utility.toastNotifications(res.message, "Success", "success");
                                    } else {
                                        Utility.toastNotifications(res.message, "Error", "error")
                                    }
                                })
                            }
                        } else {
                            if (response.success) {
                                this.closeUsersModal();
                                this.resetDataGrid();
                                Utility.toastNotifications(response.message, "Success", "success");
                            } else {
                                Utility.toastNotifications(response.message, "Error", "error")
                            }
                        }
                    }).catch((error) => {
                        loaderStateFalse();
                    })
                })
            }
        })
        return promise
    }

    render() {
        //console.log("userProfileId===tr props",this.props.userProfileId)
        const { t, roleWisePermission } = this.props;
        return (
            <div className="gridcontainer">

                <div className="totalworkercontent">
                    <div className="gridtopviews">

                        <div className="rightboxes">
                            <button type="button" className="useraddbtn" onClick={this.usersModalfunction}>{this.props.t('Ajouter')}</button>

                        </div>
                        <div className="pageinnersearch">
                            <button type="button" className="btn btn-link search_btn_addon"><i className="fa fa-search"></i></button>
                            <CustomInput
                                parentClassName="comment_input_field"
                                name="srchBox"
                                type="text"
                                placeholder={this.props.t('searchUser')}
                                onChange={this.handleUserSearchBar.bind(this)}
                                value={this.state.usersName}
                            />
                            {
                                this.state.usersName != "" ?
                                    < button type="button" className="btn btn-link dropclosebtn" onClick={this.clearSearchValue}>
                                        <img src={require('../../../../Utility/Public/images/dropcloseicon.png')} className="searchClearIcon" />
                                    </button>
                                    : null}
                        </div>
                    </div>
                    <div className="ag-theme-alpine aggridview homeag">
                        <AgGridReact
                            modules={this.state.modules}
                            columnDefs={this.state.columnDefs}
                            defaultColDef={this.state.defaultColDef}
                            components={this.state.components}
                            rowSelection="multiple"
                            rowModelType="infinite"
                            onGridReady={this.onGridReady}
                            rowHeight={62.5}
                            headerHeight={47}
                            //onSelectionChanged={this.onSelectionChanged.bind(this)}
                            cacheBlockSize={10}
                            enableRtl={localStorage.getItem('selected_lan_direction') == "rtl" ? true : false}
                        />
                    </div>
                    <ModalGlobal
                        show={this.state.usersModal}
                        onHide={this.closeUsersModal}
                        title={this.state.exheaderContent}
                        className="modalcustomize mondimension examinessModal"
                        footer={false}
                        closeButton={true}
                        body={
                            <UsersModalContent
                                //Image crop
                                addInputProfileImageChanged={this.addInputProfileImageChanged}
                                addprofileImageSelected={this.state.addprofileImageSelected}
                                crop={this.state.crop}
                                croppedImageUrl={this.state.croppedImageUrl}
                                src={this.state.src}
                                onImageLoaded={this.onImageLoaded}
                                onCropComplete={this.onCropComplete}
                                onCropChange={this.onCropChange}
                                imageCropModalShow={this.imageCropModalShow}
                                imageCropModalHide={this.imageCropModalHide}
                                imageCropModalFlag={this.state.imageCropModalFlag}
                                imageCropDataSave={this.imageCropDataSave}
                                formatDateInput={this.formatDateInput}

                                //form data
                                handelChange={this.handelChange}
                                fromData={this.state.fromData}
                                fromDataError={this.state.fromDataError}
                                addUsers={this.addUsers}
                                addProfileImagePreviewShow={this.state.addProfileImagePreviewShow}

                                customersList={this.state.customersList}
                                saveButtonDisableUsersEditModal={this.state.saveButtonDisableUsersEditModal}
                                handelChangeInfo={this.handelChangeInfo}
                                fromDataInfo={this.state.fromDataInfo}
                                fromDataInfoError={this.state.fromDataInfoError}
                                disabledEmail={this.state.disabledEmail}
                                exheaderContent={this.state.exheaderContent}
                                fromDataCustomer={this.state.fromDataCustomer}
                                fromDataCustomerError={this.state.fromDataCustomerError}
                                countryList={this.state.countryList}
                                editedId={this.state.editedId}
                            />
                        }
                    />
                    <ModalGlobal
                        show={this.state.deleteConfirmationAlertModal}
                        onHide={this.deleteConfirmationModalHide}
                        className="modalcustomize confirmationalertmodal"
                        bodyClassName="cancelConfirmationbody"
                        headerclassName="close_btn_icon"
                        title={t('deleteUserTitle')}
                        footer={false}
                        body={
                            <ConfirmationAlert
                                BodyFirstContent={t('entDeleteConfirmation')}
                                BodySecondContent={this.state.enDeleteBodySecondContent}
                                BodyThirdContent={t('userDeleteAnableGoBack')}
                                confirmationButtonContent={t('confirm')}
                                cancelButtonContent={t('cancel')}
                                deleteConfirmButton={this.usersDeleteConfirmButton}
                                deleteCancleButton={this.usersDeleteCancleButton}
                            />
                        }
                    />

                    <ModalGlobal
                        show={this.state.detailsViewModalflag}
                        onHide={this.closeDetailsViewModal}
                        className="modalcustomize detailsviewmodal headermodalcontent locationDetails exdetailsviewmodal"
                        headerShow={true}
                        closeButton={true}
                        footer={false}
                        title={this.state.detailsHeader}
                        body={
                            <DetailsViewModalContent
                                data={this.state.popupCustomer}
                                type="array"
                                labelValueMapKey="name"
                            />
                        }
                    />

                    {this.state.actionModalflag ?
                        <GridActionContent
                            styleWidth={this.state.overlayWidth}
                            styleHight={this.state.overlayHight}
                            codeOutsideClickRef={this.codeOutsideClickRef}
                            gridObjData={this.state.gridObjData}
                            modefier={this.editUsers}
                            delete={this.deleteConfirmationModalShow}
                            archivedButtonShow={false}
                        />
                        : null}

                </div>

            </div >
        );
    }
}


const mapStateToProps = (globalState) => {
    return {
        userCredentials: globalState.LoginReducer.userCredentials,
        roleWisePermission: globalState.mainReducerData.roleWisePermission,
    };
}

export default withRouter(connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
    (withTranslation()(Users)));