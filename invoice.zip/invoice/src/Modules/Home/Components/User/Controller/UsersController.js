import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { usersListingGet, usersDetailsGet, usersAddPost, usersAddPatch, usersCustRelationPostApi, customerListingGet, usersUpdatePatch, usersDeleteApi,deleteCustomerApi, usersInfoPost, usersInfoPatch} from '../Model/UsersModel';
import Config from '../../../../../Utility/Config';

export const usersListing = (data) => {
    return get(`${Config.extendedUrl}admin/users`, data).then((response) => {
        return usersListingGet(response)
    });
};
export const usersDetails = (id, data) => {
    return get(`${Config.extendedUrl}admin/users_details/${id}`, data).then((response) => {
        return usersDetailsGet(response)
    });
};

export const usersAdd = (data, id, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}admin/users`, data).then((response) => {
            return usersAddPost(response)
        });
    } else {
        return patch(`${Config.extendedUrl}admin/users/${id}`, data).then((response) => {
            return usersAddPatch(response)
        });
    }

};
export const usersCustRelationPost = (data) => {
    return post(`${Config.extendedUrl}org_cust_user_relations`, data).then((response) => {
        return usersCustRelationPostApi(response)
    });
};

export const customerList = (data) => {
    return get(`${Config.extendedUrl}customers`, data).then((response) => {
        return customerListingGet(response)
    });
};

export const usersUpdate = (id, data) => {
    return patch(`${Config.extendedUrl}admin/users/${id}`, data).then((response) => {
        return usersUpdatePatch(response)
    });
};

export const usersDelete = (data) => {
    return del(`${Config.extendedUrl}admin/users`, data).then((response) => {
        return usersDeleteApi(response)
    });
};
export const deleteCustomer = (data) => {
    return del(`${Config.extendedUrl}org_cust_user_relations`, data).then((response) => {
        return deleteCustomerApi(response)
    });
};
export const usersInfo = (data, id, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}user_info`, data).then((response) => {
            return usersInfoPost(response)
        });
    } else {
        return patch(`${Config.extendedUrl}user_info/${id}`, data).then((response) => {
            return usersInfoPatch(response)
        });
    }
};