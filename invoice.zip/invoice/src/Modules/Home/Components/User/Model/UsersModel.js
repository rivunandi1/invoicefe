export const usersListingGet = (data) => {
    return data.data
}
export const usersDetailsGet = (data) => {
    return data.data;
}
export const usersAddPost = (examineesAdd) => {
    return examineesAdd.data
}
export const usersAddPatch = (examineesupdate) => {
    return examineesupdate.data
}
export const usersCustRelationPostApi = (data) => {    
    return data.data;
}
export const customerListingGet = (data) => {
    return data.data
}
export const usersUpdatePatch = (data) => {    
    return data.data;
}
export const usersDeleteApi = (data) => {    
    return data.data;
}
export const deleteCustomerApi = (data) => {    
    return data.data;
}
export const usersInfoPost = (usersInfoAdd) => {
    return usersInfoAdd.data
}
export const usersInfoPatch = (usersInfoUpdate) => {
    return usersInfoUpdate.data
}