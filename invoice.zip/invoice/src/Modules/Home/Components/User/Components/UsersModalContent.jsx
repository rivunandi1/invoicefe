import React, { Component } from 'react';
import CustomInput from '../../../../../Utility/Components/CustomInput';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import 'react-image-crop/dist/ReactCrop.css';
import ImageCropContent from '../../../../../Utility/Components/ImageCropContent'
import ModalGlobal from '../../../../../Utility/Components/ModalGlobal'


class UsersModalContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            src: null,
            crop: {
                unit: '%',
                width: 30,
                aspect: 16 / 9
            },
            croppedImageUrl: "",
        }

    }



    render() {
        const { addInputProfileImageChanged, addprofileImageSelected, steponehide, t, disabledEmail } = this.props;
        const { crop, croppedImageUrl, src } = this.props;
        //console.log("fromData====",this.props.fromData)
        return (
            <>
                <div className="modalinnerbody">
                    <div className={`${steponehide} firstinformation`}>
                        <div className="innerbodydimension">
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="row">
                                            <div className="col-md-12">
                                                <CustomInput
                                                    parentClassName="input_field_inner required"
                                                    labelName={t('Name')}
                                                    errorLabel={this.props.fromDataError.name}
                                                    name="name"
                                                    type="text"
                                                    value={this.props.fromData.name}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChange(e, "name")}

                                                />
                                            </div>
                                            <div className="col-md-12">
                                                <div className="row">
                                                    <div className="col-md-12">
                                                        <CustomInput
                                                            parentClassName="input_field_inner required"
                                                            labelName={t('Email')}
                                                            errorLabel={this.props.fromDataError.email}
                                                            name="email"
                                                            type="text"
                                                            value={this.props.fromData.email}
                                                            labelPresent={true}
                                                            onChange={(e) => this.props.handelChange(e, "email")}

                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="user_add_img modprofile">
                                            <div className="userProfileImg">
                                                {!this.props.addProfileImagePreviewShow ?
                                                    <label className="custom-file-upload">
                                                        <span className="filetext">
                                                            <img src={addprofileImageSelected} />
                                                        </span>
                                                        <span className="plusicon">
                                                            <i className="fa fa-plus" aria-hidden="true"></i>
                                                            <input type="file" onChange={addInputProfileImageChanged} />
                                                        </span>
                                                    </label>
                                                    :
                                                    <label className="custom-file-upload">
                                                        <img src={addprofileImageSelected} />
                                                        <span className="plusicon">
                                                            <i className="fa fa-plus" aria-hidden="true"></i>
                                                            <input type="file" onChange={this.props.addInputProfileImageChanged} />
                                                        </span>
                                                    </label>
                                                }

                                                <div className="col-md-12 errorClass error_div">{this.props.traprofileImageError}</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <div className="dropdowninnerbox required">
                                                    <label>{t('customers')}</label>
                                                    <AutosuggestComponent
                                                        handleOnChange={(e) => this.props.handelChange(e, "customers_name")}
                                                        options={this.props.customersList}
                                                        selectedValue={this.props.fromDataCustomer.customers_name}
                                                        name=''
                                                        isMulti={false}
                                                        placeholder=""
                                                        isDisabled={this.props.editedId!=""?true:false}
                                                        isSearchable={true}
                                                    />
                                                    <div className="col-md-12 errorClass error_div">{this.props.fromDataCustomerError.customers_name}</div>
                                                </div>
                                            </div>
                                            <div className="col-md-6 phonenumberError">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName={t('phonenumber')}
                                                    errorLabel={this.props.fromDataInfoError.phone_no}
                                                    name="phone_no"
                                                    type="text"
                                                    value={this.props.fromDataInfo.phone_no}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChangeInfo(e, "phone_no")}

                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Addres line 1"
                                                    //errorLabel={this.props.fromDataInfoError.address_line1}
                                                    name="address_line1"
                                                    type="text"
                                                    value={this.props.fromDataInfo.address_line1}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChangeInfo(e, "address_line1")}

                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner phonenumberError"
                                                    labelName="Addres line 2"
                                                    //errorLabel={this.props.fromDataError.address_line2}
                                                    name="address_line2"
                                                    type="text"
                                                    value={this.props.fromDataInfo.address_line2}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChangeInfo(e, "address_line2")}

                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName={t('city')}
                                                    //errorLabel={this.props.fromDataInfoError.city}
                                                    name="city"
                                                    type="text"
                                                    value={this.props.fromDataInfo.city}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChangeInfo(e, "city")}

                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner phonenumberError"
                                                    labelName="State"
                                                    //errorLabel={this.props.fromDataInfoError.state}
                                                    name="state"
                                                    type="text"
                                                    value={this.props.fromDataInfo.state}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChangeInfo(e, "state")}

                                                />
                                            </div>
                                            <div className="col-md-6">
                                                <div className="dropdowninnerbox">
                                                    <label>Country</label>
                                                    <AutosuggestComponent
                                                        handleOnChange={(e) => this.props.handelChangeInfo(e, "country")}
                                                        options={this.props.countryList}
                                                        selectedValue={this.props.fromDataInfo.country}
                                                        name=''
                                                        isMulti={false}
                                                        placeholder=""
                                                        isDisabled={false}
                                                        isSearchable={true}
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-6">
                                                <CustomInput
                                                    parentClassName="input_field_inner"
                                                    labelName="Zip code"
                                                    //errorLabel={this.props.fromDataInfoError.zip_code}
                                                    name="zip_code"
                                                    type="text"
                                                    value={this.props.fromDataInfo.zip_code}
                                                    labelPresent={true}
                                                    onChange={(e) => this.props.handelChangeInfo(e, "zip_code")}

                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="row">
                                            <div className="col-md-6 custom_checkboxInner">
                                                <label className="custom_checkbox_tick">{t('active')}
                                                    <input type="checkbox" checked={this.props.fromData.status} onChange={(e) => { this.props.handelChange(e, "status") }} />
                                                    <span className="checkmarkCheckbox"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-12 modfooterbtn">
                                        <button type="button" className="savebtn" disabled={this.props.saveButtonDisableExamineesEditModal} onClick={this.props.addUsers}>{t('save')}</button>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                </div>

                <ModalGlobal
                    show={this.props.imageCropModalFlag}
                    onHide={this.props.imageCropModalHide}
                    onCancel={this.props.imageCropModalHide}
                    onSave={this.props.imageCropDataSave}
                    className="modalcustomize cropmodalcontent"
                    bodyClassName="cropmodalcontentbody"
                    headerclassName="close_btn_icon"
                    title={t('cropimage')}
                    footer={true}
                    closeButton={true}
                    saveButtonLabel={t('crop')}
                    saveButtonClassName="delconfirmbtn btn btn-primary"
                    cancelButtonClassName="delcancelbtn btn btn-primary"
                    body={
                        <ImageCropContent
                            onImageLoaded={this.props.onImageLoaded}
                            onComplete={this.props.onCropComplete}
                            onCropChange={this.props.onCropChange}
                            crop={this.props.crop}
                            croppedImageUrl={this.props.croppedImageUrl}
                            src={this.props.src}
                            onCropComplete={this.props.onCropComplete}
                            imageCropModalShow={this.props.imageCropModalShow}
                        />
                    }
                />
            </>
        );
    }
}

UsersModalContent.propTypes = {

}

UsersModalContent.defaultProps = {
    className: "modalcustomize mondimension",
    headerclassName: "close_btn_icon",
    buttonClassName: "btn btn-primary",
    BodyContent: "",
    buttonContent: "",
    bodyClassName: ""
}

const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(UsersModalContent)));