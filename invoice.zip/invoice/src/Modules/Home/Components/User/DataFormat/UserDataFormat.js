const lodash = require('lodash');
export const formatingFormData = (fromData, reserveFromData, editedId, profileImageChangeEditMode) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        if (editedId == "") {
            hash['name'] = fromData.name
            hash['email'] = fromData.email
            hash['type'] = "user"
            hash['status'] = fromData.status ? 1 : 0
            if (Object.keys(fromData.profileImage).length > 0) {
                hash['profile_img'] = fromData.profileImage
            }

            dataSet.push(hash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveFromData, fromData)
            Object.keys(compareData).map((key) => {
                hash[key] = compareData[key]
            })
            if (profileImageChangeEditMode) {
                if (Object.keys(fromData.profileImage).length > 0) {
                    hash['profile_img'] = fromData.profileImage
                }
            }
            hash['type'] = "user"
            dataSet.push(hash);
            console.log("dataSet===========",dataSet)
            resolve(dataSet)
        }
    })

    return promise;

};

export const formatingFormDataInfo = (fromDataInfo, reserveFromDataInfo, editedId) => {
    let promise = new Promise((resolve, reject) => {
        let dataSet = [];
        let hash = {}
        if (editedId == "") {
            hash['city'] = fromDataInfo.city
            hash['country'] = fromDataInfo.country.value
            hash['phone_no'] = fromDataInfo.phone_no
            hash['address_line1'] = fromDataInfo.address_line1
            hash['address_line2'] = fromDataInfo.address_line2
            hash['state'] = fromDataInfo.state
            hash['zip_code'] = fromDataInfo.zip_code
            hash['type'] = "user"
            dataSet.push(hash);
            resolve(dataSet)
        } else {
            let compareData = difference(reserveFromDataInfo, fromDataInfo)
            Object.keys(compareData).map((key) => {
                hash[key] = compareData[key]
                if(key=="country"){
                    hash["country"] = compareData.country.value
                }
                hash['type'] = "user"
            })
            dataSet.push(hash);
            resolve(dataSet)
        }
    })

    return promise;

};


const difference = (origObj, newObj) => {
    let changes = (newObj, origObj) => {
        let arrayIndexCounter = 0
        return lodash.transform(newObj, (result, value, key) => {
            if (!lodash.isEqual(value, origObj[key])) {
                let resultKey = lodash.isArray(origObj) ? arrayIndexCounter++ : key
                result[resultKey] = (lodash.isObject(value) && lodash.isObject(origObj[key])) ? changes(value, origObj[key]) : value
            }
        })
    }
    return changes(newObj, origObj)
}