import CountryWithCode from '../../../../../Utility/JsFolder/CountryWithCode';
export const setEditDataForUsers = (gridObjData) => {
    let promise = new Promise((resolve, reject) => {
        let data = {}
        data["name"] = gridObjData.data.name
        data["email"] = gridObjData.data.email
        data["status"] = gridObjData.data.status ? 1 : 0
        data["profileImage"] = ""
        console.log("data==========",data)
        resolve(data);
    })
    return promise;
};

export const setEditDataForInfo = (gridObjData) => {
    let promise = new Promise((resolve, reject) => {
        let data = {}
        data["city"] = gridObjData.data.userinfo?.city && gridObjData.data.userinfo?.city != "" ? gridObjData.data.userinfo?.city : ""
        let findCountry = CountryWithCode.filter(res => {
            return res.country == gridObjData.data.userinfo?.country && gridObjData.data.userinfo?.country != "" ? gridObjData.data.userinfo?.country : "";
        });
        if (findCountry.length > 0) {
            data["country"] = { label: findCountry[0].country, value: findCountry[0].country }
        }
        //data["country"] = { label: findCountry[0].country, value: findCountry[0].iso }
        data["phone_no"] = gridObjData.data.userinfo?.phone_no && gridObjData.data.userinfo?.phone_no != "" ? gridObjData.data.userinfo?.phone_no : ""


        data["address_line1"] = gridObjData.data.userinfo?.address_line1 && gridObjData.data.userinfo?.address_line1 != "" ? gridObjData.data.userinfo?.address_line1 : ""
        data["address_line2"] = gridObjData.data.userinfo?.address_line2 && gridObjData.data.userinfo?.address_line2 != "" ? gridObjData.data.userinfo?.address_line2 : ""
        data["state"] = gridObjData.data.userinfo?.state && gridObjData.data.userinfo?.state != "" ? gridObjData.data.userinfo?.state : ""
        data["zip_code"] = gridObjData.data.userinfo?.zip_code && gridObjData.data.userinfo?.zip_code != "" ? gridObjData.data.userinfo?.zip_code : ""
        resolve(data);
    })
    return promise;
};

