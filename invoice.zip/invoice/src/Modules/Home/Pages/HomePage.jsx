import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink, storeTabName } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp, setLanguages } from '../../Login/Actions/LoginAction';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import '../../Home/Assets/css/homedoc.scss';
import '../../Home/Assets/css/homeresponsivedoc.scss';
import { Tabs, Tab } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Organization from '../Components/Organization/Organization'
import Customer from '../Components/Customer/Customer'
import User from '../Components/User/Users'

class HomePage extends Component {
	constructor(props) {
		super(props);
		this.state = {
			selectedTabName: "organization",
			tempTabName: "",

		}
	}
	componentDidMount() {
		this.props.handleActiveLink("home_module", "");
		//this.permissionWiseTabSelected();
		this.setTabAccordingToUserType()
		

	}

	handelSelectTab = (tabName) => {
		this.props.storeTabName(tabName)
		this.setState({
			selectedTabName: tabName
		}, () => {
			//console.log("selectedTabName", this.state.selectedTabName)
			this.props.history.push(`/${localStorage.getItem('i18nextLng')}/home/${this.state.selectedTabName}`);
		})
	}

	setTabAccordingToUserType = () => {
		const { userCredentials } = this.props;
		let tabselcted = ""
		if (this.props.tabNameStore == undefined || this.props.tabNameStore == "") {
			if (userCredentials.user_details && userCredentials.user_details.type == "app_admin") {
				tabselcted = "organization"
			} else if (userCredentials.user_details && userCredentials.user_details.type == "admin") {
				tabselcted = "customer"
			}
		} else {
			tabselcted = this.props.tabNameStore
		}

		this.setState({
			selectedTabName: tabselcted
		}, () => {
			this.props.history.push(`/${localStorage.getItem('i18nextLng')}/home/${this.state.selectedTabName}`);
		})
	}
	tabUi = () => {
		const { t, roleWisePermission, userCredentials } = this.props;
		let arryHash = roleWisePermission;
		let arry = []
		if (userCredentials.user_details && userCredentials.user_details.type == "app_admin") {
			arry.push(
				<Tab eventKey="organization" title={t('organization')} key={1}>
					{this.state.selectedTabName == 'organization' ?
						< Organization /> : null}
				</Tab>
			)
		}

		if (userCredentials.user_details && userCredentials.user_details.type == "admin") {
			arry.push(
				<Tab eventKey="customer" title="Company" key={2}>
					{this.state.selectedTabName == 'customer' ?
						< Customer /> : null}
				</Tab>
			)
			arry.push(
				<Tab eventKey="user" title={t('user')} key={3}>
					{this.state.selectedTabName == 'user' ?
						< User /> : null}
				</Tab>
			)
		}
		return arry;

	}

	render() {
		const { t } = this.props;
		//console.log("localStorage",localStorage.getItem('selected_lan_direction'))
		return (
			<div className={localStorage.getItem('selected_lan_direction')=="rtl" ? "homepagecontainer connectheader direction_rtl" : "homepagecontainer connectheader direction_ltr"}>
				<Tabs
					id="homepagetabs"
					activeKey={this.state.selectedTabName}
					className="tabsmainbox"
					onSelect={this.handelSelectTab}

				>
					{this.tabUi()}
				</Tabs>
			</div >
		);
	}
}




const mapStateToProps = (globalState) => {
	//console.log("globalState===", globalState)
	return {
		//userCredentials: globalState.mainReducerData.userCredentials,
		userCredentials: globalState.LoginReducer.userCredentials,
		token: globalState.LoginReducer.token,
		access_token: globalState.mainReducerData.access_token,
		roleWisePermission: globalState.mainReducerData.roleWisePermission,
		tabNameStore: globalState.mainReducerData.tabNameStore,
		languageList: globalState.LoginReducer.languageList
	};
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, storeTabName, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp, setLanguages })
	(withTranslation()(HomePage)));