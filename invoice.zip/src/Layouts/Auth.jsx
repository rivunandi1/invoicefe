import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import Header from '../Utility/Components/Header'
import Footer from '../Utility/Components/Footer'
import NotFound from '../Utility/Pages/NotFound';
import Left from '../Utility/Components/Left'
import { logOutApp } from '../Modules/Login/Actions/LoginAction';


const AuthLayout = (props) => {
  const { userCredentials, logOutApp, history } = props
  useEffect(() => {
    checkForUSerCrendentials()
  }, []);

  const checkForUSerCrendentials = () => {
    if (Object.keys(userCredentials).length == 0) {
      logOutApp().then(
        () => history.push("/")
      );
    }
  }
  return (
    <>
      <div className="page_customize">
          <div className="pagecontainer">
              <Header history={props.history} />
              <Left history={props.history} />
              <div className={props.leftbar ? 'content_open' : 'content_closed'} style={{ minHeight: '91vh', backgroundColor: '#fff', paddingTop: '0px', transition: 'padding .3s ease-in-out', display: 'flex',borderRadius: '0px 0px 15px 65px' }}>{props.children}</div>
              {/*<Footer />*/}
          </div>
      </div>
    </>
  );

}


const mapStateToProps = (globalState) => {
  //console.log("globalState====auth",globalState);
  return {
    leftbar: globalState.mainReducerData.leftbar,
    userCredentials: globalState.LoginReducer.userCredentials
  };

}

export default connect(mapStateToProps, { logOutApp })(AuthLayout);