import React, { Component } from 'react';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import InfiniteScroll from 'react-infinite-scroll-component';
import ScaleLoader from "react-spinners/ScaleLoader";
import Utility  from './../Utility';

class DetailsViewModalContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            searchInput: ""
        }
    }
    labelUi = () => {
        const { labelValueMapKey } = this.props
        let labelArray = []

        if (this.props.data.length > 0) {
            this.props.data.map((item, idx) => {
                //console.log("item==================>", item)
                //return false;

                if (item.hasOwnProperty(labelValueMapKey) && labelValueMapKey != "") {
                    if (item.hasOwnProperty('profile_img_url') == false && item.name && labelValueMapKey != "code" && labelValueMapKey != "description_code" && labelValueMapKey != "leave_code" && labelValueMapKey != "user_name") {// for department teams modal
                        if (!this.state.searchInput || item.name.toLowerCase().startsWith(this.state.searchInput)) {
                            labelArray.push(
                                <div key={idx} className="detailscontentlabel">{item.name}</div>
                            )
                        }
                    } else if (item.hasOwnProperty('profile_img_url') == false && item.hasOwnProperty('placeName')) { // for enterprise depertment(member modal), teams(tram member modal), function (employee modal)
                        labelArray.push(
                            <div key={idx} className="detailscontentlabel">{item.placeName}</div>
                        )
                    } else if (item.hasOwnProperty('code') && labelValueMapKey == "code") {
                        labelArray.push(
                            <div onClick={() => { this.props.handleClickShiftFromModal(idx) }} key={idx} className="bXinner bXinnerDes"><span style={{ "background": item.color_code }} className={item.selected ? "bX1 selectedShift" : "bX1"}><span>{item.code}</span></span></div>
                        )
                    } else if (item.hasOwnProperty('leave_code') && labelValueMapKey == "leave_code") {
                        labelArray.push(
                            <div onClick={() => { this.props.handleClickLeaveFromModal(idx) }} key={idx} className="bXinner bXinnerDes"><span style={{ "background": item.color_code }} className={item.selected ? "bX1 selectedShift" : "bX1"}><span>{item.leave_code}</span></span></div>
                        )
                    } else if (item.hasOwnProperty('description_code') && labelValueMapKey == "description_code") {
                        labelArray.push(
                            <div onClick={() => { this.props.handleClickBenefitFromModal(idx) }} key={idx} className="bXinner bXinnerDes"><span style={{ "background": item.color_code }} className={item.selected ? "bX1 selectedShift" : "bX1"}><span>{item.description_code}</span></span></div>
                        )
                    } else if (item.hasOwnProperty('user_name') && labelValueMapKey == "user_name") {

                        if (item.dataforUser && Object.keys(item.dataforUser).length > 0) {
                            var image = item.dataforUser.profile_img
                        } else {
                            var image = require('../Public/images/usericon.png')
                        }
                        //console.log("itemitemitem>>",item)
                        labelArray.push(
                            <div key={idx} className="detailscontentlabel detailsShowBox">
                                <div className="imageviewleftbox"><img src={image} /></div>
                                <div className="userDetailsRightbox">
                                    <div className="userDetailsRow namelabel">{item.user_name}</div>
                                    <div className="userDetailsRow emaillabel">{item.dataforUser.email}</div>
                                    {item.dataforUser.hasOwnProperty('function') || item.dataforUser.hasOwnProperty('division') ? <div className="userDetailsRow">
                                        {`${item.dataforUser.hasOwnProperty('function') ? item.dataforUser.function.function_name : ""},${item.dataforUser.hasOwnProperty('division') ? item.dataforUser.division.div_name : ""}`}
                                    </div> : null}
                                    <div className="userDetailsRow">{item.dataforUser.contact_number}</div>
                                </div>
                            </div>
                        )
                    } else { // for enterprice place modal
                        /* console.log("item.profile_img===",item.profile_img)
                         console.log("Object.keys(item.profile_img)===",Object.keys(item.profile_img))
                         console.log("Object.keys(item.profile_img).length===",Object.keys(item.profile_img).length)*/
                        if (item.profile_img && Object.keys(item.profile_img).length > 0) {
                            var image = item.profile_img.file_obj
                        } else {
                            var image = require('../Public/images/usericon.png')
                        }
                        labelArray.push(
                            <div key={idx} className="detailscontentlabel detailsShowBox">
                                <div className="imageviewleftbox"><img src={image} /></div>
                                <div className="userDetailsRightbox">
                                    <div className="userDetailsRow namelabel">{Utility.displayNameFormat(item.first_name, item.last_name)}</div>
                                    <div className="userDetailsRow emaillabel">{item.email}</div>
                                    {item.hasOwnProperty('function') || item.hasOwnProperty('division') ? <div className="userDetailsRow">
                                        {`${item.hasOwnProperty('function') ? item.function.function_name : ""},${item.hasOwnProperty('division') ? item.division.div_name : ""}`}
                                    </div> : null}
                                    <div className="userDetailsRow">{item.contact_number}</div>
                                </div>
                            </div>
                        )
                    }
                } else {
                    if (!this.state.searchInput || item.toLowerCase().startsWith(this.state.searchInput)) {
                        labelArray.push(
                            <div key={idx} className="listBoxInner">{item}</div>
                        )
                    }
                }


            })
        } else if (this.props.data.length == 0) {
            /* if (this.props.data[0].hasOwnProperty(labelValueMapKey && labelValueMapKey != "")) {
                 labelArray = this.props.data[0][labelValueMapKey]
             } else {
                 labelArray = this.props.data[0]
             }*/
            labelArray = []
        }
        return labelArray
    }
    handleSearch = (e) => {
        this.setState({
            searchInput: e.target.value
        })

    }
    render() {
        const { t } = this.props;
        console.log("this.props.data.length==",this.props.data.length)
        return (
            <div className="modalinnerbody">
                {this.props.type == "string" ?
                    <div className="placesnamelabel">{this.props.data}</div>
                    : <div>
                        <div className="pageinnersearch userdetailsSearch globalModalSeach">
                            <button type="button" className="btn btn-link search_btn_addon"><img src={require('../../Utility/Public/images/searchicon.png')} className="searchIcon" /></button>
                            {this.props.InfiniteScroll == true ? <input type="text" value={this.props.searchInput} onChange={this.props.handleSearchData} placeholder={t('search')} /> : <input type="text" value={this.state.searchInput} onChange={this.handleSearch} placeholder={t('search')} />}
                            {this.props.searchInput !== "" && this.props.InfiniteScroll == true ?
                                <button type="button" className="btn btn-link dropclosebtn" onClick={this.props.clearSearchDataDetailsView}>
                                    <img src={require('../Public/images/dropcloseicon.png')} className="searchClearIcon" />
                                </button>
                                : null}
                        </div>
                        <div className="clearfix"></div>
                        {this.props.InfiniteScroll == true ? <div>
                            <div id="scrollableDiv" className="userListBox scrollSection" style={{ overflow: "auto" }}>
                                <InfiniteScroll
                                    dataLength={this.props.data.length}
                                    next={this.props.getNextData}
                                    //style={{ display: 'flex' }} //To put endMessage and loader to the top.
                                    hasMore={this.props.hasMoreData}
                                    loader={<div className="text-center"><ScaleLoader className="fadeloader_property" color="#45c1ff" size={40} /></div>}
                                    //scrollThreshold={0.8}
                                    // height={50}
                                    scrollableTarget="scrollableDiv"
                                //endMessage={<div className="text-center nodata_text">No more data</div>}
                                >
                                    {this.labelUi()}
                                </InfiniteScroll>
                            </div>
                        </div> : <>{this.labelUi()}</>}
                    </div>}
            </div>
        );
    }
}


DetailsViewModalContent.defaultProps = {
    type: 'string',
    labelValueMapKey: "",
    data: "",
    InfiniteScroll: false
}

export default withTranslation()(DetailsViewModalContent);
