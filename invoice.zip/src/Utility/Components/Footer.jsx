import React, { Component } from 'react';
class Footer extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }

    }

    render() {
        return (
            <>
                <div className="footer-inner">
					<span>Mettle Tech ©2021 All rights reserved.</span>
				</div>
            </>     

        );
    }
}

export default Footer;