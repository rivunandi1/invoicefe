import React, { Component } from 'react';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';

class GridActionContent extends Component {
    render() {
        const { t, styleWidth, styleHight, gridObjData, editButtonShow, deleteButtonShow, archivedButtonShow, leaveviewButtonShow, resultButtonShow, cancelButtonShow } = this.props;
        return (
            <div className="actionableInnerBox" style={{ position: 'absolute', left: `${styleWidth}`, top: `${styleHight}` }} ref={this.props.codeOutsideClickRef}>
                <div className="actionableBtnCenter">
                    {leaveviewButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.leaveview.bind(this, gridObjData)}><span><i className="fa fa-calendar-check-o" ></i></span> {t('leaveview')}</button>
                    </div> : null}
                    {editButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={() => { this.props.modefier(gridObjData, "") }}><span><i className="fa fa-pencil" ></i></span> {t('edit')}</button>
                    </div> : null}
                    {deleteButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.delete.bind(this, gridObjData)}><span><i className="fa fa-trash-o"></i></span> {t('delete')}</button>
                    </div> : null}
                    {archivedButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.archived.bind(this, gridObjData)}><span><i className="fa fa-archive"></i></span> {t('archivedMembers')}</button>
                    </div> : null}
                    {cancelButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.cancel.bind(this, gridObjData)}><span><i className="fa fa-times"></i></span> {t('cancel')}</button>
                    </div> : null}
                    {resultButtonShow ? <div className="actionableRow">
                        <button className="actionableIcon" onClick={this.props.result.bind(this, gridObjData)}><span><i className="fa fa-file-text"></i></span> {t('result')}</button>
                    </div> : null}
                </div>
            </div>
        );
    }
}
GridActionContent.defaultProps = {
    editButtonShow: true,
    deleteButtonShow: true,
    archivedButtonShow: true,
    leaveviewButtonShow: false,
    resultButtonShow: false,
    cancelButtonShow: false,
}
const mapStateToProps = (globalState) => {
    return {

    };
}

export default withRouter(connect(mapStateToProps, {})
    (withTranslation()(GridActionContent)));