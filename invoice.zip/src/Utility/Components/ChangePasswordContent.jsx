import React, { Component } from 'react';
import CustomInput from '../Components/CustomInput';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import PropTypes from 'prop-types';
import { setToken, logOutApp } from '../../Modules/Login/Actions/LoginAction';
import { loaderStateTrue, loaderStateFalse } from '../../Actions/AllAction';
import * as UtilityController from '../Controller/UtilityController';
import Utility from '../../../src/Utility/Utility'


class ChangePasswordContent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			changePasswordFormData: {
				userEmail: "",
				password: "",
				newPassword: "",
				confirmPassword: ""
			},
			userEmailError: "",
			passwordError: "",
			newPasswordError: "",
			confirmPasswordError: ""
		}
	}

	handleChangeUserData = (e) => {
		let { name, value } = e.target;
		let { changePasswordFormData } = this.state;
		/*if(name == "userEmail"){
			changePasswordFormData['userEmail'] = value
			// this.setState({
			// 	userEmail: value
			// },()=>{
			// 	console.log("userEmail===>",this.state.userEmail)
			// })
		}*/
		if (name == "password") {
			changePasswordFormData['password'] = value
			// this.setState({
			// 	password: value
			// },()=>{
			// 	console.log("password===>",this.state.password)
			// })
		}
		if (name == "newPassword") {
			changePasswordFormData['newPassword'] = value
			// this.setState({
			// 	newPassword: value
			// },()=>{
			// 	console.log("newPassword===>",this.state.newPassword)
			// })
		}
		if (name == "confirmPassword") {
			changePasswordFormData['confirmPassword'] = value
			// this.setState({
			// 	confirmPassword: value
			// },() =>{
			// 	console.log("confirmPassword===>",this.state.confirmPassword)
			// })
		}
		this.setState({
			changePasswordFormData
		})
	}

	validchangePasswordForm = () => {
		let { changePasswordFormData } = this.state;
		const { t } = this.props;
		//console.log("changePasswordFormData======>", changePasswordFormData)
		let valid = true;

		// if (changePasswordFormData.userEmail == "") {
		// 	valid = false;
		// 	this.setState({
		// 		userEmailError: this.props.t('invalidField')
		// 	})
		// }
		if (changePasswordFormData.password == "") {
			valid = false;
			this.setState({
				passwordError: this.props.t('invalidField')
			})
		}
		if (changePasswordFormData.newPassword == "") {
			valid = false;
			this.setState({
				newPasswordError: this.props.t('invalidField')
			})
		}
		if (changePasswordFormData.confirmPassword == "") {
			valid = false;
			this.setState({
				confirmPasswordError: this.props.t('invalidField')
			})
		}

		if (changePasswordFormData.newPassword != "" && changePasswordFormData.confirmPassword != "") {

			let passwordValidate = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-+“!@#%&/,><\’:;|_~`])\S{6,99}$/.test(changePasswordFormData.newPassword);

			if (passwordValidate) {
				this.setState({
					newPasswordError: ''
				})
			} else {
				valid = false;
				this.setState({
					newPasswordError: t('thisFieldIsInvalid')
				})
				Utility.toastNotifications(`<ul class='password-inner-box'>
				<li><b>${t('minimumLength')}</b>, ${t('mustBeAtLeast6Characters')}</li>
				<li><b>${t('requireNumbers')}</b></li>
				<li><b>${t('requireSpecialCharacter')}</b> ${t('fromThisSet')}: = + - ^ $ * . [ ] { } ( ) ?  ! @ # % & / \ , > < ' : ; | _ ~ </li>
				<li><b>${t('requireUppercaseLetters')}</b></li>
				<li><b>${t('requireLowercaseLetters')}</b></li>
				</ul>`, `${t('passworderror')}`, "longError");
			}


			let CpasswordValidate = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-+“!@#%&/,><\’:;|_~`])\S{6,99}$/.test(changePasswordFormData.confirmPassword);

			if (CpasswordValidate) {
				this.setState({
					confirmPasswordError: ''
				})
			} else {
				valid = false;
				this.setState({
					confirmPasswordError: t('thisFieldIsInvalid')
				})
				Utility.toastNotifications(`<ul class='password-inner-box'>
				<li><b>${t('minimumLength')}</b>, ${t('mustBeAtLeast6Characters')}</li>
				<li><b>${t('requireNumbers')}</b></li>
				<li><b>${t('requireSpecialCharacter')}</b> ${t('fromThisSet')}: = + - ^ $ * . [ ] { } ( ) ?  ! @ # % & / \ , > < ' : ; | _ ~ </li>
				<li><b>${t('requireUppercaseLetters')}</b></li>
				<li><b>${t('requireLowercaseLetters')}</b></li>
				</ul>`, `${t('confirmPasswordError')}`, "longError");
			}

			if (changePasswordFormData.newPassword == changePasswordFormData.confirmPassword && changePasswordFormData.newPassword != "" && changePasswordFormData.confirmPassword != "") {
				this.setState({
					newPasswordError: '',
					confirmPasswordError: ''
				})
			} else {
				valid = false;
				Utility.toastNotifications(t('passwordAndConfirmPasswordNotMatch'), "Error", "error");
			}
		}



		return valid;
	}

	changePasswordfromSubmitData = () => {
		let valid = this.validchangePasswordForm();
		//console.log("valid------------>>>>>>",valid)
		const { changePasswordFormData } = this.state;
		if (valid) {
			const { loaderStateTrue, loaderStateFalse } = this.props;
			let data = {

				"pre_password": changePasswordFormData.password,

				"new_password": changePasswordFormData.newPassword

			};
			loaderStateTrue();
			UtilityController.userNewPasswordChange(data).then((response) => {
				//console.log("response---------->", response)
				loaderStateFalse();
				if (response.success) {
					//console.log("response.success===============>>>>>", response.success)
					Utility.toastNotifications(response.message, "Success", "success");
					this.props.closeChangePassword();
				}
				// if (type == "patch") {
				// 	if (response.length > 0) {
				// 		response.map((data, index) => {
				// 			if (data.success) {
				// 				this.props.detectChangesIndividualTab(false)
				// 				this.props.detectChangesIndividualInnerTab(false)
				// 				this.userPersonalsDetails();
				// 				Utility.toastNotifications(data.message, "Success", "success");
				// 			} else {
				// 				Utility.toastNotifications(data.message, "Error", "error")
				// 			}
				// 		})
				// 	}
				// } else {
				// 	if (response.length > 0) {
				// 		response.map((data, index) => {
				// 			if (data.success) {
				// 				this.props.detectChangesIndividualTab(false)
				// 				this.props.detectChangesIndividualInnerTab(false)
				// 				this.userPersonalsDetails();
				// 				Utility.toastNotifications(data.message, "Success", "success");
				// 			} else {
				// 				Utility.toastNotifications(data.message, "Error", "error")
				// 			}
				// 		})
				// 	}
				// }

			}).catch((error) => {
				console.error("************error*************", error)
				if (error) {
					//Utility.toastNotifications(error.message, "Error", "error");
				}
				loaderStateFalse();
				if (error.message == "Network Error") {
					/*Utility.toastNotifications("Please login", "Error", "error");
					this.props.logOutApp().then(
						() => this.props.history.push("/")
					);*/
				}
			});
		}
	}
	render() {
		const { t, closeChangePassword, userCredentials } = this.props;
		let user_email = "";
		if (userCredentials && userCredentials.user_details && userCredentials.user_details.user_email!="") {
			user_email = userCredentials.user_details.user_email
		}
		
		if (user_email =="" && userCredentials && userCredentials.user_details && userCredentials.user_details.contact_number!="") {
			user_email = userCredentials.user_details.contact_number
		}
		return (
			<>
				<div className="modalinnerbody">
					<div className="change_password_row">
						<CustomInput
							parentClassName="comment_input_field"
							//errorLabel={this.state.userEmailError}
							name="userEmail"
							type="text"
							value={user_email}
							//labelPresent={true}
							onChange={this.handleChangeUserData}
							//placeholder={t('emailIdPlaceHolder')}
							readOnly={true}
						/>
					</div>
					<div className="change_password_row">
						<CustomInput
							parentClassName="comment_input_field"
							errorLabel={this.state.passwordError}
							name="password"
							type="password"
							value={this.state.changePasswordFormData.password}
							//labelPresent={true}
							onChange={this.handleChangeUserData}
							placeholder={t('enterCurrentPassword')}
						//readOnly={true}
						/>
					</div>
					<div className="change_password_row">
						<div className="input-field-full-box">
							<CustomInput
								parentClassName="comment_input_field"
								errorLabel={this.state.newPasswordError}
								name="newPassword"
								type="password"
								value={this.state.changePasswordFormData.newPassword}
								//labelPresent={true}
								onChange={this.handleChangeUserData}
								placeholder={t('enterNewPassword')}
							//readOnly={true}
							/>
						</div>
					</div>
					<div className="change_password_row">
						<div className="input-field-full-box">
							<CustomInput
								parentClassName="comment_input_field"
								errorLabel={this.state.confirmPasswordError}
								name="confirmPassword"
								type="password"
								value={this.state.changePasswordFormData.confirmPassword}
								//labelPresent={true}
								onChange={this.handleChangeUserData}
								placeholder={t('reEnterPassword')}
							//readOnly={true}
							/>
						</div>
					</div>
					<div className="col-md-12 modfooterbtn">
						<button type="button" className="savebtn" onClick={this.changePasswordfromSubmitData}>{t('submit')}</button>
						<button type="button" className="cancelbtn" onClick={this.props.closeChangePassword}>{t('cancel')}</button>
					</div>
				</div>
			</>
		);
	}
}

ChangePasswordContent.propTypes = {
	show: PropTypes.bool,
	onHide: PropTypes.func,
	className: PropTypes.string,
	headerclassName: PropTypes.string,
	bodyClassName: PropTypes.string,
	headerContent: PropTypes.string,
	formData: PropTypes.object,
	errorData: PropTypes.object,
	handleChange: PropTypes.func,
	submit: PropTypes.func
}

ChangePasswordContent.defaultProps = {
	className: "change_password_modal",
	headerclassName: "close_btn_icon",
	buttonClassName: "btn btn-primary",
	headerContent: "Change Password",
	BodyContent: "",
	buttonContent: "",
	bodyClassName: ""
}

const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.LoginReducer.userCredentials
	};
}


export default withRouter(connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken })
	(withTranslation()(ChangePasswordContent)));