import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Nav, Accordion } from "react-bootstrap";
//import { faCaretDown, faCaretUp } from "@fortawesome/free-solid-svg-icons";
//import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import { handleActiveLink, handleLeft } from '../../Actions/AllAction'

class Left extends Component {
	constructor(props) {
		super(props);
		this.handleBar = this.handleBar.bind(this);
		this.state = {
			toggleType: "",
			activeClass: "",
			accName: "",
			subMenuIcon: ""
		}
	}

	toggle = (params, linkType) => {
		if (linkType === "") {
			this.setState({
				collapsed2: true,
				accName: ""
			}, () => {
				this.props.handleActiveLink(this.state.activeClass, this.state.accName)
			});
		}

		this.setState({
			activeClass: params
		}, () => {
			this.props.handleActiveLink(this.state.activeClass, this.state.accName)
		});
	}

	handleBar = () => {
		this.props.handleLeft(!this.props.leftbar)
	}
	validationPermission = (eventKey) => {
		const { t, roleWisePermission } = this.props;
		let valid = false;
		if (roleWisePermission && roleWisePermission.hasOwnProperty(eventKey) && roleWisePermission[eventKey].read_write_permission != "") {
			valid = true;
		}
		return valid
	}



	leftUi = () => {
		const { t, roleWisePermission, userCredentials } = this.props;
		const { activeClass, accName } = this.props.activeLink;
		let dashBoardarry = ["dashboard", "userdashboard"];

		let orgnizationarry = ["worker", "addWorker", "personal", "professional", "documents", "career", "counters", "archiveEmployee", "deleteEmployee", "resetPassword", "entreprise", "department", "team", "function"];

		let planningarry = ["planning", "schedulingleave", "absences", "reminders", "report", "template"];

		let matrixingarry = ["matrix", "alerts", "plan", "catalog", "coaching"];

		let adminarry = ["roles", "leave", "codes", "interims", "roledocuments"];

		let darry = []
		let dasPermission = dashBoardarry.filter((item) => {
			let key = roleWisePermission && roleWisePermission.hasOwnProperty(item) ? roleWisePermission[item].eventKey : ""
			if (item == key) {
				darry.push(key)
			}
		})

		let orgArry = [];
		let orgPermission = orgnizationarry.filter((item) => {
			let key = roleWisePermission && roleWisePermission.hasOwnProperty(item) ? roleWisePermission[item].eventKey : ""
			if (item == key) {
				orgArry.push(key)
			}
		})
		let planArry = []
		let planningPermission = planningarry.filter((item) => {
			let key = roleWisePermission && roleWisePermission.hasOwnProperty(item) ? roleWisePermission[item].eventKey : ""
			if (item == key) {
				planArry.push(key)
			}
		})
		let matrixArry = []
		let matrixPermission = matrixingarry.filter((item) => {
			let key = roleWisePermission && roleWisePermission.hasOwnProperty(item) ? roleWisePermission[item].eventKey : ""
			if (item == key) {
				matrixArry.push(key)
			}
		})
		let adminArry = []
		let adminPermission = adminarry.filter((item) => {
			let key = roleWisePermission && roleWisePermission.hasOwnProperty(item) ? roleWisePermission[item].eventKey : ""
			if (item == key) {
				adminArry.push(key)
			}
		})

		//console.log("adminArry=========",adminArry)


		//console.log("userCredentials================>", userCredentials.user_details)
		let arry = []
		if (darry.length > 0) {
			arry.push(
				// <Nav.Item className={activeClass === 'profile_module' ? "ActiveClass" : "default dashboarditem"} onClick={this.toggle.bind(this, 'profile_module', '')} key={idx}>
				// 	<Link to="#" className="nav-link">
				// 		<div className="imgcircle"><img src={require('../Public/images/cort.png')} className="sidebaricon" /></div>
				// 	</Link>
				// </Nav.Item>
				<Nav.Item className={activeClass === 'profile_module' ? "ActiveClass" : "default dashboarditem"} onClick={this.toggle.bind(this, 'profile_module', '')} key={0}>
					{userCredentials.user_details && userCredentials.user_details.role_name == "app_admin" ?
						<Link to={`/${localStorage.getItem('i18nextLng')}/dashboard`} className="nav-link">
							<div className="imgcircle"><img src={require('../Public/images/cort.png')} className="sidebaricon" /></div>
						</Link>
						: <Link to={`/${localStorage.getItem('i18nextLng')}/userdashboard`} className="nav-link">
							<div className="imgcircle"><img src={require('../Public/images/cort.png')} className="sidebaricon" /></div>
						</Link>}
				</Nav.Item>
			)
		}
		if (orgArry.length > 0) {
			arry.push(
				<Nav.Item className={activeClass === 'home_module' ? "ActiveClass" : "default"} id="home_module_id" onClick={this.toggle.bind(this, 'home_module', '')} key={1}>
					<Link to={`/${localStorage.getItem('i18nextLng')}/home`} className="nav-link">
						<div className="imgcircle"><img src={require('../Public/images/home.png')} className="sidebaricon" /></div>
					</Link>
				</Nav.Item>
			)
		}

		if (planArry.length > 0 || userCredentials.is_leave_validator == true) {
			arry.push(
				<Nav.Item className={activeClass === 'scheduling_module' ? "ActiveClass" : "default"} onClick={this.toggle.bind(this, 'scheduling_module', '')} key={2}>
					<Link to={`/${localStorage.getItem('i18nextLng')}/scheduling`} className="nav-link">
						<div className="imgcircle"><img src={require('../Public/images/calendar.png')} className="sidebaricon" /></div>
					</Link>
				</Nav.Item>
			)
		}

		if (matrixArry) {
			arry.push(
				<Nav.Item className={activeClass === 'matrix' ? "ActiveClass" : "default chartitem"} onClick={this.toggle.bind(this, 'matrix', '')} key={3}>
					<Link to={`/${localStorage.getItem('i18nextLng')}/matrix`} className="nav-link">
						<div className="imgcircle"><img src={require('../Public/images/chart.png')} className="sidebaricon" /></div>
					</Link>
				</Nav.Item>
			)
		}
		if (adminArry.length > 0) {
			arry.push(
				<Nav.Item className={activeClass === 'role_module' ? "ActiveClass lastitemview" : "default lastitemview"} onClick={this.toggle.bind(this, 'role_module', '')} key={4}>
					<Link to={`/${localStorage.getItem('i18nextLng')}/role`} className="nav-link">
						<div className="imgcircle"><img src={require('../Public/images/roleicon.png')} className="sidebaricon" /></div>
					</Link>
				</Nav.Item>
			)
		}
		return arry;
	}


	render() {
		const { activeClass, accName } = this.props.activeLink;

		return (
			<aside id="left_bar_id" className={this.props.leftbar ? 'left_bar_customize left-bar open hide-sm' : 'left_bar_customize left-bar closed hide-sm'}>
				<div className="webtitlelogo">
					<img src={require('../Public/images/user.png')} className="sidebarimg" />
					<p className="chatitle">Challenge</p>
					<p className="peotitle">People</p>
				</div>
				<Nav className="flex-column pt-2 side-nav">

					{this.leftUi()}

				</Nav>
				<div className="bottomlogo">
					<img src={require('../Public/images/leftbarbottomlogo.png')} className="sidebarimg" />
				</div>
			</aside>

		)

	}
}


function mapStateToProps(globalState) {
	//console.log("globalState===>", globalState.mainReducerData.roleWisePermission)
	return {
		leftbar: globalState.mainReducerData.leftbar,
		activeLink: globalState.mainReducerData.activeLink,
		roleWisePermission: globalState.mainReducerData.roleWisePermission,
		userCredentials: globalState.LoginReducer.userCredentials
	};
}

export default connect(mapStateToProps, { handleActiveLink, handleLeft })(Left);