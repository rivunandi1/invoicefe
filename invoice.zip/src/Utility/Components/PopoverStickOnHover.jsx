import React, { Component } from 'react';
import Tooltip from 'rc-tooltip';
import 'rc-tooltip/assets/bootstrap.css';
import Utility  from './../Utility';

class PopoverStickOnHover extends Component {
  state = {
    destroyTooltipOnHide: false,
    trigger: {
      hover: 1,
    }
  };

  render() {
    const { data, placement } = this.props
    return (<div>
      <Tooltip
        placement={placement}
        mouseEnterDelay={0}
        mouseLeaveDelay={0.1}
        destroyTooltipOnHide={this.state.destroyTooltipOnHide}
        trigger={Object.keys(this.state.trigger)}
        overlay={<div className="empDetailsShow">
          <div className="cardviewboxinner">
            <div className="cardviewboxleftpanel">
              <div className="userPopupRow"><img src={data.profile_img_temp} /></div>
            </div>
            <div className="cardviewboxrightpanel">
              {/* <div className="userPopupRow usernamelabel">{`${data.first_name} ${data.last_name}`}</div> */}
              <div className="userPopupRow usernamelabel">{Utility.displayNameFormat(data.first_name, data.last_name)}</div>
              <div className="userPopupRow">{data.email}</div>
              <div className="userPopupRow">{`${data.function ? data.function.function_name : ""},${data.division ? data.division.div_name : ""}`}</div>
              <div className="userPopupRow">{data.contact_number}</div>
            </div>
          </div>
        </div>}
      >
        <div><img src={data.profile_img_temp} /></div>
      </Tooltip>
    </div>);
  }
}

PopoverStickOnHover.defaultProps = {
  placement: 'right',
  data: {
    profile_img_temp: "",
    first_name: "",
    last_name: "",
    function: {
      function_name: ""
    },
    division: {
      div_name: ""
    },
    contact_number: ""
  }
}
export default PopoverStickOnHover;
