import React, { Component } from 'react';
import { logOutApp } from '../../Modules/Login/Actions/LoginAction';
import { connect } from 'react-redux';

class NotFound extends Component {
  render() {
    return (
      <div className="not_found_page"></div>
    );
  }
}
//export default NotFound;

const mapStateToProps = (globalState) => {
  return {
    userCredentials: globalState.mainReducerData.userCredentials
  };
}

export default connect(mapStateToProps, { logOutApp })(NotFound);
