
export const changePasswordGet = (changePasswordData) => {
    return changePasswordData.data
}

export const userNotificationsGet = (notificationData) =>{
    return notificationData.data
}

export const userNotificationsPatch = (userNotificationsPatchData) =>{
    return userNotificationsPatchData.data;
}
export const userChangePasswordApi = (ChangePasswordData) => {
    return ChangePasswordData.data
}
export const userDetailsGet = (data) => {
    return data.data
}