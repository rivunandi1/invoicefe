import React, { Component } from 'react';
import { Switch } from "react-router-dom";
import { createHashHistory } from 'history';
import Auth from "../Layouts/Auth";
import { Route } from "react-router-dom";

//login
import LoginRoute from "../Modules/Login/Routes/LoginRoute"

//Role
import RoleRoute from "../Modules/Role/Routes/RoleRoute";

//DashboardRoute 
import DashboardRoute from '../Modules/Dashboard/Routes/DashboardRoute';


class index extends Component {
  render() {
    const history = createHashHistory();
    return (

      <>

        {/*****************Login Module Start****************/}
        <LoginRoute />
        {/*****************Login Module End****************/}
       

        {/*****************Role Module Start****************/}

        <RoleRoute allowedRoles={['app_admin']} />

        {/*****************Role Module End****************/}  


        {/*****************DashboardPage Start****************/}
        <DashboardRoute allowedRoles={['app_admin']} />
  
        
           
       
       

        
        
      </>
    );
  }
}
export default index;
