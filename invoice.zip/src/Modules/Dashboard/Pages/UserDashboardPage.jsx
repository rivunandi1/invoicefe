import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../Login/Actions/LoginAction';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import '../../Dashboard/Assets/css/dashboarddoc.scss';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';

class UserDashboardPage extends Component {
	constructor(props) {
		super(props);
		this.state = {
		}
	}

	componentDidMount() {
		this.props.handleActiveLink("profile_module", "");
	}


	render() {
		const { t } = this.props;
		return (
			<div className="homepagecontainer dashboardContainerUser">
				<div className="dashboardInnerUser">
					<div className="welcomeboxinner">
						<h1 className="welcomeTitle">{t('WelcomePeopleChallenge')}</h1>
						<p className="welcomeDes">{t('ChallengePeopleManage')}</p>
					</div>
				</div>
			</div>
		);
	}
}




const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.mainReducerData.userCredentials,
		token: globalState.mainReducerData.token,
		access_token: globalState.mainReducerData.access_token
	};
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(UserDashboardPage)));