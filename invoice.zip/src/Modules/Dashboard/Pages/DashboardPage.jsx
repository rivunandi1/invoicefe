import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../Login/Actions/LoginAction';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
import '../../Dashboard/Assets/css/dashboarddoc.scss';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Reminders from '../Components/Reminders/Reminders';
import Datachanges from '../Components/Datachanges/Datachanges';
import Training from '../Components/Training/Training';
import Absences from '../Components/Absences/Absences';

class DashboardPage extends Component {
	constructor(props) {
		super(props);
		this.state = {
			modules: [InfiniteRowModelModule],
		}
	}

	componentDidMount() {
		this.props.handleActiveLink("profile_module", "");
	}


	render() {
		const { t } = this.props;
		return (
			<div className="homepagecontainer dashboardcontainer">
				<div className="col-md-12">
					<div className="row">
						<div className="col-md-6">
							<div className="containerleftbox">
								<div className="col-md-12">
									<div className="remindersboxview">
										<Reminders/>
									</div>
									<div className="remindersboxview">
										<Training/>
									</div>
								</div>
							</div>
						</div>
						<div className="col-md-6">
							<div className="remindersboxview">
								<Datachanges/>
							</div>
							<div className="remindersboxview">
								<Absences/>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	}
}




const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.mainReducerData.userCredentials,
		token: globalState.mainReducerData.token,
		access_token: globalState.mainReducerData.access_token
	};
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(DashboardPage)));