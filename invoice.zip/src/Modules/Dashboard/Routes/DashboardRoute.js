import React, { Component } from 'react';
import { createHashHistory } from 'history';
import { Switch } from "react-router-dom";
import { Route } from "react-router-dom";
import Default from "../../../Layouts/Default";
import Auth from "../../../Layouts/Auth";
import UserDashboardPage from '../Pages/UserDashboardPage';


class DashboardRoute extends Component {
  render() {
    const history = createHashHistory();
    const { allowedRoles } = this.props;
    return (

      <Switch>

       
       
         <Route
          exact
          path="/:lng/userdashboard"
          render={() => (
            <Auth history={history} allowedRoles={allowedRoles}>
              <UserDashboardPage history={history} location={location} />
            </Auth>
          )}
        />
        
      </Switch>
    );
  }
}
export default DashboardRoute;
