import RoleActionTypes from '../Utility/RoleActionTypes';
export const setOrganizationDetails = (value) => async (dispatch) => {
    dispatch({
        type: RoleActionTypes.USER_ATTACH_ORG,
        payload: value
    });
}
