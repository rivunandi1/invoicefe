export const roleAddApi = (roleData) => {
    return roleData.data
}


