class RoleActionTypes {
    static USER_ATTACH_ORG = 'USER_ATTACH_ORG';
}
export default RoleActionTypes;