class RoleUtility {
    static validate_Max_No_Of_Days = (value) => {
        var number = value;
        var filter = /^(\d+(\.\d{0,2})?|\.?\d{1,2})$/;
        if (filter.test(number)) {
            return true;
        }
        else {
            return false;
        }
    }

    static Float_Validation = (value) => {
        var number = value;
        var filter = /[^0-9]|^0+(?!$)/g;
        if (!filter.test(number)) {
            return true;
        }
        else {
            return false;
        }
    }
}
export default RoleUtility;