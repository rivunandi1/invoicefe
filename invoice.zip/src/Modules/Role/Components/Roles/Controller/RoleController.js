import React from 'react';
import { get, post, put, del, patch } from '../../../../../Utility/Http';
import { roleAddApi, enterpriseGet, permissionAttachGet,roleGetApi,rolePermissionApi,deleteroleApi,departmentListUseServayApi,roleDataRelationsApi,roleDataRelationsGetApi,getSurveyJsonGetApi,deleteRoleDataRelationApi } from '../Model/RoleModel';
import Config from '../../../../../Utility/Config';


//cal hr new project api

export const roleAdd = (data, type,id="") => {
    if (type == "post") {
        return post(`${Config.extendedUrl}roles`, data).then((response) => {
            return roleAddApi(response)
        });
    } else if (type == "patch") {
        return patch(`${Config.extendedUrl}roles/${id}`, data).then((response) => {
            return roleAddApi(response)
        });
    }
};

export const enterprise = (data) => {
    return get(`${Config.extendedUrl}enterprises`, data).then((response) => {
        return enterpriseGet(response)
    });
};

export const permissionAttach = (data, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}generic/roles_permissions`, data).then((response) => {
            return permissionAttachGet(response)
        });
    }
};

export const roleGet = (data) => {
    return get(`${Config.extendedUrl}roles`, data).then((response) => {
        return roleGetApi(response)
    });
};

export const rolePermissionGetApi = (data) => {
    return get(`${Config.extendedUrl}generic/roles_permissions`,data).then((response) => {
        return rolePermissionApi(response)
    })
};

export const deleteRole = (data) => {
    return del(`${Config.extendedUrl}roles_permissions`, data).then((response) => {
        return deleteroleApi(response)
    });
};
export const deleteRoleDataRelation = (data) => {
    return del(`${Config.extendedUrl}role_data_relations`, data).then((response) => {
        return deleteRoleDataRelationApi(response)
    });
};

export const departmentListUseServay = (data) => {
    return get(`${Config.extendedUrl}departments/list`, data).then((response) => {
        return departmentListUseServayApi(response)
    });
};


export const roleDataRelations = (data, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}generic/role_data_relations`, data).then((response) => {
            return roleDataRelationsApi(response)
        });
    }
};


export const roleDataRelationsGet = (data) => {
    return get(`${Config.extendedUrl}generic/role_data_relations`, data).then((response) => {
        return roleDataRelationsGetApi(response)
    });
};
export const getSurveyJsonApi = (data) => {
    return get(`${Config.extendedUrl}roles/rolesurveyjson`, data).then((response) => {
        return getSurveyJsonGetApi(response)
    });
};