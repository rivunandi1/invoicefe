import React, { Component } from 'react';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { AgGridReact } from '@ag-grid-community/react';
import { InfiniteRowModelModule } from '@ag-grid-community/infinite-row-model';
import '@ag-grid-community/core/dist/styles/ag-grid.css';
import '@ag-grid-community/core/dist/styles/ag-theme-alpine.css';
// import * as RoleController from '../Controller/RoleController';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { loaderStateTrue, loaderStateFalse } from '../../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp, userrole } from '../../../Login/Actions/LoginAction';
import AutosuggestComponent from '../../../../Utility/Components/AutosuggestComponent';
import Utility from '../../../../Utility/Utility';
import CustomInput from '../../../../Utility/Components/CustomInput';
import ModalGlobal from '../../../../Utility/Components/ModalGlobal';
import AddRoleModalContent from './Components/AddRoleModalContent';
import * as RoleController from './Controller/RoleController';
//import AddRoleModal from './Components/AddRoleModal';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';

import * as Survey from "survey-react";
import * as widgets from "surveyjs-widgets";
import "survey-react/survey.css";
import RoleUtility from './Utility/RoleUtility';
import ConfirmationAlert from '../../../../Utility/Components/ConfirmationAlert';
import Config from '../../../../Utility/Config';




class Roles extends Component {
	constructor(props) {
		super(props);
		this.state = {
			addRolesModal: false,
			modules: [InfiniteRowModelModule],
			model: "",
			columnDefs: [
				{
					headerName: `${this.props.t('roles')}`,
					field: "role_name",
					minWidth: 400,
					cellRendererFramework: (params) => {
						if (params.data) {
							if (params.data.role_name && params.data.role_name.length > 30) {
								return <span className="textrenderview">
									<OverlayTrigger overlay={<Tooltip>{params.data.role_name}</Tooltip>}>
										<span >{params.data.role_name}</span>
									</OverlayTrigger>
								</span>
							} else {
								return <span className="textnowrapview">{params.data.role_name}</span>
							}
						} else {
							return <img src="https://www.ag-grid.com/example-assets/loading.gif" />
						}
					},
				},
				{
					headerName: `${this.props.t('Enterprise')}`,
					field: "enterprise",
					minWidth: 300,
					cellRendererFramework: (params) => {
						return <span>{params.data && params.data.org_details ? params.data.org_details.name : ""}</span>
					},
					//resizable: true
				},
				{
					headerName: "",
					field: "managepermissions",
					minWidth: 300,
					cellRendererFramework: (params) => {

						if (params.data) {
							if (this.props.roleWisePermission.hasOwnProperty("roles") && this.props.roleWisePermission.roles.read_write_permission != "" && this.props.roleWisePermission.roles.read_write_permission.split("").includes("W")) {
								return <button className="managePerBtn" onClick={this.managepermissions.bind(this, params)}>{this.props.t('managePermission')}</button>
							} else {
								return null;
							}
						} else {
							return null;
						}

					},
					//resizable: true
				},
			],

			defaultColDef: {
				flex: 1,
				//resizable: true,
				minWidth: 90,
			},

			frameworkComponents: {
				//modifierAndDelete: modifierAndDelete
			},
			context: { componentParent: this },

			/*components: {
				loadingRenderer: function (params) {
					if (params.value !== undefined) {
						return params.value;
					} else {
						return '<img src="https://www.ag-grid.com/example-assets/loading.gif">';
					}
				},
			},*/
			rowBuffer: 0,
			rowSelection: 'multiple',
			rowModelType: 'infinite',
			paginationPageSize: 10,
			cacheOverflowSize: 2,
			maxConcurrentDatasourceRequests: 1,
			infiniteInitialRowCount: 1,
			maxBlocksInCache: 10,

			//grid filter			
			//enterpriseFilterSelectedData:"",

			globalQueryParams: {},
			offset: 0,
			limit: 100,

			roleName: "",

			selectedRolePermissionsData: {},
			enterpriseList: [],
			traselectedEnterprise: "",
			travailleursFormData: {
				selectedEnterprise: ""
			},
			traselectedEnterpriseError: "",
			roleNamepermission: "",
			roleDataSet: [],
			roleEnFilterSelectedData: "",
			setServeyData: {},
			roleId: "",
			deptList: [],
			resultData: [],
			setEditDataSet: {},
			rolesPermissionsSetData: [],

			roleModalChange: false,
			//global Confirmation modal
			globalConfirmationModalShow: false,
			globalConfirmationModalTitle: "",
			globalConfirmationModalBodyFirstContent: "",
			globalConfirmationModalBodySecondContent: "",
			globalConfirmationModalBodyThirdContent: "",
			//global Confirmation modal,
			reserveServeyData: "",
			divisionLength:0

		}
	}

	componentDidMount() {
		//this.agGridDecisionMaker();
		this.enterprise();
		//this.departmentsListServy();
	}



	setRolepermission = (data, gridData) => {
		//console.log("data==========>>>", data)
		//console.log("gridData==========>>>", gridData)
		const { enterpriseList } = this.state;
		let tempHash = {}
		if (data.length > 0) {
			data.map((value, idx) => {
				tempHash[value.eventKey] = [];
				let read_write_permission = value.read_write_permission.split("");
				//console.log("read_write_permission", read_write_permission)
				//let _hash = {}
				//let __hash = {}
				if (read_write_permission.includes('R')) {
					//_hash['value'] = "R";
					tempHash[value.eventKey].push("R")
				}

				if (read_write_permission.includes('W')) {
					//__hash['value'] = "W"
					tempHash[value.eventKey].push("W")
				}
			})
		}
		//console.log("tempHash", tempHash)

		this.setState({
			setEditDataSet: tempHash
		}, () => {
			let traselectedEnterpriseHash = {};
			if (enterpriseList.length > 0) {
				enterpriseList.map((val, idx) => {
					if (val.value == gridData.data.org_id) {
						traselectedEnterpriseHash['label'] = val.label;
						traselectedEnterpriseHash['value'] = val.value;
						this.getSurveyJsonApi(traselectedEnterpriseHash, "EditMode");
					}
				})
			}

			/**/

			//console.log("traselectedEnterpriseHash", traselectedEnterpriseHash)
			this.setState({
				roleNamepermission: gridData.data.role_name,
				traselectedEnterprise: traselectedEnterpriseHash
			}, () => {
				this.setState({
					addRolesModal: true
				})
			})
		})
	}


	onGridReady = (params) => {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
		this.gridparams = params;

		var datasource = this.serverSideDataSource()
		params.api.setDatasource(datasource);

	};

	serverSideDataSource = () => {
		const { enterpriseFilterSelectedData, departmentFilterSelectedData, statutFilterSelectedData, activeInActiveWorkerFilter, userName } = this.state;
		let that = this
		return {
			getRows(params) {
				//console.log(JSON.stringify(params, null, 1));
				const { startRow, endRow, filterModel, sortModel } = params
				const { loaderStateTrue, loaderStateFalse } = that.props;
				loaderStateTrue();

				const { roleName, roleEnFilterSelectedData } = that.state;
				let filters = {};
				let globalQueryParamshash = {};
				let data = {}
				if (roleName != "") {
					data['role_name'] = roleName;
					filters['filter_op'] = { "role_name": "substring" }
				}

				if (roleEnFilterSelectedData != "") {
					data['org_id'] = roleEnFilterSelectedData.value;
				}

				data['offset'] = startRow;
				data['limit'] = Config.pageDataLimit;
				filters['filters'] = data

				RoleController.roleGet(filters).then((response) => {
					if (response.success) {
						let promiseArr = []
						response.data.map((item, index) => {
							let promise = new Promise((resolve, reject) => {
								resolve(item)
							})
							promiseArr.push(promise)
						})

						Promise.all(promiseArr).then((values) => {
							//console.log("values==========>", values)
							params.successCallback(values, response.total);
						});
						//params.successCallback(response.data, 499);
						//that.setImageDataTemp(response.data)

					} else {
						console.error(error);
						params.failCallback();
						Utility.toastNotifications(that.props.t('somethingWwrong'), "Error", "error")
					}
					loaderStateFalse();
				}).catch((error) => {
					console.error("************error*************", error)
					if (error) {
						//Utility.toastNotifications(error.message, "Error", "error");
					}
					loaderStateFalse();
					if (error.message == "Network Error") {
						// Utility.toastNotifications("Please login", "Error", "error");
						// this.props.logOutApp().then(
						//     () => this.props.history.push("/")
						// );
					}
				});
			}
		};
	}

	resetDataGrid = () => {
		this.gridparams.api.purgeServerSideCache(null)
		var datasource = this.serverSideDataSource()
		this.gridparams.api.setDatasource(datasource);

	}





	handleRoleSearchBar = (e) => {
		this.setState({
			roleName: e.target.value
		}, () => {
			if (this.state.roleName.length > 2) {
				this.resetDataGrid()
			}
			if (this.state.roleName == "") {
				this.resetDataGrid()
			}
		})
	}



	roleModalfunction = () => {
		this.setState({
			addRolesModal: true
		}, () => {
			//this.enterprise()
		});
	}


	closeRolesModal = () => {
		const { t } = this.props
		if (this.state.roleModalChange == true) {
			let data = {
				"title": t("cancelConfirmTitleGlobal"),
				"firstBodyContent": t("cancelConfirmContentGlobal")
			};
			this.globalConfirmationModalShow(data)
		} else {
			this.setState({
				addRolesModal: false
			}, () => {
				this.cancelRoleData()
			})
		}
	}

	globalConfirmationModalShow = (data) => {
		this.setState({
			globalConfirmationModalShow: true
		}, () => {
			this.setState({
				globalConfirmationModalTitle: data.title ? data.title : "",
				globalConfirmationModalBodyFirstContent: data.firstBodyContent ? data.firstBodyContent : "",
				globalConfirmationModalBodySecondContent: data.secondBodyContent ? data.secondBodyContent : "",
				globalConfirmationModalBodyThirdContent: data.thirdBodyContent ? data.thirdBodyContent : ""
			})
		})
	}

	globalConfirmButton = () => {
		this.globalCancelButton()
		this.setState({
			addRolesModal: false,
		}, () => {
			this.cancelRoleData()
		})
	}

	globalCancelButton = () => {
		this.setState({
			globalConfirmationModalShow: false,
			globalConfirmationModalTitle: "",
			globalConfirmationModalBodyFirstContent: "",
			globalConfirmationModalBodySecondContent: "",
			globalConfirmationModalBodyThirdContent: ""
		})
	}

	cancelRoleData = () => {
		this.setState({
			addRolesModal: false,
			roleNamepermission: "",
			roleNamepermissionError: "",
			traselectedEnterprise: "",
			traselectedEnterpriseError: "",
			setServeyData: {},
			roleId: "",
			setEditDataSet: {},
			model: new Survey.Model(this.state.model),
			rolesPermissionsSetData: [],
			roleModalChange: false
		})
	}

	/*onCompleteRolePermissions = (result,options) => {
		
		//console.log("result=========",JSON.stringify(result))		
		this.setState({
			selectedRolePermissionsData: result.data
		}, () => {
			this.rolePermissionsSubmit()
		})

	}*/

	/*departmentsListServy = () => {
		const { loaderStateTrue, loaderStateFalse, logOutApp } = this.props;
		loaderStateTrue();
		RoleController.departmentListUseServay().then((response) => {
			if (response.success) {
				console.log("response=================>>>", response)
				let departmentArry = []
				if (response.data.length > 0) {
					response.data.map((value, idx) => {
						let tempHash = {};
						tempHash['text'] = value.name;
						tempHash['value'] = value.id;
						departmentArry.push(tempHash);
					})

					this.setState({
						deptList: departmentArry
					}, () => {
						Survey.JsonObject.metaData.addProperty("question", { name: "category:string" });
						this.setState({
							model: new Survey.Model(RoleUtility.getSurveyJson(this.props.t, this.state.deptList))
						}, () => {
							//Survey.Serializer.addProperty("question", "tag:string")

						})
					})
				}
			} else {
				Utility.toastNotifications(this.props.t('somethingWwrong'), "Error", "error")
			}
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});

	}*/





	onCompletingRolePermissions = (sender, options) => {

		/*this.setState({
			//model: new Survey.Model(this.state.reserveServeyData),
		}, () => {*/
		var resultData = [];
		var resultDisplayData = [];
		for (var key in sender.data) {
			var question = sender.getQuestionByValueName(key);
			console.log("question====", question)

			if (!!question) {
				var item = { value: question.value };
				//If question name (question.valueName) doesn't equal to question.title

				//var selectAllselected = question.value.isOtherSelected;


				if (key !== question.title) {
					item.title = question.title;
				}
				resultDisplayData.push(item.displayValue);
				//If question value different from displayValue
				if (item.value != question.displayValue) {
					item.displayValue = question.displayValue
				}
				//If the custom property tag is defined set
				if (question.category !== undefined) {
					item.category = question.category;
					console.log("question.dashbord_tagbox====", question.dashbord_tagbox)
				}

				item['eventKey'] = key;
				resultData.push(item);

			}
		}
		//console.log("sender========>>>", sender)
		//console.log("resultDisplayData========>>>", resultDisplayData)
		//return false;
		//Demo formating

		//console.log("sender.data========>>>", sender.data)



		options.allowComplete = false;
		options.isCompleteOnTrigger = false;
		/*if (Object.keys(sender.data).length == 0) {
			Utility.toastNotifications("Please set your one permission", "Warning", "warning")
		}*/


		let valid = this.validRoleData(resultData);

		if (valid && Object.keys(sender.data).length > 0) {
			this.setState({
				selectedRolePermissionsData: sender.data,
				resultData: resultData
			}, () => {
				//console.log("selectedRolePermissionsData========oncomplete", this.state.selectedRolePermissionsData)
				this.rolePermissionsSubmit()
			})
		} else {
			Utility.toastNotifications((this.props.t('pleaseSetYourOnePermission')), "Warning", "warning")
		}
		//})
	}

	formateDivisionsWiseRole = (roleId, resultData) => {
		console.log("resultData=========", resultData)
		let eventHash = {};
		resultData.map((item, idx) => {
			eventHash[item.eventKey] = item
		})
		let finalArry = []
		Object.keys(eventHash).map((item) => {

			if (eventHash[item].category != "admin") {
				let tempHash = {}
				tempHash['role_id'] = roleId;
				tempHash['attr_name'] = "division_id";
				tempHash['eventkey'] = item;
				tempHash['category'] = eventHash[item].category;

				tempHash['attr_value'] = JSON.stringify([])
				if (eventHash[item].category == "dashboard") {
					tempHash['attr_value'] = JSON.stringify(eventHash["dashbord_tagbox"].value);
					tempHash['is_all_attr_value'] =this.state.divisionLength==eventHash["dashbord_tagbox"].value.length?1:0
				}

				if (eventHash[item].category == "organization") {
					tempHash['attr_value'] = JSON.stringify(eventHash["organization_tagbox"].value);
					tempHash['is_all_attr_value'] =this.state.divisionLength==eventHash["organization_tagbox"].value.length?1:0
				}

				if (eventHash[item].category == "planning") {
					tempHash['attr_value'] = JSON.stringify(eventHash["planning_tagbox"].value);
					tempHash['is_all_attr_value'] =this.state.divisionLength==eventHash["planning_tagbox"].value.length?1:0
				}

				if (item != "organization_tagbox" && item != "dashbord_tagbox") {
					finalArry.push(tempHash);
				}
			}
		})

		//console.log("finalArry===", finalArry);
		//return false;
		return finalArry;

	}




	roleNameHandelChange = (e) => {
		this.setState({
			roleNamepermission: e.target.value,
			roleNamepermissionError: "",
			roleModalChange: true,
		})
	}

	validRoleData = (result) => {
		const { traselectedEnterprise, roleNamepermission, model, reserveServeyData } = this.state;
		let valid = true;
		if (traselectedEnterprise == "") {
			this.setState({
				traselectedEnterpriseError: this.props.t('invalidField')
			})
			valid = false;
		} else {
			this.setState({ traselectedEnterpriseError: "" })
		}

		if (roleNamepermission == "") {
			this.setState({
				roleNamepermissionError: this.props.t('invalidField')
			})
			valid = false;
		} else {
			this.setState({ roleNamepermissionError: "" })
		}

		let dashbordArry = [];
		let orgArry = [];
		let planningArry = [];

		let dashbordTypeofaccessArry = [];
		let orgTypeofaccessArry = [];
		let planningTypeofaccessArry = [];

		//console.log("result===", result)

		if (result.length > 0) {
			result.map((value) => {
				if (value.category == 'dashboard') {
					dashbordArry.push(value.category)
				}

				if (value.category == 'dashboard' && value.title == 'Type of access') {
					dashbordTypeofaccessArry.push(value.title)
				}



				if (value.category == 'organization') {
					orgArry.push(value.category)
				}

				if (value.category == 'organization' && value.title == 'Type of access') {
					orgTypeofaccessArry.push(value.title)
				}

				if (value.category == 'planning') {
					planningArry.push(value.category)
				}

				if (value.category == 'planning' && value.title == 'Type of access') {
					planningTypeofaccessArry.push(value.title)
				}

			})
		}

		//console.log("dashbordArry===", dashbordArry.length)
		//console.log("dashbordTypeofaccessArry===", dashbordTypeofaccessArry)
		/*console.log("orgArry===", orgArry)
		console.log("orgTypeofaccessArry===", orgTypeofaccessArry)
		console.log("planningArry===", planningArry)
		console.log("planningTypeofaccessArry===", planningTypeofaccessArry)*/

		/*if (dashbordArry.length == 0) {
			valid = false;
		}*/

		if (dashbordArry.length > 0 && dashbordTypeofaccessArry.length == 0) {
			valid = false;
			Utility.toastNotifications(this.props.t('PleaseSelectOneDepartment'), "Warning", "warning")
		}

		/*if (orgArry.length == 0) {
			valid = false;			
		}*/

		if (orgArry.length > 0 && orgTypeofaccessArry.length == 0) {
			valid = false;
			Utility.toastNotifications(this.props.t('PleaseSelectOneDepartment'), "Warning", "warning")
		}

		/*if (planningArry.length == 0) {
			valid = false;			
		}*/

		if (planningArry.length > 0 && planningTypeofaccessArry.length == 0) {
			valid = false;
			Utility.toastNotifications(this.props.t('PleaseSelectOneDepartment'), "Warning", "warning")
		}

		return valid;
	}

	onValueChanged = (result, options) => {
		//console.log("options======oldValue",options.oldvalue)
		//console.log("options======value",options.value)
		//console.log("value changed!", JSON.stringify(result));


		//console.log("options!", JSON.stringify(options));

		for (var key in result.data) {
			var question = result.getQuestionByValueName(key);
			//console.log("question======", question.tag)
			//console.log("category======", question.category)

			//this.requiredPermissionSetOrnot(question.category,true)

		}

		//console.log("this.state.model============",this.state.model.getPlainData())
		//console.log("this.state.getPropertyByName============",this.state.model.getDisplayValue)
		//console.log("this.state.model============",this.state.model.currentPanel)


	}

	requiredPermissionSetOrnot = (category, type) => {
		const { reserveServeyData } = this.state;
		let fullarry = []
		if (reserveServeyData.pages[0].elements.length > 0) {
			reserveServeyData.pages[0].elements.map((value, idx) => {
				let arry = []
				value.elements.map((v, i) => {
					if (v.hasOwnProperty('isRequired') && v.isRequired == false && v.category == category) {
						v['isRequired'] = type
						arry.push(v)
					} else {
						v['isRequired'] = false
						arry.push(v)
					}
				})
				fullarry.push(value);
			})
		}
		let hash = {
			"pages": [
				{
					"name": "RolesPage",
					"elements": fullarry
				}
			]
		}

		this.setState({
			reserveServeyData: hash,
			//model:new Survey.Model(hash),
		})

		//console.log("hash===========",hash)

	}

	formatRole = () => {
		let { selectedRolePermissionsData, roleNamepermission, traselectedEnterprise } = this.state
		/*let roleName = ""
		if (Object.keys(selectedRolePermissionsData).length > 0) {
			Object.keys(selectedRolePermissionsData).map((item, index) => {
				if (item == "roleName") {
					roleName = selectedRolePermissionsData[item]
				}
			}),
		}*/
		let dataset = [
			{
				"role_name": roleNamepermission,
				"org_id": traselectedEnterprise.value
			}
		]
		return dataset

	}
	formatRolePermissions = (role_id) => {

		let { selectedRolePermissionsData } = this.state
		//console.log("selectedRolePermissionsData=============>>", selectedRolePermissionsData)
		let permissionsArray = []
		if (Object.keys(selectedRolePermissionsData).length > 0) {
			Object.keys(selectedRolePermissionsData).map((item, index) => {
				let _hash = {}
				//if (item != "roleName") {
				_hash["eventKey"] = item
				_hash["role_id"] = role_id
				_hash["read_write_permission"] = ""
				selectedRolePermissionsData[item].map((itemInner, IndexInner) => {

					//console.log("itemInner======", itemInner)

					if (itemInner == "R") {
						_hash["read_write_permission"] = 'R'
					}
					if (itemInner == "W") {
						_hash["read_write_permission"] += 'W'
					}


					//_hash["read_write_permission"] += itemInner.text.charAt(0).toUpperCase();

				})
				if (_hash.read_write_permission != "") {
					permissionsArray.push(_hash)
				}

				//}
			})
		}
		let dataset = []
		dataset = [
			{
				"resource_name": "RolesPermissions",
				"column_value_pair": permissionsArray
			}
		]
		return dataset
	}
	rolePermissionsSubmit = () => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		const { roleId } = this.state;
		let dataset = this.formatRole()

		let type = 'post';
		if (roleId != "") {
			type = "patch"
			dataset = dataset[0]
		}
		//console.log("roleId===",roleId)

		loaderStateTrue();
		RoleController.roleAdd(dataset, type, roleId).then((response) => {
			loaderStateFalse();
			if (type == 'patch') {
				if (response.success) {
					this.deleteRole(roleId)
					this.deleteRoleDataRelation(roleId)
				}
			} else {
				if (response.length > 0) {
					response.map((data, index) => {
						if (data.success) {
							this.permissionAttach(data.data.id)
							this.roleDataRelationsSubmit(data.data.id)
							//Utility.toastNotifications(data.message, "Success", "success")
						} else {
							Utility.toastNotifications(data.message, "Error", "error")
						}
					})
				}
			}


		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				//Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});

	}


	roleDataRelationsSubmit = (roleId) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		const { resultData, } = this.state;
		let dataset = this.formateDivisionsWiseRole(roleId, resultData);

		//console.log("dataset roleDataRelationsSubmit ", dataset)

		let data = [
			{
				"resource_name": "RoleDataRelation",
				"column_value_pair": dataset
			}
		]

		if (data[0].column_value_pair.length > 0) {
			let type = 'post';
			loaderStateTrue();
			RoleController.roleDataRelations(data, type).then((response) => {
				loaderStateFalse();
			}).catch((error) => {
				console.error("************error*************", error)
				if (error) {
					Utility.toastNotifications(error.message, "Error", "error");
				}
				loaderStateFalse();
				if (error.message == "Network Error") {

				}
			});
		} else {
			this.setState({
				roleModalChange: false
			}, () => {
				this.closeRolesModal()
			})
			this.resetDataGrid()
		}

	}

	managepermissions = (gridObj) => {
		this.setState({
			roleId: gridObj.data.id
		}, () => {
			this.roleDataRelationsGet(gridObj);
			/*let data = [{ "resource_name": "RolesPermissions", "columns": ["id", "role_id", "eventKey", "read_write_permission", "is_enabled"], "column_filters": [{ "is_enabled": 1, "role_id": this.state.roleId }] }]
			let filter = {}
			filter['filters'] = JSON.stringify(data);
			RoleController.rolePermissionGetApi(filter).then((response) => {
				if (response.data.length > 0) {
					this.roleDataRelationsGet();
					this.setRolepermission(response.data[0].RolesPermissions_data, obj);
				}
			}).catch((error) => {
				Utility.toastNotifications(error.message, "Error", "error")
				
			});*/
		})
	}


	roleDataRelationsGet = (gridObj) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		const { roleId } = this.state;

		let data = [{ "resource_name": "RoleDataRelation", "columns": ["id", "role_id", "eventkey", "attr_name", "attr_value", "category"], "column_filters": [{ "is_enabled": 1, "role_id": roleId }] }]
		let filter = {}
		filter['filters'] = JSON.stringify(data);

		loaderStateTrue();
		RoleController.roleDataRelationsGet(filter).then((response) => {
			loaderStateFalse();
			if (response.success) {
				let dataSet = response.data[0].RoleDataRelation_data;
				this.setState({
					rolesPermissionsSetData: dataSet
				}, () => {
					this.rolesPermissionsApi(gridObj);
				})
			}
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				//Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});

	}

	rolesPermissionsApi = (gridObj) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		loaderStateTrue();
		let data = [{ "resource_name": "RolesPermissions", "columns": ["id", "role_id", "eventKey", "read_write_permission", "is_enabled"], "column_filters": [{ "is_enabled": 1, "role_id": this.state.roleId }] }]
		let filter = {}
		filter['filters'] = JSON.stringify(data);
		RoleController.rolePermissionGetApi(filter).then((response) => {
			loaderStateFalse();
			if (response.data.length > 0) {
				//this.roleDataRelationsGet();
				this.setRolepermission(response.data[0].RolesPermissions_data, gridObj);
			}
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				//Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});
	}

	deleteRole = (role_id) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;

		let data = {}
		data["role_id"] = role_id;
		loaderStateTrue();
		RoleController.deleteRole(data).then((response) => {
			if (response.success) {
				this.permissionAttach(role_id)
				loaderStateFalse();

			} else {
				loaderStateFalse();
				Utility.toastNotifications(response.message, "Error", "error");
			}
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});
	}

	deleteRoleDataRelation = (role_id) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;

		let data = {}
		data["role_id"] = [role_id];
		loaderStateTrue();
		RoleController.deleteRoleDataRelation(data).then((response) => {
			if (response.success) {
				this.roleDataRelationsSubmit(role_id)
				loaderStateFalse();

			} else {
				loaderStateFalse();
				Utility.toastNotifications(response.message, "Error", "error");
			}
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				//Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});

	}

	permissionAttach = (role_id) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		let dataset = this.formatRolePermissions(role_id)
		//console.log("dataset permissionAttach", dataset)
		if (dataset[0].column_value_pair.length > 0) {
			let type = 'post';
			loaderStateTrue();
			RoleController.permissionAttach(dataset, type).then((response) => {
				loaderStateFalse();
				this.setState({
					roleModalChange: false
				}, () => {
					this.closeRolesModal()
				})
				this.resetDataGrid();
				if (response.data.length > 0) {
					Utility.toastNotifications(response.data[0].message, "Success", "success")
					response.data.map((item, index) => {
						if (item.success) {
							//Utility.toastNotifications(item.message[0], "Success", "success")
						} else {
							Utility.toastNotifications(item.message, "Error", "error")
						}
					})
				}


			}).catch((error) => {
				console.error("************error*************", error)
				if (error) {
					//Utility.toastNotifications(error.message, "Error", "error");
				}
				loaderStateFalse();
				if (error.message == "Network Error") {
					// Utility.toastNotifications("Please login", "Error", "error");
					// this.props.logOutApp().then(
					//     () => this.props.history.push("/")
					// );
				}
			});
		} else {
			this.setState({
				roleModalChange: false
			}, () => {
				this.closeRolesModal()
			})
			this.resetDataGrid()
		}
	}

	handleChangeAlltravailleurSelected = (type, event) => {
		const { travailleursFormData } = this.state;
		if (type == 'Enterprise') {
			this.setState({
				traselectedEnterprise: event,
				traselectedEnterpriseError: ""
			}, () => {
				travailleursFormData['selectedEnterprise'] = event;
				this.getSurveyJsonApi(this.state.traselectedEnterprise);
			})
		}

		this.setState({
			travailleursFormData,
			roleModalChange: true,
		})
	}



	getSurveyJsonApi = (orgId, type = "",) => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		loaderStateTrue();
		let filter = {}
		filter['filters'] = { "org_id": orgId.value };
		RoleController.getSurveyJsonApi(filter).then((response) => {
			//console.log("response===========", response)
			loaderStateFalse();

			Survey.JsonObject.metaData.addProperty("question", { name: "category:string" });

			//this.modifySurveyData(response.data).then((res) => {

			let divisionLength = response.data.pages[0].elements[0].elements[0].choices.length
			this.setState({
				model: new Survey.Model(response.data),
				divisionLength
				//reserveServeyData: res
			}, () => {
				if (type == "EditMode") {
					let setData = this.state.setEditDataSet;
					if (Object.keys(setData).length > 0) {
						Object.keys(setData).map((val) => {
							this.state.model.setValue(val, setData[val]);

						})
					}

					let setPermissionData = this.state.rolesPermissionsSetData;
					console.log("setPermissionData=========", setPermissionData)

					if (setPermissionData.length > 0) {
						setPermissionData.map((value) => {
							if (value.category == "dashboard") {
								this.state.model.setValue("dashbord_tagbox", JSON.parse(value.attr_value));
							}
							if (value.category == "organization") {
								this.state.model.setValue("organization_tagbox", JSON.parse(value.attr_value));
							}

							if (value.category == "planning") {
								this.state.model.setValue("planning_tagbox", JSON.parse(value.attr_value));
							}
						})
					}
				}
				//this.state.model.setValue("dashbord",["Can view only","Can edit"]);
			})
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				//Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});
		//})
	}

	modifySurveyData = (dataSet) => {
		let promise = new Promise((resolve, reject) => {
			//console.log("dataSet====",dataSet)
			let fullarry = []
			if (dataSet.pages[0].elements.length > 0) {
				dataSet.pages[0].elements.map((value, idx) => {

					let arry = []

					value.elements.map((v, i) => {
						//console.log("v=====>>",v)
						if (v.hasOwnProperty('isRequired') && v.isRequired) {
							v['isRequired'] = false
							arry.push(v)
						} else {
							arry.push(v)
						}
					})
					//console.log("value====>>",value)
					fullarry.push(value);
				})
			}
			let hash = {
				"pages": [
					{
						"name": "RolesPage",
						"elements": fullarry
					}
				]
			}

			resolve(hash)
		})
		return promise;
	}

	enterprise = () => {
		const { loaderStateTrue, loaderStateFalse } = this.props;
		loaderStateTrue();
		RoleController.enterprise().then((response) => {
			if (response.success) {
				let enterpriseArry = [];
				response.data.map((endata) => {
					let enterpriseHash = {};
					enterpriseHash['label'] = endata.name;
					enterpriseHash['value'] = endata.id;
					enterpriseArry.push(enterpriseHash);
				})
				this.setState({
					enterpriseList: enterpriseArry
				}, () => {
					//this.department();
				})
			}
			loaderStateFalse();
		}).catch((error) => {
			console.error("************error*************", error)
			if (error) {
				//Utility.toastNotifications(error.message, "Error", "error");
			}
			loaderStateFalse();
			if (error.message == "Network Error") {
				// Utility.toastNotifications("Please login", "Error", "error");
				// this.props.logOutApp().then(
				//     () => this.props.history.push("/")
				// );
			}
		});
	}

	handleRoleChangeEnterpriseFilter = (type, event) => {
		if (type == 'enterprise') {
			if (event) {
				this.setState({
					roleEnFilterSelectedData: event
				}, () => {
					this.resetDataGrid();
				})
			} else {
				this.setState({
					roleEnFilterSelectedData: "",
				}, () => {
					this.resetDataGrid();
				})
			}

		}
	}

	clearSearchValue = () => {
		this.setState({
			roleName: ""
		}, () => {
			this.resetDataGrid()
		})
	}

	render() {
		const { t, closeroleModal, roleAddModal, roleModalfunction, roleWisePermission } = this.props;
		return (
			<div className="gridcontainer">
				<div className="gridtopviews gridtopviewsroles">
					<div className="dropdownbox enterprisedrop">
						<AutosuggestComponent
							handleOnChange={this.handleRoleChangeEnterpriseFilter.bind(this, 'enterprise')}
							//handleOnInputChange={(e) => { this.props.handleChangeEnterpriseInput }}
							options={this.state.enterpriseList}
							selectedValue={this.state.roleEnFilterSelectedData}
							name=''
							isMulti={false}
							placeholder={t('Enterprise')}
							isDisabled={false}
							isClearable={true}
							//defaultMenuIsOpen={true}
							closeButton={true}
							menuHeader={t('Enterprise')}
							isSearchable={true}
						/>
					</div>
					{roleWisePermission.hasOwnProperty("roles") && roleWisePermission.roles.read_write_permission != "" && roleWisePermission.roles.read_write_permission.split("").includes("W") ?
						<div className="rightboxes">
							<button type="button" className="useraddbtn" onClick={this.roleModalfunction}>{t('Ajouter')}</button>
						</div>
						: null}

					<div className="pageinnersearch">
						<button type="button" className="btn btn-link search_btn_addon"><i className="fa fa-search"></i></button>
						<CustomInput
							parentClassName="comment_input_field"
							name="srchBox"
							type="text"
							placeholder={this.props.t('searchroles')}
							onChange={this.handleRoleSearchBar.bind(this)}
							value={this.state.roleName}
						/>
						{
							this.state.roleName != "" ?
								< button type="button" className="btn btn-link dropclosebtn" onClick={this.clearSearchValue}>
									<img src={require('../../../../Utility/Public/images/dropcloseicon.png')} className="searchClearIcon" />
								</button>
								: null}
					</div>
				</div>
				<div className="clearfix"></div>
				<div className="ag-theme-alpine aggridview agdepart roleviewgrid">
					{/*<AgGridReact
						modules={this.state.modules}
						columnDefs={this.state.columnDefs}
						defaultColDef={this.state.defaultColDef}
						components={this.state.components}
						rowBuffer={this.state.rowBuffer}
						rowSelection={this.state.rowSelection}
						rowModelType={this.state.rowModelType}
						paginationPageSize={this.state.paginationPageSize}
						cacheOverflowSize={this.state.cacheOverflowSize}
						maxConcurrentDatasourceRequests={
							this.state.maxConcurrentDatasourceRequests
						}
						infiniteInitialRowCount={this.state.infiniteInitialRowCount}
						maxBlocksInCache={this.state.maxBlocksInCache}
						onGridReady={this.onGridReady}
						rowHeight={62.5}
						headerHeight={47}
						context={this.state.context}
						frameworkComponents={this.state.frameworkComponents}
					/>*/}
					<AgGridReact
						modules={this.state.modules}
						columnDefs={this.state.columnDefs}
						defaultColDef={this.state.defaultColDef}
						components={this.state.components}
						rowSelection="multiple"
						rowModelType="infinite"
						onGridReady={this.onGridReady}
						rowHeight={62.5}
						headerHeight={47}
						cacheBlockSize={Config.pageDataLimit}
					/>

				</div>
				<ModalGlobal
					show={this.state.addRolesModal}
					onHide={this.closeRolesModal}
					title={t('addnewrole')}
					className="modalcustomize workerlistmodal addrolemodal"
					footer={false}
					closeButton={true}
					body={
						<AddRoleModalContent
							//onCompleteRolePermissions={this.onCompleteRolePermissions}
							handleChangeAlltravailleurSelected={this.handleChangeAlltravailleurSelected}
							enterpriseList={this.state.enterpriseList}
							traselectedEnterprise={this.state.traselectedEnterprise}
							traselectedEnterpriseError={this.state.traselectedEnterpriseError}
							roleNameHandelChange={this.roleNameHandelChange}
							roleNamepermissionError={this.state.roleNamepermissionError}
							roleNamepermission={this.state.roleNamepermission}
							onCompletingRolePermissions={this.onCompletingRolePermissions}
							onValueChanged={this.onValueChanged}
							model={this.state.model}
							roleId={this.state.roleId}


						/>
					}
				/>

				<ModalGlobal
					show={this.state.globalConfirmationModalShow}
					onHide={this.globalConfirmationModalHide}
					className="modalcustomize confirmationalertmodal"
					bodyClassName="cancelConfirmationbody"
					headerclassName="close_btn_icon"
					title={this.state.globalConfirmationModalTitle}
					footer={false}
					body={
						<ConfirmationAlert
							BodyFirstContent={this.state.globalConfirmationModalBodyFirstContent}

							BodySecondContent={this.state.globalConfirmationModalBodySecondContent}

							BodyThirdContent={this.state.globalConfirmationModalBodyThirdContent}

							confirmationButtonContent={t('confirm')}
							cancelButtonContent={t('cancel')}
							deleteConfirmButton={this.globalConfirmButton}
							deleteCancleButton={this.globalCancelButton}
						/>
					}
				/>

			</div>
		);
	}
}



const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.LoginReducer.userCredentials,
		roleWisePermission: globalState.mainReducerData.roleWisePermission
	};
}

export default withRouter(connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(Roles)));