class RoleUtility {
    static getSurveyJson = (t, deptList) => {
        //console.log("deptList======", deptList)
        let data = {
            //goNextPageAutomatic: false,            
            "pages": [
                {
                    "name": "page1",
                    "elements": [
                        {
                            "type": "panel",
                            "name": "dashbord",                            
                            "state": "collapsed",
                            "title": "Dashboard",
                            "elements": [
                                {
                                    "type": "panel",
                                    "name": "dashbordpermission",
                                    "elements": [
                                        {
                                            "name": "dashbord_tagbox",
                                            "type": "tagbox",
                                            "choices": deptList,
                                            "category":"dashboard",
                                            "title":"Department"
                                            
                                        },
                                        {
                                            "type": "checkbox",
                                            "name": "dashbord",
                                            "selectAllText": t('dashboard'),
                                            "hasSelectAll": true,
                                            "category":"dashboard",
                                            "choices": [
                                                {
                                                    "text": t('viewOnly')
                                                },
                                                {
                                                    "text": t('canEdit')
                                                }                                               

                                            ]
                                        },
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "panel",
                            "name": "organization",
                            "state": "collapsed",
                            "title": "Organization module",                            
                            "elements": [
                                {
                                    "name": "organization_tagbox",
                                    "type": "tagbox",
                                    "choices": deptList,
                                    "category":"organization"
                                },

                                {
                                    "type": "checkbox",
                                    "name": "worker",
                                    "selectAllText": t('workerList'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "addWorker",
                                    "selectAllText": t('addWorker'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "personal",
                                    "selectAllText": t('personalTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "professional",
                                    "selectAllText": t('professionalTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "documents",
                                    "selectAllText": t('documentsTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "career",
                                    "selectAllText": t('careerTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "counters",
                                    "selectAllText": t('leaveTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "archiveEmployee",
                                    "selectAllText": t('archiveEmployee'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "deleteEmployee",
                                    "selectAllText": t('deleteEmployee'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "resetPassword",
                                    "selectAllText": t('resetPassword'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "entreprise",
                                    "selectAllText": t('entrepriseTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "department",
                                    "selectAllText": t('departmentTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "team",
                                    "selectAllText": t('teamTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {

                                    "type": "checkbox",
                                    "name": "function",
                                    "selectAllText": t('functionTab'),
                                    "hasSelectAll": true,
                                    "category":"organization",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                }
                            ]
                        },
                        {
                            "type": "panel",
                            "name": "planning",
                            "state": "collapsed",
                            "title": "Module Planning",
                            "elements": [
                                {
                                    "type": "checkbox",
                                    "name": "planningpermission",
                                    "choices": [
                                        {
                                            "name": "planning_tagbox",
                                            "type": "tagbox",
                                            "choices": deptList,
                                            "category":"planning",
                                            "title":"Department"
                                            
                                        },
                                        {
                                            "type": "checkbox",
                                            "name": "roles",
                                            "selectAllText": "Roles",
                                            "hasSelectAll": true,
                                            "category":"planning",
                                            "choices": [
                                                {
                                                    "text": t('viewOnly')
                                                },
                                                {
                                                    "text": t('canEdit')
                                                }                                               

                                            ]
                                        },
                                        {
                                            "type": "checkbox",
                                            "name": "leave",
                                            "selectAllText": "Leave",
                                            "hasSelectAll": true,
                                            "category":"planning",
                                            "choices": [
                                                {
                                                    "text": t('viewOnly')
                                                },
                                                {
                                                    "text": t('canEdit')
                                                }                                               

                                            ]
                                        },
                                        {
                                            "type": "checkbox",
                                            "name": "codes",
                                            "selectAllText": "Codes",
                                            "hasSelectAll": true,
                                            "category":"planning",
                                            "choices": [
                                                {
                                                    "text": t('viewOnly')
                                                },
                                                {
                                                    "text": t('canEdit')
                                                }                                               

                                            ]
                                        },
                                        {
                                            "type": "checkbox",
                                            "name": "interims",
                                            "selectAllText": "Interims",
                                            "hasSelectAll": true,
                                            "category":"planning",
                                            "choices": [
                                                {
                                                    "text": t('viewOnly')
                                                },
                                                {
                                                    "text": t('canEdit')
                                                }                                               

                                            ]
                                        },
                                        {
                                            "type": "checkbox",
                                            "name": "roledocuments",
                                            "selectAllText": "General document",
                                            "hasSelectAll": true,
                                            "category":"planning",
                                            "choices": [
                                                {
                                                    "text": t('viewOnly')
                                                },
                                                {
                                                    "text": t('canEdit')
                                                }                                               

                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "panel",
                            "name": "skill",
                            "state": "collapsed",
                            "title": "Module Skill",
                            "elements": [
                                {
                                    "type": "checkbox",
                                    "name": "skillpermission",
                                    "choices": [
                                        "Access to the matrix",
                                        "Access to the matrix of all departments",
                                        "Access to the matrix of the assigned department",
                                        "Access to alerts",
                                        "Access to alerts from all departments",
                                        "Access to assigned department alerts",
                                        "Access to the training plan",
                                        "Manage training",
                                        "Fill in the results of a training",
                                        "Access to the catalog",
                                        "Manage the catalog",
                                        "Access to coaching",
                                        "Access to coaching from all departments",
                                        "Access to the coaching sessions of the assigned department",
                                        "Fill out a coaching form"
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "panel",
                            "name": "admin",
                            "state": "collapsed",
                            "title": "Module Admin",
                            "elements": [
                                {
                                    "type": "checkbox",
                                    "name": "roles",
                                    "selectAllText": 'Roles',
                                    "hasSelectAll": true,
                                    "category":"admin",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {
                                    "type": "checkbox",
                                    "name": "leave",
                                    "selectAllText": 'Leave',
                                    "hasSelectAll": true,
                                    "category":"admin",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {
                                    "type": "checkbox",
                                    "name": "codes",
                                    "selectAllText": 'Codes',
                                    "hasSelectAll": true,
                                    "category":"admin",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {
                                    "type": "checkbox",
                                    "name": "interims",
                                    "selectAllText": 'Interims',
                                    "hasSelectAll": true,
                                    "category":"admin",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                },
                                {
                                    "type": "checkbox",
                                    "name": "roledocuments",
                                    "selectAllText": 'General Documents',
                                    "hasSelectAll": true,
                                    "category":"admin",
                                    "choices": [

                                        {
                                            "text": t('viewOnly')
                                        },
                                        {
                                            "text": t('canEdit')
                                        }

                                    ]
                                }
                            ]
                        }


                    ]
                }
            ]
        }
        return data
    }
}
export default RoleUtility;