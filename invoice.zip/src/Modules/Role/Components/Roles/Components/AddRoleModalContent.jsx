import React, { Component } from 'react';
import "react-datepicker/dist/react-datepicker.css";
import CustomInput from '../../../../../Utility/Components/CustomInput';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { loaderStateTrue, loaderStateFalse } from '../../../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp, userrole } from '../../../../Login/Actions/LoginAction';
import AutosuggestComponent from '../../../../../Utility/Components/AutosuggestComponent';
import "bootstrap/dist/css/bootstrap.min.css";




//USe survey npm
import * as Survey from "survey-react";
import * as widgets from "surveyjs-widgets";
import "survey-react/survey.css";

import "jquery-ui/themes/base/all.css";
import "nouislider/distribute/nouislider.css";
import "select2/dist/css/select2.css";
import "bootstrap-slider/dist/css/bootstrap-slider.css";

import "jquery-bar-rating/dist/themes/css-stars.css";

import $ from "jquery";
import "jquery-ui/ui/widgets/datepicker.js";
import "select2/dist/js/select2.js";
import "jquery-bar-rating";

import "pretty-checkbox/dist/pretty-checkbox.css";



//import "icheck/skins/square/blue.css";
window["$"] = window["jQuery"] = $;
//require("icheck");



Survey.StylesManager.applyTheme("default");

//widgets.icheck(Survey, $);
widgets.prettycheckbox(Survey);
widgets.select2(Survey, $);
widgets.inputmask(Survey);
widgets.jquerybarrating(Survey, $);
widgets.jqueryuidatepicker(Survey, $);
widgets.nouislider(Survey);
widgets.select2tagbox(Survey, $);
//widgets.signaturepad(Survey);
widgets.sortablejs(Survey);
widgets.ckeditor(Survey);
widgets.autocomplete(Survey, $);
widgets.bootstrapslider(Survey);
//Finish




class AddRoleModalContent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			// 	activeEventKey: "0"
			//model: new Survey.Model(RoleUtility.getSurveyJson(this.props.t))
		}
	}

	onReadyChanged = (options) => {
		console.log("onReadyChanged==========options",options)
	}
	getSelectValues = () => {
		//console.log("onReadyChanged")
	}

	



	



	render() {

		const { show, onHide, className, headerclassName, bodyClassName, t } = this.props;


		return (
			<>
				<div className="modalinnerbody">
					<div className="col-md-12" style={{ paddingBottom: '10px' }}>
						<div className="row">
							<div className="col-md-6 removepr">
								<CustomInput
									parentClassName="input_field_inner"
									labelName={t('Nom')}
									errorLabel={this.props.roleNamepermissionError}
									name="roleNamepermission"
									type="text"
									value={this.props.roleNamepermission}
									labelPresent={true}
									onChange={this.props.roleNameHandelChange}
								//placeholder=""
								//readOnly={true}
								/>
							</div>
							<div className="col-md-6 removepl">
								<div className="dropdowninnerbox">
									<label>{t('Enterprise')}</label>
									<AutosuggestComponent
										handleOnChange={this.props.handleChangeAlltravailleurSelected.bind(this, "Enterprise")}
										//handleOnInputChange={(e) => { this.props.handleChangeEnterpriseInput }}
										options={this.props.enterpriseList}
										selectedValue={this.props.traselectedEnterprise}
										name=''
										isMulti={false}
										placeholder=""
										isDisabled={this.props.roleId!=""?true:false}
										isSearchable={true}
									//defaultMenuIsOpen={true}
									/>
									<div className="col-md-12 errorClass error_div">{this.props.traselectedEnterpriseError}</div>
								</div>
							</div>
						</div>
					</div>
					<div className="container collapse-customize">
						{this.props.model ?
							<Survey.Survey
								model={this.props.model}
								onComplete={this.onCompleteRolePermissions}
								onCompleting={this.props.onCompletingRolePermissions}
								onValueChanged={this.props.onValueChanged}
								showCompletedPage={false}
							/>
							: null}
					</div>
				</div>
			</>
		);
	}
}

AddRoleModalContent.propTypes = {

}

const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.LoginReducer.userCredentials
	};
}

export default withRouter(connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(AddRoleModalContent)));