export const roleAddApi = (roleData) => {
    return roleData.data
}

export const enterpriseGet = (enterpriseData) => {
    let enterpriseDataTemp = enterpriseData.data
    let response = {}
    response["success"] = enterpriseDataTemp.success
    response["total"] = enterpriseDataTemp.total
    response["data"] = enterpriseDataTemp.data
    return response
}
export const permissionAttachGet = (permissionAttachData) => {
    let permissionAttachDataTemp = permissionAttachData.data
    let response = {}
    /*response["success"] = permissionAttachDataTemp.success
    response["total"] = permissionAttachDataTemp.data[0].total*/
    response["data"] = []
    if (permissionAttachDataTemp[0].RolesPermissions_data.length > 0) {
        response["data"] = permissionAttachDataTemp[0].RolesPermissions_data
    }
    return response
}
export const roleGetApi = (data) => {    
    return data.data;
}
export const rolePermissionApi = (data) => {    
    return data.data;
}
export const deleteroleApi = (data) => {    
    return data.data;
}
export const departmentListUseServayApi = (data) => {    
    return data.data;
}
export const roleDataRelationsApi = (data) => {    
    return data.data;
}
export const roleDataRelationsGetApi = (data) => {    
    return data.data;
}
export const getSurveyJsonGetApi = (data) => {    
    return data.data;
}
export const deleteRoleDataRelationApi = (data) => {    
    return data.data;
}
