import React from 'react';
import { get, post, put, del,patch } from '../../../Utility/Http';
import {roleAddApi } from '../Model/RoleModel';
import Config from '../../../Utility/Config';


//cal hr new project api

export const roleAdd = (data, type) => {
    if (type == "post") {
        return post(`${Config.extendedUrl}roles`, data).then((response) => {
            return roleAddApi(response)
        });
    }else if(type == "patch"){
        return patch(`${Config.extendedUrl}roles/${data.id}`, data).then((response) => {
            return roleAddApi(response)
        });
    }
};

