import RoleActionTypes from '../Utility/RoleActionTypes';
export default (state = { "userAttachOrg": ""}, action) => {
    switch (action.type) {
        case RoleActionTypes.USER_ATTACH_ORG:
            return { ...state, "userAttachOrg": action.payload };
        default:
            return state;
    }
};
