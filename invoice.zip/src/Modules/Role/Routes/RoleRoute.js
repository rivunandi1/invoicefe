import React, { Component } from 'react';
import { createHashHistory } from 'history';
import { Switch } from "react-router-dom";
import { Route } from "react-router-dom";
import Default from "../../../Layouts/Default";
import Auth from "../../../Layouts/Auth";
import RolePage from '../Pages/RolePage';


class RoleRoute extends Component {
  render() {
    const history = createHashHistory();
    const { allowedRoles } = this.props;
    return (

      <Switch>

        {/*****************Role****************/}
        <Route
          exact
          path="/:lng/role"
          render={() => (
            <Auth history={history} allowedRoles={allowedRoles}>
              <RolePage history={history} location={location} />
            </Auth>
          )}
        />
        {/*****************Role****************/}

      </Switch>
    );
  }
}
export default RoleRoute;
