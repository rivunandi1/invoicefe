import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../../Login/Actions/LoginAction';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import '../../Role/Assets/css/roledoc.scss';
import '../../Role/Assets/css/roleresponsivedoc.scss';
import { Tabs, Tab } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Roles from '../Components/Roles/Roles';

class RolePage extends Component {
	constructor(props) {
		super(props);
		this.state = {
			roleSelectedTabName: "roles"
		}
	}

	componentDidMount() {
		this.props.handleActiveLink("role_module", "");
		this.permissionWiseTabSelected()
	}

	roleHandelSelectTab = (tabName) => {
		this.setState({
			roleSelectedTabName: tabName
		})
	}

	permissionWiseTabSelected = () => {
		const { roleWisePermission } = this.props;
		if (Object.keys(roleWisePermission) && Object.keys(roleWisePermission).length > 0) {
			let tab_order = ["roles", "leave", "codes", "interims", "roledocuments"];
			//let first_tab = Object.keys(roleWisePermission).filter((x) => tab_order.includes(x))[0];
			let first_tab = tab_order.filter((x) => Object.keys(roleWisePermission).includes(x))[0];
			this.setState({
				roleSelectedTabName: first_tab
			})
		}
	}
	validationPermission = (eventKey) => {
		const { t, roleWisePermission } = this.props;
		let valid = false;
		if (roleWisePermission && roleWisePermission.hasOwnProperty(eventKey) && roleWisePermission[eventKey].read_write_permission != "") {
			valid = true;
		}
		return valid
	}



	tabUi = () => {
		const { t } = this.props;
		let arry = []

		if (this.validationPermission('roles')) {
			arry.push(
				<Tab eventKey="roles" title={t('roles')} key={0}>
					{this.state.roleSelectedTabName == 'roles' ?
						<Roles />
						: null}
				</Tab>
			)
		}
		
		return arry;
	}

	render() {
		const { t } = this.props;
		return (
			<div className="homepagecontainer connectheader">
				<Tabs
					id="roletabs"
					activeKey={this.state.roleSelectedTabName}
					className="tabsmainbox"
					onSelect={this.roleHandelSelectTab}
				>
					{this.tabUi()}
				</Tabs>
			</div>
		);
	}
}




const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.mainReducerData.userCredentials,
		token: globalState.mainReducerData.token,
		access_token: globalState.mainReducerData.access_token,
		roleWisePermission: globalState.mainReducerData.roleWisePermission
	};
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
	(withTranslation()(RolePage)));