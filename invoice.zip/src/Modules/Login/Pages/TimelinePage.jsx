import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loaderStateTrue, loaderStateFalse, handleActiveLink } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../Actions/LoginAction';

import { withRouter } from 'react-router';
import { useTranslation, withTranslation, Trans } from 'react-i18next';
import Timeline from 'react-calendar-timeline'
// make sure you include the timeline stylesheet or the timeline will not be styled
import 'react-calendar-timeline/lib/Timeline.css'
import moment from 'moment'


class TimelinePage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            groups: [{ id: 1, title: 'group 1' }, { id: 2, title: 'group 2' }],

            items: [
                {
                    id: 1,
                    group: 1,
                    title: 'item 1',
                    start_time: moment(),
                    end_time: moment().add(1, 'hour')
                },
                {
                    id: 2,
                    group: 2,
                    title: 'item 2',
                    start_time: moment().add(-0.5, 'hour'),
                    end_time: moment().add(0.5, 'hour')
                },
                {
                    id: 3,
                    group: 1,
                    title: 'item 3',
                    start_time: moment().add(2, 'hour'),
                    end_time: moment().add(3, 'hour')
                }
            ]
        }
    }



    render() {
        const { t } = this.props;
        return (
            <div className="homepagecontainer connectheader">
                <Timeline
                    groups={this.state.groups}
                    items={this.state.items}
                    defaultTimeStart={moment().add(-12, 'hour')}
                    defaultTimeEnd={moment().add(12, 'hour')}
                />
            </div>
        );
    }
}




const mapStateToProps = (globalState) => {
    return {
        userCredentials: globalState.mainReducerData.userCredentials,
        token: globalState.mainReducerData.token,
        access_token: globalState.mainReducerData.access_token
    };
}


export default withRouter(connect(mapStateToProps, { handleActiveLink, loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp })
    (withTranslation()(TimelinePage)));