import React, { useState, useEffect, useRef } from 'react';
import Button from 'react-bootstrap/Button';
import { connect } from 'react-redux';
import Utility from '../../../Utility/Utility';
import { loaderStateTrue, loaderStateFalse, roleWisePermission } from '../../../Actions/AllAction';
import { setToken, setUserCredentials, logOutApp } from '../Actions/LoginAction';
import { Modal } from 'react-bootstrap';
import CommonLogin from '../Components/CommonLogin';
import * as LoginController from '../Controller/LoginController';
import '../Assets/css/logindoc.scss';
import '../Assets/css/loginresponsivedoc.scss';
import LoginUtility from '../Utility/LoginUtility'
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import ModalGlobal from '../../../Utility/Components/ModalGlobal';
import ConfirmationAlert from '../../../Utility/Components/ConfirmationAlert';
//import { useTranslation } from "react-i18next";
import { useTranslation, withTranslation, Trans } from 'react-i18next';

const LoginPage = (props) => {
	const [email,setemail]=useState("")
	const [password,setpassword]=useState("")
	const [updated_password,setupdated_password]=useState("")
	const [updated_confirm_password,setupdated_confirm_password]=useState("")

	const [state, setState] = useState({
		//email: "",
		//password: "",
		//updated_password: "",
		//updated_confirm_password: "",
		emailError: "",
		passwordError: "",
		updated_passwordError: "",
		updated_comfirm_passwordError: "",
		passwordLock: false,
		confirmPasswordLock: false,
		passtype: "password",
		confirmPasstype: "password",
		loginCredentials: {},
		//modal
		modalShow: false,
		updatedPasswordSession: "",
		challangeName: "",
		userName: "",

		// Focus
		emailFocus: false,
		passwordFocus: false,

		// Language change
		langaugeConfirmModal: false,
		selectedLangauge: "",

	})
	//Check multi language
	const { t, i18n } = useTranslation();
	const changeLanguage = (lng) => {
		i18n.changeLanguage(lng);
		props.history.push(`/${lng}/login`);
	};
	//Check multi language


	const { loaderStateTrue, loaderStateFalse, history, logOutApp, setToken, setUserCredentials, roleWisePermission } = props;

	const handleonFocus = (event) => {
		if (event.target.name == "email") {
			setState(prev => ({
				...prev,
				emailFocus: true
			}))
		}

		if (event.target.name == "password") {
			setState(prev => ({
				...prev,
				passwordFocus: true
			}))
		}

	}
	const handleonBlur = (event) => {
		setState(prev => ({
			...prev,
			emailFocus: false,
			passwordFocus: false
		}))
	}

	const handleChange = (event) => {
		if (event.target.name == "email") {
			if (event.target.value == "") {				
				setState(prev => ({
					...prev,
					emailError: `${t('emailError')}`
				}))
				setemail(event.target.value)
			} else {
				setState(prev => ({
					...prev,
					emailError: "",
					//email:event.target.value
				}))
				setemail(event.target.value)
			}
		}
		if (event.target.name == "password") {
			if (event.target.value == "") {
				setState(prev => ({
					...prev,
					passwordError: `${t('passwordError')}`
				}))
				setpassword(event.target.value)

			} else {
				setState(prev => ({
					...prev,
					passwordError: "",
					//password:event.target.value
				}))
				setpassword(event.target.value)
			}

		}
		if (event.target.name == "updated_password") {
			setState(prev => ({
				...prev,
				updated_passwordError: ""
			}))

			setupdated_password(event.target.value)
		}
		if (event.target.name == "updated_confirm_password") {
			setState(prev => ({
				...prev,
				updated_comfirm_passwordError: ""
			}))
			setupdated_confirm_password(event.target.value)
		}
		/*setState(prev => ({
			...prev,
			[event.target.name]: event.target.value
		}))*/
	}

	const validation = () => {
		let valid = true;	

		if (email == "" ) {
			valid = false;
			setState(prev=>({
				...prev,
				emailError: `${t('emailError')}`
			}))
		} else {
			/*var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
			if (!expr.test(email)) {
				setState(prev=>({
					...prev,
					emailError: `${t('validEmail')}`
				}))
				valid = false;
			} else {
				
			}*/

			setState({
				emailError: ""
			})
			
		}

		if (state.password == "") {
			valid = false;
			setState(prev => ({
				...prev,
				passwordError: `${t('passwordError')}`
			}))
		} else {
			setState(prev => ({
				...prev,
				passwordError: ""
			}))
		}
		return valid;
	}


	

	const forgotPassword = () => {
		props.history.push(`/${localStorage.getItem('i18nextLng')}/forgot_password`);
	}

	const login = () => {

		//alert();

		let valid = validation();
		//const { email, password, phonenumber } = state;

		if (valid) {
			loaderStateTrue();
			let data = {}
			data["username"] = email
			//data["phone_number"] = phonenumber
			data["password"] = password
			LoginController.loginGetApi(data).then((response) => {
				loaderStateFalse();
				//return false;
				if (response) {
					if (response.success) {
						//new password set
						if (response.data.challengeName == "NEW_PASSWORD_REQUIRED") {
							setState(prev => ({
								...prev,
								modalShow: true,
								updatedPasswordSession: response.data.session,
								challangeName: response.data.challengeName,
								userName: response.data.username
							}))
						} else {
							loginSuccess(response);
						}
					} else {
						if (response.message == "User does not exist.") {
							setState(prev => ({
								...prev,
								passwordError: `${t('wrongEmailPassword')}`
							}))

						} else {
							setState(prev => ({
								...prev,
								passwordError: response.message,
								passtype: "password",
							}))
						}

					}
				}
			}).catch((error) => {
				loaderStateFalse();

			});
		}

	}

	useEffect(() => {
		if (state.loginCredentials && Object.keys(state.loginCredentials).length > 0) {
			setUserCredentialsData();
		}
	}, [state.loginCredentials]);

	const loginSuccess = (response) => {
		const finalIdToken = response.data.tokenType + ' ' + response.data.idToken;
		const accessToken = response.data.accessToken
		const refreshToken = response.data.refreshToken
		const expiresIn = LoginUtility.getExpiryDetails(response.data.expiresIn)
		setToken(finalIdToken, accessToken, expiresIn, refreshToken).then(() => {
			loaderStateTrue();
			LoginController.getCurrentUser().then((userResponse) => {
				loaderStateFalse();
				if (userResponse.success) {
					setState(prev => ({
						...prev,
						loginCredentials: userResponse.data
					}))
				} else {
					logOutApp().then(
						() => history.push("/")
					);
					Utility.toastNotifications(userResponse.message, "Error", "error")
				}
			})
		})
	}

	const setUserCredentialsData = async () => {
		const { loginCredentials } = state
		setUserCredentials(loginCredentials).then(() => {
			rolePermission(loginCredentials.user_details.role_id);
		})
	}

	const rolePermission = (role_id) => {
		let data = [{ "resource_name": "RolesPermissions", "columns": ["id", "role_id", "eventKey", "read_write_permission", "is_enabled"], "column_filters": [{ "is_enabled": 1, "role_id": role_id }] }]
		let filter = {}
		filter['filters'] = JSON.stringify(data);
		LoginController.rolePermissionGetApi(filter).then((response) => {

			//console.log("response.data===",response.data)

			if (response.data.length > 0) {
				let permissionHash = {};
				response.data[0].RolesPermissions_data.map((value) => {
					permissionHash[value.eventKey] = value
				})
				roleWisePermission(permissionHash).then(() => {	
					const { loginCredentials } = state
					//console.log("loginCredentials",loginCredentials)
					/*let permission = ['app_admin','admin']				
					if(permission.includes(loginCredentials.user_details.role_name)){
						props.history.push(`/${localStorage.getItem('i18nextLng')}/dashboard`);
					}else{
						props.history.push(`/${localStorage.getItem('i18nextLng')}/userdashboard`);
					}*/

					props.history.push(`/${localStorage.getItem('i18nextLng')}/userdashboard`);
					

				});
			}

		}).catch((error) => {
			Utility.toastNotifications(error.message, "Error", "error")
			logOutApp().then(
				() => history.push("/")
			);
		});
	}




	const showText = () => {
		setState(prev => ({
			...prev,
			passwordLock: true,
			passtype: "text"
		}))
	}

	const showPassword = () => {
		setState(prev => ({
			...prev,
			passwordLock: false,
			passtype: "password"
		}))
	}

	const showUpdateConfirmText = () => {
		setState(prev => ({
			...prev,
			confirmPasswordLock: true,
			confirmPasstype: "text"
		}))
	}

	const showUpdateConfirmPassword = () => {
		setState(prev => ({
			...prev,
			confirmPasswordLock: false,
			confirmPasstype: "password"
		}))
	}

	const handleClose = () => {
		loaderStateFalse();
		setState(prev => ({
			...prev,
			modalShow: false,
			updated_password: "",
			updated_confirm_password: ""
		}))
	}

	const updatePassword = () => {
		const { updated_confirm_password, userName, updatedPasswordSession, challangeName } = state;
		let valid = updatePasswordCheck();
		//console.log("updatedPasswordSession", updatedPasswordSession)
		if (valid) {
			loaderStateTrue();
			let header = {};
			header["session"] = updatedPasswordSession;
			let data = {
				"username": userName,
				"password": updated_password,
				//session:session,
				"challengeName": challangeName
			}
			LoginController.forcePasswordChange(data, header).then((response) => {
				if (response) {

					if (response.success) {
						handleClose();

						Utility.toastNotifications(response.message, "Success", "success")
						const finalIdToken = response.data.tokenType + ' ' + response.data.idToken;
						const accessToken = response.data.accessToken
						const refreshToken = response.data.refreshToken
						const expiresIn = LoginUtility.getExpiryDetails(response.data.expiresIn)
						setToken(finalIdToken, accessToken, expiresIn, refreshToken).then(() => {
							logOutApp().then(
								() => history.push("/")
							);
						})

					} else {
						loaderStateFalse();
					}
				}
			}).catch((error) => {
				//Utility.toastNotifications(error.message, "Error", "error")
				logOutApp().then(
					() => history.push("/")
				);
			});
		}
	}

	const updatePasswordCheck = () => {
		let valid = true;
		//const { updated_password, updated_confirm_password } = state;

		let passwordValidate = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-+“!@#%&/,><\’:;|_~`])\S{6,99}$/.test(updated_password);
		if (passwordValidate) {
			setState(prev => ({
				...prev,
				updated_passwordError: ''
			}))
		} else {
			valid = false;
			setState(prev => ({
				...prev,
				updated_passwordError: t('thisFieldIsInvalid')
			}))
			Utility.toastNotifications(`<ul class='password-inner-box'>
            <li><b>${t('minimumLength')}</b>, ${t('mustBeAtLeast6Characters')}</li>
            <li><b>${t('requireNumbers')}</b></li>
            <li><b>${t('requireSpecialCharacter')}</b> ${t('fromThisSet')}: = + - ^ $ * . [ ] { } ( ) ?  ! @ # % & / \ , > < ' : ; | _ ~ </li>
            <li><b>${t('requireUppercaseLetters')}</b></li>
            <li><b>${t('requireLowercaseLetters')}</b></li>
          </ul>`, `${t('passworderror')}`, "longError");
		}


		let CpasswordValidate = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.\[\]{}\(\)?\-+“!@#%&/,><\’:;|_~`])\S{6,99}$/.test(updated_confirm_password);

		if (CpasswordValidate) {
			setState(prev => ({
				...prev,
				updated_comfirm_passwordError: ''
			}))
		} else {
			valid = false;
			setState(prev => ({
				...prev,
				updated_comfirm_passwordError: t('thisFieldIsInvalid')
			}))
			Utility.toastNotifications(`<ul class='password-inner-box'>
            <li><b>${t('minimumLength')}</b>, ${t('mustBeAtLeast6Characters')}</li>
            <li><b>${t('requireNumbers')}</b></li>
            <li><b>${t('requireSpecialCharacter')}</b> ${t('fromThisSet')}: = + - ^ $ * . [ ] { } ( ) ?  ! @ # % & / \ , > < ' : ; | _ ~ </li>
            <li><b>${t('requireUppercaseLetters')}</b></li>
            <li><b>${t('requireLowercaseLetters')}</b></li>
          </ul>`, `${t('confirmPasswordError')}`, "longError");
		}

		if (updated_password == updated_confirm_password && updated_password != "" && updated_confirm_password != "") {
			setState(prev => ({
				...prev,
				updated_passwordError: '',
				updated_comfirm_passwordError: ''
			}))
		} else {
			valid = false;
			Utility.toastNotifications(t('passwordAndConfirmPasswordNotMatch'), "Error", "error");
		}

		return valid;

	}

	const lanOnSelect = (lng) => {

		setState(prev => ({
			...prev,
			langaugeConfirmModal: true,
			selectedLangauge: lng
		}))

		// let confirmation = false;
		// confirmation = window.confirm(`${t('areYouSureYouWantToReload')}`);
		// if (confirmation) {
		// 	i18n.changeLanguage(lng);
		// 	let splitUrl = props.match.url.split('/');
		// 	props.history.push(`/${lng}/${splitUrl[2]}`);
		// 	window.location.reload();
		// }

	}

	const confirmLangaugeChange = () => {
		const{selectedLangauge}= state;

		i18n.changeLanguage(selectedLangauge);
		let splitUrl = props.match.url.split('/');
		props.history.push(`/${selectedLangauge}/${splitUrl[2]}`);
		window.location.reload();
		setState(prev => ({
			...prev,
			langaugeConfirmModal: false,
		}))
	
	}

	const cancelLangaugeChange= () =>{
		setState(prev => ({
			...prev,
			langaugeConfirmModal: false,
		}))
	}


	return (
		<div className="appContainer" id="login_container">


			<CommonLogin
				handleChange={handleChange}
				email={email}
				password={password}
				emailError={state.emailError}
				passwordError={state.passwordError}
				passtype={state.passtype}
				//passwordLock={state.passwordLock}
				//showText={showText}
				//showPassword={showPassword}
				login={login}
				forgotPassword={forgotPassword}

				handleonFocus={handleonFocus}
				handleonBlur={handleonBlur}
				emailFocus={state.emailFocus}
				passwordFocus={state.passwordFocus}

				passPlaceholder={t('passPlaceholder')}
				forgotTitle={t('forgot_password_text')}
				submitTitle={t('loginButton')}
				user_name={t('user_name')}
				lanOnSelect={lanOnSelect}
			/>

			<Modal
				show={state.modalShow}
				onHide={handleClose}
				//backdrop="static"
				//keyboard={false}
				className="forcePasswordChange"
			>
				<Modal.Header closeButton>
					<Modal.Title>{t('ChangePasswordButton')}</Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<div className="passwordRow">
						<input type="password" onChange={handleChange} name="updated_password" value={updated_password} placeholder={t('updatepassword')} className="input__fields_property" />
						<div className="col-md-12 errorClass error_div">{state.updated_passwordError}</div>
					</div>
					<div className="passwordRow">
						<input type="password" onChange={handleChange} name="updated_confirm_password" value={updated_confirm_password} placeholder={t('updateconfirmpass')} className="input__fields_property" />
						<div className="col-md-12 errorClass error_div">{state.updated_comfirm_passwordError}</div>
					</div>
				</Modal.Body>
				<Modal.Footer>
					<Button variant="primary" onClick={updatePassword} className="update_btn">{t('submit')}</Button>
				</Modal.Footer>
			</Modal>

			<ModalGlobal
				show={state.langaugeConfirmModal}
				onHide={cancelLangaugeChange}
				className="modalcustomize confirmationalertmodal"
				bodyClassName="cancelConfirmationbody"
				headerclassName="close_btn_icon"
				title={t('languagechange')}
				footer={false}
				body={
				<ConfirmationAlert
				BodyFirstContent={t('areYouSureYouWantToReload')}
				confirmationButtonContent={t('confirm')}
				deleteConfirmButton={confirmLangaugeChange}
				cancelButtonContent={t('cancel')}
				deleteCancleButton={cancelLangaugeChange}
				/>
				}
			/>

		</div>
	);
}

CommonLogin.propTypes = {
	handleChange: PropTypes.func,
	email: PropTypes.string,
	password: PropTypes.string,
	emailError: PropTypes.string,
	passwordError: PropTypes.string,
	passtype: PropTypes.string,
	passwordLock: PropTypes.bool,
	showText: PropTypes.func,
	showPassword: PropTypes.func,
	login: PropTypes.func,
	forgotPassword: PropTypes.func,
	backgroundImageUrl: PropTypes.string
}


const mapStateToProps = (globalState) => {
	return {
		userCredentials: globalState.LoginReducer.userCredentials
	};
}

export default connect(mapStateToProps, { loaderStateTrue, loaderStateFalse, setToken, setUserCredentials, logOutApp, roleWisePermission })(withRouter(LoginPage));


