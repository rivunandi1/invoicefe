import React, { useState, useEffect, useRef } from 'react';
import '../Assets/css/logindoc.scss';
import '../Assets/css/loginresponsivedoc.scss';
import { withRouter } from 'react-router';

const AppLandingPage = (props) => {
	const [state, setState] = useState({		

	})
	const setLanguage = () => {
        props.history.push('/en/login');		
	}
	useEffect(() => {		
		setLanguage();
	}, [state.loginCredentials]);

	return (
		<></>
	);
}


export default (withRouter(AppLandingPage));


