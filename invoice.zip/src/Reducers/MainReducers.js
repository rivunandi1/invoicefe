import AllActionTypes from '../Utility/AllActionTypes';

export default (state = { "loaderState": false, "leftbar": false, "activeLink": { 'accName': "", 'activeClass': "" },roleWisePermission:{} }, action) => {
    switch (action.type) {
        case AllActionTypes.LOADER_STATE_TRUE:
            return { ...state, "loaderState": action.payload };
        case AllActionTypes.LOADER_STATE_FALSE:
            return { ...state, "loaderState": action.payload };
        case AllActionTypes.HANDLE_LEFT:
            return { ...state, "leftbar": action.payload };
        case AllActionTypes.ACTIVE_LINK:
            return { ...state, "activeLink": action.payload };
        case AllActionTypes.ROLE_PERMISSION:
            return { ...state, "roleWisePermission": action.payload };
       
		case AllActionTypes.CLEAR_DATA:
            return action.payload;					  
        default:
            return state;
    }
};
