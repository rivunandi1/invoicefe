import { combineReducers } from 'redux';
import mainReducerData from './MainReducers';
import LoginReducer from '../Modules/Login/Reducers/LoginReducer';
export default combineReducers({
    mainReducerData,
    LoginReducer
})